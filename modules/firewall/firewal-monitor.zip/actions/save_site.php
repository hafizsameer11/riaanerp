<?php
require_once __DIR__ . '/../includes/auth.php';
requireAuth();
require_once __DIR__ . '/../includes/functions.php';

$id = $_POST['id'] ?? null;

$fields = [
    'name','location','primary_ip','secondary_ip','ssh_username',
    'description','login_url','login_username',
    'ping_count','ping_interval_sec','failover_command',
    'failback_command','reboot_command'
];

$data = [];
foreach ($fields as $f) { $data[$f] = $_POST[$f] ?? null; }

$monitoring = isset($_POST['monitoring_enabled']) ? 1 : 0;

$sshPass = $_POST['ssh_password'] ?? null;
$loginPass = $_POST['login_password'] ?? null;

if ($id) {
    $stmt = db()->prepare("SELECT * FROM sites WHERE id=?");
    $stmt->execute([$id]);
    $old = $stmt->fetch();

    $sql = "UPDATE sites SET ";
    $params = [];

    foreach ($fields as $f) {
        $sql .= "$f=:$f, ";
        $params[$f] = $data[$f];
    }

    if ($sshPass) {
        $sql .= "ssh_password_enc=:sshpass, ";
        $params['sshpass'] = enc($sshPass);
    }
    if ($loginPass) {
        $sql .= "login_password_enc=:loginpass, ";
        $params['loginpass'] = enc($loginPass);
    }

    $sql .= "monitoring_enabled=:m WHERE id=:id";
    $params['m'] = $monitoring;
    $params['id'] = $id;

    $stmt = db()->prepare($sql);
    $stmt->execute($params);

} else {
    $stmt = db()->prepare("
        INSERT INTO sites
        (name,location,primary_ip,secondary_ip,ssh_username,ssh_password_enc,
        description,login_url,login_username,login_password_enc,
        ping_count,ping_interval_sec,monitoring_enabled,
        failover_command,failback_command,reboot_command)
        VALUES
        (:name,:location,:primary_ip,:secondary_ip,:ssh_user,:ssh_pass,
        :descr,:login_url,:login_user,:login_pass,
        :pingc,:pingi,:mon,
        :fo,:fb,:rb)
    ");

    $stmt->execute([
        'name'=>$data['name'],
        'location'=>$data['location'],
        'primary_ip'=>$data['primary_ip'],
        'secondary_ip'=>$data['secondary_ip'],
        'ssh_user'=>$data['ssh_username'],
        'ssh_pass'=>enc($sshPass),
        'descr'=>$data['description'],
        'login_url'=>$data['login_url'],
        'login_user'=>$data['login_username'],
        'login_pass'=>enc($loginPass),
        'pingc'=>$data['ping_count'],
        'pingi'=>$data['ping_interval_sec'],
        'mon'=>$monitoring,
        'fo'=>$data['failover_command'],
        'fb'=>$data['failback_command'],
        'rb'=>$data['reboot_command']
    ]);
}

header("Location: ../pages/index.php");
exit;


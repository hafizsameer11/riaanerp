<?php
// Enable error reporting for debugging (remove in production)
error_reporting(E_ALL);
ini_set('display_errors', 0); // Don't display, but log
ini_set('log_errors', 1);

require_once __DIR__ . '/../includes/auth.php';
requireAuth();
require_once __DIR__ . '/../includes/functions.php';

$siteId = $_POST['site_id'] ?? null;
$action = $_POST['action'] ?? null;

// Debug: Check if we're receiving the data
if (!$siteId || !$action) {
    $_SESSION['error'] = "Missing site_id or action. Received: site_id=" . ($siteId ?? 'null') . ", action=" . ($action ?? 'null');
    header("Location: ../pages/index.php");
    exit;
}

$stmt = db()->prepare("SELECT * FROM sites WHERE id=?");
$stmt->execute([$siteId]);
$site = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$site) {
    $_SESSION['error'] = "Site not found with ID: " . $siteId;
    header("Location: ../pages/index.php");
    exit;
}

$before = $site['status'];
$after = $before;
$output = "";
$sshSuccess = null;
$commandExecuted = null;

$sshUser = $site['ssh_username'];
$sshPass = dec($site['ssh_password_enc']);
$targetIp = $site['secondary_ip'];

if ($action === "failover") {
    $cmd = $site['failover_command'] ?? '';
    if (empty($cmd)) {
        $_SESSION['error'] = "Failover command not configured for site: " . $site['name'];
        header("Location: ../pages/index.php");
        exit;
    }
    $commandExecuted = $cmd;
    $res = runSshCommand($targetIp, $sshUser, $sshPass, $cmd);
    $output = $res['output'];
    $sshSuccess = $res['ok'] ? 1 : 0;
    if ($res['ok']) {
        $after = "DOWN";
        $output = "✅ SSH Command Executed Successfully\n" . $output;
    } else {
        $output = "❌ SSH Command Failed\n" . $output;
    }
} elseif ($action === "failback") {
    $cmd = $site['failback_command'] ?? '';
    if (empty($cmd)) {
        $_SESSION['error'] = "Failback command not configured for site: " . $site['name'];
        header("Location: ../pages/index.php");
        exit;
    }
    $commandExecuted = $cmd;
    $res = runSshCommand($targetIp, $sshUser, $sshPass, $cmd);
    $output = $res['output'];
    $sshSuccess = $res['ok'] ? 1 : 0;
    if ($res['ok']) {
        $after = "UP";
        $output = "✅ SSH Command Executed Successfully\n" . $output;
    } else {
        $output = "❌ SSH Command Failed\n" . $output;
    }
} elseif ($action === "reboot") {
    $cmd = $site['reboot_command'] ?? '';
    if (empty($cmd)) {
        $_SESSION['error'] = "Reboot command not configured for site: " . $site['name'];
        header("Location: ../pages/index.php");
        exit;
    }
    $commandExecuted = $cmd;
    $res = runSshCommand($targetIp, $sshUser, $sshPass, $cmd);
    $output = $res['output'];
    $sshSuccess = $res['ok'] ? 1 : 0;
    if ($res['ok']) {
        $output = "✅ SSH Command Executed Successfully\n" . $output;
    } else {
        $output = "❌ SSH Command Failed\n" . $output;
    }
} elseif ($action === "stop") {
    $stmt = db()->prepare("UPDATE sites SET monitoring_enabled=0 WHERE id=?");
    $stmt->execute([$siteId]);
    $output = "Monitoring stopped for site: " . $site['name'];
} elseif ($action === "start") {
    $stmt = db()->prepare("UPDATE sites SET monitoring_enabled=1 WHERE id=?");
    $stmt->execute([$siteId]);
    $output = "Monitoring started for site: " . $site['name'];
}

if ($after !== $before) {
    $stmt = db()->prepare("UPDATE sites SET status=? WHERE id=?");
    $stmt->execute([$after, $siteId]);
}

logAction($siteId, $action, "user", $before, $after, $output, $sshSuccess, $commandExecuted);

sendNotificationEmail(getEmails(), "Manual Action: $action - " . $site['name'], $output);

// Set success message
if ($sshSuccess === 1) {
    $_SESSION['success'] = "Action '$action' executed successfully for " . $site['name'];
} elseif ($sshSuccess === 0) {
    $_SESSION['error'] = "Action '$action' failed for " . $site['name'] . ": " . substr($output, 0, 100);
} else {
    $_SESSION['success'] = "Action '$action' completed for " . $site['name'];
}

header("Location: ../pages/index.php");
exit;


<?php
require_once __DIR__ . '/../includes/auth.php';
requireAuth();
require_once __DIR__ . '/../includes/functions.php';
$email = $_POST['email'] ?? null;
if ($email) {
    $stmt = db()->prepare("INSERT INTO notification_emails (email) VALUES (?)");
    $stmt->execute([$email]);
}
header("Location: ../pages/manage_emails.php");


<?php
require_once __DIR__ . '/../includes/auth.php';
requireAuth();
require_once __DIR__ . '/../includes/functions.php';

$id = $_GET['id'] ?? null;
$site = null;
if ($id) {
    $stmt = db()->prepare("SELECT * FROM sites WHERE id=?");
    $stmt->execute([$id]);
    $site = $stmt->fetch(PDO::FETCH_ASSOC);
}
function val($f){ global $site; return $site[$f] ?? ''; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?=$id?'Edit':'Add'?> Site - Firewall Monitor</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px 0;
        }
        .section-divider {
            border-top: 2px solid #e5e7eb;
            margin: 2rem 0;
            padding-top: 2rem;
        }
        .section-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: #1f2937;
            margin-bottom: 1.5rem;
            padding-bottom: 0.5rem;
            border-bottom: 2px solid #e5e7eb;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card shadow-lg mb-4">
            <div class="card-body p-4">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h1 class="h3 mb-0">
                        <i class="bi bi-<?=$id?'pencil-square':'plus-circle'?>"></i> <?=$id?'Edit':'Add'?> Site
                    </h1>
                    <div>
                        <a href="index.php" class="btn btn-outline-secondary">
                            <i class="bi bi-arrow-left"></i> Back to Dashboard
                        </a>
                        <a href="../actions/logout.php" class="btn btn-outline-danger">
                            <i class="bi bi-box-arrow-right"></i> Logout
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="card shadow-lg">
            <div class="card-body p-4">
                <form method="post" action="../actions/save_site.php">
                    <input type="hidden" name="id" value="<?=$id?>">

                    <div class="section-title">
                        <i class="bi bi-info-circle"></i> Basic Information
                    </div>
                    
                    <div class="mb-3">
                        <label for="name" class="form-label fw-bold">Site Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="name" name="name" value="<?=htmlspecialchars(val('name'))?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="location" class="form-label fw-bold">Location</label>
                        <input type="text" class="form-control" id="location" name="location" value="<?=htmlspecialchars(val('location'))?>" placeholder="e.g., Data Center A">
                    </div>

                    <div class="mb-3">
                        <label for="description" class="form-label fw-bold">Description</label>
                        <textarea class="form-control" id="description" name="description" rows="3" placeholder="Site description or notes"><?=htmlspecialchars(val('description'))?></textarea>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="primary_ip" class="form-label fw-bold">Primary IP Address <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="primary_ip" name="primary_ip" value="<?=htmlspecialchars(val('primary_ip'))?>" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="secondary_ip" class="form-label fw-bold">Secondary IP Address <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="secondary_ip" name="secondary_ip" value="<?=htmlspecialchars(val('secondary_ip'))?>" required>
                        </div>
                    </div>

                    <div class="section-divider">
                        <div class="section-title">
                            <i class="bi bi-terminal"></i> SSH Configuration
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="ssh_username" class="form-label fw-bold">SSH Username <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="ssh_username" name="ssh_username" value="<?=htmlspecialchars(val('ssh_username'))?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="ssh_password" class="form-label fw-bold">SSH Password <?=$id?'<small class="text-muted">(leave blank to keep current)</small>':'<span class="text-danger">*</span>'?></label>
                                <input type="password" class="form-control" id="ssh_password" name="ssh_password" <?=$id?'':'required'?>>
                            </div>
                        </div>
                    </div>

                    <div class="section-divider">
                        <div class="section-title">
                            <i class="bi bi-globe"></i> Web Login (Optional)
                        </div>

                        <div class="mb-3">
                            <label for="login_url" class="form-label fw-bold">Login URL</label>
                            <input type="url" class="form-control" id="login_url" name="login_url" value="<?=htmlspecialchars(val('login_url'))?>" placeholder="https://example.com/login">
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="login_username" class="form-label fw-bold">Login Username</label>
                                <input type="text" class="form-control" id="login_username" name="login_username" value="<?=htmlspecialchars(val('login_username'))?>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="login_password" class="form-label fw-bold">Login Password <?=$id?'<small class="text-muted">(leave blank to keep current)</small>':''?></label>
                                <input type="password" class="form-control" id="login_password" name="login_password">
                            </div>
                        </div>
                    </div>

                    <div class="section-divider">
                        <div class="section-title">
                            <i class="bi bi-activity"></i> Monitoring Settings
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="ping_count" class="form-label fw-bold">Ping Count <small class="text-muted">(per check)</small></label>
                                <input type="number" class="form-control" id="ping_count" name="ping_count" value="<?=val('ping_count')?>" min="1" max="100" placeholder="<?=PING_DEFAULT_COUNT?>">
                                <small class="text-muted">
                                    Number of ping attempts per monitoring check. 
                                    <strong>Default: <?=PING_DEFAULT_COUNT?></strong> (leave empty to use default)
                                    <br>Example: 10 = ping 10 times, 20 = ping 20 times, 50 = ping 50 times
                                </small>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="ping_interval_sec" class="form-label fw-bold">Ping Interval (seconds)</label>
                                <input type="number" class="form-control" id="ping_interval_sec" name="ping_interval_sec" value="<?=val('ping_interval_sec')?>" min="1" max="60" placeholder="<?=PING_DEFAULT_INTERVAL_SEC?>">
                                <small class="text-muted">
                                    Seconds between each ping attempt. 
                                    <strong>Default: <?=PING_DEFAULT_INTERVAL_SEC?> seconds</strong> (leave empty to use default)
                                    <br>Example: 5 = wait 5 seconds between each ping
                                </small>
                            </div>
                        </div>
                        <?php 
                        $current_count = val('ping_count') ?: PING_DEFAULT_COUNT;
                        $current_interval = val('ping_interval_sec') ?: PING_DEFAULT_INTERVAL_SEC;
                        $total_time = ($current_count - 1) * $current_interval;
                        ?>
                        <div class="alert alert-info">
                            <i class="bi bi-info-circle"></i> <strong>How it works:</strong> 
                            The system will ping the primary IP <strong><?=$current_count?></strong> times, 
                            waiting <strong><?=$current_interval?></strong> seconds between each ping. 
                            Total monitoring time: approximately <strong><?=$total_time?></strong> seconds per check.
                            <br>If all pings fail, automatic failover is triggered.
                        </div>

                        <div class="mb-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="monitoring_enabled" name="monitoring_enabled" value="1" <?=($site['monitoring_enabled']??1)?'checked':''?>>
                                <label class="form-check-label fw-bold" for="monitoring_enabled">
                                    Enable Monitoring
                                </label>
                            </div>
                        </div>
                    </div>

                    <div class="section-divider">
                        <div class="section-title">
                            <i class="bi bi-code-slash"></i> SSH Commands
                        </div>

                        <div class="mb-3">
                            <label for="failover_command" class="form-label fw-bold">Failover Command <span class="text-danger">*</span></label>
                            <textarea class="form-control font-monospace" id="failover_command" name="failover_command" rows="3" required placeholder="Command to execute when primary IP fails"><?=htmlspecialchars(val('failover_command'))?></textarea>
                        </div>

                        <div class="mb-3">
                            <label for="failback_command" class="form-label fw-bold">Failback Command <span class="text-danger">*</span></label>
                            <textarea class="form-control font-monospace" id="failback_command" name="failback_command" rows="3" required placeholder="Command to execute when restoring primary IP"><?=htmlspecialchars(val('failback_command'))?></textarea>
                        </div>

                        <div class="mb-3">
                            <label for="reboot_command" class="form-label fw-bold">Reboot Command <span class="text-danger">*</span></label>
                            <textarea class="form-control font-monospace" id="reboot_command" name="reboot_command" rows="3" required placeholder="Command to reboot the firewall"><?=htmlspecialchars(val('reboot_command'))?></textarea>
                        </div>
                    </div>

                    <div class="d-flex gap-2 mt-4 pt-4 border-top">
                        <button type="submit" class="btn btn-primary btn-lg">
                            <i class="bi bi-save"></i> Save Site
                        </button>
                        <a href="index.php" class="btn btn-secondary btn-lg">
                            <i class="bi bi-x-circle"></i> Cancel
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>


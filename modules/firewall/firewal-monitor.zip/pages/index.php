<?php
require_once __DIR__ . '/../includes/auth.php';
requireAuth();
require_once __DIR__ . '/../includes/functions.php';

$status = $_GET['status'] ?? null;
$search = $_GET['search'] ?? null;

$sites = getSites($status, $search);

function statusColor($s) {
    return [
        'UP'       => '#10b981',
        'DEGRADED' => '#f59e0b',
        'DOWN'     => '#ef4444',
        'UNKNOWN'  => '#6b7280'
    ][$s] ?? '#6b7280';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Firewall Monitor Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px 0;
        }
        .status-dot {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 8px;
        }
        .table-hover tbody tr:hover {
            background-color: rgba(102, 126, 234, 0.05);
        }
        .action-buttons form {
            display: inline-block;
            margin-right: 5px;
        }
        .empty-state {
            text-align: center;
            padding: 80px 20px;
            color: #6b7280;
        }
        .empty-state i {
            font-size: 64px;
            margin-bottom: 20px;
            opacity: 0.5;
        }
    </style>
</head>
<body>
    <div class="container-fluid px-4">
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-triangle"></i> <?= htmlspecialchars($_SESSION['error']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle"></i> <?= htmlspecialchars($_SESSION['success']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>
        
        <div class="card shadow-lg mb-4">
            <div class="card-body p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h1 class="h3 mb-0">
                        <i class="bi bi-shield-check"></i> Firewall Monitor Dashboard
                    </h1>
                    <div class="btn-group" role="group">
                        <a href="index.php" class="btn btn-primary">
                            <i class="bi bi-speedometer2"></i> Dashboard
                        </a>
                        <a href="site_form.php" class="btn btn-success">
                            <i class="bi bi-plus-circle"></i> Add New Site
                        </a>
                        <a href="manage_emails.php" class="btn btn-info text-white">
                            <i class="bi bi-envelope"></i> Manage Emails
                        </a>
                        <a href="logs.php" class="btn btn-secondary">
                            <i class="bi bi-list-ul"></i> View Logs
                        </a>
                        <a href="settings.php" class="btn btn-warning text-white">
                            <i class="bi bi-gear"></i> Settings
                        </a>
                        <a href="../actions/logout.php" class="btn btn-outline-danger">
                            <i class="bi bi-box-arrow-right"></i> Logout
                        </a>
                    </div>
                </div>

                <form method="get" class="bg-light p-3 rounded">
                    <div class="row g-3 align-items-end">
                        <div class="col-md-3">
                            <label class="form-label fw-bold">Status Filter</label>
                            <select name="status" class="form-select">
                                <option value="">All Statuses</option>
                                <option value="UP" <?=$status==='UP'?'selected':''?>>UP</option>
                                <option value="DEGRADED" <?=$status==='DEGRADED'?'selected':''?>>DEGRADED</option>
                                <option value="DOWN" <?=$status==='DOWN'?'selected':''?>>DOWN</option>
                            </select>
                        </div>
                        <div class="col-md-7">
                            <label class="form-label fw-bold">Search</label>
                            <input type="text" name="search" class="form-control" placeholder="Search by site name..." value="<?=htmlspecialchars($search ?? '')?>">
                        </div>
                        <div class="col-md-2">
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="bi bi-search"></i> Filter
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="card shadow-lg">
            <div class="card-body p-4">
                <?php if (empty($sites)): ?>
                    <div class="empty-state">
                        <i class="bi bi-router"></i>
                        <h3>No sites found</h3>
                        <p class="text-muted">Add your first site to start monitoring</p>
                        <a href="site_form.php" class="btn btn-primary mt-3">
                            <i class="bi bi-plus-circle"></i> Add New Site
                        </a>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>Status</th>
                                    <th>Site Name</th>
                                    <th>Location</th>
                                    <th>Primary IP</th>
                                    <th>Secondary IP</th>
                                    <th>Ping Settings</th>
                                    <th>Monitoring</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($sites as $s): ?>
                                <tr>
                                    <td>
                                        <span class="status-dot" style="background: <?=statusColor($s['status'])?>;"></span>
                                        <span class="badge bg-<?=$s['status']==='UP'?'success':($s['status']==='DEGRADED'?'warning':($s['status']==='DOWN'?'danger':'secondary'))?>">
                                            <?=$s['status']?>
                                        </span>
                                    </td>
                                    <td><strong><?=htmlspecialchars($s['name'])?></strong></td>
                                    <td><?=htmlspecialchars($s['location'] ?? 'N/A')?></td>
                                    <td><code class="bg-light px-2 py-1 rounded"><?=$s['primary_ip']?></code></td>
                                    <td><code class="bg-light px-2 py-1 rounded"><?=$s['secondary_ip']?></code></td>
                                    <td>
                                        <small>
                                            <strong><?=$s['ping_count'] ?: PING_DEFAULT_COUNT?></strong> pings<br>
                                            <span class="text-muted"><?=$s['ping_interval_sec'] ?: PING_DEFAULT_INTERVAL_SEC?>s interval</span>
                                        </small>
                                    </td>
                                    <td>
                                        <?php if ($s['monitoring_enabled']): ?>
                                            <span class="badge bg-info">Enabled</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">Disabled</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="action-buttons">
                                            <form method="post" action="../actions/action.php" class="d-inline" id="action-form-<?=$s['id']?>">
                                                <input type="hidden" name="site_id" value="<?=$s['id']?>">
                                                <button type="submit" name="action" value="failover" class="btn btn-danger btn-sm" onclick="return confirm('Execute Failover for <?=htmlspecialchars($s['name'])?>?');">
                                                    <i class="bi bi-exclamation-triangle"></i> Failover
                                                </button>
                                                <button type="submit" name="action" value="failback" class="btn btn-success btn-sm" onclick="return confirm('Execute Fail Back for <?=htmlspecialchars($s['name'])?>?');">
                                                    <i class="bi bi-arrow-counterclockwise"></i> Fail Back
                                                </button>
                                                <button type="submit" name="action" value="reboot" class="btn btn-warning btn-sm" onclick="return confirm('Execute Reboot for <?=htmlspecialchars($s['name'])?>?');">
                                                    <i class="bi bi-arrow-clockwise"></i> Reboot
                                                </button>
                                                <button type="submit" name="action" value="<?=$s['monitoring_enabled']?'stop':'start'?>" class="btn btn-secondary btn-sm">
                                                    <i class="bi bi-<?=$s['monitoring_enabled']?'pause':'play'?>"></i> <?=$s['monitoring_enabled']?'Stop':'Start'?>
                                                </button>
                                            </form>
                                            <a href="site_form.php?id=<?=$s['id']?>" class="btn btn-outline-primary btn-sm">
                                                <i class="bi bi-pencil"></i> Edit
                                            </a>
                                            <a href="../actions/delete_site.php?id=<?=$s['id']?>" class="btn btn-outline-danger btn-sm" onclick="return confirm('Are you sure you want to delete this site?')">
                                                <i class="bi bi-trash"></i> Delete
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>


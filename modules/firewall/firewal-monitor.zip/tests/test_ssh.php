<?php
/**
 * SSH Connection Test Script
 * Use this to test if SSH connection works before using in the main system
 */

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';

echo "========================================\n";
echo "SSH Connection Test\n";
echo "========================================\n\n";

// Test configuration
$test_ip = '127.0.0.1';  // Change to your server IP
$test_user = 'your-username';  // Change to your SSH username
$test_pass = 'your-password';  // Change to your SSH password
$test_command = 'echo "SSH Test Successful" && date && whoami';

echo "Testing SSH connection...\n";
echo "IP: $test_ip\n";
echo "User: $test_user\n";
echo "Command: $test_command\n\n";

// Test SSH connection
$result = runSshCommand($test_ip, $test_user, $test_pass, $test_command);

if ($result['ok']) {
    echo "✅ SSH Connection SUCCESSFUL!\n";
    echo "Output:\n";
    echo $result['output'] . "\n";
} else {
    echo "❌ SSH Connection FAILED!\n";
    echo "Error: " . $result['output'] . "\n";
    echo "\nTroubleshooting:\n";
    echo "1. Check if SSH is installed: php -m | grep ssh2\n";
    echo "2. Install SSH2: pecl install ssh2\n";
    echo "3. Test SSH manually: ssh $test_user@$test_ip\n";
    echo "4. Check firewall allows port 22\n";
}

echo "\n========================================\n";
echo "Test Complete\n";
echo "========================================\n";


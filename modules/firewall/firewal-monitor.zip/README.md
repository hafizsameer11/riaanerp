# Firewall Monitor System

A PHP-based firewall monitoring system with automatic failover capabilities.

## 📁 Project Structure

```
firewall-monitor/
├── includes/          # Core PHP files
│   ├── config.php     # Configuration settings
│   ├── db.php         # Database connection
│   ├── functions.php  # Core functions (SSH, ping, encryption)
│   └── auth.php       # Authentication system
│
├── pages/             # Main application pages
│   ├── index.php      # Dashboard
│   ├── site_form.php  # Add/Edit site form
│   ├── logs.php       # Action logs
│   ├── manage_emails.php  # Email management
│   └── settings.php   # System settings
│
├── actions/           # Action handlers
│   ├── action.php     # Manual actions (failover, failback, reboot)
│   ├── save_site.php  # Save site handler
│   ├── delete_site.php # Delete site handler
│   ├── save_email.php # Save email handler
│   ├── delete_email.php # Delete email handler
│   └── logout.php     # Logout handler
│
├── scripts/           # Background scripts
│   └── monitor.php    # Continuous monitoring worker
│
├── tests/             # Test files
│   ├── test_ssh.php   # SSH connection test
│   ├── test_ping.php  # Ping functionality test
│   └── test_commands.sh # Safe test commands
│
├── docs/              # Documentation
│   └── TESTING_GUIDE.md # Testing instructions
│
├── req/               # Reference files (client provided)
│   ├── index (4).php  # Example credential manager
│   ├── stoffice.sh    # Example reboot script
│   └── stofficemonitor.sh # Example monitor script
│
├── db.sql             # Database schema
├── index.php          # Root redirect
└── README.md          # This file
```

## 🚀 Quick Start

1. **Import Database**:
   ```bash
   mysql -u root < db.sql
   ```

2. **Configure**:
   - Edit `includes/config.php`:
     - Database credentials
     - Encryption key (change from default)
     - PIN code for authentication
     - SMTP settings

3. **Start Web Server**:
   ```bash
   php -S localhost:8000
   ```

4. **Start Monitor** (in separate terminal):
   ```bash
   php scripts/monitor.php
   ```

5. **Access**:
   - Open browser: `http://localhost:8000`
   - Enter PIN (default: 4683)

## 📋 Features

- ✅ PIN-based authentication
- ✅ Add/Edit/Delete firewall sites
- ✅ Continuous ping monitoring
- ✅ Automatic failover on primary IP failure
- ✅ Manual actions (Failover, Fail Back, Reboot)
- ✅ Email notifications
- ✅ Action logging
- ✅ Configurable ping count and intervals
- ✅ Per-site and global ping settings

## 🔧 Requirements

- PHP 7.4+
- MySQL 5.7+
- PHP SSH2 extension (`pecl install ssh2`)
- PHP OpenSSL extension
- PHP PDO MySQL extension

## 📝 Configuration

Edit `includes/config.php` to configure:
- Database connection
- Encryption key
- PIN code
- SMTP settings
- Default ping settings

## 🧪 Testing

See `docs/TESTING_GUIDE.md` for complete testing instructions.

Quick test:
```bash
php tests/test_ssh.php
php tests/test_ping.php
```

## 📞 Support

For issues or questions, check the logs page in the dashboard.


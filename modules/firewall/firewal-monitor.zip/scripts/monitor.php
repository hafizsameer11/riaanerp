<?php
require_once __DIR__ . '/../includes/functions.php';

echo "========================================\n";
echo "Firewall Monitor Started\n";
echo "========================================\n";
echo date('Y-m-d H:i:s') . " - Monitoring active...\n\n";

$iteration = 0;

while (true) {
    $iteration++;
    $sites = db()->query("SELECT * FROM sites WHERE monitoring_enabled=1")->fetchAll();
    
    if (empty($sites)) {
        if ($iteration === 1) {
            echo "No sites with monitoring enabled found.\n";
            echo "Add sites and enable monitoring in the dashboard.\n\n";
        }
    } else {
        echo "[" . date('H:i:s') . "] Checking " . count($sites) . " site(s)...\n";
    }

    foreach ($sites as $s) {
        $count = $s['ping_count'] ?: PING_DEFAULT_COUNT;
        $interval = $s['ping_interval_sec'] ?: PING_DEFAULT_INTERVAL_SEC;
        $oldStatus = $s['status'];

        echo "  → {$s['name']} ({$s['primary_ip']}): ";
        echo "Pinging {$count} times with {$interval}s interval... ";
        
        $ping = pingHost($s['primary_ip'], $count, $interval);

        if ($ping['successes'] === $count) {
            $status = "UP";
            $statusIcon = "✅";
        } elseif ($ping['successes'] === 0) {
            $status = "DOWN";
            $statusIcon = "❌";
        } else {
            $status = "DEGRADED";
            $statusIcon = "⚠️ ";
        }

        echo "{$statusIcon} {$ping['successes']}/{$count} successful";
        if ($status !== $oldStatus) {
            echo " [STATUS CHANGED: {$oldStatus} → {$status}]";
        }
        echo "\n";

        $statusChanged = ($status !== $oldStatus);
        
        // Log every ping check to database
        logPingCheck($s['id'], $count, $interval, $ping['successes'], $ping['failures'], $status, $statusChanged, $oldStatus);

        $stmt = db()->prepare("
            UPDATE sites SET status=?, last_ping_time=NOW(), last_ping_successes=?, last_ping_failures=?
            WHERE id=?
        ");
        $stmt->execute([$status, $ping['successes'], $ping['failures'], $s['id']]);

        if ($status === "DOWN" && $oldStatus !== "DOWN") {
            echo "    ⚠️  PRIMARY IP DOWN - Triggering automatic failover...\n";
            $sshPass = dec($s['ssh_password_enc']);
            $res = runSshCommand($s['secondary_ip'], $s['ssh_username'], $sshPass, $s['failover_command']);
            
            if ($res['ok']) {
                echo "    ✅ Failover command executed successfully\n";
            } else {
                echo "    ❌ Failover command failed: " . $res['output'] . "\n";
            }
            
            logAction($s['id'], "auto_failover", "system", $oldStatus, "DOWN", $res['output'], $res['ok'] ? 1 : 0, $s['failover_command']);
            sendNotificationEmail(getEmails(), "AUTO FAILOVER: {$s['name']}", $res['output']);
            echo "    📧 Email notification sent\n";
        }
    }

    if (!empty($sites)) {
        echo "\n";
    }
    
    sleep(5);
}


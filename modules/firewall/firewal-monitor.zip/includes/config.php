<?php

// ---------------------
// DATABASE CONFIG
// ---------------------
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'firewall_monitor');
define('DB_USER', 'root');     // mac default: root
define('DB_PASS', '');         // mac default: empty

// ---------------------
// SYSTEM ENCRYPTION KEY
// ---------------------
define('ENC_KEY', 'CHANGE_THIS_TO_A_RANDOM_32_CHAR_KEY');

// ---------------------
// MONITORING DEFAULTS
// ---------------------
define('PING_DEFAULT_COUNT', 10);
define('PING_DEFAULT_INTERVAL_SEC', 5);

// ---------------------
// SMTP CONFIG (NO AUTH, NO TLS)
// ---------------------
define('SMTP_HOST', '156.38.197.98');
define('SMTP_PORT', 587);
define('SMTP_FROM', 'monitor@system.local');
define('SMTP_FROM_NAME', 'Firewall Monitor');

// ---------------------
// SSH CONFIG
// ---------------------
define('SSH_PORT', 22);

// ---------------------
// AUTHENTICATION
// ---------------------
define('PIN_CODE', '4683'); // Change this to match your ERP system PIN


<?php
require_once __DIR__ . '/db.php';

// ------------------
// ENCRYPTION
// ------------------
function enc($plain) {
    if (!$plain) return null;
    $iv = random_bytes(16);
    $cipher = openssl_encrypt($plain, 'AES-256-CBC', ENC_KEY, 0, $iv);
    return base64_encode($iv . $cipher);
}
function dec($enc) {
    if (!$enc) return null;
    $enc = base64_decode($enc);
    $iv = substr($enc, 0, 16);
    $cipher = substr($enc, 16);
    return openssl_decrypt($cipher, 'AES-256-CBC', ENC_KEY, 0, $iv);
}

// ------------------
// PING FUNCTION
// ------------------
function pingHost($ip, $count, $interval) {
    $cmd = sprintf(
        'ping -c %d -i %d %s 2>&1',
        $count,
        $interval,
        escapeshellarg($ip)
    );
    $output = [];
    exec($cmd, $output);
    $text = implode("\n", $output);

    preg_match_all('/time=/', $text, $m);
    $success = count($m[0]);
    $fail = $count - $success;

    return ['successes' => $success, 'failures' => $fail, 'raw' => $text];
}

// ------------------
// SSH FUNCTION
// ------------------
function runSshCommand($ip, $user, $pass, $command) {
    // Check if SSH2 extension is installed and loaded
    if (!extension_loaded('ssh2')) {
        return ['ok' => false, 'output' => 'SSH2 extension not installed. Please install php-ssh2 extension: pecl install ssh2'];
    }
    
    // Verify all required SSH2 functions exist
    if (!function_exists('ssh2_connect') || 
        !function_exists('ssh2_auth_password') || 
        !function_exists('ssh2_exec')) {
        return ['ok' => false, 'output' => 'SSH2 extension functions not available. Please install php-ssh2 extension and add "extension=ssh2.so" to php.ini'];
    }

    // @phpstan-ignore-next-line - SSH2 functions exist when extension is loaded
    $conn = @ssh2_connect($ip, SSH_PORT);
    if (!$conn) {
        $error = error_get_last();
        return ['ok' => false, 'output' => "Cannot connect to $ip:" . SSH_PORT . ". " . ($error['message'] ?? 'Connection failed')];
    }

    // @phpstan-ignore-next-line - SSH2 functions exist when extension is loaded
    if (!@ssh2_auth_password($conn, $user, $pass)) {
        return ['ok' => false, 'output' => "SSH authentication failed for user '$user' on $ip"];
    }

    // @phpstan-ignore-next-line - SSH2 functions exist when extension is loaded
    $stream = @ssh2_exec($conn, $command);
    if (!$stream) {
        return ['ok' => false, 'output' => "Failed to execute command on $ip"];
    }
    
    stream_set_blocking($stream, true);
    $output = stream_get_contents($stream);
    fclose($stream);

    return ['ok' => true, 'output' => $output ?: 'Command executed (no output)'];
}

// ------------------
// EMAIL SENDER
// ------------------
function sendNotificationEmail($emails, $subject, $body) {
    $headers = "From: " . SMTP_FROM_NAME . " <" . SMTP_FROM . ">\r\n";
    foreach ($emails as $email) {
        mail($email, $subject, $body, $headers);
    }
}

function getEmails() {
    return db()->query("SELECT email FROM notification_emails WHERE active=1")->fetchAll(PDO::FETCH_COLUMN);
}

// ------------------
// SITE HELPERS
// ------------------
function getSites($filter, $search) {
    $sql = "SELECT * FROM sites WHERE 1=1";
    $params = [];

    if ($filter) {
        $sql .= " AND status = :status";
        $params['status'] = $filter;
    }

    if ($search) {
        $sql .= " AND name LIKE :search";
        $params['search'] = "%" . $search . "%";
    }

    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function logAction($siteId, $type, $by, $before, $after, $output, $sshSuccess = null, $command = null) {
    $stmt = db()->prepare("
        INSERT INTO site_actions (site_id, action_type, initiated_by, status_before, status_after, ssh_output, ssh_success, command_executed)
        VALUES (:id,:type,:by,:before,:after,:out,:success,:cmd)
    ");
    $stmt->execute([
        'id' => $siteId,
        'type' => $type,
        'by' => $by,
        'before' => $before,
        'after' => $after,
        'out' => $output,
        'success' => $sshSuccess,
        'cmd' => $command
    ]);
}

function logPingCheck($siteId, $pingCount, $pingInterval, $successes, $failures, $status, $statusChanged = false, $previousStatus = null) {
    $stmt = db()->prepare("
        INSERT INTO ping_logs (site_id, ping_count, ping_interval_sec, successes, failures, status, status_changed, previous_status)
        VALUES (:id,:count,:interval,:successes,:failures,:status,:changed,:prev)
    ");
    $stmt->execute([
        'id' => $siteId,
        'count' => $pingCount,
        'interval' => $pingInterval,
        'successes' => $successes,
        'failures' => $failures,
        'status' => $status,
        'changed' => $statusChanged ? 1 : 0,
        'prev' => $previousStatus
    ]);
}


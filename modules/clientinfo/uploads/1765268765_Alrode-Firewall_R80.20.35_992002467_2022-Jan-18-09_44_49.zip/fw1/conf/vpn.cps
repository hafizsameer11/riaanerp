#
# VPN configuration file for the non-cpmi command line.
#
#
# Syntax (of complicated fields. The rest is obvious):
#
# SIMPLE-OID,    Name, OID, Type
#
# COLUMN,        Name, OID, Type, Index-order, Display, Display-Totals
#
# SUM-COLUMN,    Name, Display-Totlas, Column-Name-1, Column-Name-2, ....
#
# OUTPUT-FORMAT, "DEFAULT"/"LIST"    *If does not exist - assumed "DEFAULT"  
#
# OID-BASE takes effect only within the section it is in.
#

START-BLOCK

	BLOCK-NAME, "vpn"

	OID-BASE, 1.3.6.1.4.1.2620.1.2

	START-FLAVOUR 
		FLAVOUR-NAME, "default"

		ADD-OID-ATOM, 4
			ADD-OID-ATOM, 1    # general statistics	
				SIMPLE-OID, "Encrypted packets",   1, UINT64
				SIMPLE-OID, "Decrypted packets",   2, UINT64
			REMOVE-OID-ATOM    # end of general statistics

			ADD-OID-ATOM, 2    # general errrors
				SIMPLE-OID, "Encryption errors",    			1, UINT64
				SIMPLE-OID, "Decryption errors",   			2, UINT64
				SIMPLE-OID, "IKE errors",          				3, UINT64
				SIMPLE-OID, "Connection related errors",       	4, UINT64
			REMOVE-OID-ATOM    # end of general errors
		REMOVE-OID-ATOM    	    # end of general statistics

	END-FLAVOUR


	START-FLAVOUR
		FLAVOUR-NAME, "product"
	
		SIMPLE-OID, "Product",         	1, STRING
		SIMPLE-OID, "Major version",   	2, UINT16
		SIMPLE-OID, "Minor version",   	3, UINT16
		SIMPLE-OID, "Kernel build num.",   	11, UINT32

	END-FLAVOUR


	START-FLAVOUR
		FLAVOUR-NAME, "IKE"

		ADD-OID-ATOM, 9
			ADD-OID-ATOM, 1    # IKE globals
				SIMPLE-OID, "IKE current SAs", 				             		1, UINT64
				SIMPLE-OID, "IKE current SAs initiated by me",                 	2, UINT64
				SIMPLE-OID, "IKE current SAs initiated by peer",            	 	3, UINT64
				SIMPLE-OID, "IKE max concurrent SAs",                    		10, UINT64
				SIMPLE-OID, "IKE max concurrent SAs initiated by me",          11, UINT64
				SIMPLE-OID, "IKE max concurrent SAs initiated by peer",      	12, UINT64
				SIMPLE-OID, "IKE total SAs",        				     		4, UINT64
				SIMPLE-OID, "IKE total SAs initiated by me",                   		5, UINT64
				SIMPLE-OID, "IKE total SAs initiated by peer", 		             	6, UINT64
				SIMPLE-OID, "IKE total SA attempts",          			 	7, UINT64
				SIMPLE-OID, "IKE total SA attempts initiated by me",          	8, UINT64
				SIMPLE-OID, "IKE total SA attempts initiated by peer",          	9, UINT64
				SIMPLE-OID, "IKE current ongoing SA negotiations",          	13, UINT64
				SIMPLE-OID, "IKE max concurrent SA negotiations", 			14, UINT64
			REMOVE-OID-ATOM    # end of IKE globals

			ADD-OID-ATOM, 2    # IKE errors
				SIMPLE-OID, "IKE no response from peer (initiator errors)",  	2, UINT64
				SIMPLE-OID, "IKE total failures (initiator errors)", 			1, UINT64
				SIMPLE-OID, "IKE total failures (responder errors)",   		3, UINT64
			REMOVE-OID-ATOM    # end of IKE errors
		REMOVE-OID-ATOM    # end of IKE

		ADD-OID-ATOM, 4		# general statistics
			ADD-OID-ATOM, 2   # general errrors
				SIMPLE-OID, "IKE total failures (initiator + responder)",		3, UINT64					
			REMOVE-OID-ATOM    # end of general errors
		REMOVE-OID-ATOM    # end of general statistics
	
	END-FLAVOUR

	START-FLAVOUR
		FLAVOUR-NAME, "ipsec"

		ADD-OID-ATOM, 5
			ADD-OID-ATOM, 2    # IPsec sa statistics
				SIMPLE-OID, "IPsec current Inbound SAs",              		1, UINT64
				SIMPLE-OID, "IPsec current Outbound SAs",             		3, UINT64
				SIMPLE-OID, "IPsec max concurrent Inbound SAs",       	9, UINT64
				SIMPLE-OID, "IPsec max concurrent Outbound SAs",     	10, UINT64
				SIMPLE-OID, "IPsec total Inbound SAs",                		2, UINT64
				SIMPLE-OID, "IPsec total Outbound SAs",               		4, UINT64
			REMOVE-OID-ATOM    # end of sa statistics

			ADD-OID-ATOM, 4		# IPsec statistics
				SIMPLE-OID, "IPsec number of VPN-1 peers",				21, UINT64
				SIMPLE-OID, "IPsec maximum number of VPN-1 peers",		22, UINT64
				SIMPLE-OID, "IPsec number of VPN-1 RA peers",			23, UINT64
				SIMPLE-OID, "IPsec maximum number of VPN-1 RA peers",	24, UINT64
                SIMPLE-OID, "IPsec Remote Access Licenses",	26, STRING
			REMOVE-OID-ATOM    # end of IPsec statistics

			ADD-OID-ATOM, 3    # IPsec sa errors
				SIMPLE-OID, "IPsec decryption errors",                    		1, UINT64
				SIMPLE-OID, "IPsec authentication errors",                		2, UINT64
				SIMPLE-OID, "IPsec replay errors",                        			3, UINT64
				SIMPLE-OID, "IPsec Connection related errors",       			4, UINT64
				SIMPLE-OID, "IPsec unknown SPI errors",                   		7, UINT64
				SIMPLE-OID, "IPsec other inbound errors",                 		5, UINT64
				SIMPLE-OID, "IPsec other outbound errors",                		6, UINT64
			REMOVE-OID-ATOM   # end of IPsec sa errors
		REMOVE-OID-ATOM   

	END-FLAVOUR

	START-FLAVOUR
		FLAVOUR-NAME, "traffic"

		ADD-OID-ATOM, 5
			ADD-OID-ATOM, 4		# IPsec statistics
				SIMPLE-OID, "IPsec UDP encrypted packets",          1, UINT64
				SIMPLE-OID, "IPsec UDP decrypted packets",          2, UINT64
				SIMPLE-OID, "IPsec encrypted bytes",                19, UINT64
				SIMPLE-OID, "IPsec decrypted bytes",                20, UINT64
				SIMPLE-OID, "IPsec encrypted packets",              5, UINT64
				SIMPLE-OID, "IPsec decrypted packets",              6, UINT64
			REMOVE-OID-ATOM    # end of IPsec statistics
		REMOVE-OID-ATOM   

	END-FLAVOUR

	START-FLAVOUR
		FLAVOUR-NAME, "compression"

		ADD-OID-ATOM, 5
			ADD-OID-ATOM, 4		# IPsec statistics
				SIMPLE-OID, "IPsec bytes before decompression",   		7, UINT64
				SIMPLE-OID, "IPsec bytes after decompression",  		8, UINT64
				SIMPLE-OID, "IPsec bytes decompression overhead", 	9, UINT64
				SIMPLE-OID, "IPsec packets decompressed",        		10, UINT64
				SIMPLE-OID, "IPsec decompression errors",        		11, UINT64
				SIMPLE-OID, "IPsec bytes before compression",   		12, UINT64
				SIMPLE-OID, "IPsec bytes after compression",    		13, UINT64
				SIMPLE-OID, "IPsec bytes compression overhead", 		14, UINT64
				SIMPLE-OID, "IPsec bytes non compressible",     		15, UINT64
				SIMPLE-OID, "IPsec packets compressed",       	 		16, UINT64
				SIMPLE-OID, "IPsec packets non compressible",   		17, UINT64
				SIMPLE-OID, "IPsec compression errors",         			18, UINT64
			REMOVE-OID-ATOM    # end of IPsec statistics
		REMOVE-OID-ATOM    

	END-FLAVOUR

	START-FLAVOUR
		FLAVOUR-NAME, "accelerator"

		ADD-OID-ATOM, 8
			ADD-OID-ATOM, 1 # hw status
				SIMPLE-OID, "HW accel. vendor",                      	1, STRING
				SIMPLE-OID, "HW accel. status", 					2, STRING
				SIMPLE-OID, "HW accel. driver major version",		3, UINT32
				SIMPLE-OID, "HW accel. driver minor version",		4, UINT32
			REMOVE-OID-ATOM    # end of hw status

			ADD-OID-ATOM, 2   # hw statsitics
				SIMPLE-OID, "HW accel. encrypted IPsec packets",    	1, UINT64
				SIMPLE-OID, "HW accel. decrypted IPsec packets",    	2, UINT64
				SIMPLE-OID, "HW accel. encrypted IPsec bytes",      		3, UINT64
				SIMPLE-OID, "HW accel. decrypted IPsec bytes",      		4, UINT64
				SIMPLE-OID, "HW accel. encryption errors",      			9, UINT64
				SIMPLE-OID, "HW accel. decryption errors",      			10, UINT64
				SIMPLE-OID, "HW accel. context errors",      			11, UINT64
			REMOVE-OID-ATOM    # end of hw statistics
		REMOVE-OID-ATOM    # end of hw

	END-FLAVOUR

	START-FLAVOUR
		FLAVOUR-NAME, "nic"

		ADD-OID-ATOM, 10
			ADD-OID-ATOM, 1 # IPsec NICs general status
				SIMPLE-OID, "IPsec NIC: Number of IPsec NIC's   ",    		1, UINT32
				SIMPLE-OID, "IPsec NIC: Current SA's ",      				3, UINT64
				SIMPLE-OID, "IPsec NIC: Total SA's   ", 	   				2, UINT64
				SIMPLE-OID, "IPsec NIC: Decrypted bytes by NIC  ", 		4, UINT64
				SIMPLE-OID, "IPsec NIC: Encrypted bytes by NIC  ",     		5, UINT64
				SIMPLE-OID, "IPsec NIC: Decrypted packets by NIC", 		6, UINT64
				SIMPLE-OID, "IPsec NIC: Encrypted packets by NIC",     		7, UINT64
			REMOVE-OID-ATOM    # end of IPsec NICs general statistics
		REMOVE-OID-ATOM    # end of nic

	END-FLAVOUR

	START-FLAVOUR
		FLAVOUR-NAME, "statistics"
		OID-BASE, 1.3.6.1.4.1.2620.999.2 # statistical info

		ADD-OID-ATOM, 5
			ADD-OID-ATOM, 2
				SIMPLE-OID, "IKE Successes (per sec)",	2.4, UINT64
			REMOVE-OID-ATOM 
		REMOVE-OID-ATOM    

		ADD-OID-ATOM, 4
			ADD-OID-ATOM, 2	
				SIMPLE-OID, "IKE Failures (per sec)",		3.4, UINT64
			REMOVE-OID-ATOM 
		REMOVE-OID-ATOM    
		
		ADD-OID-ATOM, 5
			ADD-OID-ATOM, 4
				SIMPLE-OID, "Encryption Throughput (bytes per sec)",	19.4, UINT64
				SIMPLE-OID, "Decryption Throughput (bytes per sec)",	20.4, UINT64
			REMOVE-OID-ATOM 
		REMOVE-OID-ATOM    
		
		ADD-OID-ATOM, 4
			ADD-OID-ATOM, 1
				SIMPLE-OID, "Encrypted Packets (per sec)",	1.4, UINT64
				SIMPLE-OID, "Decrypted Packets (per sec)",	2.4, UINT64
			REMOVE-OID-ATOM 
			ADD-OID-ATOM, 2
				SIMPLE-OID, "Encryption Errors (per sec)",	 	1.4, UINT64
				SIMPLE-OID, "Decryption Errors (per sec)",	 	2.4, UINT64
			REMOVE-OID-ATOM 
		REMOVE-OID-ATOM    

		ADD-OID-ATOM, 8
			ADD-OID-ATOM, 2
				SIMPLE-OID, "VPN Accel Enc Throughput (bytes per sec)",	 	3.4, UINT64
				SIMPLE-OID, "VPN Accel Dec Throughput (bytes per sec)",	4.4, UINT64
				SIMPLE-OID, "VPN Accel Encryption Errors (per sec)",		9.4, UINT64
				SIMPLE-OID, "VPN Accel Decryption Errors (per sec)",		10.4, UINT64
			REMOVE-OID-ATOM 
		REMOVE-OID-ATOM    

		ADD-OID-ATOM, 5
			ADD-OID-ATOM, 4
				SIMPLE-OID, "Compressed Packets (per sec)",		16.4, UINT64
				SIMPLE-OID, "Decompressed Packets (per sec)", 	10.4, UINT64
				SIMPLE-OID, "Compression Errors (per sec)",  		18.4, UINT64
				SIMPLE-OID, "Decompression Errors (per sec)", 	11.4, UINT64
			REMOVE-OID-ATOM 
		REMOVE-OID-ATOM    

	END-FLAVOUR

	START-FLAVOUR
		FLAVOUR-NAME, "watermarks"
		OID-BASE, 1.3.6.1.4.1.2620.1000.2 # statistical info

		ADD-OID-ATOM, 5
			ADD-OID-ATOM, 2
				SIMPLE-OID, "IKE Successes (max per sec)",	2.4, UINT64
			REMOVE-OID-ATOM 
		REMOVE-OID-ATOM    

		ADD-OID-ATOM, 4
			ADD-OID-ATOM, 2	
				SIMPLE-OID, "IKE Failures (max per sec)",	 	3.4, UINT64
			REMOVE-OID-ATOM 
		REMOVE-OID-ATOM    

		ADD-OID-ATOM, 5
			ADD-OID-ATOM, 4
				SIMPLE-OID, "Encryption Throughput (max bytes per sec)",	 19.4, UINT64
				SIMPLE-OID, "Decryption Throughput (max bytes per sec)",	 20.4, UINT64
			REMOVE-OID-ATOM 
		REMOVE-OID-ATOM    

		ADD-OID-ATOM, 4
			ADD-OID-ATOM, 1
				SIMPLE-OID, "Encrypted Packets (max per sec)",	1.4, UINT64
				SIMPLE-OID, "Decrypted Packets (max per sec)",	2.4, UINT64
			REMOVE-OID-ATOM 
			ADD-OID-ATOM, 2
				SIMPLE-OID, "Encryption Errors (max per sec)",		1.4, UINT64
				SIMPLE-OID, "Decryption Errors (max per sec)",	2.4, UINT64
			REMOVE-OID-ATOM 
		REMOVE-OID-ATOM    

		ADD-OID-ATOM, 8
			ADD-OID-ATOM, 2
				SIMPLE-OID, "VPN Accel Enc Throughput (max bytes per sec)",		3.4, UINT64
				SIMPLE-OID, "VPN Accel Dec Throughput (max bytes per sec)",		4.4, UINT64
				SIMPLE-OID, "VPN Accel Encryption Errors (max per sec)",	9.4, UINT64
				SIMPLE-OID, "VPN Accel Decryption Errors (max per sec)",	10.4, UINT64
			REMOVE-OID-ATOM 
		REMOVE-OID-ATOM    

		ADD-OID-ATOM, 5
			ADD-OID-ATOM, 4
				SIMPLE-OID, "Compressed Packets (max per sec)",		16.4, UINT64
				SIMPLE-OID, "Decompressed Packets (max per sec)",	10.4, UINT64
				SIMPLE-OID, "Compression Errors (max per sec)",		18.4, UINT64
				SIMPLE-OID, "Decompression Errors (max per sec)",		11.4, UINT64
			REMOVE-OID-ATOM 
		REMOVE-OID-ATOM    

	END-FLAVOUR

	START-FLAVOUR
		FLAVOUR-NAME, "all"

		ADD-OID-ATOM, 4
			ADD-OID-ATOM, 1    # general statistics	
				SIMPLE-OID, "Encrypted packets",   1, UINT64
				SIMPLE-OID, "Decrypted packets",   2, UINT64
			REMOVE-OID-ATOM    # end of general statistics

			ADD-OID-ATOM, 2    # general errrors
				SIMPLE-OID, "Encryption errors",    			1, UINT64
				SIMPLE-OID, "Decryption errors",   			2, UINT64
				SIMPLE-OID, "Connection related errors",       	4, UINT64
			REMOVE-OID-ATOM    # end of general errors
		REMOVE-OID-ATOM    	    # end of general statistics
	
		SIMPLE-OID, "Product",         	1, STRING
		SIMPLE-OID, "Major version",   	2, UINT16
		SIMPLE-OID, "Minor version",   	3, UINT16
		SIMPLE-OID, "Kernel build num.",   	11, UINT32

		ADD-OID-ATOM, 9
			ADD-OID-ATOM, 1    # IKE globals
				SIMPLE-OID, "IKE current SAs", 				             		1, UINT64
				SIMPLE-OID, "IKE current SAs initiated by me",                 	2, UINT64
				SIMPLE-OID, "IKE current SAs initiated by peer",            	 	3, UINT64
				SIMPLE-OID, "IKE max concurrent SAs",                    		10, UINT64
				SIMPLE-OID, "IKE max concurrent SAs initiated by me",          11, UINT64
				SIMPLE-OID, "IKE max concurrent SAs initiated by peer",      	12, UINT64
				SIMPLE-OID, "IKE total SAs",        				     		4, UINT64
				SIMPLE-OID, "IKE total SAs initiated by me",                   		5, UINT64
				SIMPLE-OID, "IKE total SAs initiated by peer", 		             	6, UINT64
				SIMPLE-OID, "IKE total SA attempts",          			 	7, UINT64
				SIMPLE-OID, "IKE total SA attempts initiated by me",          	8, UINT64
				SIMPLE-OID, "IKE total SA attempts initiated by peer",          	9, UINT64
				SIMPLE-OID, "IKE current ongoing SA negotiations",          	13, UINT64
				SIMPLE-OID, "IKE max concurrent SA negotiations", 			14, UINT64
			REMOVE-OID-ATOM    # end of IKE globals

			ADD-OID-ATOM, 2    # IKE errors
				SIMPLE-OID, "IKE no response from peer (initiator errors)",  	2, UINT64
				SIMPLE-OID, "IKE total failures (initiator errors)", 			1, UINT64
				SIMPLE-OID, "IKE total failures (responder errors)",   		3, UINT64
			REMOVE-OID-ATOM    # end of IKE errors
		REMOVE-OID-ATOM    # end of IKE

		ADD-OID-ATOM, 4		# general statistics
			ADD-OID-ATOM, 2   # general errrors
				SIMPLE-OID, "IKE total failures (initiator + responder)",		3, UINT64					
			REMOVE-OID-ATOM    # end of general errors
		REMOVE-OID-ATOM    # end of general statistics
	
		ADD-OID-ATOM, 5
			ADD-OID-ATOM, 2    # IPsec sa statistics
				SIMPLE-OID, "IPsec current Inbound SAs",              		1, UINT64
				SIMPLE-OID, "IPsec current Outbound SAs",             		3, UINT64
				SIMPLE-OID, "IPsec max concurrent Inbound SAs",       	9, UINT64
				SIMPLE-OID, "IPsec max concurrent Outbound SAs",     	10, UINT64
				SIMPLE-OID, "IPsec total Inbound SAs",                		2, UINT64
				SIMPLE-OID, "IPsec total Outbound SAs",               		4, UINT64
			REMOVE-OID-ATOM    # end of sa statistics

			ADD-OID-ATOM, 4		# IPsec statistics
				SIMPLE-OID, "IPsec number of VPN-1 peers",				21, UINT64
				SIMPLE-OID, "IPsec maximum number of VPN-1 peers",		22, UINT64
				SIMPLE-OID, "IPsec number of VPN-1 RA peers",			23, UINT64
				SIMPLE-OID, "IPsec maximum number of VPN-1 RA peers",	24, UINT64
			REMOVE-OID-ATOM    # end of IPsec statistics

			ADD-OID-ATOM, 3    # IPsec sa errors
				SIMPLE-OID, "IPsec decryption errors",                    		1, UINT64
				SIMPLE-OID, "IPsec authentication errors",                		2, UINT64
				SIMPLE-OID, "IPsec replay errors",                        			3, UINT64
				SIMPLE-OID, "IPsec Connection related errors",      			4, UINT64
				SIMPLE-OID, "IPsec unknown SPI errors",                   		7, UINT64
				SIMPLE-OID, "IPsec other inbound errors",                 		5, UINT64
				SIMPLE-OID, "IPsec other outbound errors",                		6, UINT64
			REMOVE-OID-ATOM   # end of IPsec sa errors
		REMOVE-OID-ATOM   

		ADD-OID-ATOM, 5
			ADD-OID-ATOM, 4		# IPsec statistics
				SIMPLE-OID, "IPsec UDP encrypted packets",          1, UINT64
				SIMPLE-OID, "IPsec UDP decrypted packets",          2, UINT64
				SIMPLE-OID, "IPsec encrypted bytes",                19, UINT64
				SIMPLE-OID, "IPsec decrypted bytes",                20, UINT64
				SIMPLE-OID, "IPsec encrypted packets",              5, UINT64
				SIMPLE-OID, "IPsec decrypted packets",              6, UINT64
			REMOVE-OID-ATOM    # end of IPsec statistics
		REMOVE-OID-ATOM   

		ADD-OID-ATOM, 5
			ADD-OID-ATOM, 4		# IPsec statistics
				SIMPLE-OID, "IPsec bytes before decompression",   		7, UINT64
				SIMPLE-OID, "IPsec bytes after decompression",  		8, UINT64
				SIMPLE-OID, "IPsec bytes decompression overhead", 	9, UINT64
				SIMPLE-OID, "IPsec packets decompressed",        		10, UINT64
				SIMPLE-OID, "IPsec decompression errors",        		11, UINT64
				SIMPLE-OID, "IPsec bytes before compression",   		12, UINT64
				SIMPLE-OID, "IPsec bytes after compression",    		13, UINT64
				SIMPLE-OID, "IPsec bytes compression overhead", 		14, UINT64
				SIMPLE-OID, "IPsec bytes non compressible",     		15, UINT64
				SIMPLE-OID, "IPsec packets compressed",       	 		16, UINT64
				SIMPLE-OID, "IPsec packets non compressible",   		17, UINT64
				SIMPLE-OID, "IPsec compression errors",         			18, UINT64
			REMOVE-OID-ATOM    # end of IPsec statistics
		REMOVE-OID-ATOM    

		ADD-OID-ATOM, 8
			ADD-OID-ATOM, 1 # hw status
				SIMPLE-OID, "HW accel. vendor",                      	1, STRING
				SIMPLE-OID, "HW accel. status", 					2, STRING
				SIMPLE-OID, "HW accel. driver major version",		3, UINT32
				SIMPLE-OID, "HW accel. driver minor version",		4, UINT32
			REMOVE-OID-ATOM    # end of hw status

			ADD-OID-ATOM, 2   # hw statsitics
				SIMPLE-OID, "HW accel. encrypted IPsec packets",    	1, UINT64
				SIMPLE-OID, "HW accel. decrypted IPsec packets",    	2, UINT64
				SIMPLE-OID, "HW accel. encrypted IPsec bytes",      		3, UINT64
				SIMPLE-OID, "HW accel. decrypted IPsec bytes",      		4, UINT64
				SIMPLE-OID, "HW accel. encryption errors",      			9, UINT64
				SIMPLE-OID, "HW accel. decrytpion errors",      			10, UINT64
				SIMPLE-OID, "HW accel. context errors",      			11, UINT64
			REMOVE-OID-ATOM    # end of hw statistics
		REMOVE-OID-ATOM    # end of hw

		ADD-OID-ATOM, 10
			ADD-OID-ATOM, 1 # IPsec NICs general status
				SIMPLE-OID, "IPsec NIC: Number of IPsec NIC's   ",    		1, UINT32
				SIMPLE-OID, "IPsec NIC: Current SA's ",      				3, UINT64
				SIMPLE-OID, "IPsec NIC: Total SA's   ", 	   				2, UINT64
				SIMPLE-OID, "IPsec NIC: Decrypted bytes by NIC  ", 		4, UINT64
				SIMPLE-OID, "IPsec NIC: Encrypted bytes by NIC  ",     		5, UINT64
				SIMPLE-OID, "IPsec NIC: Decrypted packets by NIC", 		6, UINT64
				SIMPLE-OID, "IPsec NIC: Encrypted packets by NIC",     		7, UINT64
			REMOVE-OID-ATOM    # end of IPsec NICs general statistics
		REMOVE-OID-ATOM    # end of nic

	END-FLAVOUR
		
END-BLOCK

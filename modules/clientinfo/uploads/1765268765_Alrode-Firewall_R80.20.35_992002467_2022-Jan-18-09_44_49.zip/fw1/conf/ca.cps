#
# HA configuration file for the non-cpmi command line.
#
#
# Syntax (of complicated fields. The rest is obvious):
#
# SIMPLE-OID,    Name, OID, Type
#
# COLUMN,        Name, OID, Type, Index-order, Display, Display-Totals
#
# SUM-COLUMN,    Name, Display-Totlas, Column-Name-1, Column-Name-2, ....
#
# OUTPUT-FORMAT, "DEFAULT"/"LIST"    *If does not exist - assumed "DEFAULT"  
#
# OID-BASE takes effect only within the section it is in.
#

START-BLOCK

	BLOCK-NAME, "ca"

	OID-BASE, 1.3.6.1.4.1.2620.1.19

	START-FLAVOUR

		FLAVOUR-NAME, "default"

		SIMPLE-OID, "Product Name", 				1, STRING
		SIMPLE-OID, "Up and Running", 				2, UINT32
		SIMPLE-OID, "Total Number of certificates",	3, UINT64
		SIMPLE-OID, "Total Number of users", 		9, UINT64
		SIMPLE-OID, "Total Number of SIC certificates",	12, UINT64
		SIMPLE-OID, "Total Number of IKE certificates", 13, UINT64
		SIMPLE-OID, "Last CRL Distribution Point",		14, UINT32
		
	END-FLAVOUR

	START-FLAVOUR

		FLAVOUR-NAME, "crl"

		SIMPLE-OID, "Product Name", 				1, STRING
		SIMPLE-OID, "Last CRL Distribution Point",		14, UINT32
		
	END-FLAVOUR

	START-FLAVOUR

		FLAVOUR-NAME, "cert"

		SIMPLE-OID, "Product Name", 				1, STRING
		SIMPLE-OID, "Total Number of certificates",	3, UINT64
		SIMPLE-OID, "Number of Pending certificates",	4, UINT64
		SIMPLE-OID, "Number of Valid certificates", 	5, UINT64
		SIMPLE-OID, "Number of Renewed certificates", 6, UINT64
		SIMPLE-OID, "Number of Revoked certificates", 	7, UINT64
		SIMPLE-OID, "Number of Expired certificates", 	8, UINT64
		
	END-FLAVOUR

	START-FLAVOUR

		FLAVOUR-NAME, "user"

		SIMPLE-OID, "Product Name", 				1, STRING
		SIMPLE-OID, "Total Number of users", 		9, UINT64
		SIMPLE-OID, "Number of LDAP users",			10, UINT64
		SIMPLE-OID, "Number of Internal users",		11, UINT64
		
	END-FLAVOUR

	START-FLAVOUR

		FLAVOUR-NAME, "all"

		SIMPLE-OID, "Product Name", 				1, STRING
		SIMPLE-OID, "Build Number",				15, UINT32
		SIMPLE-OID, "Up and Running", 				2, UINT32
		SIMPLE-OID, "Total Number of certificates",	3, UINT64
		SIMPLE-OID, "Number of Pending certificates",	4, UINT64
		SIMPLE-OID, "Number of Valid certificates", 	5, UINT64
		SIMPLE-OID, "Number of Renewed certificates", 6, UINT64
		SIMPLE-OID, "Number of Revoked certificates", 	7, UINT64
		SIMPLE-OID, "Number of Expired certificates", 	8, UINT64
		SIMPLE-OID, "Total Number of users", 		9, UINT64
		SIMPLE-OID, "Number of Internal users",		10, UINT64
		SIMPLE-OID, "Number of LDAP users",			11, UINT64
		SIMPLE-OID, "Total Number of SIC certificates",	12, UINT64
		SIMPLE-OID, "Total Number of IKE certificates", 13, UINT64
		SIMPLE-OID, "Last CRL Distribution Point",		14, UINT32
		
	END-FLAVOUR
	
END-BLOCK

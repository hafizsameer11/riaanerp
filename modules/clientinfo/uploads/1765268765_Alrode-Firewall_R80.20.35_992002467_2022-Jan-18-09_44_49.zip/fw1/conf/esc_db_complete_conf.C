Version: generic
Date: 18August2016 19:00

Sign {

(
	:blades (
		# FW Blade
		:0 (
			:key ("")
			:supported_product_types (
				:include_set (
					: ("Gateway")
					: ("VSX")
				)
			)
			:blade_license_models (
				: (
					:license_triplets (
						: (
							:product ("fw1")
							:version ("6.0")
							:feature ("fwbase")
						)
					)
				)
			)
		)
		# VPN Blade
		:1 (
			:key ("")
			:supported_product_types (
				:include_set (
					: ("Gateway")
					: ("VSX")
				)
			)
			:blade_license_models (
				: (
					:license_triplets (
						: (
							:type ("and")
							: (
								:product ("fw1")
								:version ("6.0")
								:feature ("vpnstrong")
							)
							: (
								:product ("fw1")
								:version ("6.0")
								:feature ("encul")
							)
						)
					)
				)
			)	
		)
		# IPS Blade
		:2 (
			:key ("IPS")
			:supported_product_types (
				:include_set (
					: ("Gateway")
					: ("VSX")
				)
			)
			:blade_license_models (
				: (
					:license_triplets (
						: (
							:type ("or")
							: (
								:product ("fw1")
								:version ("6.0")
								:feature ("ips")
							)
							: (
								:product ("fw1")
								:version ("6.0")
								:feature ("ipss1")
							)
						)
					)
					:contract_triplets (
						: (
							:product ("services")
							:version ("6.0")
							:feature ("sd_update")
						)
					)
				)
			)	
		)
		# ANTISPAM Blade
		:3 (
			:key ("ASPM")
			:supported_product_types (
				:include_set (
					: ("Gateway")
					: ("VSX")
				)
			)
			:blade_license_models (
				: (
					:license_triplets (
						: (
							:product ("fw1")
							:version ("6.0")
							:feature ("aspm")
						)
					)
					:contract_triplets (
						: (
							:product ("services")
							:version ("6.0")
							:feature ("as_update")
						)
					)
				)
			)	
		)
		# APPI Blade
		:4 (
			:key ("APPI")
			:supported_product_types (
				:include_set (
					: ("Gateway")
					: ("VSX")
				)
			)
			:blade_license_models (
				: (
					:license_triplets (
						: (
							:product ("fw1")
							:version ("6.0")
							:feature ("appi")
						)
					)
					:contract_triplets (
						: (
							:product ("services")
							:version ("6.0")
							:feature ("apcl_update")
						)
					)
				)	
			)	
		)
		# ADV_URLF Blade
		:5 (
			:key ("URLF")
			:supported_product_types (
				:include_set (
					: ("Gateway")
					: ("VSX")
				)
			)
			:blade_license_models (
				: (
					:license_triplets (
						: (
							:product ("fw1")
							:version ("6.0")
							:feature ("urlf")
						)
					)
					:contract_triplets (
						: (
							:product ("services")
							:version ("6.0")
							:feature ("ufp_update")
						)
					)
				)
			)	
		)
		# AVI_DEF Blade
		:6 (
			:key ("AV")
			:supported_product_types (
				:include_set (
					: ("Gateway")
					: ("VSX")
				)
			)
			:blade_license_models (
				: (
					:license_triplets (
						: (
							:product ("fw1")
							:version ("6.0")
							:feature ("av")
						)
					)
					:contract_triplets (
						: (
							:product ("services")
							:version ("6.0")
							:feature ("av_update")
						)
					)
				)
			)	
		)
		# BOTNET_DEF  Blade
		:7 (
			:key ("ABOT")
			:supported_product_types (
				:include_set (
					: ("Gateway")
					: ("VSX")
				)
			)
			:supported_versions  (
				: (
					:range_from ("R75.40")
					:range_to ("Unlimited")
				)		
			)
			:blade_license_models (
				: (
					:license_triplets (
						: (
							:product ("fw1")
							:version ("6.0")
							:feature ("abot")
						)
					)
					:contract_triplets (
						: (
							:product ("services")
							:version ("6.0")
							:feature ("abot_update")
						)
					)
				)
			)	
		)
		# THREAT_EMU_LOCAL Blade
		:8 (
			:key ("TEMU")
			:supported_product_types (
				:include_set (
					: ("Gateway")
					: ("VSX")
				)
			)
			:supported_versions  (
				: (
					:range_from ("R77")
					:range_to ("Unlimited")
				)
			)
			:blade_license_models (
				: (
					:license_triplets (
						: (
							:product ("fw1")
							:version ("6.0")
							:feature ("temu")
						)
					)
					:contract_triplets (
						: (
							:product ("services")
							:version ("6.0")
							:feature ("temu_local")
						)
					)
				)
			)
		)
		# eESC_THREAT_EMU_CLOUD Blade
		:9 (
			:supported_product_types (
				:include_set (
					: ("Gateway")
					: ("VSX")
				)
			)
			:supported_versions  (
				: (
					:range_from ("R77")
					:range_to ("Unlimited")
				)
			)
			:blade_license_models (
				: (
					:contract_triplets (
						: (
							:product ("services")
							:version ("6.0")
							:feature ("temu100000m")
						)
					)
				)
			)	
		)
		# eESC_THREAT_EXTRACTION  Blade
		:10 (
			:key ("TEX")
			:supported_product_types (
				:include_set (
					: ("Gateway")
					: ("VSX")
				)
			)
			:supported_versions  (
				: (
					:range_from ("R77.30")
					:range_to ("Unlimited")
				)
			)
			:blade_license_models (
				: (
					:license_triplets (
						: (
							:product ("fw1")
							:version ("6.0")
							:feature ("tex")
						)
					)
					:contract_triplets (
						: (
							:product ("services")
							:version ("6.0")
							:feature ("tex_update")
						)
					)
				)
			)
		)
		# DLP Blade
		:11 (
			:key ("DLP")
			:supported_product_types (
				:include_set (
					: ("Gateway")
					: ("VSX")
				)
			)
			:blade_license_models (
				: (
					:license_triplets (
						: (
							:product ("fw1")
							:version ("6.0")
							:feature ("dlp")
						)
					)
					:contract_triplets (
						: (
							:product ("services")
							:version ("6.0")
							:feature ("dlp_update")
						)
					)
				)
			)	
		)
		# VSX Blade
		:12 (
			:key ("")
			:supported_product_types (
				:include_set (
					: ("VSX")
				)
			)
			:blade_license_models (
				: (
					:license_triplets (
						: (
							:type ("or")
							: (
								:product ("fw1")
								:version ("6.0")
								:feature ("fwbase")
							)
							: (
								:product ("fw1")
								:version ("6.0")
								:feature ("vsx1")
							)
							: (
								:product ("fw1")
								:version ("6.0")
								:feature ("vsx5")
							)
						)
					)
				)
			)	
		)
		# Content Awareness Blade
		:13 (
			:key ("")
			:supported_product_types (
				:include_set (
					: ("Gateway")
					: ("VSX")
				)
			)
			:supported_versions (
				: (
					:range_from ("R80.10")
					:range_to ("Unlimited")
				)
			)
			:blade_license_models (
				: (
					:license_triplets (
						: (
							:product ("fw1")
							:version ("6.0")
							:feature ("fwbase")
						)
					)
				)
			)	
		)

		# POLICY_MGMT Blade
		:1000 (
			:key ("")
			:supported_product_types (
				:include_set (
					: ("Management")
				)
			)
			:blade_license_models (
				: (
					:license_triplets (
						: (
							:type ("and")
							: (
								:product ("fw1")
								:version ("6.0")
								:feature ("mgmtcore")
							)
							: (
								:product ("fw1")
								:version ("6.0")
								:feature ("policyui")
							)
						)
					)
				)
			)	
		)
		# LOGGER Blade
		:1001 (
			:key ("")
			:supported_product_types (
					:include_set (
						: ("Management")
						: ("LogServer")
						: ("SmartEvent")
						: ("CLM")
						: ("CorrelationUnit")
					)
			)
			:blade_license_models (
				: (
					:license_triplets (
						: (
							:product ("fw1")
							:version ("6.0")
							:feature ("clm")
						)
					)
				)
			)
		)
		# MGMT_MONITOR Blade
		:1002 (
			:key ("")
			:supported_product_types (
				:include_set (
					: ("Management")
				)
			)
			:blade_license_models (
				: (
					:license_triplets (
						: (
							:product ("etm")
							:version ("6.0")
							:feature ("rtm_u")
						)
					)
				)
			)	
		)
		# SMART_EVENT Blade
		:1003 (
			:key ("EVCR")
			:supported_product_types (
				:include_set (
					: ("Management")
					: ("LogServer")
					: ("SmartEvent")
					: ("CorrelationUnit")
				)
				:exclude_set (
					: ("CMA")
					: ("MLM")
				)
			)
			:blade_license_models (
				: (
					:license_triplets (
						: (
							:type ("or")
							: (
								:product ("evnt")
								:version ("6.0")
								:feature ("alzs1")
							)
							: (
								:product ("evnt")
								:version ("6.0")
								:feature ("alzsu")
							)
						)
					)		
				)	
				: (
					:license_triplets (
						: (
							:product ("evnt")
							:version ("6.0")
							:feature ("smrt_evnt")
						)
					)
					:contract_triplets (
						: (
							:product ("services")
							:version ("6.0")
							:feature ("sme_service")
						)
					)
				)
			)
		)
		# SMART_EVENT_INTRO Blade
		:1004 (
			:key ("")
			:supported_product_types (
				:include_set (
					: ("Management")
					: ("LogServer")
					: ("SmartEvent")
					: ("CorrelationUnit")
				)
				:exclude_set (
					: ("CMA")
					: ("MLM")
				)
			)
			:supported_versions  (
				: (
					:range_from ("Unlimited")
					:range_to ("R80")
				)		
			)
			:blade_license_models (
				: (
					:license_triplets (
						: (
							:product ("fw1")
							:version ("6.0")
							:feature ("ipsa")
						)
					)
				)
			)	
		)
		# MGMT_GRC Blade
		:1005 (
			:key ("COMP")
			:supported_product_types (
				:include_set (
					: ("Management")
				)
			)
			:blade_license_models (
				: (
					:license_triplets (
						: (
							:product ("fw1")
							:version ("6.0")
							:feature ("comp")
						)
					)
					:contract_triplets (
						: (
							:product ("services")
							:version ("6.0")
							:feature ("comp_update")
						)
					)
				)
			)
		)
		# MULTI_DOMAIN Blade
		:1006 (
			:key ("")
			:supported_product_types (
				:include_set (
					: ("MDS")
				)
			)
		)
		# MAB Blade
		:2000 (
			:key ("SSLVPN")
			:supported_product_types (
				:include_set (
					: ("Gateway")
					: ("VSX")
				)
			)
			:supported_versions  (
				: (
					:range_from ("R71.10")
					:range_to ("Unlimited")
				)		
			)
			:blade_license_models (
				: (
					:license_triplets (
						: (
							:type ("or")
							: (
								:product ("cvpn")
								:version ("6.0")
								:feature ("cvpn")
							)
							: (
								:product ("cvpn")
								:version ("6.0")
								:feature ("cvpn10users")
							)
							: (
								:product ("cvpn")
								:version ("6.0")
								:feature ("cvpn25users")
							)
							: (
								:product ("cvpn")
								:version ("6.0")
								:feature ("cvpn50users")
							)
							: (
								:product ("cvpn")
								:version ("6.0")
								:feature ("cvpn100users")
							)
							: (
								:product ("cvpn")
								:version ("6.0")
								:feature ("cvpn250users")
							)
							: (
								:product ("cvpn")
								:version ("6.0")
								:feature ("cvpn500users")
							)
							: (
								:product ("cvpn")
								:version ("6.0")
								:feature ("cvpn1000users")
							)
							: (
								:product ("cvpn")
								:version ("6.0")
								:feature ("cvpn2000users")
							)
							: (
								:product ("cvpn")
								:version ("6.0")
								:feature ("cvpn3000users")
							)
							: (
								:product ("cvpn")
								:version ("6.0")
								:feature ("cvpn5000users")
							)
							: (
								:product ("cvpn")
								:version ("6.0")
								:feature ("cvpnunlimited")
							)
						)
					)
				)	
			)
		)
		# MAB_MAIL Blade
		#:2001 (
		#	:key ("")
		#	:supported_product_types (
		#		:include_set (
		#			: ("Gateway")
		#			: ("VSX")
		#		)
		#	)
		#)
		#	:blade_license_models (
		#		: (
		#			:license_triplets (
		#				: (
		#					:product ("cvpn")
		#					:version ("6.0")
		#					:feature ("mobmail")
		#				)
		#			)
		#		)
		#	)	
		#)
	)
)

}= HSvCj7C4yK4Gn4XR7KfitKrzczZKvZfVMepnV5WhQESnqZKHq Index=1 Version=0

(FW1_basic_scheme
		:groups (
				: (user
						:type (string)
						 : (
								 :field_name (user)
								 :field_type (string)
						 )
						 : (
								 :field_name (vpn_user)
								 :field_type (string)
						 )
				)
		)
		:unification (
				: (
						:group (HeaderAction)
						:action (use_internal_action)
                        :context_unification_action (consider_context)
				)
				: (
						:group (HeaderInterfaceDir)
						:action (use_internal_action)
                        :context_unification_action (consider_context)
				)
				: (
						:group (HeaderOrigin)
						:action (use_first_value)
                        :context_unification_action (consider_context)
				)
				: (
						:group (HeaderInterfaceName)
						:action (use_first_significant)
                        :context_unification_action (consider_context)
				)
				: (
						:group (HeaderTime)
                        			:action (use_last_value)
                        :context_unification_action (consider_context)
				)
				: (
						:group (HeaderLogId)
						:action (use_first_value)
                        :context_unification_action (consider_context)
				)
				: (
						:group (HeaderOriginSicName)
						:action (use_first_value)
                        :context_unification_action (consider_context)
				)
				: (
						:group (UP_primary_app_table)
						:action (use_last_value)
						:context_unification_action (consider_context)
				)
				: (
						:group (UP_match_table)
						:action (use_last_value)
						:context_unification_action (consider_context)
				)
				: (
						:group (up_account)
						:action (add_unique_value)
						:context_unification_action (consider_context)
				)		
				: (
						:group (UP_limit)
						:action (add_unique_value)
						:context_unification_action (consider_context)
				)
				: (
						:group (UP_app_table)
						:action (use_last_value)
						:context_unification_action (consider_context)
				)	
				: (
						:group (UP_match_2_app_table)
						:action (use_last_value)
						:context_unification_action (consider_context)
				)
				: (
						:group (UP_urlf_table)
						:action (use_last_value)
						:context_unification_action (consider_context)
				)
				: (
						:group (UP_urlf_user_override_table)
						:action (use_last_value)
						:context_unification_action (consider_context)
				)
				: (
						:group (UP_match_2_data_table)
						:action (use_last_value)
						:context_unification_action (consider_context)
				)	
				: (
						:group (dlpda_file_table)
						:action (append_table_field)
						:context_unification_action (consider_context)
				)		
				: (
						:group (dlpda_data_type_table)
						:action (append_table_field)
						:context_unification_action (consider_context)
				)		
				: (
						:group (dlpda_matched_text_table)
						:action (append_table_field)
						:context_unification_action (consider_context)
				)		
				: (
						:group (dlpda_dt_2_matched_text_table)
						:action (append_table_field)
						:context_unification_action (consider_context)
				)
				: (
						:group (dlpda_match_2_file_table)
						:action (append_table_field)
						:context_unification_action (consider_context)
				)						
				: (
						:group (product)
						:action (add_unique_value)
				)
				: (
						:group (user)
						:action (use_last_value)
						:context_unification_action (consider_context)
				)
				: (
						:group (src_user_name)
						:action (use_last_value)
						:context_unification_action (consider_context)
				)
				: (
						:group (src_machine_name)
						:action (use_last_value)
						:context_unification_action (consider_context)
				)
				: (
						:group (dst_user_name)
						:action (use_last_value)
						:context_unification_action (consider_context)
				)
				: (
						:group (dst_machine_name)
						:action (use_last_value)
						:context_unification_action (consider_context)
				)
				: (
						:group (snid)
						:action (use_last_value)
						:context_unification_action (consider_context)
				)
				: (
						:group (proto)
						:action (use_last_value)
				)
				: (
						:group (src)
						:action (use_last_value)
				)
				: (
						:group (dst)
						:action (use_last_value)
				)
				: (
						:group (service)
						:action (use_last_value)
				)
				: (
						:group (rule)
						:action (use_last_value)
				)
				: (
						:group (message)
						:action (add_value)
				)
				: (
						:group (elapsed)
						:action (add_value)
				)
				: (
						:group (bytes)
						:action (add_value)
						:context_unification_action (consider_context)
				)
				: (
						:group (bytes_received_client)
						:action (add_value)
				)
				: (
						:group (bytes_received_server)
						:action (add_value)
				)
				: (
						:group (bytes_transmitted_client)
						:action (add_value)
				)
				: (
						:group (bytes_transmitted_server)
						:action (add_value)
				)
				: (
						:group (dropped_incoming)
						:action (add_value)
						:context_unification_action (consider_context)
				)
				: (
						:group (dropped_outgoing)
						:action (add_value)
						:context_unification_action (consider_context)
				)
				: (
						:group (dropped_total)
						:action (add_value)
						:context_unification_action (consider_context)
				)
				: (
						:group (client_inbound_packets)
						:action (add_value)
				)
				: (
						:group (client_outbound_packets)
						:action (add_value)
				)
				: (
						:group (h_len)
						:action (add_value)
				)
				: (
						:group (len)
						:action (add_value)
				)
				: (
						:group (packets)
						:action (add_value)
				)
				: (
						:group (packets_received)
						:action (add_value)
				)
				: (
						:group (packets_transmitted)
						:action (add_value)
				)
				: (
						:group (reason)
						:action (add_value)
				)
				: (
						:group (resource)
						:action (add_value)
						:context_unification_action (consider_context)
				)
				: (
						:group (server_inbound_packets)
						:action (add_value)
				)
				: (
						:group (server_outbound_packets)
						:action (add_value)
				)
				: (
						:group (start_time)
						:action (use_first_value)
				)
				: (
						:group (to)
						:action (add_value)
				)
				: (
						:group (from)
						:action (add_unique_value)
				)
				: (
						:group (res_action)
						:action (add_value)
				)
				: (
						:group (file)
						:action (add_value)
				)
				: (
						:group (message_info)
						:action (add_value)
				)
				: (
						:group (server_inbound_bytes)
						:action (add_value)
				)
				: (
						:group (server_outbound_bytes)
						:action (add_value)
				)
				: (
						:group (client_inbound_bytes)
						:action (add_value)
				)
				: (
						:group (client_outbound_bytes)
						:action (add_value)
				)
				: (
						:group (query:)
						:action (add_value)
				)
				: (
						:group (dns_query)
						:action (add_value)
				)
				: (
						:group (dns_type)
						:action (add_value)
				)
				: (
						:group ("src phone number")
						:action (add_value)
				)
				: (
						:group ("dst phone number")
						:action (add_value)
				)
				: (
						:group ("media type")
						:action (add_value)
				)
				: (
						:group ("Log ID")
						:action (add_unique_value)
				)
				: (
						:group ("Suppressed Logs")
						:action (add_value)
				)
				: (
						:group (sent_bytes)
						:action (add_value)
						:context_unification_action (consider_context)
				)
				: (
						:group (received_bytes)
						:action (add_value)
						:context_unification_action (consider_context)
				)
				: (
						:group (spyware_name)
						:action (use_first_value)
				)
				: (
						:group (app_sig_id)
						:action (use_last_value)
				)
				: (
						:group (packet_capture_unique_id)
						:action (add_value)
				)
				: (
						:group (packet_capture_time)
						:action (add_value)
				)
				: (
						:group (packet_capture_name)
						:action (add_value)
				)
				: (
						:group (additional_ip)
						:action (add_unique_value)
				)
				: (
						:group (more_matched_file)
						:action (add_value)
				)
				: (
						:group (more_matched_file_percentage)
						:action (add_value)
				)
				: (
						:group (more_matched_file_text_segments)
						:action (add_value)
				)
				: (
						:group (portal_message)
						:action (use_first_value)
				)
				:default_action (use_last_value)
				:default_context_unification_action (ignore_context)
		)
		:flags_unification (
				: (
						:flag_name (is_sys)
						:action (use_last_value)
				)
		)
		:custom_unification (
           : (
                   :id (134283527)
                   :op (raw)
#	Account Update log
			 )
           : (
                   :id (134283528)
                   :op (raw)
#   URL Update log
			)
		   : (
                   :id (134283529)
                   :op (raw)
#   Connection limit Update log
			 )
       )
		:log_table_join_scheme (
			:table (
				:name (UP_primary_app_table)
				:first_in_join (true)
				:keep_pk_after_join (true)
				:foreign_key (
					:column_index (0)
					:column_name (app_id)
					:keep_pk_after_join (true)
					:foreign_table_name (app_urlf_table)
				)
			)
			:table (
				:name (UP_match_table)
				:first_in_join (true)
				:keep_pk_after_join (true)
			)
			:table (
				:name (UP_match_2_app_table)
				:connection_table (true)
				:foreign_key (
					:column_index (0)
					:column_name (match_id)
					:keep_pk_after_join (true)
					:foreign_table_name (UP_match_table)
				)
				:foreign_key (
					:column_index (1)
					:column_name (id)
					:keep_pk_after_join (true)
					:foreign_table_name (app_urlf_table)
				)
			)
			:table (
				:name (dlpda_match_2_file_table)
				:first_in_join (true)
				:keep_pk_after_join (true)
				:foreign_key (
					:column_index (1)
					:column_name (file_id)
					:keep_pk_after_join (true)
					:foreign_table_name (dlpda_file_table)
				)
			)
			:table (
				:name (dlpda_data_type_table)
				:first_in_join (true)
				:foreign_key (
					:column_index (1)
					:column_name (file_id)
					:keep_pk_after_join (true)
					:foreign_table_name (dlpda_file_table)
				)
			)
			:table (
				:name (dlpda_dt_2_matched_text_table)
				:connection_table (true)
				:foreign_key (
					:column_index (0)
					:column_name (data_type_fk)
					:foreign_table_name (dlpda_data_type_table)
				)
				:foreign_key (
					:column_index (1)
					:column_name (text_fk)
					:foreign_table_name (dlpda_matched_text_table)
				)
			)
		)
		:log_union_scheme (
			:tables_to_union (
				:name (UP_app_table)
				:name (UP_urlf_table)
				:name (UP_urlf_user_override_table)
			)
			:multi_type_column_name (
				:name (name)
				:name (properties)
			)
			:union_table_final_name (app_urlf_table)
		)
		:log_join_alias_name_scheme (
			: (
				:original_name (UP_match_table)
				:alias_name (match_table)
			)
			: (
				:original_name (match_table.match_id)
				:alias_name (match_id)
			)
			: (
				:original_name (match_table.layer_uuid)
				:alias_name (layer_uuid)
			)
			: (
				:original_name (match_table.layer_name)
				:alias_name (layer_name)
			)
			: (
				:original_name (match_table.action)
				:alias_name (rule_action)
			)
			: (
				:original_name (match_table.rule_uid)
				:alias_name (rule_uid)
			)
			: (
				:original_name (match_table.rule_name)
				:alias_name (rule_name)
			)
			: (
				:original_name (match_table.track)
				:alias_name (track)
			)
			: (
				:original_name (match_table.parent_rule)
				:alias_name (parent_rule)
			)
			: (
				:original_name (app_urlf_table.id)
				:alias_name (app_id)
			)
			: (
				:original_name (app_urlf_table.name)
				:alias_name (appi_name)
			)
			: (
				:original_name (app_urlf_table.category)
				:alias_name (app_category)
			)
			: (
				:original_name (app_urlf_table.matched_category)
				:alias_name (matched_category)
			)
			: (
				:original_name (app_urlf_table.properties)
				:alias_name (app_properties)
			)
			: (
				:original_name (app_urlf_table.risk)
				:alias_name (app_risk)
			)
			: (
				:original_name (app_urlf_table.sig_id)
				:alias_name (app_sig_id)
			)
			: (
				:original_name (UP_primary_app_table)
				:alias_name (primary_application)
			)
			: (
				:original_name (primary_application.id)
				:alias_name (app_id)
			)
			: (
				:original_name (primary_application.name)
				:alias_name (appi_name)
			)
			: (
				:original_name (primary_application.category)
				:alias_name (app_category)
			)
			: (
				:original_name (primary_application.matched_category)
				:alias_name (matched_category)
			)
			: (
				:original_name (primary_application.properties)
				:alias_name (app_properties)
			)
			: (
				:original_name (primary_application.risk)
				:alias_name (app_risk)
			)
			: (
				:original_name (primary_application.sig_id)
				:alias_name (app_sig_id)
			)
			: (
				:original_name (dlpda_match_2_file_table)
				:alias_name (file_table)
			)
			: (
				:original_name (file_table.match_id)
				:alias_name (match_id)
			)
			: (
				:original_name (file_table.file_id)
				:alias_name (file_id)
			)
			: (
				:original_name (dlpda_file_table.file_id)
				:alias_name (file_id)
			)
			: (
				:original_name (dlpda_file_table.file_name)
				:alias_name (file_name)
			)
			: (
				:original_name (dlpda_file_table.file_type)
				:alias_name (file_type)
			)
			: (
				:original_name (dlpda_file_table.file_size)
				:alias_name (file_size)
			)
			: (
				:original_name (dlpda_file_table.file_url)
				:alias_name (file_url)
			)
			: (
				:original_name (dlpda_file_table.parent_file_id)
				:alias_name (parent_file_id)
			)
			: (
				:original_name (dlpda_file_table.file_direction)
				:alias_name (file_direction)
			)
			: (
				:original_name (dlpda_data_type_table)
				:alias_name (data_type_table)
			)
			: (
				:original_name (data_type_table.data_type_pk)
				:alias_name (data_type_id)
			)
			: (
				:original_name (data_type_table.data_type_uid)
				:alias_name (data_type_uid)
			)
			: (
				:original_name (data_type_table.data_type_name)
				:alias_name (data_type_name)
			)
			: (
				:original_name (data_type_table.parent_data_type_uid)
				:alias_name (parent_data_type_uid)
			)
			: (
				:original_name (data_type_table.match_id)
				:alias_name (match_id)
			)
			: (
				:original_name (dlpda_matched_text_table)
				:alias_name (matched_text_table)
			)
			: (
				:original_name (matched_text_table.text)
				:alias_name (text)
			)
			: (
				:original_name (matched_text_table.count)
				:alias_name (count)
			)
		)
)
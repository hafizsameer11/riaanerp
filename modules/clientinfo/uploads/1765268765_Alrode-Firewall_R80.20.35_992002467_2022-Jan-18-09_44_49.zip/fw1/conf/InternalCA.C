(
	:mgmt_tools_web_gui (1)
	:mgmt_tools_admin_list (
	)
	:mgmt_tools_user_list (
	)
	:crl_duration (604800)
	:authorization_code_length (6)
	:serial_num_of_digits (5)
)

(
	:accept_ips1_connections_sensor_2_mgmt (
							:name (accept_ips1_connections_sensor_2_mgmt)
							:src (
									: (ips1_sensors_list)
							)
							:dst (
									: (management_list)
							)
							:service (
									: (CPD)
									: (FW1)
									: (FW1_log)
									: (FW1_ica_pull)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_ips1_connections_mgmt_2_sensor (
							:name (accept_ips1_connections_mgmt_2_sensor)
							:src (
									: (management_list)
							)
							:dst (
									: (ips1_sensors_list)
							)
							:service (
									: (CPD)
									: (FW1)
									: (FW1_log)
									: (FW1_ica_pull)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_cprid (
							:name (accept_cprid)
							:src (
									: (management_list)
							)
							:dst (
									: (cp_NG_products_list)
									: (GW)
							)
							:service (
									: (FW1_CPRID)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_dag_dhcp (
							:name (accept_dag_dhcp)
							:src (
									: (Any)
							)
							:dst (
									: (Any)
							)
							:service (
									: (dhcp-req-localmodule)
									: (dhcp-rep-localmodule)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:enable_radius_queries (
							:name (enable_radius_queries)
							:src (
									: (firewalled_list)
									: (GW)
							)
							:dst (
									: (radius_servers_list)
							)
							:service (
									: (Any)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:enable_tacacs_queries (
							:name (enable_tacacs_queries)
							:src (
									: (firewalled_list)
									: (GW)
							)
							:dst (
									: (tacacs_servers_list)
							)
							:service (
									: (Any)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:enable_ldap_queries (
							:name (enable_ldap_queries)
							:src (
									: (GW)
									: (management_list)
									: (firewalled_list)
							)
							:dst (
									: (ldap_servers_list)
							)
							:service (
									: (Any)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_tunnel_test_community (
							:name (accept_tunnel_test_community)
							:src (
									: (Any)
							)
							:dst (
									: (Any)
							)
							:service (
									: (tunnel_test)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_tunnel_test (
							:name (accept_tunnel_test)
							:src (
									: (Any)
							)
							:dst (
									: (Any)
							)
							:service (
									: (tunnel_test)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_tunnel_test_traditional (
							:name (accept_tunnel_test_traditional)
							:src (
									: (Any)
							)
							:dst (
									: (Any)
							)
							:service (
									: (tunnel_test)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:auth_services_real_ports_block (
							:name (auth_services_real_ports_block)
							:src (
									: (Any)
							)
							:dst (
									: (GW)
									: (local_cluster_ips)
							)
							:service (
									: (Any)
							)
							:inspect_func_name ()
							:action (drop)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_icmp (
							:name (accept_icmp)
							:src (
									: (Any)
							)
							:dst (
									: (Any)
							)
							:service (
									: (ICMP)
									: (info-req)
									: (timestamp)
									: (mask-request)
									: (multicast-listener-query)
									: (multicast-listener-report) 
									: (multicast-listener-done) 
									: (router-solicitation) 
									: (router-advertisement) 
									: (neighbor-solicitation) 
									: (neighbor-advertisement) 
									: (ICMPv6) 
									: (redirect6)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_outgoing (
							:name (accept_outgoing)
							:src (
									: (GW)
							)
							:dst (
									: (Any)
							)
							:service (
									: (Any)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_outgoing_to_cp_services (
							:name (accept_outgoing_to_cp_services)
							:src (
									: (GW)
							)
							:dst (
									: (Any)
							)
							:service (
									: (http)
									: (https)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:enable_portal_http (
							:name (enable_portal_http)
							:src (
									: (Any)
							)
							:dst (
									: (Any)
							)
							:service (
									: (HTTP)
									: (HTTPS)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:nac_implied_pep_services (
							:name (nac_implied_pep_services)
							:src (
									: (pdp_list)
							)
							:dst (
									: (Any)
							)
							:service (
									: (Any)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:nac_implied_pdp_services (
							:name (nac_implied_pdp_services)
							:src (
									: (pep_list)
							)
							:dst (
									: (Any)
							)
							:service (
									: (Any)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_cpmi_port (
							:name (accept_cpmi_port)
							:src (
									: (gui_clients_list)
									: (report_server_list)
									: (smartPortal_server_list)
									: (abacus_server_list)
									: (cpmi_clients_list)
							)
							:dst (
									: (management_list)
							)
							:service (
									: (CPMI)
									: (CPM)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (true)
	)
	:accept_cpmi_port_reverse (
							:name (accept_cpmi_port_reverse)
							:src (
									: (management_list)
							)
							:dst (
									: (gui_clients_list)
							)
							:service (
									: (Any)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (true)
	)
	:accept_cpd_port (
							:name (accept_cpd_port)
							:src (
									: (Any)
							)
							:dst (
									: (Any)
							)
							:service (
									: (CPD)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (true)
	)
	:accept_cpd_port_reverse (
							:name (accept_cpd_port_reverse)
							:src (
									: (GW)
							)
							:dst (
									: (mgmt_dynamic_ips)
									: (management_list)
							)
							:service (
									: (Any)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_cpd_amon (
							:name (accept_cpd_amon)
							:src (
									: (Any)
							)
							:dst (
									: (management_list)
									: (firewalled_list)
									: (GW)
									: (abacus_server_list)
									: (event_analyzers_list)
							)
							:service (
									: (CPD_amon)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (true)
	)
	:accept_fw1_sam (
							:name (accept_fw1_sam)
							:src (
									: (management_list)
									: (abacus_server_list)
							)
							:dst (
									: (management_list)
									: (firewalled_list)
									: (GW)
							)
							:service (
									: (FW1_sam)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_fw1_ike_reverse (
							:name (accept_fw1_ike_reverse)
							:src (
									: (GW)
									: (local_cluster_ips)
							)
							:dst (
									: (Any)
							)
							:service (
									: (Any)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_fw1_ike (
							:name (accept_fw1_ike)
							:src (
									: (Any)
							)
							:dst (
									: (GW)
									: (local_cluster_ips)
							)
							:service (
									: (Any)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_fw_ica_pull_port (
							:name (accept_fw_ica_pull_port)
							:src (
									: (Any)
							)
							:dst (
									: (Any)
							)
							:service (
									: (FW1_ica_pull)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_fw_ica_push_port (
							:name (accept_fw_ica_push_port)
							:src (
									: (Any)
							)
							:dst (
									: (management_list)
									: (firewalled_list)
									: (GW)
									: (smartPortal_server_list)
							)
							:service (
									: (FW1_ica_push)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_fw_ica_services_port (
							:name (accept_fw_ica_services_port)
							:src (
									: (Any)
							)
							:dst (
									: (Any)
							)
							:service (
									: (FW1_ica_services)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_cp_rtm (
							:name (accept_cp_rtm)
							:src (
									: (management_list)
							)
							:dst (
									: (rtm_list)
							)
							:service (
									: (CP_rtm)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_cp_redundant (
							:name (accept_cp_redundant)
							:src (
									: (management_list)
							)
							:dst (
									: (management_list)
							)
							:service (
									: (CP_redundant)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_cp_reporting (
							:name (accept_cp_reporting)
							:src (
									: (gui_clients_list)
							)
							:dst (
									: (report_server_list)
							)
							:service (
									: (CP_reporting)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_fw1_ufp (
							:name (accept_fw1_ufp)
							:src (
									: (GW)
							)
							:dst (
									: (ufp_servers_list)
							)
							:service (
									: (Any)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_fw1_cvp (
							:name (accept_fw1_cvp)
							:src (
									: (GW)
							)
							:dst (
									: (cvp_servers_list)
							)
							:service (
									: (Any)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_physical_servers_ping (
							:name (accept_physical_servers_ping)
							:src (
									: (GW)
							)
							:dst (
									: (physical_servers_list)
							)
							:service (
									: (ICMP)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_fw1_lea (
							:name (accept_fw1_lea)
							:src (
									: (Any)
							)
							:dst (
									: (log_server_list) 
									: (management_list)
							)
							:service (
									: (FW1_lea)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_remote_smartlog (
							:name (accept_remote_smartlog)
							:src (
									: (log_server_list) 
									: (management_list)
							)
							:dst (
									: (log_server_list) 
									: (management_list)
							)
							:service (
									: (SML_Remote)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_fw1_seam (
							:name (accept_fw1_seam)
							:src (
									: (event_analyzers_list)
							)
							:dst (
									: (abacus_server_list)
							)
							:service (
									: (CP_seam)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_user_authority (
							:name (accept_user_authority)
							:src (
									: (ua_products_list)
							)
							:dst (
									: (management_list)
							)
							:service (
									: (FW1_ica_push)
									: (CPD)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_uaa_communication (
							:name (accept_uaa_communication)
							:src (
									: (ua_products_list)
							)
							:dst (
									: (ua_products_list)
							)
							:service (
									: (FW1_uaa)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_uaa_amon (
							:name (accept_uaa_amon)
							:src (
									: (ua_products_list)
							)
							:dst (
									: (Any)
							)
							:service (
									: (CPD_amon)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_user_authority_sic (
							:name (accept_user_authority_sic)
							:src (
									: (management_list)
							)
							:dst (
									: (ua_products_list)
							)
							:service (
									: (FW1_ica_push)
									: (CPD)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_fw1_omi_sic (
							:name (accept_fw1_omi_sic)
							:src (
									: (report_server_list)
							)
							:dst (
									: (management_list)
							)
							:service (
									: (FW1_omi-sic)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_rdp_port (
							:name (accept_rdp_port)
							:src (
									: (Any)
							)
							:dst (
									: (Any)
							)
							:service (
									: (sys_srvc_RDP)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_fw1_dag_push (
							:name (accept_fw1_dag_push)
							:src (
									: (management_list)
							)
							:dst (
									: (Any)
							)
							:service (
									: (CPD)
									: (FW1)
									: (FW1_ica_push)
									: (FW1_CPRID)
									: (CPD_amon)
									: (FW1_sam)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_ica_ssl (
							:name (accept_ica_ssl)
							:src (
									: (gui_clients_list)
							)
							:dst (
									: (management_list)
							)
							:service (
									: (FW1_ica_mgmt_tools)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_isp_redundancy_pings (
							:name (accept_isp_redundancy_pings)
							:src (
									: (GW)
							)
							:dst (
									: (Any)
							)
							:service (
									: (ICMP)
									: (info-req)
									: (timestamp)
									: (mask-request)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_swtp_sms (
							:name (accept_swtp_sms)
							:src (
									: (Any)
							)
							:dst (
									: (management_list)
							)
							:service (
									: (SWTP_SMS)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_swtp_gw (
							:name (accept_swtp_gw)
							:src (
									: (management_list)
							)
							:dst (
									: (Any)
							)
							:service (
									: (SWTP_Gateway)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_vpn_ca_enrolment (
							:name (accept_vpn_ca_enrolment)
							:src (
									: (management_list)
							)
							:dst (
									: (ca_servers_addresses)
							)
							:service (
									: (Any)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_av_http (
							:name (accept_av_http)
							:src (
									: (Any)
							)
							:dst (
									: (GW)
									: (local_cluster_ips)
							)
							:service (
									: (Any)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_av_signature_update (
							:name (accept_av_signature_update)
							:src (
									: (firewalled_list)
									: (GW)
									: (management_list)
							)
							:dst (
									: (Any)
							)
							:service (
									: (Any)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_os_cluster_sync (
							 :name (accept_os_cluster_sync)
							 :src (
											 : (cluster_members_ips)
							 )
							 :dst (
											 : (cluster_members_ips)
							 )
							 :service (
											 : (Any)
							 )
							 :inspect_func_name ()
							 :action (accept)
							 :install (Any)
							 :rule_id ()
							 :optimize_drops_support_rule (false)
	)
	:accept_fwd_topo_port (
							:name (accept_fwd_topo_port)
							:src (
									: (Any)
							)
							:dst (
									: (firewalled_list) 
									: (GW)
									: (management_list)
							)
							:service (
									: (FW1_topo)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_fw1_pslogon_ng (
							:name (accept_fw1_pslogon_ng)
							:src (
									: (Any)
							)
							:dst (
									: (NG_policy_server_list)
							)
							:service (
									: (FW1_pslogon_NG)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_scv_status (
							:name (accept_scv_status)
							:src (
									: (Any)
							)
							:dst (
									: (Any)
							)
							:service (
									: (FW1_scv_keep_alive)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_l2tp (
							:name (accept_l2tp)
							:src (
									: (Any)
							)
							:dst (
									: (Any)
							)
							:service (
									: (L2TP)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:multiportal_real_ports_block_in (
							:name (multiportal_real_ports_block_in)
							:src (
									: (Any)
							)
							:dst (
									: (GW)
									: (local_cluster_ips)
							)
							:service (
									: (Any)
							)
							:inspect_func_name ()
							:action (drop)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:multiportal_real_ports_block_out (
							:name (multiportal_real_ports_block_out)
							:src (
				                    : (GW)
									: (local_cluster_ips)
							)
							:dst (
									: (Any)
							)
							:service (
									: (Any)
							)
							:inspect_func_name ()
							:action (drop)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	
	:nac_implied_captive_allow (
							:name (nac_implied_captive_allow)
							:src (
									: (Any)
							)
							:dst (
									: (captive_portal_list)
							)
							:service (
									: (http)
									: (https)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:monitor_blocklist_traffic (
							:name (monitor_blocklist_traffic)
							:src (
									: (Any)
							)
							:dst (
									: (Any)
							)
							:service (
									: (Any)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:drop_blocklist_traffic (
							:name (drop_blocklist_traffic)
							:src (
									: (Any)
							)
							:dst (
									: (Any)
							)
							:service (
									: (Any)
							)
							:inspect_func_name ()
							:action (drop)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:enforce_net_quota (
							:name (enforce_net_quota)
							:src (
									: (Any)
							)
							:dst (
									: (Any)
							)
							:service (
									: (Any)
							)
							:inspect_func_name ()
							:action (drop)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_domain_udp (
							:name (accept_domain_udp)
							:src (
									: (Any)
							)
							:dst (
									: (Any)
							)
							:service (
									: (domain-udp)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_domain_tcp (
							:name (accept_domain_tcp)
							:src (
									: (Any)
							)
							:dst (
									: (Any)
							)
							:service (
									: (domain-tcp)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_rip (
							:name (accept_rip)
							:src (
									: (Any)
							)
							:dst (
									: (Any)
							)
							:service (
									: (rip)
									: (RIPng)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_discovery (
							:name (accept_discovery)
							:src (
									: (Any)
							)
							:dst (
									: (Any)
							)
							:service (
									: (multicast-listener-query)
									: (multicast-listener-report) 
									: (multicast-listener-done) 
									: (router-solicitation) 
									: (router-advertisement) 
									: (neighbor-solicitation) 
									: (neighbor-advertisement) 
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_outgoing_connectra (
							:name (accept_outgoing_connectra)
							:src (
									: (GW)
							)
							:dst (
									: (Any)
							)
							:service (
									: (http)
									: (https)
									: (nbsession)
									: (microsoft-ds)
									: (smtp)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:enable_tcpt (
							:name (enable_tcpt)
							:src (
									: (Any)
							)
							:dst (
									: (GW)
									: (local_cluster_ips)
							)
							:service (
									: (Any)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_office_dhcp_connection (
							:name (accept_office_dhcp_connection)
							:src (
									: (Any)
							)
							:dst (
									: (Any)
							)
							:service (
									: (dhcp-req-localmodule)
									: (dhcp-rep-localmodule)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_fwd_svc_port (
							:name (accept_fwd_svc_port)
							:src (
									: (Any)
							)
							:dst (
									: (firewalled_list)
									: (GW)
									: (management_list)
							)
							:service (
									: (FW1)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_fwd_log_port (
							:name (accept_fwd_log_port)
							:src (
									: (Any)
							)
							:dst (
									: (Any)
							)
							:service (
									: (FW1_log)
									: (FW1_ela)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:enable_load_agent_queries (
							:name (enable_load_agent_queries)
							:src (
									: (GW)
							)
							:dst (
									: (load_servers_list)
							)
							:service (
									: (Any)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:enable_portal_dns (
							:name (enable_portal_dns)
							:src (
									: (GW)
							)
							:dst (
									: (portal_dns_ips)
							)
							:service (
									: (domain-udp)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:enable_portal_wins (
							:name (enable_portal_wins)
							:src (
									: (GW)
							)
							:dst (
									: (portal_wins_ips)
							)
							:service (
									: (nbname)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_connectra_proxy_http (
							:name (accept_connectra_proxy_http)
							:src (
									: (Any)
							)
							:dst (
									: (http_proxy_ips)
							)
							:service (
									: (Any)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_connectra_proxy_https (
							:name (accept_connectra_proxy_https)
							:src (
									: (Any)
							)
							:dst (
									: (https_proxy_ips)
							)
							:service (
									: (Any)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_ipso_cluster_mgmt_protocol (
							:name (accept_ipso_cluster_mgmt_protocol)
							:src (
									: (GW)
									: (cluster_members_ips)
							)
							:dst (
									: (GW)
									: (cluster_members_ips)
							)
							:service (
									: (IPSO_Clustering_Mgmt_Protocol)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_dynamic_routing_sync (
							:name (accept_dynamic_routing_sync)
							:src (
									: (cluster_members_ips)
							)
							:dst (
									: (Any)
							)
							:service (
									: (FIBMGR)
									: (igmp)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_dlpgws_exchange_agents_clear_traffic (
							:name (accept_dlpgws_exchange_agents_clear_traffic)
							:src (
									: (DLPExchangeAgentsSrcIp_list)
							)
							:dst (
									: (GW)
									: (local_cluster_ips)
							)
							:service (
									: (CheckPointExchangeAgent)
									: (FW1_cvp)
									: (FW1_ela)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_dlpgws_exchange_agents_ica (
							:name (accept_dlpgws_exchange_agents_ica)
							:src (
									: (DLPExchangeAgentsSrcIp_list)
							)
							:dst (
									: (GW)
									: (local_cluster_ips)
							)
							:service (
									: (FW1_ica_pull)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_dlpgws_smtp_traffic_from_internal (
							:name (accept_dlpgws_smtp_traffic_from_internal)
							:src (
									: (DLPSMTPServersSrcIp_list)
							)
							:dst (
									: (GW)
									: (local_cluster_ips)
							)
							:service (
									: (smtp)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_dlpgws_usercheck_traffic_from_internal (
							:name (accept_dlpgws_usercheck_traffic_from_internal)
							:src (
									: (Any)
							)
							:dst (
									: (GW)
									: (local_cluster_ips)
							)
							:service (
									: (UserCheck)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_dlpgws_usercheck_traffic_from_any (
							:name (accept_dlpgws_usercheck_traffic_from_any)
							:src (
									: (Any)
							)
							:dst (
									: (GW)
									: (local_cluster_ips)
							)
							:service (
									: (UserCheck)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_dlpgws_smtp_traffic_from_any (
							:name (accept_dlpgws_smtp_traffic_from_any)
							:src (
									: (DLPSMTPServersSrcIp_list)
							)
							:dst (
									: (GW)
									: (local_cluster_ips)
							)
							:service (
									: (smtp)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_dedicated_dlpgws_exchange_clear_traffic (
							:name (accept_dedicated_dlpgws_exchange_clear_traffic)
							:src (
									: (DLPExchangeAgentsSrcIp_list)
							)
							:dst (
									: (GW)
									: (local_cluster_ips)
							)
							:service (
									: (CheckPointExchangeAgent)
									: (FW1_cvp)
									: (FW1_ela)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_dedicated_dlpgws_smtp_traffic (
							:name (accept_dedicated_dlpgws_smtp_traffic)
							:src (
									: (DLPSMTPServersSrcIp_list)
							)
							:dst (
									: (GW)
									: (local_cluster_ips)
							)
							:service (
									: (smtp)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_dlpgws_traffic (
							:name (accept_dlpgws_traffic)
							:src (
									: (Any)
							)
							:dst (
									: (GW)
									: (local_cluster_ips)
							)
							:service (
									: (Any)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_dlpgws_dedicated_traffic_ica (
							:name (accept_dlpgws_dedicated_traffic_ica)
							:src (
									: (Any)
							)
							:dst (
									: (GW)
									: (local_cluster_ips)
							)
							:service (
									: (FW1_ica_pull)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:drop_other_traffic_to_dlpgws (
							:name (drop_other_traffic_to_dlpgws)
							:src (
									: (Any)
							)
							:dst (
									: (GW)
							)
							:service (
									: (Any)
							)
							:inspect_func_name ()
							:action (drop)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:Communities_rule (
							:name (Communities_rule)
							:src (
									: (Any)
							)
							:dst (
									: (Any)
							)
							:service (
									: (Any)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_proxied_conns (
							:name (accept_proxied_conns)
							:src (
									: (GW)
									: (host_ip_addrs)
							)
							:dst (
									: (Any)
							)
							:service (
									: (Any)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:nac_implied_radius_clients_services (
							:name (nac_implied_radius_clients_services)
							:src (
									: (radius_authorized_clients)
							)
							:dst (
									: (GW)
									: (local_cluster_ips)
							)	
							:service (
									: (Any)
							)
							:inspect_func_name ()							
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)							
	)
	:nac_implied_clean_radius_clients_services (
							:name (nac_implied_clean_radius_clients_services)
							:src (
									: (Any)
							)
							:dst (
									: (GW)
									: (local_cluster_ips)
							)
							:service (
									: (Any)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)							
	)
	:client_auth_portal_allow (
							:name (client_auth_portal_allow)
							:src (
									: (Any)
							)
							:dst (
									: (GW)
									: (local_cluster_ips)
							)
							:service (
								: (FW1_clntauth_http)
								: (FW1_clntauth_telnet)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_integrity_server_ports (
							:name (accept_integrity_server_ports)
							:src (
									: (Any)
							)
							:dst (
									: (integrity_list)
									: (firewalled_list)
									: (GW)
							)
							:service (
									: (Any)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
 	:accept_app_mode_back_conn (
                                                        :name (accept_app_mode_back_conn)
                                                        :src (
                                                                        : (native_app_servers)
                                                        )
                                                        :dst (
                                                                        : (Any)
                                                        )
                                                        :service (
                                                                        : (Any)
                                                        )
                                                        :inspect_func_name ()
                                                        :action (accept)
                                                        :install (Any)
                                                        :rule_id ()
                                                        :optimize_drops_support_rule (false)
      )
      :accept_mail_connections_to_gw (
							      :name (accept_mail_connections_to_gw)
							      :src (
											      : (Any)
							      )
							      :dst (
											      : (firewalled_list)
							      )
							      :service (
											      : (smtp)
							      )
							      :inspect_func_name ()
							      :action (accept)
							      :install (Any)
							      :rule_id ()
							      :optimize_drops_support_rule (false)
          )
	      :session_is_accept_cluster_sync (
							      :name (session_is_accept_cluster_sync)
							      :src (
											      : (cluster_members_ips)
							      )
							      :dst (
											      : (cluster_members_ips)
							      )
							      :service (
											      : (tcp-high-ports)
							      )
							      :inspect_func_name ()
							      :action (accept)
							      :install (Any)
							      :rule_id ()
							      :optimize_drops_support_rule (false)
          )
		:te_fake_internet_redirect (
							:name (te_fake_internet_redirect)
							:src (
											: (Any)
							)
							:dst (
											: (Any)
							)
							:service (
											: (http)
											: (domain-udp)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
    )
	:te_fake_internet_drop (
							:name (te_fake_internet_drop)
							:src (
											: (Any)
							)
							:dst (
											: (Any)
							)
							:service (
											: (Any)
							)
							:inspect_func_name ()
							:action (drop)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
    )
	:te_allow_vm_communication (
							:name (te_allow_vm_communication)
							:src (
											: (Any)
							)
							:dst (
											: (Any)
							)
							:service (
											: (Any)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
    )
	:te_allow_internal_communication (
							:name (te_allow_internal_communication)
							:src (
											: (te_list)
							)
							:dst (
											: (te_list)
							)
							:service (
											: (Any)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
    )
    :accept_sfw_webui_access_policy (
   						:name (accept_sfw_webui_access_policy)
   						:src (
	   						: (Any)
   						)
   						:dst (
	   						: (firewalled_list)   						
	   						: (GW)   								
   						)
   						:service (
   							: (Any)
   						)
						:inspect_func_name ()
						:action (accept)
						:install (Any)
						:rule_id ()
						:optimize_drops_support_rule (false)
	)
	:drop_blocked_hosts (
							:name (drop_blocked_hosts)
							:src (
									: (Any)
							)
							:dst (
									: (Any)
							)
							:service (
									: (Any)
							)
							:inspect_func_name ()
							:action (drop)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_sfw_dag_outgoing_ppp_connections (
							:name (accept_sfw_dag_outgoing_ppp_connections)
							:src (
								: (GW)
							)
							:dst (
								: (Any)
							)
							:service (
								: (GRE)
								: (PPTP_TCP)
								: (L2TP)
							)
							:action (accept)
							:inspect_func_name ()
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)	
	:accept_sfw_gw_provided_local_services (
							:name (accept_sfw_gw_provided_local_services)
							:src (
	   							: (Any)
   							)
							:dst (
								: (Any)   								
							)
							:service (
								: (Any_TCP_UDP)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:redirect_sfw_unknown_identity (
							:name (redirect_sfw_unknown_identity)
							:src (
	   							: (Any)
   							)
							:dst (
								: (Any)   								
							)
							:service (
								: (Any_TCP_UDP)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:block_sfw_unknown_identity (
							:name (block_sfw_unknown_identity)
							:src (
	   							: (Any)
   							)
							:dst (
								: (Any)   								
							)
							:service (
								: (Any_TCP_UDP)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
	:accept_sfw_gw_ntp_udp (
							:name (accept_sfw_gw_ntp_udp)
							:src (
	   							: (Any)
   							)
							:dst (
								: (GW)   								
							)
							:service (
								: (ntp-udp)
							)
							:inspect_func_name ()
							:action (accept)
							:install (Any)
							:rule_id ()
							:optimize_drops_support_rule (false)
	)
)

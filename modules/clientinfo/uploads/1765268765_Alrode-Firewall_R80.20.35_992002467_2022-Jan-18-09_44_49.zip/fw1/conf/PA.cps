#
# PA configuration file for the non-cpmi command line.
#
#
# Syntax (of complicated fields. The rest is obvious):
#
# SIMPLE-OID,    Name, OID, Type
#
# COLUMN,        Name, OID, Type, Index-order, Display, Display-Totals
#
# SUM-COLUMN,    Name, Display-Totlas, Column-Name-1, Column-Name-2, ....
#
# OUTPUT-FORMAT, "DEFAULT"/"LIST"    *If does not exist - assumed "DEFAULT"
#
# OID-BASE takes effect only within the section it is in.
#

START-BLOCK

        BLOCK-NAME, "mg"

        OID-BASE, 1.3.6.1.4.1.2620.1.33


        #################################################

        START-FLAVOUR

                FLAVOUR-NAME, "default"

                SIMPLE-OID, "Product Name",              1, STRING
                SIMPLE-OID, "Major version",             2, UINT16
                SIMPLE-OID, "Minor version",             3, UINT16
                SIMPLE-OID, "Build number",              4, UINT32
                SIMPLE-OID, "Version String",            5, STRING
                SIMPLE-OID, "Last received signature",  12, STRING
                SIMPLE-OID, "Last applied signature",   13, STRING
                SIMPLE-OID, "Last received action_id",  14, STRING
                SIMPLE-OID, "Last run action id",       15, STRING
                SIMPLE-OID, "Next working window",      16, UINT32
                SIMPLE-OID, "Last sync time",           17, UINT32
                SIMPLE-OID, "Next sync time",           18, UINT32
                SIMPLE-OID, "PA mode",                  19, INT32
                SIMPLE-OID  "Settings status"           20, INT32
                SIMPLE-OID  "Settings error message"    21, STRING
                SIMPLE-OID, "Status Code",              101, UINT16
                SIMPLE-OID, "Short Status",             102, STRING
                SIMPLE-OID, "Long Status",              103, STRING

        END-FLAVOUR

END-BLOCK
#
# FW configuration file for the non-cpmi command line.
#
#
# Syntax (of complicated fields. The rest is obvious):
#
# SIMPLE-OID,    Name, OID, Type
#
# COLUMN,        Name, OID, Type, Index-order, Display, Display-Totals
#
# SUM-COLUMN,    Name, Display-Totlas, Column-Name-1, Column-Name-2, ....
#
# OUTPUT-FORMAT, "DEFAULT"/"LIST"    *If does not exist - assumed "DEFAULT"  
#
# OID-BASE takes effect only within the section it is in.
#


START-BLOCK

	BLOCK-NAME, "fg"

	OID-BASE, 1.3.6.1.4.1.2620.1.3


######################################################################

	START-FLAVOUR

		FLAVOUR-NAME, "all"
		
			SIMPLE-OID, "Product",        1, STRING
			SIMPLE-OID, "Version",		  4, STRING
			SIMPLE-OID, "Kernel Build",   5, INT32
			SIMPLE-OID, "Policy Name", 	  6, STRING
			SIMPLE-OID, "Install time",   7, STRING
			SIMPLE-OID, "Interfaces Num", 8, INT32

			START-TABLE

				START-TABLE-HEADER
			
					TABLE-NAME,        "Interface table"
					TABLE-OID,         9.1
					PRINT-ONLY-TOTALS, FALSE
					OUTPUT-FORMAT,     DEFAULT

				END-TABLE-HEADER

				START-ROW-SPLITTER
		
				PSEUDO-INDEX-TITLES, "Dir"
				LOGICAL-COLUMN-TITLES, "Limit (Bps)", "Avg Rate (Bps)", "Conns", "Pend pkts", "Pend bytes"

			ROW, "in", "Limit in", "Avg rate in", "Connections in", "Pend pkts in", "Pend bytes in"
			ROW, "out", "Limit out", "Avg rate out", "Connections out", "Pend pkts out","Pend bytes out"

				END-ROW-SPLITTER

				COLUMN,  "Index",                  1, INT32,  1, FALSE, FALSE 
				COLUMN,  "Name", 	        2, STRING, 0, TRUE,  FALSE
				COLUMN,  "Limit in",          4, INT32,  0, TRUE,  FALSE
				COLUMN,  "Limit out",         5, INT32,  0, TRUE,  FALSE
				COLUMN,  "Avg rate in",        6, INT32,  0, TRUE,  FALSE
				COLUMN,  "Avg rate out",       7, INT32,  0, TRUE,  FALSE
				COLUMN,  "Pend pkts in",    10, INT32,  0, TRUE,  FALSE
				COLUMN,  "Pend pkts out",   11, INT32,  0, TRUE,  FALSE
				COLUMN,  "Pend bytes in",      12, INT32,  0, TRUE,  FALSE
				COLUMN,  "Pend bytes out",     13, INT32,  0, TRUE,  FALSE
				COLUMN,  "Connections in",        14, INT32,  0, TRUE,  FALSE
				COLUMN,  "Connections out",       15, INT32,  0, TRUE,  FALSE
			
			END-TABLE
					
	END-FLAVOUR

	
END-BLOCK

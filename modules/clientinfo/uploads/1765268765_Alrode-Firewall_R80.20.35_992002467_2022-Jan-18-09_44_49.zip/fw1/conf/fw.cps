#
# FW configuration file for the non-cpmi command line.
#
#
# Syntax (of complicated fields. The rest is obvious):
#
# SIMPLE-OID,    Name, OID, Type
#
# COLUMN,        Name, OID, Type, Index-order, Display, Display-Totals
#
# SUM-COLUMN,    Name, Display-Totlas, Column-Name-1, Column-Name-2, ....
#
# OUTPUT-FORMAT, "DEFAULT"/"LIST"    *If does not exist - assumed "DEFAULT"  
#
# OID-BASE takes effect only within the section it is in.
#


START-BLOCK

	BLOCK-NAME, "fw"

	OID-BASE, 1.3.6.1.4.1.2620.1.1

######################################################################

	START-FLAVOUR

		FLAVOUR-NAME, "default"

		ADD-OID-ATOM, 25
		
			SIMPLE-OID, "Policy name",  1, STRING
			SIMPLE-OID, "Install time", 2, STRING

			START-TABLE

				START-TABLE-HEADER
			
					TABLE-NAME,        "Interface table"
					TABLE-OID,         5.1
					PRINT-ONLY-TOTALS, FALSE
					OUTPUT-FORMAT,     DEFAULT

				END-TABLE-HEADER

				START-ROW-SPLITTER

					PSEUDO-INDEX-TITLES, "Dir"
					LOGICAL-COLUMN-TITLES, "Total", "Accept", "Deny", "Log"

					ROW, "in",  "Total-In",  "Accept-In",  "Deny-In",  "Log-In"
					ROW, "out", "Total-Out", "Accept-Out", "Deny-Out", "Log-Out"

				END-ROW-SPLITTER

				COLUMN,     "Index",       1, UINT32, 1, FALSE, FALSE 
				COLUMN,     "Name",        2, STRING, 0, TRUE,  FALSE
				SUM-COLUMN, "Total-In",    TRUE, "Accept-In",  "Drop-In",  "Reject-In"
				SUM-COLUMN, "Total-Out",   TRUE, "Accept-Out", "Drop-Out", "Reject-Out"
				COLUMN,     "Accept-In",   5, UINT32, 0, FALSE, TRUE
				COLUMN,     "Accept-Out",  6, UINT32, 0, FALSE, TRUE
				SUM-COLUMN, "Deny-In",     TRUE, "Drop-In",  "Reject-In"
				SUM-COLUMN, "Deny-Out"  ,  TRUE, "Drop-Out", "Reject-Out"
				COLUMN,     "Drop-In",     9, UINT32, 0, FALSE, FALSE
				COLUMN,     "Drop-Out",   10, UINT32, 0, FALSE, FALSE
				COLUMN,     "Reject-In",  11, UINT32, 0, FALSE, FALSE
				COLUMN,     "Reject-Out", 12, UINT32, 0, FALSE, FALSE
				COLUMN,     "Log-In",     13, UINT32, 0, FALSE, TRUE
				COLUMN,     "Log-Out",    14, UINT32, 0, FALSE, TRUE
			
			END-TABLE
			
			START-TABLE

				START-TABLE-HEADER
			
					TABLE-NAME,        "Interface table (64-bit)"
					TABLE-OID,         25.1
					PRINT-ONLY-TOTALS, FALSE
					OUTPUT-FORMAT,     DEFAULT

				END-TABLE-HEADER

				START-ROW-SPLITTER

					PSEUDO-INDEX-TITLES, "Dir"
					LOGICAL-COLUMN-TITLES, "Total", "Accept", "Deny", "Log"

					ROW, "in",  "Total-In",  "Accept-In",  "Deny-In",  "Log-In"
					ROW, "out", "Total-Out", "Accept-Out", "Deny-Out", "Log-Out"

				END-ROW-SPLITTER

				COLUMN,     "Index",       1, UINT32, 1, FALSE, FALSE 
				COLUMN,     "Name",        2, STRING, 0, TRUE,  FALSE
				SUM-COLUMN, "Total-In",    TRUE, "Accept-In",  "Drop-In",  "Reject-In"
				SUM-COLUMN, "Total-Out",   TRUE, "Accept-Out", "Drop-Out", "Reject-Out"
				COLUMN,     "Accept-In",   5, UINT64, 0, FALSE, TRUE
				COLUMN,     "Accept-Out",  6, UINT64, 0, FALSE, TRUE
				SUM-COLUMN, "Deny-In",     TRUE, "Drop-In",  "Reject-In"
				SUM-COLUMN, "Deny-Out"  ,  TRUE, "Drop-Out", "Reject-Out"
				COLUMN,     "Drop-In",     9, UINT64, 0, FALSE, FALSE
				COLUMN,     "Drop-Out",   10, UINT64, 0, FALSE, FALSE
				COLUMN,     "Reject-In",  11, UINT64, 0, FALSE, FALSE
				COLUMN,     "Reject-Out", 12, UINT64, 0, FALSE, FALSE
				COLUMN,     "Log-In",     13, UINT64, 0, FALSE, TRUE
				COLUMN,     "Log-Out",    14, UINT64, 0, FALSE, TRUE
			
			END-TABLE
			
			START-TABLE

				START-TABLE-HEADER
			
					TABLE-NAME,        "ISP link table"
					TABLE-OID,         7.1
					PRINT-ONLY-TOTALS, FALSE
					OUTPUT-FORMAT,     DEFAULT

				END-TABLE-HEADER

				COLUMN,     "Index",       1, UINT32, 1, FALSE, FALSE 
				COLUMN,     "Name",        2, STRING, 0, TRUE,  FALSE
				COLUMN,     "Status",      3, STRING, 0, TRUE,  FALSE
				COLUMN,     "Role",        4, STRING, 0, TRUE,  FALSE
				
			END-TABLE

		REMOVE-OID-ATOM    # Removes the "25" atom
		
	END-FLAVOUR

######################################################################

	START-FLAVOUR

		FLAVOUR-NAME, "interfaces"

			ADD-OID-ATOM, 27

				START-TABLE

					START-TABLE-HEADER

						TABLE-NAME, "Network interfaces"
						TABLE-OID, 1
						PRINT-ONLY-TOTALS, FALSE
						OUTPUT-FORMAT, DEFAULT

					END-TABLE-HEADER

					COLUMN,     "Index",       	 1, UINT32, 	1, FALSE, 	FALSE 
					COLUMN,     "Name",       	 2, STRING, 	0, TRUE,  	FALSE
					COLUMN, 	"IP",			 3, IP, 		0, TRUE, 	FALSE
					COLUMN, 	"Netmask",		 4, IP, 		0, TRUE, 	FALSE
					COLUMN,	"Flags",			 5, UINT32, 	0, TRUE, 	FALSE
					COLUMN	"Peer name",	 6, STRING,	0, TRUE, 	FALSE
					COLUMN	"Remote IP",	 7, IP,		0, TRUE, 	FALSE
					COLUMN	"Topology", 		 8, UINT32,	0, TRUE, 	FALSE
					COLUMN	"Proxy name",	 9, STRING,	0, TRUE,	FALSE
					COLUMN	"Slaves",		10, STRING,	0, TRUE,	FALSE
					COLUMN "Ports",		11, STRING,	0, TRUE,	FALSE
					COLUMN "IPv6 Address",		12, IPV6,	0, TRUE,	FALSE
					COLUMN "IPv6 Len",		13, UINT32,	0, TRUE,	FALSE
					
				END-TABLE

			REMOVE-OID-ATOM

	END-FLAVOUR

######################################################################


######################################################################

	START-FLAVOUR

		FLAVOUR-NAME, "policy" # policy

		SIMPLE-OID, "Product name",  21,  STRING
		
		ADD-OID-ATOM, 25
		
			SIMPLE-OID, "Policy name",           1, STRING
			SIMPLE-OID, "Policy install time",   2, STRING
			SIMPLE-OID, "Num. connections",      3, UINT32
			SIMPLE-OID, "Peak num. connections", 4, UINT32
			SIMPLE-OID, "Connections capacity limit", 10, UINT32
			SIMPLE-OID, "Total accepted packets", 6, UINT64
			SIMPLE-OID, "Total dropped packets",  16, UINT64
			SIMPLE-OID, "Total rejected packets",   14, UINT64
			SIMPLE-OID, "Total accepted bytes",   8, UINT64
			SIMPLE-OID, "Total dropped bytes",    9, UINT64
			SIMPLE-OID, "Total rejected bytes",   15, UINT64
			SIMPLE-OID, "Total logged",   13, UINT64

			START-TABLE

				START-TABLE-HEADER
				
					TABLE-NAME,        "Interface table"
					TABLE-OID,         5.1
					PRINT-ONLY-TOTALS, FALSE
					OUTPUT-FORMAT,     DEFAULT

				END-TABLE-HEADER

				START-ROW-SPLITTER

					PSEUDO-INDEX-TITLES, "Dir"
					LOGICAL-COLUMN-TITLES, "Accept", "Drop", "Reject", "Log"

					ROW, "in",  "Accept-In",  "Drop-In",  "Reject-In",  "Log-In"
					ROW, "out", "Accept-Out", "Drop-Out", "Reject-Out", "Log-Out"

				END-ROW-SPLITTER

				COLUMN, "Index",       1, UINT32, 1, FALSE, FALSE 
				COLUMN, "Name",        2, STRING, 0, TRUE,  FALSE
				COLUMN, "Accept-In",   5, UINT32, 0, FALSE, TRUE
				COLUMN, "Accept-Out",  6, UINT32, 0, FALSE, TRUE
				COLUMN, "Drop-In",     9, UINT32, 0, FALSE, TRUE
				COLUMN, "Drop-Out",   10, UINT32, 0, FALSE, TRUE
				COLUMN, "Reject-In",  11, UINT32, 0, FALSE, TRUE
				COLUMN, "Reject-Out", 12, UINT32, 0, FALSE, TRUE
				COLUMN, "Log-In",     13, UINT32, 0, FALSE, TRUE
				COLUMN, "Log-Out",    14, UINT32, 0, FALSE, TRUE
			
			END-TABLE
			
			START-TABLE

				START-TABLE-HEADER
				
					TABLE-NAME,        "Interface table (64-bit)"
					TABLE-OID,         25.1
					PRINT-ONLY-TOTALS, FALSE
					OUTPUT-FORMAT,     DEFAULT

				END-TABLE-HEADER

				START-ROW-SPLITTER

					PSEUDO-INDEX-TITLES, "Dir"
					LOGICAL-COLUMN-TITLES, "Accept", "Drop", "Reject", "Log"

					ROW, "in",  "Accept-In",  "Drop-In",  "Reject-In",  "Log-In"
					ROW, "out", "Accept-Out", "Drop-Out", "Reject-Out", "Log-Out"

				END-ROW-SPLITTER

				COLUMN, "Index",       1, UINT32, 1, FALSE, FALSE 
				COLUMN, "Name",        2, STRING, 0, TRUE,  FALSE
				COLUMN, "Accept-In",   5, UINT64, 0, FALSE, TRUE
				COLUMN, "Accept-Out",  6, UINT64, 0, FALSE, TRUE
				COLUMN, "Drop-In",     9, UINT64, 0, FALSE, TRUE
				COLUMN, "Drop-Out",   10, UINT64, 0, FALSE, TRUE
				COLUMN, "Reject-In",  11, UINT64, 0, FALSE, TRUE
				COLUMN, "Reject-Out", 12, UINT64, 0, FALSE, TRUE
				COLUMN, "Log-In",     13, UINT64, 0, FALSE, TRUE
				COLUMN, "Log-Out",    14, UINT64, 0, FALSE, TRUE
			
			END-TABLE
			
		REMOVE-OID-ATOM    # Removes the "25" atom
	
	END-FLAVOUR

######################################################################

	START-FLAVOUR

		FLAVOUR-NAME, "perf" # performance

		SIMPLE-OID, "Product name",  21,  STRING
		
		ADD-OID-ATOM, 26
		
			ADD-OID-ATOM, 1
				SIMPLE-OID, "hmem - block size",                1, UINT32
				SIMPLE-OID, "hmem - requested bytes",           2, UINT32
				SIMPLE-OID, "hmem - initial allocated bytes",   3, UINT32
				SIMPLE-OID, "hmem - initial allocated blocks",  4, UINT32
				SIMPLE-OID, "hmem - initial allocated pools",   5, UINT32
				SIMPLE-OID, "hmem - current allocated bytes",   6, UINT32
				SIMPLE-OID, "hmem - current allocated blocks",  7, UINT32
				SIMPLE-OID, "hmem - current allocated pools",   8, UINT32
				SIMPLE-OID, "hmem - maximum bytes",             9, UINT32
				SIMPLE-OID, "hmem - maximum pools",            10, UINT32
				SIMPLE-OID, "hmem - bytes used",               11, UINT32
				SIMPLE-OID, "hmem - blocks used",              12, UINT32
				SIMPLE-OID, "hmem - bytes unused",             13, UINT32
				SIMPLE-OID, "hmem - blocks unused",            14, UINT32
				SIMPLE-OID, "hmem - bytes peak",               15, UINT32
				SIMPLE-OID, "hmem - blocks peak",              16, UINT32
				SIMPLE-OID, "hmem - bytes internal use",       17, UINT32
				SIMPLE-OID, "hmem - number of items",          18, UINT32
				SIMPLE-OID, "hmem - alloc operations",         19, UINT32
				SIMPLE-OID, "hmem - free operations",          20, UINT32
				SIMPLE-OID, "hmem - failed alloc",             21, UINT32
				SIMPLE-OID, "hmem - failed free",              22, UINT32
			REMOVE-OID-ATOM    # Removes the "1" atom

			ADD-OID-ATOM, 2
				SIMPLE-OID, "kmem - system physical mem",       1, UINT32
				SIMPLE-OID, "kmem - available physical mem",    2, UINT32
				SIMPLE-OID, "kmem - aix heap size",             3, UINT32
				SIMPLE-OID, "kmem - bytes used",                4, UINT32
				SIMPLE-OID, "kmem - blocking bytes used",       5, UINT32
				SIMPLE-OID, "kmem - non blocking bytes used",   6, UINT32
				SIMPLE-OID, "kmem - bytes unused",              7, UINT32
				SIMPLE-OID, "kmem - bytes peak",                8, UINT32
				SIMPLE-OID, "kmem - blocking bytes peak",       9, UINT32
				SIMPLE-OID, "kmem - non blocking bytes peak",  10, UINT32
				SIMPLE-OID, "kmem - bytes internal use",       11, UINT32
				SIMPLE-OID, "kmem - number of items",          12, UINT32
				SIMPLE-OID, "kmem - alloc operations",         13, UINT32
				SIMPLE-OID, "kmem - free operations",          14, UINT32
				SIMPLE-OID, "kmem - failed alloc",             15, UINT32
				SIMPLE-OID, "kmem - failed free",              16, UINT32
			REMOVE-OID-ATOM    # Removes the "2" atom

			ADD-OID-ATOM, 3
				SIMPLE-OID, "inspect - packets",                1, UINT32
				SIMPLE-OID, "inspect - operations",             2, UINT32
				SIMPLE-OID, "inspect - lookups",                3, UINT32
				SIMPLE-OID, "inspect - record",                 4, UINT32
				SIMPLE-OID, "inspect - extract",                5, UINT32
			REMOVE-OID-ATOM    # Removes the "3" atom

			ADD-OID-ATOM, 4
				SIMPLE-OID, "cookies - total",                  1, UINT32
				SIMPLE-OID, "cookies - alloc",                  2, UINT32
				SIMPLE-OID, "cookies - free",                   3, UINT32
				SIMPLE-OID, "cookies - dup",                    4, UINT32
				SIMPLE-OID, "cookies - get",                    5, UINT32
				SIMPLE-OID, "cookies - put",                    6, UINT32
				SIMPLE-OID, "cookies - len",                    7, UINT32
			REMOVE-OID-ATOM    # Removes the "4" atom

			ADD-OID-ATOM, 5
				SIMPLE-OID, "chains - alloc",                   1, UINT32
				SIMPLE-OID, "chains - free",                    2, UINT32
			REMOVE-OID-ATOM    # Removes the "5" atom

			ADD-OID-ATOM, 6
				SIMPLE-OID, "fragments - fragments",            1, UINT32
				SIMPLE-OID, "fragments - expired",              2, UINT32
				SIMPLE-OID, "fragments - packets",              3, UINT32
			REMOVE-OID-ATOM    # Removes the "6" atom
			
			ADD-OID-ATOM, 8
				SIMPLE-OID, "ufp - % hits ratio",          1,  UINT32
				SIMPLE-OID, "ufp - total connections",	 2,  UINT32
				SIMPLE-OID, "ufp - hits connections" ,	 3,  UINT32
			REMOVE-OID-ATOM    # Removes the "8" atom

			ADD-OID-ATOM, 9
				ADD-OID-ATOM, 5
				
					SIMPLE-OID, 	 "ufp - session max"  ,     1,UINT32
	 				SIMPLE-OID, 	 "ufp - session current",   2,UINT32
	 				SIMPLE-OID, 	 "ufp - session count" ,    3,UINT32
	 				SIMPLE-OID, 	 "ufp - rej session "  ,    4,UINT32 	
	 				SIMPLE-OID, 	 "ufp - time stamp"	,	    		5,STRING
	 				SIMPLE-OID, 	 "ufp - is alive" 	,  			    6,UINT32


				REMOVE-OID-ATOM    # Removes the "5" atom
			REMOVE-OID-ATOM    # Removes the "9" atom


			ADD-OID-ATOM, 9
				ADD-OID-ATOM, 1
				
					SIMPLE-OID, 	 "http - pid",		 				1,UINT32
					SIMPLE-OID, 	 "http - proto",	 	 				2,UINT32
					SIMPLE-OID, 	 "http - port" ,	 	 				3,UINT16
					SIMPLE-OID, 	 "http - logical port"	,	    	4,UINT16
	 				SIMPLE-OID, 	 "http - max avail socket",	    	5,UINT32
	 				SIMPLE-OID, 	 "http - socket in use max",      	6,UINT32
	 				SIMPLE-OID, 	 "http - socket in use current",  	7,UINT32
	 				SIMPLE-OID, 	 "http - socket in use count", 		8,UINT32
	 				SIMPLE-OID, 	 "http - session max",		    	9,UINT32
	 				SIMPLE-OID, 	 "http - session current",    		10,UINT32
	 				SIMPLE-OID, 	 "http - session count",	  	    	11,UINT32
	 				SIMPLE-OID, 	 "http - auth session max",	  		12,UINT32
	 				SIMPLE-OID, 	 "http - auth session current",    	13,UINT32
	 				SIMPLE-OID, 	 "http - auth session count", 	    14,UINT32
	 				SIMPLE-OID, 	 "http - accepted session"	 ,   	15,UINT32
	 				SIMPLE-OID, 	 "http - rejected session" ,	    	16,UINT32
	 				SIMPLE-OID, 	 "http - auth failures"	,	        17,UINT32
	 				SIMPLE-OID, 	 "http - opsec cvp session max"  ,    18,UINT32
	 				SIMPLE-OID, 	 "http - opsec cvp session current",  19,UINT32
	 				SIMPLE-OID, 	 "http - opsec cvp session count" ,   20,UINT32
	 				SIMPLE-OID, 	 "http - opsec cvp rej session "  ,   21,UINT32
	 				SIMPLE-OID, 	 "http - ssl encryp session max",	    22,UINT32
	 				SIMPLE-OID, 	 "http - ssl encryp session current",	23,UINT32
	 				SIMPLE-OID, 	 "http - ssl encryp session count",   24,UINT32
	 				SIMPLE-OID, 	 "http - transparent session max"	,   25,UINT32
	 				SIMPLE-OID, 	 "http - transparent session current",26,UINT32
	 				SIMPLE-OID, 	 "http - transparent session count" , 27,UINT32
	 				SIMPLE-OID, 	 "http - proxied session max"	 ,      28,UINT32
	 				SIMPLE-OID, 	 "http - proxied session current"	 ,  29,UINT32
	 				SIMPLE-OID, 	 "http - proxied session count" ,     30,UINT32
	 				SIMPLE-OID, 	 "http - tunneled session max"	 ,  31,UINT32
	 				SIMPLE-OID, 	 "http - tunneled session current" ,  32,UINT32
	 				SIMPLE-OID, 	 "http - tunneled session count" ,    33,UINT32
	 				SIMPLE-OID, 	 "http - ftp session max"  	,       34,UINT32
	 				SIMPLE-OID, 	 "http - ftp session current"  	 ,  35,UINT32
	 				SIMPLE-OID, 	 "http - ftp session count" 	,       36,UINT32
	 				SIMPLE-OID, 	 "http - time stamp" 	,  			    37,STRING
	 				SIMPLE-OID, 	 "http - is alive" 	,  			    38,UINT32

			
				REMOVE-OID-ATOM    # Removes the "1" atom

				ADD-OID-ATOM, 2
				
					SIMPLE-OID, 	 "ftp - pid",							 1,UINT32
					SIMPLE-OID, 	 "ftp - proto",	 					 2,UINT32
					SIMPLE-OID, 	 "ftp - port" ,	 	 				 3,UINT16
					SIMPLE-OID, 	 "ftp - logical port"	,	  			 4,UINT16
	 				SIMPLE-OID, 	 "ftp - max avail socket",	  		 5,UINT32
	 				SIMPLE-OID, 	 "ftp - socket in use max",      		 6,UINT32
	 				SIMPLE-OID, 	 "ftp - socket in use current",  		 7,UINT32
	 				SIMPLE-OID, 	 "ftp - socket in use count", 		 8,UINT32
	 				SIMPLE-OID, 	 "ftp - session max",		    		 9,UINT32
	 				SIMPLE-OID, 	 "ftp - session current",    			 10,UINT32
	 				SIMPLE-OID, 	 "ftp - session count",	  	   		 11,UINT32
	 				SIMPLE-OID, 	 "ftp - auth session max",	  	     12,UINT32
	 				SIMPLE-OID, 	 "ftp - auth session current",   		 13,UINT32
	 				SIMPLE-OID, 	 "ftp - auth session count", 	   		 14,UINT32
	 				SIMPLE-OID, 	 "ftp - accepted session"	 ,    		 15,UINT32
	 				SIMPLE-OID, 	 "ftp - rejected session" ,	   		 16,UINT32
	 				SIMPLE-OID, 	 "ftp - auth failures"	,	   		 17,UINT32
	 				SIMPLE-OID, 	 "ftp - opsec cvp session max"  ,   	 18,UINT32
	 				SIMPLE-OID, 	 "ftp - opsec cvp session current",    19,UINT32
	 				SIMPLE-OID, 	 "ftp - opsec cvp session count" , 	 20,UINT32
	 				SIMPLE-OID, 	 "ftp - opsec cvp rej session "  ,  	 21,UINT32
	 	 			SIMPLE-OID, 	 "ftp - time stamp" 	,  			     22,STRING
	 				SIMPLE-OID, 	 "ftp - is alive" 	,  			     23,UINT32

 				
				REMOVE-OID-ATOM    # Removes the "2" atom

				ADD-OID-ATOM, 3
				
					SIMPLE-OID, 	 "telnet - pid",		 				1,UINT32
					SIMPLE-OID, 	 "telnet - proto",	 	 			2,UINT32
					SIMPLE-OID, 	 "telnet - port" ,	 	 			3,UINT16
					SIMPLE-OID, 	 "telnet - logical port"	,	  	    4,UINT16
	 				SIMPLE-OID, 	 "telnet - max avail socket",	    	5,UINT32
	 				SIMPLE-OID, 	 "telnet - socket in use max",      	6,UINT32
	 				SIMPLE-OID, 	 "telnet - socket in use current",   	7,UINT32
	 				SIMPLE-OID, 	 "telnet - socket in use count", 	 	8,UINT32
	 				SIMPLE-OID, 	 "telnet - session max",		    	9,UINT32
	 				SIMPLE-OID, 	 "telnet - session current",    		10,UINT32
	 				SIMPLE-OID, 	 "telnet - session count",	  	    11,UINT32
	 				SIMPLE-OID, 	 "telnet - auth session max",	  		12,UINT32
	 				SIMPLE-OID, 	 "telnet - auth session current",     13,UINT32
	 				SIMPLE-OID, 	 "telnet - auth session count", 	    14,UINT32
	 				SIMPLE-OID, 	 "telnet - accepted session"	 ,      15,UINT32
	 				SIMPLE-OID, 	 "telnet - rejected session" ,	    16,UINT32
	 				SIMPLE-OID, 	 "telnet - auth failures"	,	    	17,UINT32
	 				SIMPLE-OID, 	 "telnet - time stamp"	,	    	18,STRING
 					SIMPLE-OID, 	 "telnet - is alive" 	,  			    19,UINT32

				REMOVE-OID-ATOM    # Removes the "3" atom

				ADD-OID-ATOM, 4
				
					SIMPLE-OID, 	 "rlogin - pid",		 				1,UINT32
					SIMPLE-OID, 	 "rlogin - proto",	 		 		2,UINT32
					SIMPLE-OID, 	 "rlogin - port" ,	 	 			3,UINT16
					SIMPLE-OID, 	 "rlogin - logical port"	,	    	4,UINT16
	 				SIMPLE-OID, 	 "rlogin - max avail socket",	    	5,UINT32
	 				SIMPLE-OID, 	 "rlogin - socket in use max",      	6,UINT32
	 				SIMPLE-OID, 	 "rlogin - socket in use current", 	7,UINT32
	 				SIMPLE-OID, 	 "rlogin - socket in use count", 	 	8,UINT32
	 				SIMPLE-OID, 	 "rlogin - session max",		    	9,UINT32
	 				SIMPLE-OID, 	 "rlogin - session current",    		10,UINT32
	 				SIMPLE-OID, 	 "rlogin - session count",	  	    11,UINT32
	 				SIMPLE-OID, 	 "rlogin - auth session max",	  		12,UINT32
	 				SIMPLE-OID, 	 "rlogin - auth session current",    	13,UINT32
	 				SIMPLE-OID, 	 "rlogin - auth session count", 	   	14,UINT32
	 				SIMPLE-OID, 	 "rlogin - accepted session"	 ,    	15,UINT32
	 				SIMPLE-OID, 	 "rlogin - rejected session" ,	    16,UINT32
	 				SIMPLE-OID, 	 "rlogin - auth failures"	,	    	17,UINT32
 					SIMPLE-OID, 	 "rlogin - time stamp"	,	    	18,STRING
	 				SIMPLE-OID, 	 "rlogin - is alive" 	,  			    19,UINT32


				REMOVE-OID-ATOM    # Removes the "4" atom

				ADD-OID-ATOM, 6
				
					SIMPLE-OID, 	 "smtp - pid",		 				1,UINT32
					SIMPLE-OID, 	 "smtp - proto",	 	 				2,UINT32
					SIMPLE-OID, 	 "smtp - port" ,	 	 				3,UINT16
					SIMPLE-OID, 	 "smtp - logical port"	,	    	4,UINT16
	 				SIMPLE-OID, 	 "smtp - max avail socket",	    	5,UINT32
	 				SIMPLE-OID, 	 "smtp - socket in use max",      	6,UINT32
	 				SIMPLE-OID, 	 "smtp - socket in use current",   	7,UINT32
	 				SIMPLE-OID, 	 "smtp - socket in use count", 	 	8,UINT32
	 				SIMPLE-OID, 	 "smtp - session max",		    	9,UINT32
	 				SIMPLE-OID, 	 "smtp - session current",    		10,UINT32
	 				SIMPLE-OID, 	 "smtp - session count",	  	    	11,UINT32
	 				SIMPLE-OID, 	 "smtp - accepted session"	 ,    	15,UINT32
	 				SIMPLE-OID, 	 "smtp - rejected session" ,	    	16,UINT32
	 				SIMPLE-OID,		 "smtp - mail max",   			 	18,UINT32
					SIMPLE-OID,		 "smtp - mail curr",  			 	19,UINT32
					SIMPLE-OID,		 "smtp - mail count",  				20,UINT32
					SIMPLE-OID,		 "smtp - outgoing mail max",   		21,UINT32
					SIMPLE-OID,		 "smtp - outgoing mail curr",  		22,UINT32
					SIMPLE-OID,		 "smtp - outgoing mail count",  		23,UINT32
					SIMPLE-OID,		 "smtp - max mail on conn",  			24,UINT32	
					SIMPLE-OID,		 "smtp - total mails ", 		    	25,UINT32
					SIMPLE-OID, 	 "smtp - time stamp"	,	    		26,STRING
	 				SIMPLE-OID, 	 "smtp - is alive" 	,  			    27,UINT32

	
				REMOVE-OID-ATOM    # Removes the "6" atom
			REMOVE-OID-ATOM    # Removes the "9" atom

			ADD-OID-ATOM, 10
				ADD-OID-ATOM, 1		
					SIMPLE-OID, 	 "sync - configured",		 				1,STRING
					SIMPLE-OID, 	 "sync - out state",		 					2,STRING
					SIMPLE-OID, 	 "sync - in state",		 					3,STRING
					SIMPLE-OID, 	 "sync - number of sent packets",		 		4,UINT32
					SIMPLE-OID, 	 "sync - number of Kbytes sent",		 		5,UINT32
					SIMPLE-OID, 	 "sync - number of packets received",		 	6,UINT32
					SIMPLE-OID, 	 "sync - number of Kbytes received",		 		7,UINT32
					SIMPLE-OID, 	 "sync - number of retrans requests sent",		 	8,UINT32
					SIMPLE-OID, 	 "sync - number of retrans requests received",		9,UINT32
					SIMPLE-OID, 	 "sync - number of ack packets sent",		 		10,UINT32
					SIMPLE-OID, 	 "sync - number of ack packets received",		 	11,UINT32
					SIMPLE-OID, 	 "sync - number of packets dropped by network",	12,UINT32
					SIMPLE-OID, 	 "sync - overall number of table updates to be synced",		13,UINT32
					SIMPLE-OID, 	 "sync - number of updates filtered by 'non sync'",	14,UINT32
				REMOVE-OID-ATOM    # Removes the "1" atom
			REMOVE-OID-ATOM    # Removes the "10" atom

		REMOVE-OID-ATOM    # Removes the "26" atom
	
	END-FLAVOUR
		
######################################################################

	START-FLAVOUR

		FLAVOUR-NAME, "hmem" # hmem

		SIMPLE-OID, "Product name",  21,  STRING
		
		ADD-OID-ATOM, 26
		
			ADD-OID-ATOM, 1
				SIMPLE-OID, "hmem - block size",                1, UINT32
				SIMPLE-OID, "hmem - requested bytes",           2, UINT32
				SIMPLE-OID, "hmem - initial allocated bytes",   3, UINT32
				SIMPLE-OID, "hmem - initial allocated blocks",  4, UINT32
				SIMPLE-OID, "hmem - initial allocated pools",   5, UINT32
				SIMPLE-OID, "hmem - current allocated bytes",   6, UINT32
				SIMPLE-OID, "hmem - current allocated blocks",  7, UINT32
				SIMPLE-OID, "hmem - current allocated pools",   8, UINT32
				SIMPLE-OID, "hmem - maximum bytes",             9, UINT32
				SIMPLE-OID, "hmem - maximum pools",            10, UINT32
				SIMPLE-OID, "hmem - bytes used",               11, UINT32
				SIMPLE-OID, "hmem - blocks used",              12, UINT32
				SIMPLE-OID, "hmem - bytes unused",             13, UINT32
				SIMPLE-OID, "hmem - blocks unused",            14, UINT32
				SIMPLE-OID, "hmem - bytes peak",               15, UINT32
				SIMPLE-OID, "hmem - blocks peak",              16, UINT32
				SIMPLE-OID, "hmem - bytes internal use",       17, UINT32
				SIMPLE-OID, "hmem - number of items",          18, UINT32
				SIMPLE-OID, "hmem - alloc operations",         19, UINT32
				SIMPLE-OID, "hmem - free operations",          20, UINT32
				SIMPLE-OID, "hmem - failed alloc",             21, UINT32
				SIMPLE-OID, "hmem - failed free",              22, UINT32
			REMOVE-OID-ATOM    # Removes the "1" atom

	END-FLAVOUR

######################################################################

	START-FLAVOUR

		FLAVOUR-NAME, "kmem" # kmem

		SIMPLE-OID, "Product name",  21,  STRING
		
		ADD-OID-ATOM, 26
		
			ADD-OID-ATOM, 2
				SIMPLE-OID, "kmem - system physical mem",       1, UINT32
				SIMPLE-OID, "kmem - available physical mem",    2, UINT32
				SIMPLE-OID, "kmem - aix heap size",             3, UINT32
				SIMPLE-OID, "kmem - bytes used",                4, UINT32
				SIMPLE-OID, "kmem - blocking bytes used",       5, UINT32
				SIMPLE-OID, "kmem - non blocking bytes used",   6, UINT32
				SIMPLE-OID, "kmem - bytes unused",              7, UINT32
				SIMPLE-OID, "kmem - bytes peak",                8, UINT32
				SIMPLE-OID, "kmem - blocking bytes peak",       9, UINT32
				SIMPLE-OID, "kmem - non blocking bytes peak",  10, UINT32
				SIMPLE-OID, "kmem - bytes internal use",       11, UINT32
				SIMPLE-OID, "kmem - number of items",          12, UINT32
				SIMPLE-OID, "kmem - alloc operations",         13, UINT32
				SIMPLE-OID, "kmem - free operations",          14, UINT32
				SIMPLE-OID, "kmem - failed alloc",             15, UINT32
				SIMPLE-OID, "kmem - failed free",              16, UINT32
			REMOVE-OID-ATOM    # Removes the "2" atom

	END-FLAVOUR

######################################################################

	START-FLAVOUR

		FLAVOUR-NAME, "inspect" # inspect

		SIMPLE-OID, "Product name",  21,  STRING
		
		ADD-OID-ATOM, 26
		
			ADD-OID-ATOM, 3
				SIMPLE-OID, "inspect - packets",       1, UINT32
				SIMPLE-OID, "inspect - operations",    2, UINT32
				SIMPLE-OID, "inspect - lookups",       3, UINT32
				SIMPLE-OID, "inspect - record",        4, UINT32
				SIMPLE-OID, "inspect - extract",       5, UINT32
			REMOVE-OID-ATOM    # Removes the "3" atom
	
		REMOVE-OID-ATOM    # Removes the "26" atom
		
	END-FLAVOUR


######################################################################

	START-FLAVOUR

		FLAVOUR-NAME, "cookies" # cookies

		SIMPLE-OID, "Product name",  21,  STRING
		
		ADD-OID-ATOM, 26
		
			ADD-OID-ATOM, 4
				SIMPLE-OID, "cookies - total",        1, UINT32
				SIMPLE-OID, "cookies - alloc",        2, UINT32
				SIMPLE-OID, "cookies - free",         3, UINT32
				SIMPLE-OID, "cookies - dup",          4, UINT32
				SIMPLE-OID, "cookies - get",          5, UINT32
				SIMPLE-OID, "cookies - put",          6, UINT32
				SIMPLE-OID, "cookies - len",          7, UINT32
			REMOVE-OID-ATOM    # Removes the "4" atom
	
		REMOVE-OID-ATOM    # Removes the "26" atom
		
	END-FLAVOUR

######################################################################

	START-FLAVOUR

		FLAVOUR-NAME, "chains" # chains

		SIMPLE-OID, "Product name",  21,  STRING
		
		ADD-OID-ATOM, 26

			ADD-OID-ATOM, 5
				SIMPLE-OID, "chains - alloc",          1, UINT32
				SIMPLE-OID, "chains - free",           2, UINT32
			REMOVE-OID-ATOM    # Removes the "5" atom
	
		REMOVE-OID-ATOM    # Removes the "26" atom
		
	END-FLAVOUR


######################################################################

	START-FLAVOUR

		FLAVOUR-NAME, "fragments" # fragments

		SIMPLE-OID, "Product name",  21,  STRING
		
		ADD-OID-ATOM, 26

			ADD-OID-ATOM, 6
				SIMPLE-OID, "fragments - fragments",            1,  UINT32
				SIMPLE-OID, "fragments - expired",              2,  UINT32
				SIMPLE-OID, "fragments - packets",              3,  UINT32
			REMOVE-OID-ATOM    # Removes the "6" atom
	
		REMOVE-OID-ATOM    # Removes the "26" atom
		
	END-FLAVOUR
	
######################################################################

	START-FLAVOUR

		FLAVOUR-NAME, "totals" # totals

		ADD-OID-ATOM, 25

			START-TABLE

				START-TABLE-HEADER
				
					TABLE-OID,         5.1
					PRINT-ONLY-TOTALS, TRUE
					OUTPUT-FORMAT,     DEFAULT

				END-TABLE-HEADER

				COLUMN,     "Index",       1, UINT32, 1, FALSE, FALSE 
				SUM-COLUMN, "Accept",      TRUE, "Accept-In", "Accept-Out",
				SUM-COLUMN, "Deny",        TRUE, "Drop-In", "Drop-Out", "Reject-In", "Reject-Out"
				SUM-COLUMN, "Log",         TRUE, "Log-In", "Log-Out",
				COLUMN,     "Accept-In",   5, UINT32, 0, FALSE, TRUE
				COLUMN,     "Accept-Out",  6, UINT32, 0, FALSE, TRUE
				COLUMN,     "Drop-In",     9, UINT32, 0, FALSE, TRUE
				COLUMN,     "Drop-Out",   10, UINT32, 0, FALSE, TRUE
				COLUMN,     "Reject-In",  11, UINT32, 0, FALSE, TRUE
				COLUMN,     "Reject-Out", 12, UINT32, 0, FALSE, TRUE
				COLUMN,     "Log-In",     13, UINT32, 0, FALSE, TRUE
				COLUMN,     "Log-Out",    14, UINT32, 0, FALSE, TRUE
			
			END-TABLE
			
		REMOVE-OID-ATOM    # Removes the "25" atom
		
	END-FLAVOUR
	
######################################################################

	START-FLAVOUR

		FLAVOUR-NAME, "totals64" # totals

		ADD-OID-ATOM, 25

			START-TABLE

				START-TABLE-HEADER
				
					TABLE-OID,         25.1
					PRINT-ONLY-TOTALS, TRUE
					OUTPUT-FORMAT,     DEFAULT

				END-TABLE-HEADER

				COLUMN,     "Index",       1, UINT32, 1, FALSE, FALSE 
				SUM-COLUMN, "Accept",      TRUE, "Accept-In", "Accept-Out",
				SUM-COLUMN, "Deny",        TRUE, "Drop-In", "Drop-Out", "Reject-In", "Reject-Out"
				SUM-COLUMN, "Log",         TRUE, "Log-In", "Log-Out",
				COLUMN,     "Accept-In",   5, UINT64, 0, FALSE, TRUE
				COLUMN,     "Accept-Out",  6, UINT64, 0, FALSE, TRUE
				COLUMN,     "Drop-In",     9, UINT64, 0, FALSE, TRUE
				COLUMN,     "Drop-Out",   10, UINT64, 0, FALSE, TRUE
				COLUMN,     "Reject-In",  11, UINT64, 0, FALSE, TRUE
				COLUMN,     "Reject-Out", 12, UINT64, 0, FALSE, TRUE
				COLUMN,     "Log-In",     13, UINT64, 0, FALSE, TRUE
				COLUMN,     "Log-Out",    14, UINT64, 0, FALSE, TRUE
			
			END-TABLE

		REMOVE-OID-ATOM    # Removes the "25" atom

	END-FLAVOUR

######################################################################

	START-FLAVOUR

		FLAVOUR-NAME, "ufp" # ufp

		ADD-OID-ATOM, 26

			ADD-OID-ATOM, 8
				SIMPLE-OID, "ufp - % hits ratio",        1,  UINT32
				SIMPLE-OID, "ufp - total connections",	 2,  UINT32
				SIMPLE-OID, "ufp - hits connections" ,	 3,  UINT32
			REMOVE-OID-ATOM    # Removes the "1" atom
			
			ADD-OID-ATOM, 9
				ADD-OID-ATOM, 5
				
					SIMPLE-OID, 	 "ufp - session max"  ,     1,UINT32
	 				SIMPLE-OID, 	 "ufp - session current",   2,UINT32
	 				SIMPLE-OID, 	 "ufp - session count" ,    3,UINT32
	 				SIMPLE-OID, 	 "ufp - rej session "  ,    4,UINT32
	 				SIMPLE-OID, 	 "ufp - time stamp",		5,STRING
	 				SIMPLE-OID, 	 "ufp - is alive" 	,		6,UINT32

				REMOVE-OID-ATOM    # Removes the "5" atom
			REMOVE-OID-ATOM    # Removes the "9" atom
		REMOVE-OID-ATOM    # Removes the "26" atom
		
	END-FLAVOUR
	
######################################################################

	START-FLAVOUR

		FLAVOUR-NAME, "http" # http

		ADD-OID-ATOM, 26

			ADD-OID-ATOM, 9
				ADD-OID-ATOM, 1
				
					SIMPLE-OID, 	 "http - pid",							1,UINT32
					SIMPLE-OID, 	 "http - proto",						2,UINT32
					SIMPLE-OID, 	 "http - port" ,						3,UINT16
					SIMPLE-OID, 	 "http - logical port"	,				4,UINT16
	 				SIMPLE-OID, 	 "http - max avail socket",				5,UINT32
	 				SIMPLE-OID, 	 "http - socket in use max",			6,UINT32
	 				SIMPLE-OID, 	 "http - socket in use current",		7,UINT32
	 				SIMPLE-OID, 	 "http - socket in use count", 			8,UINT32
	 				SIMPLE-OID, 	 "http - session max",					9,UINT32
	 				SIMPLE-OID, 	 "http - session current",				10,UINT32
	 				SIMPLE-OID, 	 "http - session count",				11,UINT32
	 				SIMPLE-OID, 	 "http - auth session max",				12,UINT32
	 				SIMPLE-OID, 	 "http - auth session current",	    	13,UINT32
	 				SIMPLE-OID, 	 "http - auth session count", 			14,UINT32
	 				SIMPLE-OID, 	 "http - accepted session"	 ,			15,UINT32
	 				SIMPLE-OID, 	 "http - rejected session" ,	    	16,UINT32
	 				SIMPLE-OID, 	 "http - auth failures"	,				17,UINT32
	 				SIMPLE-OID, 	 "http - opsec cvp session max",		18,UINT32
	 				SIMPLE-OID, 	 "http - opsec cvp session current",	19,UINT32
	 				SIMPLE-OID, 	 "http - opsec cvp session count" ,		20,UINT32
	 				SIMPLE-OID, 	 "http - opsec cvp rej session "  ,		21,UINT32
	 				SIMPLE-OID, 	 "http - ssl encryp session max",		22,UINT32
	 				SIMPLE-OID, 	 "http - ssl encryp session current",	23,UINT32
	 				SIMPLE-OID, 	 "http - ssl encryp session count",		24,UINT32
	 				SIMPLE-OID, 	 "http - transparent session max"	,	25,UINT32
	 				SIMPLE-OID, 	 "http - transparent session current",	26,UINT32
	 				SIMPLE-OID, 	 "http - transparent session count" ,	27,UINT32
	 				SIMPLE-OID, 	 "http - proxied session max"	 ,      28,UINT32
	 				SIMPLE-OID, 	 "http - proxied session current"	 ,  29,UINT32
	 				SIMPLE-OID, 	 "http - proxied session count" ,		30,UINT32
	 				SIMPLE-OID, 	 "http - tunneled session max"	 ,		31,UINT32
	 				SIMPLE-OID, 	 "http - tunneled session current" ,	32,UINT32
	 				SIMPLE-OID, 	 "http - tunneled session count" ,		33,UINT32
	 				SIMPLE-OID, 	 "http - ftp session max"  	,			34,UINT32
	 				SIMPLE-OID, 	 "http - ftp session current"  	 ,		35,UINT32
	 				SIMPLE-OID, 	 "http - ftp session count" 	,       36,UINT32
	 				SIMPLE-OID, 	 "http - time stamp" 	,  			    37,STRING
	 				SIMPLE-OID, 	 "http - is alive" 	,  					38,UINT32
	 				SIMPLE-OID, 	 "http - CI total infected" 	,  		39,UINT32
	 				SIMPLE-OID, 	 "http - CI total blocked" 	,  	    	40,UINT32
	 				SIMPLE-OID, 	 "http - CI total scanned" 	,   		41,UINT32

				REMOVE-OID-ATOM    # Removes the "1" atom
			REMOVE-OID-ATOM    # Removes the "9" atom
		REMOVE-OID-ATOM    # Removes the "26" atom
		
	END-FLAVOUR



######################################################################

	START-FLAVOUR

		FLAVOUR-NAME, "ftp" # ftp

		ADD-OID-ATOM, 26

			ADD-OID-ATOM, 9
				ADD-OID-ATOM, 2
				
					SIMPLE-OID, 	 "ftp - pid",						1,UINT32
					SIMPLE-OID, 	 "ftp - proto",	 					2,UINT32
					SIMPLE-OID, 	 "ftp - port" ,	 	 				3,UINT16
					SIMPLE-OID, 	 "ftp - logical port"	,	  		4,UINT16
	 				SIMPLE-OID, 	 "ftp - max avail socket",	  		5,UINT32
	 				SIMPLE-OID, 	 "ftp - socket in use max",      	6,UINT32
	 				SIMPLE-OID, 	 "ftp - socket in use current",  	7,UINT32
	 				SIMPLE-OID, 	 "ftp - socket in use count", 		8,UINT32
	 				SIMPLE-OID, 	 "ftp - session max",		    	9,UINT32
	 				SIMPLE-OID, 	 "ftp - session current",    		10,UINT32
	 				SIMPLE-OID, 	 "ftp - session count",	  	   		11,UINT32
	 				SIMPLE-OID, 	 "ftp - auth session max",	  	    12,UINT32
	 				SIMPLE-OID, 	 "ftp - auth session current",   	13,UINT32
	 				SIMPLE-OID, 	 "ftp - auth session count", 	   	14,UINT32
	 				SIMPLE-OID, 	 "ftp - accepted session"	 ,    	15,UINT32
	 				SIMPLE-OID, 	 "ftp - rejected session" ,	   		16,UINT32
	 				SIMPLE-OID, 	 "ftp - auth failures"	,	   		17,UINT32
	 				SIMPLE-OID, 	 "ftp - opsec cvp session max"  ,   18,UINT32
	 				SIMPLE-OID, 	 "ftp - opsec cvp session current", 19,UINT32
	 				SIMPLE-OID, 	 "ftp - opsec cvp session count" , 	20,UINT32
	 				SIMPLE-OID, 	 "ftp - opsec cvp rej session "  ,  21,UINT32
	 	 			SIMPLE-OID, 	 "ftp - time stamp" 	,  			22,STRING
	 				SIMPLE-OID, 	 "ftp - is alive" 	,  			    23,UINT32
	 				SIMPLE-OID, 	 "ftp - CI total infected" 	,  		24,UINT32
	 				SIMPLE-OID, 	 "ftp - CI total blocked" 	,     	25,UINT32
	 				SIMPLE-OID, 	 "ftp - CI total scanned" 	,  		26,UINT32

 				
				REMOVE-OID-ATOM    # Removes the "2" atom
			REMOVE-OID-ATOM    # Removes the "9" atom
		REMOVE-OID-ATOM    # Removes the "26" atom
		
	END-FLAVOUR

######################################################################

	START-FLAVOUR

		FLAVOUR-NAME, "telnet" # telnet

		ADD-OID-ATOM, 26

			ADD-OID-ATOM, 9
				ADD-OID-ATOM, 3
				
					SIMPLE-OID, 	 "telnet -  pid",		 			1,UINT32
					SIMPLE-OID, 	 "telnet -  proto",	 	 			2,UINT32
					SIMPLE-OID, 	 "telnet -  port" ,	 	 			3,UINT16
					SIMPLE-OID, 	 "telnet -  logical port"	,	  	4,UINT16
	 				SIMPLE-OID, 	 "telnet -  max avail socket",	    5,UINT32
	 				SIMPLE-OID, 	 "telnet -  socket in use max",     6,UINT32
	 				SIMPLE-OID, 	 "telnet -  socket in use current", 7,UINT32
	 				SIMPLE-OID, 	 "telnet -  socket in use count", 	8,UINT32
	 				SIMPLE-OID, 	 "telnet -  session max",		    9,UINT32
	 				SIMPLE-OID, 	 "telnet -  session current",    	10,UINT32
	 				SIMPLE-OID, 	 "telnet -  session count",	  	    11,UINT32
	 				SIMPLE-OID, 	 "telnet -  auth session max",	  	12,UINT32
	 				SIMPLE-OID, 	 "telnet -  auth session current",  13,UINT32
	 				SIMPLE-OID, 	 "telnet -  auth session count", 	14,UINT32
	 				SIMPLE-OID, 	 "telnet -  accepted session"	 ,  15,UINT32
	 				SIMPLE-OID, 	 "telnet -  rejected session" ,	    16,UINT32
	 				SIMPLE-OID, 	 "telnet -  auth failures"	,	    17,UINT32
	 				SIMPLE-OID, 	 "telnet -  time stamp"	,	    	18,STRING
	 				SIMPLE-OID, 	 "telnet -  is alive" 	,  			19,UINT32

 				
				REMOVE-OID-ATOM    # Removes the "3" atom
			REMOVE-OID-ATOM    # Removes the "9" atom
		REMOVE-OID-ATOM    # Removes the "26" atom
		
	END-FLAVOUR

######################################################################

	START-FLAVOUR

		FLAVOUR-NAME, "rlogin" # rlogin

		ADD-OID-ATOM, 26

			ADD-OID-ATOM, 9
				ADD-OID-ATOM, 4
				
					SIMPLE-OID, 	 "rlogin - pid",		 			1,UINT32
					SIMPLE-OID, 	 "rlogin - proto",	 		 		2,UINT32
					SIMPLE-OID, 	 "rlogin - port" ,	 	 			3,UINT16
					SIMPLE-OID, 	 "rlogin - logical port"	,	    4,UINT16
	 				SIMPLE-OID, 	 "rlogin - max avail socket",	    5,UINT32
	 				SIMPLE-OID, 	 "rlogin - socket in use max",      6,UINT32
	 				SIMPLE-OID, 	 "rlogin- socket in use current", 	7,UINT32
	 				SIMPLE-OID, 	 "rlogin - socket in use count", 	8,UINT32
	 				SIMPLE-OID, 	 "rlogin - session max",		    9,UINT32
	 				SIMPLE-OID, 	 "rlogin - session current",    	10,UINT32
	 				SIMPLE-OID, 	 "rlogin - session count",	  	    11,UINT32
	 				SIMPLE-OID, 	 "rlogin - auth session max",	  	12,UINT32
	 				SIMPLE-OID, 	 "rlogin - auth session current",   13,UINT32
	 				SIMPLE-OID, 	 "rlogin - auth session count", 	14,UINT32
	 				SIMPLE-OID, 	 "rlogin - accepted session"	 ,  15,UINT32
	 				SIMPLE-OID, 	 "rlogin - rejected session" ,	    16,UINT32
	 				SIMPLE-OID, 	 "rlogin - auth failures"	,	    17,UINT32
	 				SIMPLE-OID, 	 "rlogin - time stamp"	,	    	18,STRING
	 				SIMPLE-OID, 	 "rlogin - is alive" 	,  			19,UINT32


				REMOVE-OID-ATOM    # Removes the "4" atom
			REMOVE-OID-ATOM    # Removes the "9" atom
		REMOVE-OID-ATOM    # Removes the "26" atom
	

	END-FLAVOUR

######################################################################

	START-FLAVOUR

		FLAVOUR-NAME, "smtp" # smtp

		ADD-OID-ATOM, 26

			ADD-OID-ATOM, 9
				ADD-OID-ATOM, 6
				
					SIMPLE-OID, 	 "smtp - pid",		 				1,UINT32
					SIMPLE-OID, 	 "smtp - proto",	 	 			2,UINT32
					SIMPLE-OID, 	 "smtp - port" ,	 	 			3,UINT16
					SIMPLE-OID, 	 "smtp - logical port"	,	    	4,UINT16
	 				SIMPLE-OID, 	 "smtp - max avail socket",	    	5,UINT32
	 				SIMPLE-OID, 	 "smtp - socket in use max",      	6,UINT32
	 				SIMPLE-OID, 	 "smtp - socket in use current",   	7,UINT32
	 				SIMPLE-OID, 	 "smtp - socket in use count", 	 	8,UINT32
	 				SIMPLE-OID, 	 "smtp - session max",		    	9,UINT32
	 				SIMPLE-OID, 	 "smtp - session current",    		10,UINT32
	 				SIMPLE-OID, 	 "smtp - session count",	  	    11,UINT32
	 				SIMPLE-OID, 	 "smtp - accepted session"	 ,    	15,UINT32
	 				SIMPLE-OID, 	 "smtp - rejected session" ,	    16,UINT32
	 				SIMPLE-OID,		 "smtp - mail max",   			 	18,UINT32
					SIMPLE-OID,		 "smtp - mail curr",  			 	19,UINT32
					SIMPLE-OID,		 "smtp - mail count",  				20,UINT32
					SIMPLE-OID,		 "smtp - outgoing mail max",   		21,UINT32
					SIMPLE-OID,		 "smtp - outgoing mail curr",  		22,UINT32
					SIMPLE-OID,		 "smtp - outgoing mail count",  	23,UINT32
					SIMPLE-OID,		 "smtp - max mail on conn",  		24,UINT32
					SIMPLE-OID,		 "smtp - total mails ", 		    25,UINT32
	 				SIMPLE-OID, 	 "smtp - time stamp"	,	    	26,STRING
	 				SIMPLE-OID, 	 "smtp - is alive" 	,  			    27,UINT32
	 				SIMPLE-OID, 	 "smtp - CI total infected" 	,	28,UINT32
	 				SIMPLE-OID, 	 "smtp - CI total blocked" 	,     	29,UINT32
	 				SIMPLE-OID, 	 "smtp - CI total scanned" 	,  		30,UINT32

				REMOVE-OID-ATOM    # Removes the "6" atom
			REMOVE-OID-ATOM    # Removes the "9" atom
		REMOVE-OID-ATOM    # Removes the "26" atom
		
	END-FLAVOUR

	START-FLAVOUR

		FLAVOUR-NAME, "pop3" # pop3

		ADD-OID-ATOM, 26

			ADD-OID-ATOM, 9
				ADD-OID-ATOM, 7
				
					SIMPLE-OID, 	 "pop3 - pid",		 				1,UINT32
					SIMPLE-OID, 	 "pop3 - proto",	 	 			2,UINT32
					SIMPLE-OID, 	 "pop3 - port" ,	 	 			3,UINT16
					SIMPLE-OID, 	 "pop3 - logical port"	,	    	4,UINT16
	 				SIMPLE-OID, 	 "pop3 - max avail socket",	    	5,UINT32
	 				SIMPLE-OID, 	 "pop3 - socket in use max",      	6,UINT32
	 				SIMPLE-OID, 	 "pop3 - socket in use current",   	7,UINT32
	 				SIMPLE-OID, 	 "pop3 - socket in use count", 	 	8,UINT32
	 				SIMPLE-OID, 	 "pop3 - session max",		    	9,UINT32
	 				SIMPLE-OID, 	 "pop3 - session current",    		10,UINT32
	 				SIMPLE-OID, 	 "pop3 - session count",	  	    11,UINT32
	 				SIMPLE-OID, 	 "pop3 - accepted session"	 ,    	15,UINT32
	 				SIMPLE-OID, 	 "pop3 - rejected session" ,	    16,UINT32
	 				SIMPLE-OID,		 "pop3 - mail max",   			 	18,UINT32
					SIMPLE-OID,		 "pop3 - mail curr",  			 	19,UINT32
					SIMPLE-OID,		 "pop3 - mail count",  				20,UINT32
					SIMPLE-OID,		 "pop3 - outgoing mail max",   		21,UINT32
					SIMPLE-OID,		 "pop3 - outgoing mail curr",  		22,UINT32
					SIMPLE-OID,		 "pop3 - outgoing mail count",  	23,UINT32
					SIMPLE-OID,		 "pop3 - max mail on conn",  		24,UINT32
					SIMPLE-OID,		 "pop3 - total mails ", 		    25,UINT32
	 				SIMPLE-OID, 	 "pop3 - time stamp"	,	    	26,STRING
	 				SIMPLE-OID, 	 "pop3 - is alive" 	,  			    27,UINT32
	 				SIMPLE-OID, 	 "pop3 - CI total infected" 	,	28,UINT32
	 				SIMPLE-OID, 	 "pop3 - CI total blocked" 	,     	29,UINT32
	 				SIMPLE-OID, 	 "pop3 - CI total scanned" 	,  		30,UINT32

				REMOVE-OID-ATOM    # Removes the "7" atom
			REMOVE-OID-ATOM    # Removes the "9" atom
		REMOVE-OID-ATOM    # Removes the "26" atom
		
	END-FLAVOUR

	START-FLAVOUR

		FLAVOUR-NAME, "sync" # sync

		ADD-OID-ATOM, 26
			ADD-OID-ATOM, 10
				ADD-OID-ATOM, 1		
					SIMPLE-OID, 	 "sync - configured",		 				1,STRING
					SIMPLE-OID, 	 "sync - out state",		 					2,STRING
					SIMPLE-OID, 	 "sync - in state",		 					3,STRING
					SIMPLE-OID, 	 "sync - number of sent packets",		 		4,UINT32
					SIMPLE-OID, 	 "sync - number of Kbytes sent",		 		5,UINT32
					SIMPLE-OID, 	 "sync - number of packets received",		 	6,UINT32
					SIMPLE-OID, 	 "sync - number of Kbytes received",		 		7,UINT32
					SIMPLE-OID, 	 "sync - number of retrans requests sent",		 	8,UINT32
					SIMPLE-OID, 	 "sync - number of retrans requests received",		9,UINT32
					SIMPLE-OID, 	 "sync - number of ack packets sent",		 		10,UINT32
					SIMPLE-OID, 	 "sync - number of ack packets received",		 	11,UINT32
					SIMPLE-OID, 	 "sync - number of packets dropped by network",	12,UINT32
					SIMPLE-OID, 	 "sync - overall number of table updates to be synced",		13,UINT32
					SIMPLE-OID, 	 "sync - number of updates filtered by 'non sync'",	14,UINT32
				REMOVE-OID-ATOM    # Removes the "1" atom

		REMOVE-OID-ATOM    # Removes the "10" atom
		REMOVE-OID-ATOM    # Removes the "26" atom
	END-FLAVOUR

##################################################################################

	START-FLAVOUR

#   NOTE: This flavour is used by the 'fw stat' command.
#         Any change here requires a compatibe change in the
#         'fw stat' code.

		FLAVOUR-NAME, "_fw_stat_flavour" 
		
		ADD-OID-ATOM, 25
		
			SIMPLE-OID, "1", 1, STRING    # Policy name
			SIMPLE-OID, "2", 2, STRING    # Install time
			
			START-TABLE

				START-TABLE-HEADER
			
					TABLE-NAME,        ""
					TABLE-OID,         5.1
					PRINT-ONLY-TOTALS, FALSE
					OUTPUT-FORMAT,     LIST

				END-TABLE-HEADER

				COLUMN,     "Index",	1, 	UINT32, 1, FALSE, FALSE 
				COLUMN,     "3",        2, 	STRING, 0, TRUE,  FALSE   # Interface name
				SUM-COLUMN, "4",		TRUE, "7", "6", "5"           # Inbound summary
				COLUMN,     "5",  		11,	UINT32, 0, TRUE, FALSE    # Inbound reject
				COLUMN,     "6",     	9, 	UINT32, 0, TRUE, FALSE    # Inbound drop
				COLUMN,     "7",   		5, 	UINT32, 0, TRUE, FALSE    # Inbound accept
				COLUMN,     "8",     	13, UINT32, 0, TRUE, FALSE    # Inbound logged
				SUM-COLUMN, "9",   		TRUE, "C", "B", "A"           # Outbound summury
				COLUMN,     "A", 		12, UINT32, 0, TRUE, FALSE    # Outbound reject
				COLUMN,     "B",   		10, UINT32, 0, TRUE, FALSE    # Outbound drop
				COLUMN,     "C",  		6, 	UINT32, 0, TRUE, FALSE    # Outbound accept
				COLUMN,     "D",    	14, UINT32, 0, TRUE, FALSE    # Outbound logged
			
			END-TABLE

		REMOVE-OID-ATOM    # Removes the "25" atom
		
	END-FLAVOUR

######################################################################

	START-FLAVOUR

		FLAVOUR-NAME, "log_connection"

			ADD-OID-ATOM, 30
			
				SIMPLE-OID, "Overall Status", 1, INT32    					# Status
				SIMPLE-OID, "Overall Status Description", 2, STRING    		# Status Desc
				SIMPLE-OID, "Local Logging Mode Description", 4, STRING    	# Local logging Desc
				SIMPLE-OID, "Local Logging Mode Status", 5, INT32 			# Local logging Stat
				SIMPLE-OID, "Local Logging Sending Rate", 6, UINT32			# Local logging Sending Rate
				SIMPLE-OID, "Log Handling Rate", 7, UINT32					# Log Handling Rate
				ADD-OID-ATOM, 3
				
				START-TABLE

					START-TABLE-HEADER

						TABLE-NAME, "Log Servers Connections"
						TABLE-OID, 1
						PRINT-ONLY-TOTALS, FALSE
						OUTPUT-FORMAT, DEFAULT

					END-TABLE-HEADER

					COLUMN,     "Index",       	 1, UINT32, 	1, FALSE, 	FALSE 
					COLUMN,     "IP",       	 2, STRING, 	0, TRUE,  	FALSE
					COLUMN, 	"Status",			 3, UINT32, 		0, TRUE, 	FALSE
					COLUMN, 	"Status Description",		 4, STRING, 		0, TRUE, 	FALSE
					COLUMN, 	"Sending Rate",		 	5, UINT32,	0, TRUE, 	FALSE
					
				END-TABLE
				
				REMOVE-OID-ATOM

			REMOVE-OID-ATOM

	END-FLAVOUR

######################################################################

	START-FLAVOUR

		FLAVOUR-NAME, "all" # all

		SIMPLE-OID, "Product name",      21, STRING
		SIMPLE-OID, "Major version",     22, UINT16
		SIMPLE-OID, "Minor version",     23, UINT16
		SIMPLE-OID, "Kernel build num.", 24, UINT32

		ADD-OID-ATOM, 25
		
			SIMPLE-OID, "Policy name",           1, STRING
			SIMPLE-OID, "Policy install time",   2, STRING
			SIMPLE-OID, "Num. connections",      3, UINT32
			SIMPLE-OID, "Peak num. connections", 4, UINT32
			SIMPLE-OID, "Connections capacity limit", 10, UINT32
			SIMPLE-OID, "Total accepted packets", 6, UINT64

			START-TABLE

				START-TABLE-HEADER
				
					TABLE-NAME,        "Interface table"
					TABLE-OID,         5.1
					PRINT-ONLY-TOTALS, FALSE
					OUTPUT-FORMAT,     DEFAULT

				END-TABLE-HEADER

				START-ROW-SPLITTER

					PSEUDO-INDEX-TITLES, "Dir"
					LOGICAL-COLUMN-TITLES, "Accept", "Drop", "Reject", "Log"

					ROW, "in",  "Accept-In",  "Drop-In",  "Reject-In",  "Log-In"
					ROW, "out", "Accept-Out", "Drop-Out", "Reject-Out", "Log-Out"

				END-ROW-SPLITTER

				COLUMN, "Index",       1, UINT32, 1, FALSE, FALSE 
				COLUMN, "Name",        2, STRING, 0, TRUE,  FALSE
				COLUMN, "Accept-In",   5, UINT32, 0, FALSE, TRUE
				COLUMN, "Accept-Out",  6, UINT32, 0, FALSE, TRUE
				COLUMN, "Drop-In",     9, UINT32, 0, FALSE, TRUE
				COLUMN, "Drop-Out",   10, UINT32, 0, FALSE, TRUE
				COLUMN, "Reject-In",  11, UINT32, 0, FALSE, TRUE
				COLUMN, "Reject-Out", 12, UINT32, 0, FALSE, TRUE
				COLUMN, "Log-In",     13, UINT32, 0, FALSE, TRUE
				COLUMN, "Log-Out",    14, UINT32, 0, FALSE, TRUE
			
			END-TABLE
			
			START-TABLE

				START-TABLE-HEADER
				
					TABLE-NAME,        "Interface table (64-bit)"
					TABLE-OID,         25.1
					PRINT-ONLY-TOTALS, FALSE
					OUTPUT-FORMAT,     DEFAULT

				END-TABLE-HEADER

				START-ROW-SPLITTER

					PSEUDO-INDEX-TITLES, "Dir"
					LOGICAL-COLUMN-TITLES, "Accept", "Drop", "Reject", "Log"

					ROW, "in",  "Accept-In",  "Drop-In",  "Reject-In",  "Log-In"
					ROW, "out", "Accept-Out", "Drop-Out", "Reject-Out", "Log-Out"

				END-ROW-SPLITTER

				COLUMN, "Index",       1, UINT32, 1, FALSE, FALSE 
				COLUMN, "Name",        2, STRING, 0, TRUE,  FALSE
				COLUMN, "Accept-In",   5, UINT64, 0, FALSE, TRUE
				COLUMN, "Accept-Out",  6, UINT64, 0, FALSE, TRUE
				COLUMN, "Drop-In",     9, UINT64, 0, FALSE, TRUE
				COLUMN, "Drop-Out",   10, UINT64, 0, FALSE, TRUE
				COLUMN, "Reject-In",  11, UINT64, 0, FALSE, TRUE
				COLUMN, "Reject-Out", 12, UINT64, 0, FALSE, TRUE
				COLUMN, "Log-In",     13, UINT64, 0, FALSE, TRUE
				COLUMN, "Log-Out",    14, UINT64, 0, FALSE, TRUE
			
			END-TABLE
			
			START-TABLE

				START-TABLE-HEADER
			
					TABLE-NAME,        "ISP link table"
					TABLE-OID,         7.1
					PRINT-ONLY-TOTALS, FALSE
					OUTPUT-FORMAT,     DEFAULT

				END-TABLE-HEADER

				COLUMN,     "Index",       1, UINT32, 1, FALSE, FALSE 
				COLUMN,     "Name",        2, STRING, 0, TRUE,  FALSE
				COLUMN,     "Status",      3, STRING, 0, TRUE,  FALSE
				COLUMN,     "Role",        4, STRING, 0, TRUE,  FALSE
				
			END-TABLE


		REMOVE-OID-ATOM    # Removes the "25" atom

		ADD-OID-ATOM, 26
		
			ADD-OID-ATOM, 1
				SIMPLE-OID, "hmem - block size",                1, UINT32
				SIMPLE-OID, "hmem - requested bytes",           2, UINT32
				SIMPLE-OID, "hmem - initial allocated bytes",   3, UINT32
				SIMPLE-OID, "hmem - initial allocated blocks",  4, UINT32
				SIMPLE-OID, "hmem - initial allocated pools",   5, UINT32
				SIMPLE-OID, "hmem - current allocated bytes",   6, UINT32
				SIMPLE-OID, "hmem - current allocated blocks",  7, UINT32
				SIMPLE-OID, "hmem - current allocated pools",   8, UINT32
				SIMPLE-OID, "hmem - maximum bytes",             9, UINT32
				SIMPLE-OID, "hmem - maximum pools",            10, UINT32
				SIMPLE-OID, "hmem - bytes used",               11, UINT32
				SIMPLE-OID, "hmem - blocks used",              12, UINT32
				SIMPLE-OID, "hmem - bytes unused",             13, UINT32
				SIMPLE-OID, "hmem - blocks unused",            14, UINT32
				SIMPLE-OID, "hmem - bytes peak",               15, UINT32
				SIMPLE-OID, "hmem - blocks peak",              16, UINT32
				SIMPLE-OID, "hmem - bytes internal use",       17, UINT32
				SIMPLE-OID, "hmem - number of items",          18, UINT32
				SIMPLE-OID, "hmem - alloc operations",         19, UINT32
				SIMPLE-OID, "hmem - free operations",          20, UINT32
				SIMPLE-OID, "hmem - failed alloc",             21, UINT32
				SIMPLE-OID, "hmem - failed free",              22, UINT32
			REMOVE-OID-ATOM    # Removes the "1" atom

			ADD-OID-ATOM, 2
				SIMPLE-OID, "kmem - system physical mem",       1, UINT32
				SIMPLE-OID, "kmem - available physical mem",    2, UINT32
				SIMPLE-OID, "kmem - aix heap size",             3, UINT32
				SIMPLE-OID, "kmem - bytes used",                4, UINT32
				SIMPLE-OID, "kmem - blocking bytes used",       5, UINT32
				SIMPLE-OID, "kmem - non blocking bytes used",   6, UINT32
				SIMPLE-OID, "kmem - bytes unused",              7, UINT32
				SIMPLE-OID, "kmem - bytes peak",                8, UINT32
				SIMPLE-OID, "kmem - blocking bytes peak",       9, UINT32
				SIMPLE-OID, "kmem - non blocking bytes peak",  10, UINT32
				SIMPLE-OID, "kmem - bytes internal use",       11, UINT32
				SIMPLE-OID, "kmem - number of items",          12, UINT32
				SIMPLE-OID, "kmem - alloc operations",         13, UINT32
				SIMPLE-OID, "kmem - free operations",          14, UINT32
				SIMPLE-OID, "kmem - failed alloc",             15, UINT32
				SIMPLE-OID, "kmem - failed free",              16, UINT32
			REMOVE-OID-ATOM    # Removes the "2" atom

			ADD-OID-ATOM, 3
				SIMPLE-OID, "inspect - packets",                1, UINT32
				SIMPLE-OID, "inspect - operations",             2, UINT32
				SIMPLE-OID, "inspect - lookups",                3, UINT32
				SIMPLE-OID, "inspect - record",                 4, UINT32
				SIMPLE-OID, "inspect - extract",                5, UINT32
			REMOVE-OID-ATOM    # Removes the "3" atom

			ADD-OID-ATOM, 4
				SIMPLE-OID, "cookies - total",                  1, UINT32
				SIMPLE-OID, "cookies - alloc",                  2, UINT32
				SIMPLE-OID, "cookies - free",                   3, UINT32
				SIMPLE-OID, "cookies - dup",                    4, UINT32
				SIMPLE-OID, "cookies - get",                    5, UINT32
				SIMPLE-OID, "cookies - put",                    6, UINT32
				SIMPLE-OID, "cookies - len",                    7, UINT32
			REMOVE-OID-ATOM    # Removes the "4" atom

			ADD-OID-ATOM, 5
				SIMPLE-OID, "chains - alloc",                   1,  UINT32
				SIMPLE-OID, "chains - free",                    2,  UINT32
			REMOVE-OID-ATOM    # Removes the "5" atom

			ADD-OID-ATOM, 6
				SIMPLE-OID, "fragments - fragments",            1,  UINT32
				SIMPLE-OID, "fragments - expired",              2,  UINT32
				SIMPLE-OID, "fragments - packets",              3,  UINT32
			REMOVE-OID-ATOM    # Removes the "6" atom
			
			ADD-OID-ATOM, 8
				SIMPLE-OID, "ufp - % hits ratio",        1,  UINT32
				SIMPLE-OID, "ufp - total connections",	 2,  UINT32
				SIMPLE-OID, "ufp - hits connections" ,	 3,  UINT32
			REMOVE-OID-ATOM    # Removes the "8" atom

			ADD-OID-ATOM, 9
				ADD-OID-ATOM, 5
				
					SIMPLE-OID, 	 "ufp - session max"  ,     1,UINT32
	 				SIMPLE-OID, 	 "ufp - session current",   2,UINT32
	 				SIMPLE-OID, 	 "ufp - session count" ,    3,UINT32
	 				SIMPLE-OID, 	 "ufp - rej session "  ,    4,UINT32
	 				SIMPLE-OID, 	 "ufp - time stamp"  ,		5,STRING
	 				SIMPLE-OID, 	 "ufp - is alive" 	,		6,UINT32
				REMOVE-OID-ATOM    # Removes the "5" atom
			REMOVE-OID-ATOM    # Removes the "9" atom


			ADD-OID-ATOM, 9
				ADD-OID-ATOM, 1
				
					SIMPLE-OID, 	 "http - pid",							1,UINT32
					SIMPLE-OID, 	 "http - proto",						2,UINT32
					SIMPLE-OID, 	 "http - port" ,						3,UINT16
					SIMPLE-OID, 	 "http - logical port"	,				4,UINT16
	 				SIMPLE-OID, 	 "http - max avail socket",				5,UINT32
	 				SIMPLE-OID, 	 "http - socket in use max",			6,UINT32
	 				SIMPLE-OID, 	 "http - socket in use current",		7,UINT32
	 				SIMPLE-OID, 	 "http - socket in use count",			8,UINT32
	 				SIMPLE-OID, 	 "http - session max",					9,UINT32
	 				SIMPLE-OID, 	 "http - session current",				10,UINT32
	 				SIMPLE-OID, 	 "http - session count",				11,UINT32
	 				SIMPLE-OID, 	 "http - auth session max",				12,UINT32
	 				SIMPLE-OID, 	 "http - auth session current",			13,UINT32
	 				SIMPLE-OID, 	 "http - auth session count",			14,UINT32
	 				SIMPLE-OID, 	 "http - accepted session"	 ,			15,UINT32
	 				SIMPLE-OID, 	 "http - rejected session" ,	    	16,UINT32
	 				SIMPLE-OID, 	 "http - auth failures"	,				17,UINT32
	 				SIMPLE-OID, 	 "http - opsec cvp session max"  ,		18,UINT32
	 				SIMPLE-OID, 	 "http - opsec cvp session current",	19,UINT32
	 				SIMPLE-OID, 	 "http - opsec cvp session count" ,		20,UINT32
	 				SIMPLE-OID, 	 "http - opsec cvp rej session "  ,		21,UINT32
	 				SIMPLE-OID, 	 "http - ssl encryp session max",		22,UINT32
	 				SIMPLE-OID, 	 "http - ssl encryp session current",	23,UINT32
	 				SIMPLE-OID, 	 "http - ssl encryp session count",		24,UINT32
	 				SIMPLE-OID, 	 "http - transparent session max"	,	25,UINT32
	 				SIMPLE-OID, 	 "http - transparent session current",	26,UINT32
	 				SIMPLE-OID, 	 "http - transparent session count" ,	27,UINT32
	 				SIMPLE-OID, 	 "http - proxied session max"	 ,		28,UINT32
	 				SIMPLE-OID, 	 "http - proxied session current",		29,UINT32
	 				SIMPLE-OID, 	 "http - proxied session count" ,		30,UINT32
	 				SIMPLE-OID, 	 "http - tunneled session max"	 ,		31,UINT32
	 				SIMPLE-OID, 	 "http - tunneled session current" ,	32,UINT32
	 				SIMPLE-OID, 	 "http - tunneled session count" ,		33,UINT32
	 				SIMPLE-OID, 	 "http - ftp session max"  	,			34,UINT32
	 				SIMPLE-OID, 	 "http - ftp session current"  	 ,		35,UINT32
	 				SIMPLE-OID, 	 "http - ftp session count" 	,		36,UINT32
	 				SIMPLE-OID, 	 "http - time stamp" 	,				37,STRING
	 				SIMPLE-OID, 	 "http - is alive" 	,					38,UINT32
				REMOVE-OID-ATOM    # Removes the "1" atom
		

				ADD-OID-ATOM, 2
				
					SIMPLE-OID, 	 "ftp - pid",						 1,UINT32
					SIMPLE-OID, 	 "ftp - proto",	 					 2,UINT32
					SIMPLE-OID, 	 "ftp - port" ,	 	 				 3,UINT16
					SIMPLE-OID, 	 "ftp - logical port"	,	  		 4,UINT16
	 				SIMPLE-OID, 	 "ftp - max avail socket",	  		 5,UINT32
	 				SIMPLE-OID, 	 "ftp - socket in use max",      	 6,UINT32
	 				SIMPLE-OID, 	 "ftp - socket in use current",		 7,UINT32
	 				SIMPLE-OID, 	 "ftp - socket in use count", 		 8,UINT32
	 				SIMPLE-OID, 	 "ftp - session max",		         9,UINT32
	 				SIMPLE-OID, 	 "ftp - session current",    	     10,UINT32
	 				SIMPLE-OID, 	 "ftp - session count",	  	   		 11,UINT32
	 				SIMPLE-OID, 	 "ftp - auth session max",	  	     12,UINT32
	 				SIMPLE-OID, 	 "ftp - auth session current",   	 13,UINT32
	 				SIMPLE-OID, 	 "ftp - auth session count", 	   	 14,UINT32
	 				SIMPLE-OID, 	 "ftp - accepted session"	 ,    	 15,UINT32
	 				SIMPLE-OID, 	 "ftp - rejected session" ,	   		 16,UINT32
	 				SIMPLE-OID, 	 "ftp - auth failures"	,	   		 17,UINT32
	 				SIMPLE-OID, 	 "ftp - opsec cvp session max"  ,    18,UINT32
	 				SIMPLE-OID, 	 "ftp - opsec cvp session current",  19,UINT32
	 				SIMPLE-OID, 	 "ftp - opsec cvp session count" , 	 20,UINT32
	 				SIMPLE-OID, 	 "ftp - opsec cvp rej session "  ,	 21,UINT32
	 	 			SIMPLE-OID, 	 "ftp - time stamp" 	,  			 22,STRING
	 				SIMPLE-OID, 	 "ftp - is alive" 	,  			     23,UINT32

 				
				REMOVE-OID-ATOM    # Removes the "2" atom
		

				ADD-OID-ATOM, 3
				
					SIMPLE-OID, 	 "telnet - pid",		 			1,UINT32
					SIMPLE-OID, 	 "telnet - proto",	 	 			2,UINT32
					SIMPLE-OID, 	 "telnet - port" ,	 	 			3,UINT16
					SIMPLE-OID, 	 "telnet - logical port"	,	  	4,UINT16
	 				SIMPLE-OID, 	 "telnet - max avail socket",	    5,UINT32
	 				SIMPLE-OID, 	 "telnet - socket in use max",      6,UINT32
	 				SIMPLE-OID, 	 "telnet - socket in use current",  7,UINT32
	 				SIMPLE-OID, 	 "telnet - socket in use count", 	8,UINT32
	 				SIMPLE-OID, 	 "telnet - session max",		    9,UINT32
	 				SIMPLE-OID, 	 "telnet - session current",    	10,UINT32
	 				SIMPLE-OID, 	 "telnet - session count",	  	    11,UINT32
	 				SIMPLE-OID, 	 "telnet - auth session max",	  	12,UINT32
	 				SIMPLE-OID, 	 "telnet - auth session current",   13,UINT32
	 				SIMPLE-OID, 	 "telnet - auth session count", 	14,UINT32
	 				SIMPLE-OID, 	 "telnet - accepted session"	 ,  15,UINT32
	 				SIMPLE-OID, 	 "telnet - rejected session" ,	    16,UINT32
	 				SIMPLE-OID, 	 "telnet - auth failures"	,	    17,UINT32
 					SIMPLE-OID, 	 "telnet - time stamp" 	,  			18,STRING
	 				SIMPLE-OID, 	 "telnet - is alive" 	,  			19,UINT32


				REMOVE-OID-ATOM    # Removes the "3" atom

				ADD-OID-ATOM, 4
				
					SIMPLE-OID, 	 "rlogin - pid",		 			1,UINT32
					SIMPLE-OID, 	 "rlogin - proto",	 		 		2,UINT32
					SIMPLE-OID, 	 "rlogin - port" ,	 	 			3,UINT16
					SIMPLE-OID, 	 "rlogin - logical port"	,	    4,UINT16
	 				SIMPLE-OID, 	 "rlogin - max avail socket",	    5,UINT32
	 				SIMPLE-OID, 	 "rlogin - socket in use max",      6,UINT32
	 				SIMPLE-OID, 	 "rlogin - socket in use current", 	7,UINT32
	 				SIMPLE-OID, 	 "rlogin - socket in use count", 	8,UINT32
	 				SIMPLE-OID, 	 "rlogin - session max",		    9,UINT32
	 				SIMPLE-OID, 	 "rlogin - session current",    	10,UINT32
	 				SIMPLE-OID, 	 "rlogin - session count",	  	    11,UINT32
	 				SIMPLE-OID, 	 "rlogin - auth session max",		12,UINT32
	 				SIMPLE-OID, 	 "rlogin - auth session current",   13,UINT32
	 				SIMPLE-OID, 	 "rlogin - auth session count", 	14,UINT32
	 				SIMPLE-OID, 	 "rlogin - accepted session"	 ,  15,UINT32
	 				SIMPLE-OID, 	 "rlogin - rejected session" ,	    16,UINT32
	 				SIMPLE-OID, 	 "rlogin - auth failures"	,	    17,UINT32
 				    SIMPLE-OID, 	 "rlogin - time stamp" 	,  			18,STRING
 				    SIMPLE-OID, 	 "rlogin - is alive" 	,  			19,UINT32


				REMOVE-OID-ATOM    # Removes the "4" atom

				ADD-OID-ATOM, 6
				
					SIMPLE-OID, 	 "smtp - pid",		 				1,UINT32
					SIMPLE-OID, 	 "smtp - proto",	 	 			2,UINT32
					SIMPLE-OID, 	 "smtp - port" ,	 	 			3,UINT16
					SIMPLE-OID, 	 "smtp - logical port"	,	    	4,UINT16
	 				SIMPLE-OID, 	 "smtp - max avail socket",	    	5,UINT32
	 				SIMPLE-OID, 	 "smtp - socket in use max",      	6,UINT32
	 				SIMPLE-OID, 	 "smtp - socket in use current",   	7,UINT32
	 				SIMPLE-OID, 	 "smtp - socket in use count", 	 	8,UINT32
	 				SIMPLE-OID, 	 "smtp - session max",		    	9,UINT32
	 				SIMPLE-OID, 	 "smtp - session current",    		10,UINT32
	 				SIMPLE-OID, 	 "smtp - session count",	  	    11,UINT32
	 				SIMPLE-OID, 	 "smtp - accepted session"	 ,    	15,UINT32
	 				SIMPLE-OID, 	 "smtp - rejected session" ,	    16,UINT32
	 				SIMPLE-OID,		 "smtp - mail max",   			 	18,UINT32
					SIMPLE-OID,		 "smtp - mail curr",  			 	19,UINT32
					SIMPLE-OID,		 "smtp - mail count",  				20,UINT32
					SIMPLE-OID,		 "smtp - outgoing mail max",   		21,UINT32
					SIMPLE-OID,		 "smtp - outgoing mail curr",  		22,UINT32
					SIMPLE-OID,		 "smtp - outgoing mail count",  	23,UINT32
					SIMPLE-OID,		 "smtp - max mail on conn",  		24,UINT32	
					SIMPLE-OID,		 "smtp - total mails ", 		    25,UINT32
		 			SIMPLE-OID, 	 "smtp - time stamp" 	,  			26,STRING
	 				SIMPLE-OID, 	 "smtp - is alive" 	,  			    27,UINT32
				REMOVE-OID-ATOM    # Removes the "6" atom
			REMOVE-OID-ATOM    # Removes the "9" atom
			ADD-OID-ATOM, 10
				ADD-OID-ATOM, 1		
					SIMPLE-OID, 	 "sync - configured",		 				1,STRING
					SIMPLE-OID, 	 "sync - out state",		 					2,STRING
					SIMPLE-OID, 	 "sync - in state",		 					3,STRING
					SIMPLE-OID, 	 "sync - number of sent packets",		 		4,UINT32
					SIMPLE-OID, 	 "sync - number of Kbytes sent",		 		5,UINT32
					SIMPLE-OID, 	 "sync - number of packets received",		 	6,UINT32
					SIMPLE-OID, 	 "sync - number of Kbytes received",		 		7,UINT32
					SIMPLE-OID, 	 "sync - number of retrans requests sent",		 	8,UINT32
					SIMPLE-OID, 	 "sync - number of retrans requests received",		9,UINT32
					SIMPLE-OID, 	 "sync - number of ack packets sent",		 		10,UINT32
					SIMPLE-OID, 	 "sync - number of ack packets received",		 	11,UINT32
					SIMPLE-OID, 	 "sync - number of packets dropped by network",	12,UINT32
					SIMPLE-OID, 	 "sync - overall number of table updates to be synced",		13,UINT32
					SIMPLE-OID, 	 "sync - number of updates filtered by 'non sync'",	14,UINT32
				REMOVE-OID-ATOM    # Removes the "1" atom
			REMOVE-OID-ATOM    # Removes the "10" atom

		REMOVE-OID-ATOM		# Removes the "26" atom
	END-FLAVOUR

END-BLOCK

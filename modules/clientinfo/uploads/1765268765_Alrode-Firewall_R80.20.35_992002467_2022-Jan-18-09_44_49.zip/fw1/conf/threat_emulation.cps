#
# Anti-Malware configuration file for the non-cpmi command line.
#
#
# Syntax (of complicated fields. The rest is obvious):
#
# SIMPLE-OID,    Name, OID, Type
#
# COLUMN,        Name, OID, Type, Index-order, Display, Display-Totals
#
# SUM-COLUMN,    Name, Display-Totlas, Column-Name-1, Column-Name-2, ....
#
# OUTPUT-FORMAT, "DEFAULT"/"LIST"    *If does not exist - assumed "DEFAULT"  
#
# OID-BASE takes effect only within the section it is in.
#

START-BLOCK

	BLOCK-NAME, "threat-emulation"
	
	OID-BASE, 1.3.6.1.4.1.2620.1.49
	
	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "default"

		SIMPLE-OID, "Status",               	  101, UINT32
		SIMPLE-OID, "Status short description",   102, STRING
		SIMPLE-OID, "Status long description",    103, STRING
		SIMPLE-OID, "Engine Major Version",   	  29,  UINT32
		SIMPLE-OID, "Engine Minor Version",    	  30,  UINT32

	END-FLAVOUR
	
	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "general_statuses"
		
		SIMPLE-OID, "TE Email Scanned",             		12, UINT32
		SIMPLE-OID, "TE Downloaded Files Scanned",  		13, UINT32
		SIMPLE-OID, "TE Files In Queue",         			14, UINT32
		SIMPLE-OID, "TE Number Of Emulation Environments",  15, UINT32
		SIMPLE-OID, "TE Is First Download", 				36, UINT32
		
	END-FLAVOUR
	
	#################################################
	
	START-FLAVOUR

		FLAVOUR-NAME, "update_status"
		
		SIMPLE-OID, "TE Update Status",         	16, STRING
		SIMPLE-OID, "TE Update Description",  		17, STRING
		
	END-FLAVOUR
	
	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "scanned_files"
		
		ADD-OID-ATOM, 4
		
		SIMPLE-OID, "TE Scanned Files",               	  1, UINT32
		SIMPLE-OID, "TE Scanned Files Last Day",          2, UINT32
		SIMPLE-OID, "TE Scanned Files Last Week",         3, UINT32
		SIMPLE-OID, "TE Scanned Files Last Month",        4, UINT32

	END-FLAVOUR
	
	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "malware_detected"
		
		ADD-OID-ATOM, 5
		
		SIMPLE-OID, "TE Malware Detected",               	 1, UINT32
		SIMPLE-OID, "TE Malware Detected Last Day",          2, UINT32
		SIMPLE-OID, "TE Malware Detected Last Week",         3, UINT32
		SIMPLE-OID, "TE Malware Detected Last Month",        4, UINT32
		
	END-FLAVOUR
	
	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "scanned_on_cloud"
		
		ADD-OID-ATOM, 6
		
		SIMPLE-OID, "TE Scanned Files On Threat Cloud",               	  1, UINT32
		SIMPLE-OID, "TE Scanned Files On Threat Cloud Last Day",          2, UINT32
		SIMPLE-OID, "TE Scanned Files On Threat Cloud Last Week",         3, UINT32
		SIMPLE-OID, "TE Scanned Files On Threat Cloud Last Month",        4, UINT32
		
	END-FLAVOUR
	
	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "malware_on_cloud"
		
		ADD-OID-ATOM, 7
		
		SIMPLE-OID, "TE Malware Detected On Threat Cloud",               	 1, UINT32
		SIMPLE-OID, "TE Malware Detected On Threat Cloud Last Day",          2, UINT32
		SIMPLE-OID, "TE Malware Detected On Threat Cloud Last Week",         3, UINT32
		SIMPLE-OID, "TE Malware Detected On Threat Cloud Last Month",        4, UINT32
		
	END-FLAVOUR
	
	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "average_process_time"
		
		ADD-OID-ATOM, 8
		
		SIMPLE-OID, "TE Average Process Time",               	 1, UINT32
		SIMPLE-OID, "TE Average Process Time Last Day",          2, UINT32
		SIMPLE-OID, "TE Average Process Time Last Week",         3, UINT32
		SIMPLE-OID, "TE Average Process Time Last Month",        4, UINT32
		
	END-FLAVOUR
	
	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "emulated_file_size"
		
		ADD-OID-ATOM, 9
		
		SIMPLE-OID, "TE Emulated File Size",              	   1, UINT32
		SIMPLE-OID, "TE Emulated File Size Last Day",          2, UINT32
		SIMPLE-OID, "TE Emulated File Size Last Week",         3, UINT32
		SIMPLE-OID, "TE Emulated File Size Last Month",        4, UINT32
		
	END-FLAVOUR
	
	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "queue_size"
		
		ADD-OID-ATOM, 10
		
		SIMPLE-OID, "TE Queue Size",              	   1, UINT32
		SIMPLE-OID, "TE Queue Size Last Day",          2, UINT32
		SIMPLE-OID, "TE Queue Size Last Week",         3, UINT32
		SIMPLE-OID, "TE Queue Size Last Month",        4, UINT32
		
	END-FLAVOUR
	
	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "peak_size"
		
		ADD-OID-ATOM, 11
		
		SIMPLE-OID, "TE Peak Size",              	   1, UINT32
		SIMPLE-OID, "TE Peak Size Last Day",          2, UINT32
		SIMPLE-OID, "TE Peak Size Last Week",         3, UINT32
		SIMPLE-OID, "TE Peak Size Last Month",        4, UINT32
		
	END-FLAVOUR

	#################################################
	
	START-FLAVOUR

		FLAVOUR-NAME, "file_type_stat_file_scanned"

		ADD-OID-ATOM, 18.1
		
		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Threat-Emulation Statistics, Scanned Files"
				TABLE-OID,         1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    			   1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "File Type",        			   2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Scanned",    					   3, UINT32, 0, TRUE,  FALSE
			COLUMN,     "Scanned Last Day",    			   4, UINT32, 0, TRUE,  FALSE
			COLUMN,     "Scanned Last Week",    		   5, UINT32, 0, TRUE,  FALSE
			COLUMN,     "Scanned Last Month",       	   6, UINT32, 0, TRUE, FALSE 
				
		END-TABLE
	
	END-FLAVOUR
	
	#################################################	
	
	START-FLAVOUR

		FLAVOUR-NAME, "file_type_stat_malware_detected"

		ADD-OID-ATOM, 18.1
	
		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Threat-Emulation Statistics, Malware Detected"
				TABLE-OID,         1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    			   1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "File Type",        			   2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Malware Detected",        		   7, UINT32, 0, TRUE,  FALSE
			COLUMN,     "Malware Detected Last Day",       8, UINT32, 0, TRUE,  FALSE
			COLUMN,     "Malware Detected Last Week",      9, UINT32, 0, TRUE,  FALSE
			COLUMN,     "Malware Detected Last Month",     10, UINT32, 0, TRUE,  FALSE
			
		END-TABLE
	END-FLAVOUR
	
	#################################################
	
	START-FLAVOUR

		FLAVOUR-NAME, "file_type_stat_cloud_scanned"

		ADD-OID-ATOM, 18.1
		
		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Threat-Emulation Statistics, Threatcloud Scanned"
				TABLE-OID,         1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    			   1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "File Type",        			   2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Threatcloud Scanned",       	   11, UINT32, 0, TRUE, FALSE 
			COLUMN,     "Threatcloud Scanned Last Day",    12, UINT32, 0, TRUE,  FALSE
			COLUMN,     "Threatcloud Scanned Last Week",   13, UINT32, 0, TRUE,  FALSE
			COLUMN,     "Threatcloud Scanned Last Month",  14, UINT32, 0, TRUE,  FALSE
			
		END-TABLE
	
	END-FLAVOUR
	
	#################################################	

	START-FLAVOUR

		FLAVOUR-NAME, "file_type_stat_cloud_malware_scanned"

		ADD-OID-ATOM, 18.1
			START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Threat-Emulation Statistics, Threatcloud Malware Scanned"
				TABLE-OID,         1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    			   1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "File Type",        			   2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Scanned",    					   3, UINT32, 0, TRUE,  FALSE
			COLUMN,     "Threatcloud Malware",       	   15, UINT32, 0, TRUE, FALSE 
			COLUMN,     "Threatcloud Malware Last Day",    16, UINT32, 0, TRUE,  FALSE
			COLUMN,     "Threatcloud Malware Last Week",   17, UINT32, 0, TRUE,  FALSE
			COLUMN,     "Threatcloud Malware Last Month",  18, UINT32, 0, TRUE,  FALSE
					
		END-TABLE
	
	END-FLAVOUR
	
	#################################################	
	
	START-FLAVOUR

		FLAVOUR-NAME, "file_type_stat_filter_by_analysis"

		ADD-OID-ATOM, 18.1
			START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Threat-Emulation Statistics, Filter By Analysis"
				TABLE-OID,         1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    			   1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "File Type",        			   2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Filter By Analysis",       	   19, UINT32, 0, TRUE, FALSE 
			COLUMN,     "Filter By Analysis Last Day",     20, UINT32, 0, TRUE,  FALSE
			COLUMN,     "Filter By Analysis Last Week",    21, UINT32, 0, TRUE,  FALSE
			COLUMN,     "Filter By Analysis Last Month",   22, UINT32, 0, TRUE,  FALSE
		
		END-TABLE
	
	END-FLAVOUR
	
	#################################################	
	
	START-FLAVOUR

		FLAVOUR-NAME, "file_type_stat_cache_hit_rate"

		ADD-OID-ATOM, 18.1
	
		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Threat-Emulation Statistics, Cache Hit Rate"
				TABLE-OID,         1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    			   1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "File Type",        			   2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Cache Hit Rate",       	       23, UINT32, 0, TRUE, FALSE 
			COLUMN,     "Cache Hit Rate Last Day",         24, UINT32, 0, TRUE,  FALSE
			COLUMN,     "Cache Hit Rate Last Week",    	   25, UINT32, 0, TRUE,  FALSE
			COLUMN,     "Cache Hit Rate Last Month",       26, UINT32, 0, TRUE,  FALSE
		
		END-TABLE
	
	END-FLAVOUR
	
	#################################################		
		
	START-FLAVOUR

		FLAVOUR-NAME, "file_type_stat_error_count"

		ADD-OID-ATOM, 18.1
		
		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Threat-Emulation Statistics, Error Count"
				TABLE-OID,         1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    			   1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "File Type",        			   2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Error Count",       	       	   27, UINT32, 0, TRUE, FALSE 
			COLUMN,     "Error Count Last Day",        	   28, UINT32, 0, TRUE,  FALSE
			COLUMN,     "Error Count Last Week",    	   29, UINT32, 0, TRUE,  FALSE
			COLUMN,     "Error Count Last Month",    	   30, UINT32, 0, TRUE,  FALSE
		
		END-TABLE
	
	END-FLAVOUR
	
	#################################################		
	
	START-FLAVOUR

		FLAVOUR-NAME, "file_type_stat_no_resource_count"

		ADD-OID-ATOM, 18.1
	

		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Threat-Emulation Statistics, No Resource Count"
				TABLE-OID,         1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    			   1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "File Type",        			   2, STRING, 0, TRUE,  FALSE
			COLUMN,     "No Resource Count",       	       31, UINT32, 0, TRUE, FALSE 
			COLUMN,     "No Resource Count Last Day",      32, UINT32, 0, TRUE,  FALSE
			COLUMN,     "No Resource Count Last Week",     33, UINT32, 0, TRUE,  FALSE
			COLUMN,     "No Resource Count Last Month",    34, UINT32, 0, TRUE,  FALSE
		
		END-TABLE
		
	END-FLAVOUR
	
	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "contract"
		
		SIMPLE-OID, "TE Contract Name",              	 19, STRING
		SIMPLE-OID, "TE Subscription Expire Date",       20, STRING
		SIMPLE-OID, "TE Cloud Hourly Quota",         	 21, UINT32
		SIMPLE-OID, "TE Cloud Monthly Quota",            22, UINT32
		SIMPLE-OID, "TE Cloud Remaining Quota",          23, UINT32
		SIMPLE-OID, "TE Maximal VMs Number",          	 24, UINT32
		SIMPLE-OID, "TE Subscription Status",         	 25, STRING
		SIMPLE-OID, "TE Cloud Quota Status",      		 26, STRING
		SIMPLE-OID, "TE Subscription Description",       27, STRING
		SIMPLE-OID, "TE Cloud Quota Description",        28, STRING
		
		SIMPLE-OID, "TE Cloud Quota Identifier",        			 31, STRING
		SIMPLE-OID, "TE Cloud Monthly Quota Period Start",        	 32, UINT32
		SIMPLE-OID, "TE Cloud Monthly Quota Period End",        	 33, UINT32
		SIMPLE-OID, "TE Cloud Monthly Quota Usage for This GW",      34, UINT32		
		SIMPLE-OID, "TE Cloud Hourly Quota Usage for this GW",      	35, UINT32

		SIMPLE-OID, "TE Cloud Monthly Quota Usage for Quota ID",      	37, UINT32
		SIMPLE-OID, "TE Cloud Hourly Quota Usage for Quota ID",      	38, UINT32
		SIMPLE-OID, "TE Cloud Monthly Quota Exceeded",      			39, UINT32
		SIMPLE-OID, "TE Cloud Hourly Quota Exceeded",      				40, UINT32
		SIMPLE-OID, "TE Cloud Last Quota Update GMT Time", 				41, UINT32
		
		
	END-FLAVOUR
	
	#################################################
	
	START-FLAVOUR

		FLAVOUR-NAME, "downloads_information_current"

		SIMPLE-OID, "Average Download Percentage", 3, STRING
		
		ADD-OID-ATOM, 2
		
		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Threat-Emulation Current Files Table"
				TABLE-OID,         1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Type",        		2, STRING, 0, TRUE,  FALSE
			COLUMN,     "UUID",    			3, STRING, 0, TRUE,  FALSE
			COLUMN,     "Name",    			4, STRING, 0, TRUE,  FALSE
			COLUMN,     "Revision",    		5, INT32, 0, TRUE,  FALSE
			COLUMN,     "Size",    		   	6, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Start Down Time",  7, STRING, 0, TRUE,  FALSE 
			COLUMN,     "Down Percent",     8, STRING, 0, TRUE,  FALSE
			
		END-TABLE
		
	END-FLAVOUR

	#################################################
	
	START-FLAVOUR

		FLAVOUR-NAME, "downloading_file_information"

		SIMPLE-OID, "Average Download Percentage", 3, STRING
		
		ADD-OID-ATOM, 2
		
		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Threat-Emulation Downloading Files Table"
				TABLE-OID,         1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    			    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Type",        			     		2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Downloading File Revision",    	9, INT32, 0, TRUE,  FALSE
			COLUMN,     "Downloading File Size",    		10, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Downloading File Down Start Time", 11, STRING, 0, TRUE,  FALSE
			COLUMN,     "Downloading File Down Percent",  	12, STRING, 0, TRUE, FALSE 
		
		END-TABLE
		
	END-FLAVOUR
	
	#################################################
	
	START-FLAVOUR

		FLAVOUR-NAME, "queue_table"

		ADD-OID-ATOM, 1.1
		
		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Threat-Emulation Queue Files Table"
				TABLE-OID,         1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    			     1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "File Name",        			     2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Time In Queue",    		 		 3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Analyzed On",    		 			 4, STRING, 0, TRUE,  FALSE
			COLUMN,     "Image",    		   	 			 5, STRING, 0, TRUE,  FALSE
			COLUMN,     "File Size",  						 6, UINT64, 0, TRUE,  FALSE 
			COLUMN,     "File Source",  					 7, STRING, 0, TRUE,  FALSE 
				
		END-TABLE
		
	END-FLAVOUR
	
	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "history_te_incidents"

		REMOVE-OID-ATOM
		ADD-OID-ATOM, 47
		
		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Threat-Emulation Incidents (last hour in 10 minutes resolution)"
				TABLE-OID,         1.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Low",        		10, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Medium",    		11, UINT64, 0, TRUE,  FALSE
			COLUMN,     "High",    			12, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Critical",    		13, UINT64, 0, TRUE,  FALSE
		
		END-TABLE
		
		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Threat-Emulation Incidents (last day in 4 hours resolution)"
				TABLE-OID,         1.2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Low",        		10, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Medium",    		11, UINT64, 0, TRUE,  FALSE
			COLUMN,     "High",    			12, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Critical",    		13, UINT64, 0, TRUE,  FALSE
		
		END-TABLE
	
		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Threat-Emulation Incidents (last week in 1 day resolution)"
				TABLE-OID,         1.3.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Low",        		10, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Medium",    		11, UINT64, 0, TRUE,  FALSE
			COLUMN,     "High",    			12, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Critical",    		13, UINT64, 0, TRUE,  FALSE
		
		END-TABLE
		
		
		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Threat-Emulation Incidents (last month in 5 days resolution)"
				TABLE-OID,         1.4.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Low",        		10, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Medium",    		11, UINT64, 0, TRUE,  FALSE
			COLUMN,     "High",    			12, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Critical",    		13, UINT64, 0, TRUE,  FALSE
		
		END-TABLE
		
		REMOVE-OID-ATOM

	END-FLAVOUR
	
	#################################################
	
	START-FLAVOUR

		FLAVOUR-NAME, "history_te_comp_hosts"

		REMOVE-OID-ATOM
		ADD-OID-ATOM, 47
		
		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Threat-Emulation Compromised hosts (last hour in 10 minutes resolution)"
				TABLE-OID,         1.7.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Low",        		10, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Medium",    		11, UINT64, 0, TRUE,  FALSE
			COLUMN,     "High",    			12, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Critical",    		13, UINT64, 0, TRUE,  FALSE
		
		END-TABLE
		
		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Threat-Emulation Compromised hosts (last day in 4 hours resolution)"
				TABLE-OID,         1.8.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Low",        		10, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Medium",    		11, UINT64, 0, TRUE,  FALSE
			COLUMN,     "High",    			12, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Critical",    		13, UINT64, 0, TRUE,  FALSE
		
		END-TABLE
	
		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Threat-Emulation Compromised hosts (last week in 1 day resolution)"
				TABLE-OID,         1.9.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Low",        		10, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Medium",    		11, UINT64, 0, TRUE,  FALSE
			COLUMN,     "High",    			12, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Critical",    		13, UINT64, 0, TRUE,  FALSE
		
		END-TABLE
		
		
		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Threat-Emulation Compromised hosts (last month in 5 days resolution)"
				TABLE-OID,         1.10.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Low",        		10, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Medium",    		11, UINT64, 0, TRUE,  FALSE
			COLUMN,     "High",    			12, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Critical",    		13, UINT64, 0, TRUE,  FALSE
		
		END-TABLE
		
		REMOVE-OID-ATOM

	END-FLAVOUR

END-BLOCK


START-BLOCK

	BLOCK-NAME, "asm"

	OID-BASE, 1.3.6.1.4.1.2620.1.17

	######################################################################

	START-FLAVOUR

		FLAVOUR-NAME, "default"

		ADD-OID-ATOM, 1			# ASM attacks

			ADD-OID-ATOM, 1			# layer 3 attacks
			REMOVE-OID-ATOM, 1		# layer 3 attacks

			ADD-OID-ATOM, 2			# layer 4 attacks

				ADD-OID-ATOM, 1			# TCP attacks

					ADD-OID-ATOM, 1			# SYN attacks

						SIMPLE-OID, "SynAckTimeout",  1, UINT32
						SIMPLE-OID, "SynAckReset", 	  2, UINT32
						SIMPLE-OID, "ModeChange",     3, UINT32
						SIMPLE-OID, "Curr_mode", 	  4, UINT32
						SIMPLE-OID, "Unacked_syns",	  5, UINT32

					REMOVE-OID-ATOM, 1		# SYN attacks

					ADD-OID-ATOM, 2			# Small PMTU attacks

						SIMPLE-OID, "PMTU num",       1, UINT32
						SIMPLE-OID, "PMTU min",       2, UINT32

					REMOVE-OID-ATOM, 2		# Small PMTU attacks

					ADD-OID-ATOM, 3			# Seq-val attacks

						SIMPLE-OID, "Invalid ack",       1, UINT32
						SIMPLE-OID, "Invalid seq",       2, UINT32
						SIMPLE-OID, "Invalid restrans",  3, UINT32

					REMOVE-OID-ATOM, 3		# Seq-val attacks

				REMOVE-OID-ATOM, 1		# TCP attacks

				ADD-OID-ATOM, 2			# UDP attacks
				REMOVE-OID-ATOM, 2		# UDP attacks

				ADD-OID-ATOM, 3			# Portscan attacks

					ADD-OID-ATOM, 1			# Vertical Portscan

						SIMPLE-OID, "Host Port Scan",       1, UINT32

					REMOVE-OID-ATOM, 1		# Vertical Portscan

					ADD-OID-ATOM, 2			# Horizontal Portscan

						SIMPLE-OID, "IP Sweep Scan",     1, UINT32

					REMOVE-OID-ATOM, 2		# Horizontal Portscan

				REMOVE-OID-ATOM, 3		# Portscan attacks

			REMOVE-OID-ATOM, 2		# layer 4 attacks
		
			ADD-OID-ATOM, 3			# layer 5 attacks

				ADD-OID-ATOM, 1			# HTTP attacks

					ADD-OID-ATOM, 1			# HTTP worms

						SIMPLE-OID, "HTTP worms num",        1, UINT32

					REMOVE-OID-ATOM, 1		# HTTP worms

					ADD-OID-ATOM, 2			# HTTP format

						SIMPLE-OID, "HTTP URL len",       	 1, UINT32
						SIMPLE-OID, "HTTP header len",       2, UINT32
						SIMPLE-OID, "HTTP max headers num",  3, UINT32

					REMOVE-OID-ATOM, 2		# HTTP format

					ADD-OID-ATOM, 3			# HTTP ascii

						SIMPLE-OID, "HTTP ASCII num",        1, UINT32

					REMOVE-OID-ATOM, 3		# HTTP ascii

					ADD-OID-ATOM, 4			# HTTP p2p

						SIMPLE-OID, "HTTP P2P header num",        1, UINT32

					REMOVE-OID-ATOM, 4		# HTTP p2p

					ADD-OID-ATOM, 5			# Web Security

						ADD-OID-ATOM, 1			# Connections

							ADD-OID-ATOM, 1			# General

								SIMPLE-OID, "WS Created connections",        			 1, UINT32

								SIMPLE-OID, "WS Concurrent connections",   				 2, UINT32

								SIMPLE-OID, "WS Connections rejected - total",     		 3, UINT32
								SIMPLE-OID, "WS Connections rej. with error - total",    4, UINT32

							REMOVE-OID-ATOM, 1		# General

							ADD-OID-ATOM, 2			# Protection Rejections

								SIMPLE-OID, "WS Protection - HTTP format",         		 1, UINT32
								SIMPLE-OID, "WS Protection - HTTP methods",					 2, UINT32
								SIMPLE-OID, "WS Protection - Directory traversal",    	 3, UINT32
								SIMPLE-OID, "WS Protection - Cross-site scripting",		 4, UINT32
								SIMPLE-OID, "WS Protection - SQL injection",          	 5, UINT32
								SIMPLE-OID, "WS Protection - Command stealth",        	 6, UINT32
								SIMPLE-OID, "WS Protection - Header spoofing",        	 7, UINT32
								SIMPLE-OID, "WS Protection - Server-side scripting",  	 8, UINT32
								SIMPLE-OID, "WS Protection - Header rejection",			 9, UINT32
								SIMPLE-OID, "WS Protection - Quick UFP",					10, UINT32
								SIMPLE-OID, "WS Protection - Buffer overflow",        	11, UINT32
								SIMPLE-OID, "WS Protection - ASCII only response",       	12, UINT32
								SIMPLE-OID, "WS Protection - Error concealment",        	13, UINT32
								SIMPLE-OID, "WS Protection - LDAP injection",	        	14, UINT32
								SIMPLE-OID, "WS Protection - Directory listing",        	15, UINT32
								SIMPLE-OID, "WS Protection - Instant messenger",        	16, UINT32								

							REMOVE-OID-ATOM, 2		# Protection Rejections

						REMOVE-OID-ATOM, 1		# Connections

						ADD-OID-ATOM, 2			# Sessions

							SIMPLE-OID, "WS Created sessions",        			  		 1, UINT32
							SIMPLE-OID, "WS Concurrent sessions",     			   		 2, UINT32
							SIMPLE-OID, "WS HTTP/1.1 sessions", 		    			 3, UINT32
							SIMPLE-OID, "WS HTTP/1.0 sessions",       					 4, UINT32

						REMOVE-OID-ATOM, 2		# Sessions

						ADD-OID-ATOM, 3			# Content

							SIMPLE-OID, "WS Request length max",        				 1, UINT32
							SIMPLE-OID, "WS Request length average",        			 2, UINT32

							SIMPLE-OID, "WS URL length max",        					 3, UINT32
							SIMPLE-OID, "WS URL length average",        				 4, UINT32

						REMOVE-OID-ATOM, 3		# Content

					REMOVE-OID-ATOM, 5		# Web Security

				REMOVE-OID-ATOM, 1		# HTTP attacks

				ADD-OID-ATOM, 2			# CIFS

				ADD-OID-ATOM, 1			# CIFS worms

					SIMPLE-OID, "CIFS worms num", 		 1, UINT32

				REMOVE-OID-ATOM, 1		# CIFS worms

				ADD-OID-ATOM, 2			# CIFS NULL sessions

					SIMPLE-OID, "CIFS NULL session num", 		 1, UINT32

				REMOVE-OID-ATOM, 2		# CIFS NULL sessions

				ADD-OID-ATOM, 3			# CIFS block popup num

					SIMPLE-OID, "CIFS blocked popup num", 		 1, UINT32

				REMOVE-OID-ATOM, 3		# CIFS block popup num

				ADD-OID-ATOM, 4			# CIFS blocked commands

					SIMPLE-OID, "CIFS blocked commands num", 		 1, UINT32

				REMOVE-OID-ATOM, 4		# CIFS blocked commands

				ADD-OID-ATOM, 5			# CIFS password len

					SIMPLE-OID, "CIFS password length num", 		 1, UINT32

				REMOVE-OID-ATOM, 5		# CIFS password len

			REMOVE-OID-ATOM, 2		# CIFS

			ADD-OID-ATOM, 3			# P2P

				ADD-OID-ATOM, 1			# P2P other

					SIMPLE-OID, "P2P other num", 		 1, UINT32

				REMOVE-OID-ATOM, 1		# P2P other

				ADD-OID-ATOM, 2			# P2P Kazaa

					SIMPLE-OID, "P2P Kazaa num", 		 1, UINT32

				REMOVE-OID-ATOM, 2		# P2P Kazaa

				ADD-OID-ATOM, 3			# P2P Emule

					SIMPLE-OID, "P2P Emule num", 		 1, UINT32

				REMOVE-OID-ATOM, 3		# P2P Emule

				ADD-OID-ATOM, 4			# P2P Gnutella

					SIMPLE-OID, "P2P Gnutella num", 	 1, UINT32

				REMOVE-OID-ATOM, 4		# P2P Gnutella

				ADD-OID-ATOM, 5			# P2P Skype

					SIMPLE-OID, "P2P Skype num", 	 	1, UINT32

				REMOVE-OID-ATOM, 5		# P2P Skype

				ADD-OID-ATOM, 6			# P2P Bittorrent

					SIMPLE-OID, "P2P Bittorrent num",  	1, UINT32

				REMOVE-OID-ATOM, 6		# P2P Bittorrent

				ADD-OID-ATOM, 7			# P2P Yahoo Messenger

					SIMPLE-OID, "P2P Yahoo Messenger num",  	1, UINT32

				REMOVE-OID-ATOM, 7		# P2P Yahoo Messenger

				ADD-OID-ATOM, 8			# P2P ICQ

					SIMPLE-OID, "P2P ICQ num",  	1, UINT32

				REMOVE-OID-ATOM, 8		# P2P ICQ
				

			REMOVE-OID-ATOM, 3		# P2P

		REMOVE-OID-ATOM, 3		# layer 5 attacks
		REMOVE-OID-ATOM, 1    	# ASM attacks
		
	END-FLAVOUR

	######################################################################

	START-FLAVOUR

		FLAVOUR-NAME, "WS"

		ADD-OID-ATOM, 1			# ASM attacks

			ADD-OID-ATOM, 3			# layer 5 attacks

				ADD-OID-ATOM, 1			# HTTP attacks

					ADD-OID-ATOM, 5			# Web Security

						ADD-OID-ATOM, 1			# Connections

							ADD-OID-ATOM, 1			# General

								SIMPLE-OID, "Created connections",        			 1, UINT32

								SIMPLE-OID, "Concurrent connections",   			 2, UINT32

								SIMPLE-OID, "Connections rejected - total",     	 3, UINT32
								SIMPLE-OID, "Connections rej. with error - total",   4, UINT32

							REMOVE-OID-ATOM, 1		# General

							ADD-OID-ATOM, 2			# Protection Rejections

								SIMPLE-OID, "Protection - HTTP format",					 1, UINT32
								SIMPLE-OID, "Protection - HTTP methods",         	 	 2, UINT32
								SIMPLE-OID, "Protection - Directory traversal",    	 3, UINT32
								SIMPLE-OID, "Protection - Cross-site scripting",    	 4, UINT32
								SIMPLE-OID, "Protection - SQL injection",          	 5, UINT32
								SIMPLE-OID, "Protection - Command Stealth",        	 6, UINT32
								SIMPLE-OID, "Protection - Header spoofing",        	 7, UINT32
								SIMPLE-OID, "Protection - Server-side scripting",  	 8, UINT32
								SIMPLE-OID, "Protection - Header rejection",      		 9, UINT32
								SIMPLE-OID, "Protection - Quick UFP",        			10, UINT32
								SIMPLE-OID, "Protection - Buffer overflow",        	11, UINT32
								SIMPLE-OID, "Protection - ASCII only response",      	12, UINT32
								SIMPLE-OID, "Protection - Error concealment",        	13, UINT32
								SIMPLE-OID, "Protection - LDAP injection",	        	14, UINT32
								SIMPLE-OID, "Protection - Directory listing",        	15, UINT32
								SIMPLE-OID, "Protection - Instant messenger",        	16, UINT32								

							REMOVE-OID-ATOM, 2		# Protection Rejections

						REMOVE-OID-ATOM, 1		# Connections

					REMOVE-OID-ATOM, 5		# Web Security

					ADD-OID-ATOM, 1			# HTTP worms

						SIMPLE-OID, "Protection - Worm catcher",      		   1, UINT32

					REMOVE-OID-ATOM, 1		# HTTP worms

					ADD-OID-ATOM, 3			# HTTP ascii

						SIMPLE-OID, "Protection - ASCII only requests",        1, UINT32

					REMOVE-OID-ATOM, 3		# HTTP ascii

					ADD-OID-ATOM, 4			# HTTP p2p

						SIMPLE-OID, "Protection - Peer 2 Peer",        		   1, UINT32

					REMOVE-OID-ATOM, 4		# HTTP p2p

					ADD-OID-ATOM, 5			# Web Security

						ADD-OID-ATOM, 2			# Sessions

							SIMPLE-OID, "Created sessions",        			  		 1, UINT32
							SIMPLE-OID, "Concurrent sessions",     			   		 2, UINT32
							SIMPLE-OID, "HTTP/1.1 sessions", 		    			 3, UINT32
							SIMPLE-OID, "HTTP/1.0 sessions",       					 4, UINT32

						REMOVE-OID-ATOM, 2		# Sessions

						ADD-OID-ATOM, 3			# Content

							SIMPLE-OID, "Request length max",        				 1, UINT32
							SIMPLE-OID, "Request length average",        			 2, UINT32

							SIMPLE-OID, "URL length max",        					 3, UINT32
							SIMPLE-OID, "URL length average",        				 4, UINT32

						REMOVE-OID-ATOM, 3		# Content

					REMOVE-OID-ATOM, 5		# Web Security

				REMOVE-OID-ATOM, 1		# HTTP attacks

			REMOVE-OID-ATOM, 3		# layer 5 attacks

		REMOVE-OID-ATOM, 1		# ASM attacks

	END-FLAVOUR
	
END-BLOCK




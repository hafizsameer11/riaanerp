(
        : (
                :host ("cws.checkpoint.com")
                :description (0)
                :type (domain)
        )
        : (
                :host ("supportcenter.checkpoint.com")
                :description (0)
                :type (domain)
        )
        : (
                :host ("supportcontent.checkpoint.com")
                :description (0)
                :type (domain)
        )
        : (
                :host ("updates.checkpoint.com")
                :description (0)
                :type (domain)
        )
        : (
                :host ("dl3.checkpoint.com")
                :description (0)
                :type (domain)
        )
        : (
                :host ("usercenter.checkpoint.com")
                :description (0)
                :type (domain)
        )
        : (
                :host ("resolver1.chkp.ctmail.com")
                :description (0)
                :type (domain)
        )
        : (
                :host ("resolver2.chkp.ctmail.com")
                :description (0)
                :type (domain)
        )
        : (
                :host ("resolver3.chkp.ctmail.com")
                :description (0)
                :type (domain)
        )
        : (
                :host ("resolver4.chkp.ctmail.com")
                :description (0)
                :type (domain)
        )
        : (
                :host ("resolver5.chkp.ctmail.com")
                :description (0)
                :type (domain)
        )
        : (
                :host ("download.ctmail.com")
                :description (0)
                :type (domain)
        )
        : (
                :host ("te.checkpoint.com")
                :description (0)
                :type (domain)
        )
        : (
                :host ("kav8.zonealarm.com")
                :description (0)
                :type (domain)
        )
        : (
                :host ("kav8.checkpoint.com")
                :description (0)
                :type (domain)
        )
	: (
		:host ("avupdates.checkpoint.com")
		:description (0)
		:type (domain)
	)
        : (
                :host ("sigcheck.checkpoint.com")
                :description (0)
                :type (domain)
        )
        : (
                :host ("smbmgmtservice.checkpoint.com")
                :description (0)
                :type (domain)
        )
        : (
                :host ("secureupdates.checkpoint.com")
                :description (0)
                :type (domain)
        )
        : (
                :host ("productcoverage.checkpoint.com")
                :description (0)
                :type (domain)
        )
        : (
                :host ("sc1.checkpoint.com")
                :description (0)
                :type (domain)
        )
        : (
                :host ("sc2.checkpoint.com")
                :description (0)
                :type (domain)
        )
        : (
                :host ("sc3.checkpoint.com")
                :description (0)
                :type (domain)
        )
        : (
                :host ("sc4.checkpoint.com")
                :description (0)
                :type (domain)
        )
        : (
                :host ("sc5.checkpoint.com")
                :description (0)
                :type (domain)
        )
        : (
                :host ("push.checkpoint.com")
                :description (0)
                :type (domain)
        )
        : (
                :host ("downloads.checkpoint.com")
                :description (0)
                :type (domain)
        )
		: (
                :host ("gwevents.checkpoint.com")
                :description (0)
                :type (domain)
        )
        : (
                :host ("smbcloudmgmt.checkpoint.com")
                :description (0)
                :type (domain)
        )
        : (
                :host ("smbclouddeployment.checkpoint.com")
                :description (0)
                :type (domain)
        )
        : (
                :host ("smbrelay.checkpoint.com")
                :description (0)
                :type (domain)
        )
        : (
                :host ("crl.verisign.com")
                :description (0)
                :type (domain)
        )
        : (
                :host ("crl.entrust.net")
                :description (0)
                :type (domain)
        )
        : (
                :host ("Kav82.zonealarm.com")
                :description (0)
                :type (domain)
        )
        : (
                :host ("services.checkpoint.com")
                :description (0)
                :type (domain)
        )
        : (
                :host ("teadv.checkpoint.com")
                :description (0)
                :type (domain)
        )
        : (
                :host ("threat-emulation.checkpoint.com")
                :description (0)
                :type (domain)
        )
        : (
                :host ("zerotouch.checkpoint.com")
                :description (0)
                :type (domain)
        )
        : (
                :host ("productservices.checkpoint.com")
                :description (0)
                :type (domain)
        )
)

(
	:version (5.9)
	: (MailServerMultiSetDefinitions
		:AdminInfo (
			:chkpf_uid ("{D080EF90-F6E2-43D3-B30F-C5F9FC6EA80E}")
			:ClassName (spii_feature_definitions)
			:table (spii_params)
			:LastModified (
					:Time ("Wed Jul 30 16:59:26 2003")
					:By (CheckPoint)
					:From (CheckPoint)
			)
		)
		:type (spii_feature_definitions) 
		:feature_settings ()
		:id (1)
		:feature_fields (
			:0  (
				:AdminInfo (
					:chkpf_uid ("{80273A1C-FD42-4A1A-81E2-135D5E085198}")
					:ClassName (feature_field)
					)
				:name (type)
				:type (string)
			)
			:1  (
				:AdminInfo (
					:chkpf_uid ("{4C64C26D-E585-421E-9FD6-C1D1F2A786BC}")
					:ClassName (feature_field)
					)
				:name (pop3_port)
				:type (int)
			)
			:2  (
				:AdminInfo (
					:chkpf_uid ("{6688DE4C-C636-4D9B-87D7-9B8AF05CFE84}")
					:ClassName (feature_field)
					)
				:name (imap_port)
				:type (int)
			)
			:3  (
				:AdminInfo (
					:chkpf_uid ("{5F7E235F-875D-4CB4-9EDD-7C78F13C6898}")
					:ClassName (feature_field)
					)
				:name (log_username)
				:type (boolean)
			)
			:4  (
				:AdminInfo (
					:chkpf_uid ("{6944EF81-4C04-4D4B-A338-0C73D2777669}")
					:ClassName (feature_field)
					)
				:name (verify_with_vpn)
				:type (boolean)
			)
			:5  (
				:AdminInfo (
					:chkpf_uid ("{0E02A844-0DEA-4773-B39D-50FFA1DA5AD4}")
					:ClassName (feature_field)
					)
				:name (verify_with_ua)
				:type (boolean)
			)
			:6  (
				:AdminInfo (
					:chkpf_uid ("{A8194542-E9C5-4005-84FE-2859968D1E38}")
					:ClassName (feature_field)
					)
				:name (pop3_imap_security)
				:type (boolean)
			)
			:7  (
				:AdminInfo (
					:chkpf_uid ("{5610C909-2EB0-43F7-A344-48BD04B525D9}")
					:ClassName (feature_field)
					)
				:name (mail_server_drop_connections)
				:type (boolean)
			)
			:8  (
				:AdminInfo (
					:chkpf_uid ("{01B06CCB-86BF-4F9C-A0E7-57D49C2FDEC5}")
					:ClassName (feature_field)
					)
				:name (mail_server_tracking)
				:type (alert_command)
			)
			:9	(
				:AdminInfo (
					:chkpf_uid ("{DB68737D-062B-446C-B7BF-4073F9AE166C}")
					:ClassName (feature_field)
					)
				:name (allow_multi_usr_cmds)
				:type (boolean)
			)
			:10	(
				:AdminInfo (
					:chkpf_uid ("{816763F9-744F-4B9F-83F0-916C32148722}")
					:ClassName (feature_field)
					)
				:name (is_pop3_server)
				:type (boolean)
			)
			:11	(
				:AdminInfo (
					:chkpf_uid ("{61898517-4DE9-492E-8134-39C1C1395C9C}")
					:ClassName (feature_field)
					)
				:name (is_imap_server)
				:type (boolean)
			)
			:12	(
				:AdminInfo (
					:chkpf_uid ("{5E7DBC11-F800-4B2D-B94A-8F2D217207A5}")
					:ClassName (feature_field)
					)
				:name (operating_system)
				:type (string)
			)
		)
	)
	: (inspect_streaming_feature
		 :AdminInfo (
			:chkpf_uid ("{F7B913B0-024F-4DFF-BE6D-5E6CC74FDB24}")
			:ClassName (spii_feature_definitions)
			:table (spii_params)
			:LastModified (
					:Time ("Wed Jul 30 16:59:26 2003")
					:By (CheckPoint)
					:From (CheckPoint)
			)
		  )
                :id (56)
                :type (spii_feature_definitions)
                :feature_fields (
                        :0 (
                        	:AdminInfo (
					:chkpf_uid ("{817864DC-36FE-4E6D-BA5F-14C703BD1525}")
					:ClassName (feature_field)
				)
                               	:name (streaming_type)
                               	:type (string)
                        )
                        :1 (
                        	:AdminInfo (
					:chkpf_uid ("{533619FB-6A90-486A-A6E7-368F2D8F6DD5}")
					:ClassName (feature_field)
				)
                               	:name (max_buffer_size)
                                :type (int)
                        )
                        :2 (
                        	:AdminInfo (
					:chkpf_uid ("{4F94A7C4-2286-4B31-A20D-3CB0F8886D4E}")
					:ClassName (feature_field)
				)
                               	:name (init_buffer_size)
                                :type (int)
                        )
                        :3 (
                        	:AdminInfo (
					:chkpf_uid ("{B92D77D6-389B-4723-A728-E0D14B19237C}")
					:ClassName (feature_field)
				)
                                :name (min_message_size)
                               	 :type (int)
                        )
                        :4 (
                        	:AdminInfo (
					:chkpf_uid ("{925C6927-3967-49A5-B082-2B76642DC286}")
					:ClassName (feature_field)
				)
                               	:name (parse_handler)
                                	:type (inspect_handler)
                        )
                        :5 (
                        	:AdminInfo (
					:chkpf_uid ("{C8850078-C013-4BEF-B2C5-A97E9128EAF1}")
					:ClassName (feature_field)
				)
                                :name (inspection_handler)
                               	:type (inspect_handler)
                        )
                        :6 (
                        	:AdminInfo (
					:chkpf_uid ("{6D72BD86-1459-4064-8E0C-501038799F99}")
					:ClassName (feature_field)
				)
                               	:name (end_handler)
                               	:type (inspect_handler)
                        )
                        :7 (
                        	:AdminInfo (
					:chkpf_uid ("{FDD22ECD-9E1F-48CE-AC6E-B6A33F022C74}")
					:ClassName (feature_field)
				)
                                :name (error_handler)
                               	:type (inspect_handler)
                        )
                        :8 (
                        	:AdminInfo (
					:chkpf_uid ("{1267C532-C8AA-4B0E-9801-EBD9E32444BD}")
					:ClassName (feature_field)
				)
                                :name (kernel_index)
                               	:type (int)
                        )
                )
		:feature_settings ()
        )
	: (MailServerGlobalDefinitions
		:AdminInfo (
			:chkpf_uid ("{86E1241C-2ED3-480A-836F-A3F9498D0AE9}")
			:ClassName (spii_feature_definitions)
			:table (spii_params)
		)
		:feature_settings (ReferenceObject
			:Table (asm)
			:Name (AdvancedSecurityObject)
			:Uid ("{FCFD107B-35E2-11D6-A48B-00D0B7BE171D}")
			:path (
				: (asm_active_protection)
				: (mail_servers_enforcement)
			)
		)
		:type (spii_feature_definitions) 
		:id (2)
		:feature_fields (
			:0  (
				:AdminInfo (
					:chkpf_uid ("{3C22EBF2-3E06-4162-A704-447D14993E00}")
					:ClassName (feature_field)
					)
				:name (type)
				:type (string)
			)
			:1  (
				:AdminInfo (
					:chkpf_uid ("{E4774DBD-4AF1-438C-984E-30E1A8138C9D}")
					:ClassName (feature_field)
					)
				:name (enforce_mail_servers_protection)
				:type (boolean)
			)	
			:2  (
				:AdminInfo (
					:chkpf_uid ("{7776CC7F-ADA7-472A-8159-0B18632C8BF9}")
					:ClassName (feature_field)
					)
				:name (is_max_username_length)
				:type (boolean)
			)
			:3  (
				:AdminInfo (
					:chkpf_uid ("{64578095-9B85-40FF-8569-7BB984063AA0}")
					:ClassName (feature_field)
					)
				:name (max_username_length)
				:type (int)
			)
			:4  (
				:AdminInfo (
					:chkpf_uid ("{CA99CE7F-A62E-445E-989B-4FB118900767}")
					:ClassName (feature_field)
					)
				:name (is_max_noop_cmds)
				:type (boolean)
			)
			:5  (
				:AdminInfo (
					:chkpf_uid ("{4CB26B45-E63B-4966-925B-67595981E6B3}")
					:ClassName (feature_field)
					)
				:name (max_noop_cmds)
				:type (int)
			)
			:6  (
				:AdminInfo (
					:chkpf_uid ("{59968BD0-B031-4DB4-A730-6686FB38E210}")
					:ClassName (feature_field)
					)
				:name (block_bin_data)
				:type (boolean)
			)
			:7  (
				:AdminInfo (
					:chkpf_uid ("{2F4D55C6-D0EE-4572-B138-AB3FD4A8C623}")
					:ClassName (feature_field)
					)
				:name (block_identical_name_and_pass)
				:type (boolean)
			)
			:8  (
				:AdminInfo (
					:chkpf_uid ("{B5900637-D0E8-444E-90B5-0091694F4BD2}")
					:ClassName (feature_field)
					)
				:name (mail_servers_alert)
				:type (alert_command)
			)
			:9  (
				:AdminInfo (
					:chkpf_uid ("{8A83C037-9090-4A84-8F12-22CD8A6C883D}")
					:ClassName (feature_field)
					)
				:name (mail_servers_monitor_only)
				:type (boolean)
			)
			:10  (
				:AdminInfo (
					:chkpf_uid ("{125494E4-5026-4824-92CB-371F8258568B}")
					:ClassName (feature_field)
					)
				:name (apply_mail_servers_enforcement_on)
				:type (string)
			)
			:11  (
				:AdminInfo (
					:chkpf_uid ("{1EFD382A-809E-471A-BB2F-B0D5060E3DA2}")
					:ClassName (feature_field)
					)
				:name (allow_unknown_commands)
				:type (boolean)
			)
			:12  (
				:AdminInfo (
					:chkpf_uid ("{234D55C6-D0EE-4572-B138-AB3FD4A8C623}")
					:ClassName (feature_field)
					)
				:name (mail_servers_packet_capture)
				:type (boolean)
			)
		)
	)
	: (web_server_protection_scheme
		:AdminInfo (
			:chkpf_uid ("{70D8B1B9-D248-46CB-81F6-D3065F097FF5}")
			:ClassName (spii_feature_definitions)
			:table (spii_params)
			)
		:id (34)
		:type (spii_feature_definitions) 
		:feature_fields (
			:0 (
				:AdminInfo (
					:chkpf_uid ("{E387DBA0-CC96-4920-9FFF-B517CF9C7B75}")
					:ClassName (feature_field)
					)
				:name (http_format_size)
				:type (boolean)
			)
			:1 (
				:AdminInfo (
					:chkpf_uid ("{54E6A675-8880-4B39-A7E6-8CE0D813A3CA}")
					:ClassName (feature_field)
					)
				:name (http_request_validity)
				:type (boolean)
			)
			:2 (
				:AdminInfo (
					:chkpf_uid ("{EA8F67A6-063D-42EA-A9B3-E14043F8A083}")
					:ClassName (feature_field)
					)
				:name (protect_http_dir_traversal)
				:type (boolean)
			)
			:3 (
				:AdminInfo (
					:chkpf_uid ("{B4F8E406-36CA-477B-9EC1-DF23F09E3F14}")
					:ClassName (feature_field)
					)
				:name (http_worm_catcher)
				:type (boolean)
			)
			:4 (
				:AdminInfo (
					:chkpf_uid ("{D4DD35C6-0DD1-4F7A-B482-3A72BC74EE7B}")
					:ClassName (feature_field)
					)
				:name (cross_sites_scripting)
				:type (boolean)
			)
			:5 (
				:AdminInfo (
					:chkpf_uid ("{847C2D3E-B0D1-4EDD-94D7-FB6C0586E119}")
					:ClassName (feature_field)
					)
				:name (strip)
				:type (string)
			)
			:6 (
				:AdminInfo (
					:chkpf_uid ("{05598537-3CC2-4136-9F9E-2FBD55C0FB35}")
					:ClassName (feature_field)
					)
				:name (http_sql_injection)
				:type (boolean)
			)
			:7 (
				:AdminInfo (
					:chkpf_uid ("{CD775373-99F6-4603-A3C2-CD385BAB30D2}")
					:ClassName (feature_field)
					)
				:name (http_sql_injection_level)
				:type (string)
			)
			:8 (
				:AdminInfo (
					:chkpf_uid ("{D077E4CD-C024-4925-A8F0-7A49E77439A5}")
					:ClassName (feature_field)
					)
				:name (http_command_stealth)
				:type (boolean)
			)
			:9 (
				:AdminInfo (
					:chkpf_uid ("{9163A665-8904-45F7-A96E-31D974603647}")
					:ClassName (feature_field)
					)
				:name (http_command_stealth_level)
				:type (string)
			)
			:10 (
				:AdminInfo (
					:chkpf_uid ("{E24D81A5-37FF-4B53-9F90-0CF48A1E5156}")
					:ClassName (feature_field)
					)
				:name (http_generic_header_spoofing)
				:type (boolean)
			)
			:11 (
				:AdminInfo (
					:chkpf_uid ("{2D358582-F06D-46C0-B637-1F3555D6D997}")
					:ClassName (feature_field)
					)
				:name (web_server_type)
				:type (string)
			)
			:12 (
				:AdminInfo (
					:chkpf_uid ("{E6B27CDA-5A10-46E6-B2A6-C3EB2861D6A7}")
					:ClassName (feature_field)
					)
				:name (http_allow_methods)
				:type (boolean)
			)
			:13 (
				:AdminInfo (
					:chkpf_uid ("{83C6ACB5-8D6A-482A-A84D-8308507DA347}")
					:ClassName (feature_field)
					)
				:name (http_header_rejection)
				:type (boolean)
			)
			:14 (
				:AdminInfo (
					:chkpf_uid ("{8BF49412-3629-4E89-8EFD-07343D209C9F}")
					:ClassName (feature_field)
					)
				:name (http_buffer_overflow)
				:type (boolean)
			)
			:15 (
				:AdminInfo (
					:chkpf_uid ("{18A20340-C51E-4812-B64F-F2205523DCBA}")
					:ClassName (feature_field)
					)
				:name (http_buffer_overflow_level)
				:type (string)
			)
			:16 (
				:AdminInfo (
					:chkpf_uid ("{4CAF5FD3-B728-472C-B019-C668199517D4}")
					:ClassName (feature_field)
					)
				:name (operating_system)
				:type (string)
			)
			:17 (
				:AdminInfo (
					:chkpf_uid ("{3E291D4D-6413-407E-93BB-84576B18BDAE}")
					:ClassName (feature_field)
				)
				:name (http_ldap_injection)
				:type (boolean)
			)
			:18 (
				:AdminInfo (
					:chkpf_uid ("{ECDE88C5-D8FF-4B2E-AE13-1AEF3E6710EF}")
					:ClassName (feature_field)
				)
				:name (http_ldap_injection_level)
				:type (string)
			)
			:19 (
				:AdminInfo (
					:chkpf_uid ("{BC09191E-3880-48F7-8671-8E8E4B5EC093}")
					:ClassName (feature_field)
				)
				:name (http_directory_listing)
				:type (boolean)
			)
			:20 (
				:AdminInfo (
					:chkpf_uid ("{AC437644-EE20-4C08-859F-935F78C5101C}")
					:ClassName (feature_field)
				)
				:name (http_directory_listing_level)
				:type (string)
			)
			:21 (
				:AdminInfo (
					:chkpf_uid ("{4BD03D89-ECD3-4250-9C89-D1051215DD7B}")
					:ClassName (feature_field)
				)
				:name (http_error_concealment)
				:type (boolean)
			)
			:22 (
				:AdminInfo (
					:chkpf_uid ("{4E3A0058-13C5-4304-8A6D-8755FF63C2C2}")
					:ClassName (feature_field)
				)
				:name (http_error_concealment_scan_engines)
				:type (boolean)
			)
			:23 (
				:AdminInfo (
					:chkpf_uid ("{3C27DF2E-A72E-437A-A380-B36CE2293116}")
					:ClassName (feature_field)
				)
				:name (http_enforced_engines_list_spii)
				:type (strlist)
			)
			:24 (
				:AdminInfo (
					:chkpf_uid ("{7CECB481-3919-45C0-966B-4CDBB685E168}")
					:ClassName (feature_field)
				)
				:name (http_allowed_methods_apply_default)
				:type (boolean)
			)
			:25 (
				:AdminInfo (
					:chkpf_uid ("{F2066EE5-8F8B-49B5-B867-462DB47631CB}")
					:ClassName (feature_field)
				)
				:name (http_allowed_methods_apply_safe)
				:type (boolean)
			)
			:26 (
				:AdminInfo (
					:chkpf_uid ("{9FE817DE-6CBA-49A2-8E4D-BBD4D08B758E}")
					:ClassName (feature_field)
				)
				:name (http_allowed_methods_apply_unsafe)
				:type (boolean)
			)
			:27 (
				:AdminInfo (
					:chkpf_uid ("{5FFFB0CF-0529-44E3-8AD0-0F90AA6C3723}")
					:ClassName (feature_field)
				)
				:name (http_allowed_methods_apply_webdav)
				:type (boolean)
			)
			:28 (
				:AdminInfo (
					:chkpf_uid ("{C46822B5-796E-4EAE-8467-0C397818837C}")
					:ClassName (feature_field)
				)
				:name (web_server_monitor_only)
				:type (boolean)
			)
		)
		:feature_settings ()
	)
	
	: (http_format_size_global_definitions
		:AdminInfo (
			:chkpf_uid ("{D638FEE0-3546-405B-8932-61C35FAFEA0C}")
			:ClassName (spii_feature_definitions)
			:table (spii_params)
		)
		:type (spii_feature_definitions) 
		:feature_settings (ReferenceObject
			:Table (asm)
			:Name (AdvancedSecurityObject)
			:Uid ("{FCFD107B-35E2-11D6-A48B-00D0B7BE171D}")
			:path (
				: (asm_active_protection)
				: (HTTP_security_server)
			)
		)
		:id (3)
		:feature_fields (
			:0 (
				:AdminInfo (
					:chkpf_uid ("{9219147F-2BD5-4F67-9250-B92FE12E2BC1}")
					:ClassName (feature_field)
					)
				:name (http_format_size_enabled)
				:type (boolean)
			)
			:1 (
				:AdminInfo (
					:chkpf_uid ("{5F503942-EB9B-4CC3-8056-49CFC3F78D2D}")
					:ClassName (feature_field)
					)
				:name (http_apply_format_size_on)
				:type (string)
			)
			:2 (
				:AdminInfo (
					:chkpf_uid ("{C191882E-4189-4091-AAE3-0489A738FEC6}")
					:ClassName (feature_field)
					)
				:name (http_format_size_track)
				:type (string)
			)
			:3 (
				:AdminInfo (
					:chkpf_uid ("{A55E84B9-79B8-4D28-8CB4-F9AEEA6D30B2}")
					:ClassName (feature_field)
					)
				:name (http_format_size_monitor_only)
				:type (boolean)
			)
			:4 (
				:AdminInfo (
					:chkpf_uid ("{EC8CBA45-FE76-452D-8E15-8B6614226FD4}")
					:ClassName (feature_field)
					)
				:name (http_format_size_send_error)
				:type (boolean)
			)
			:5 (
				:AdminInfo (
					:chkpf_uid ("{685728FE-4262-4DCA-B1BA-6B3112399D7D}")
					:ClassName (feature_field)
					)
				:name (http_enforce_max_url_length)
				:type (boolean)
			)
			:6 (
				:AdminInfo (
					:chkpf_uid ("{8F2309AF-8A35-4832-882A-7F8C9BD2B333}")
					:ClassName (feature_field)
					)
				:name (http_max_request_url_length)
				:type (int)
			)
			:7 (
				:AdminInfo (
					:chkpf_uid ("{D976AEE6-3868-4CB5-9D2A-81DD066D1F5A}")
					:ClassName (feature_field)
					)
				:name (http_enforce_max_header_length)
				:type (boolean)
			)
			:8 (
				:AdminInfo (
					:chkpf_uid ("{E25E90CC-D0A2-406D-AC4F-FC925EDFD31F}")
					:ClassName (feature_field)
					)
				:name (http_max_header_length)
				:type (int)
			)
			:9 (
				:AdminInfo (
					:chkpf_uid ("{F670F9BE-9143-407F-B92E-482830DE3D06}")
					:ClassName (feature_field)
					)
				:name (http_enforce_max_num_of_http_headers)
				:type (boolean)
			)
			:10 (
				:AdminInfo (
					:chkpf_uid ("{A62B2072-C7B9-4076-ADFD-5FE69C4BE0F7}")
					:ClassName (feature_field)
					)
				:name (http_max_header_num)
				:type (int)
			)
			:11 (
				:AdminInfo (
					:chkpf_uid ("{6BA41C58-0F4C-4BCC-961C-C14DAB161EC9}")
					:ClassName (feature_field)
					)
				:name (http_enforce_max_request_body_length)
				:type (boolean)
			)
			:12 (
				:AdminInfo (
					:chkpf_uid ("{5FF8AFFA-EF9F-499E-8A5D-567B22467438}")
					:ClassName (feature_field)
					)
				:name (http_max_request_body_length)
				:type (int)
			)
			:13 (
				:AdminInfo (
				       :chkpf_uid ("{6291E51A-FEFF-44FD-AF1B-788C6E715F2F}")
				       :ClassName (feature_field)
				       )
				:name (http_format_size_packet_capture)
				:type (boolean)
                     		)
			:14 (
				   :AdminInfo (
						  :chkpf_uid ("{E6C56883-268F-4A05-ABC7-921BD33BDBD5}")
						  :ClassName (feature_field)
						  )
				   :name (http_enforce_param_name_max_length)
				   :type (boolean)
			)
			:15 (
				   :AdminInfo (
						  :chkpf_uid ("{A5D4321D-E452-43E6-9895-A46DD1CCF9F0}")
						  :ClassName (feature_field)
						  )
				   :name (http_param_name_max_length)
				   :type (int)
			)                     

		)
	)

	: (http_ascii_only_request_protection
		:AdminInfo (
			:chkpf_uid ("{3C2E05E4-DA0D-405B-8742-F862D18B7565}")
			:ClassName (spii_feature_definitions)
			:table (spii_params)
			)
		:feature_settings (ReferenceObject
			:Table (asm)
			:Name (AdvancedSecurityObject)
			:Uid ("{FCFD107B-35E2-11D6-A48B-00D0B7BE171D}")
			:path (
				: (asm_active_protection)
				: (HTTP_security_server)
			)
		)
		:type (spii_feature_definitions) 
		:id (4)
		:feature_fields (
			:0 (
				:AdminInfo (
					:chkpf_uid ("{8B4236D6-E6D6-4056-838C-B349D103EE61}")
					:ClassName (feature_field)
					)
				:name (http_check_request_enabled)
				:type (boolean)
			)
			:1 (
				:AdminInfo (
					:chkpf_uid ("{0E65195C-FAAE-47CA-92DC-3BD8883CADE4}")
					:ClassName (feature_field)
					)
				:name (http_apply_request_validity_on)
				:type (string)
			)
			:2 (
				:AdminInfo (
					:chkpf_uid ("{72398BF0-500F-4298-B551-861F91246BDA}")
					:ClassName (feature_field)
					)
				:name (http_request_validity_track)
				:type (string)
			)
			:3 (
				:AdminInfo (
					:chkpf_uid ("{367D6592-F46B-4E50-8331-2064C242BD97}")
					:ClassName (feature_field)
					)
				:name (http_request_validity_monitor_only)
				:type (boolean)
			)
			:4 (
				:AdminInfo (
					:chkpf_uid ("{D1697714-C576-4E79-A142-ACA8255AEC67}")
					:ClassName (feature_field)
					)
				:name (http_request_validity_send_error)
				:type (boolean)
			)
			:5 (
				:AdminInfo (
					:chkpf_uid ("{FBFA37E4-8661-4E4F-B0A5-2D7D82071BEB}")
					:ClassName (feature_field)
					)
				:name (http_check_request_form_fields)
				:type (boolean)
			)
			:6 (
				:AdminInfo (
					:chkpf_uid ("{4367163B-EAFA-422E-AB45-1A94FEDF4417}")
					:ClassName (feature_field)
					)
				:name (http_check_request_validity)
				:type (boolean)
			)
			:7 (
			        :AdminInfo (
			               :chkpf_uid ("{4E62A953-9C4F-403C-A38F-7641E35881D3}")
			               :ClassName (feature_field)
			               )
			        :name (http_request_validity_packet_capture)
			        :type (boolean)
			)
		)
	)
	
	: (http_dir_traversal
		:AdminInfo (
			:chkpf_uid ("{3BE08EFC-ADA0-4897-9A56-2BDA19FF4DBD}")
			:ClassName (spii_feature_definitions)
			:table (spii_params)
			)
		:feature_settings (ReferenceObject
			:Table (asm)
			:Name (AdvancedSecurityObject)
			:Uid ("{FCFD107B-35E2-11D6-A48B-00D0B7BE171D}")
			:path (
				: (asm_active_protection)
				: (HTTP_security_server)
				: (http_dir_traversal)
			)
		)
		:type (spii_feature_definitions) 
		:id (5)
		:feature_fields (
			:0 (
				:AdminInfo (
					:chkpf_uid ("{40F68E91-CA2F-44FB-BD54-225C4C27FA88}")
					:ClassName (feature_field)
					)
				:name (http_dir_traversal_blocked)
				:type (boolean)
			)
			:1 (
				:AdminInfo (
					:chkpf_uid ("{6263DB04-B540-433E-B138-07C840079647}")
					:ClassName (feature_field)
					)
				:name (http_dir_traversal_apply_on)
				:type (string)
			)
			:2 (
				:AdminInfo (
					:chkpf_uid ("{3615A650-A60C-4925-B27A-0D23DB9D1B1A}")
					:ClassName (feature_field)
					)
				:name (http_dir_traversal_track)
				:type (string)
			)
			:3 (
				:AdminInfo (
					:chkpf_uid ("{E7BDDA4D-7667-4F49-8CE8-B6DF4582BA70}")
					:ClassName (feature_field)
					)
				:name (http_dir_traversal_monitor_only)
				:type (boolean)
			)
			:4 (
				:AdminInfo (
					:chkpf_uid ("{EEA713F2-6E8C-4EBE-B4F2-4E88F3B4B2CC}")
					:ClassName (feature_field)
					)
				:name (http_dir_traversal_send_error)
				:type (boolean)
			)
			:5 (
			       :AdminInfo (
			              :chkpf_uid ("{4DAFECF4-D4AC-42A0-A711-2D6AD6CCE60C}")
			              :ClassName (feature_field)
			              )
			       :name (http_dir_traversal_packet_capture)
			       :type (boolean)
			)
		)
	)

	: (http_worm_catcher
		:AdminInfo (
			:chkpf_uid ("{DA1B92D5-7F8C-464F-941E-949AFE3E83D4}")
			:ClassName (spii_feature_definitions)
			:table (spii_params)
			)
		:feature_settings (ReferenceObject
			:Table (asm)
			:Name (AdvancedSecurityObject)
			:Uid ("{FCFD107B-35E2-11D6-A48B-00D0B7BE171D}")
			:path (
				: (asm_active_protection)
				: (general_http_worm_catcher_protection)
			)
		)
		:type (spii_feature_definitions) 
		:id (6)
		:feature_fields (
			:0 (
				:AdminInfo (
					:chkpf_uid ("{3C596473-5EC0-4947-A6CC-90A03E4A9470}")
					:ClassName (feature_field)
					)
				:name (asm_http_worm_catcher)
				:type (boolean)
			)
			:1 (
				:AdminInfo (
					:chkpf_uid ("{4C8BAE5B-9D4A-49D6-AAAB-C09EFFCD8220}")

					:ClassName (feature_field)
					)
				:name (http_apply_worm_catcher_on)
				:type (string)
			)
			:2 (
				:AdminInfo (
					:chkpf_uid ("{D472D319-8FB9-4AD5-A49F-E526FCDEC52C}")
					:ClassName (feature_field)
					)
				:name (asm_http_worm_catcher_log)
				:type (string)
			)
			:3 (
				:AdminInfo (
					:chkpf_uid ("{2DFDEDA4-F03E-48B1-97DE-B9C5A9D93D93}")
					:ClassName (feature_field)
					)
				:name (http_worm_catcher_monitor_only)
				:type (boolean)
			)
			:4 (
				:AdminInfo (
					:chkpf_uid ("{37ED4F90-7B63-4B0F-83F3-F39F62C30718}")
					:ClassName (feature_field)
					)
				:name (http_worm_catcher_send_error)
				:type (boolean)
			)
			:5 (
			       :AdminInfo (
			              :chkpf_uid ("{E38AB3F8-DDF0-4E8D-83CC-5554E29ADA48}")
			              :ClassName (feature_field)
			              )
			       :name (asm_http_worm_catcher_packet_capture)
			       :type (boolean)
			)
		)
	)
	
	: (http_sql_injection
		:AdminInfo (
			:chkpf_uid ("{4A1B72DD-A936-4226-80F1-8715A26B28A5}")
			:ClassName (spii_feature_definitions)
			:table (spii_params)
			)
		:feature_settings (ReferenceObject
			:Table (asm)
			:Name (AdvancedSecurityObject)
			:Uid ("{FCFD107B-35E2-11D6-A48B-00D0B7BE171D}")
			:path (
				: (asm_active_protection)
				: (HTTP_security_server)
				: (http_sql_injection)
			)
		)
		:type (spii_feature_definitions) 
		:id (8)
		:feature_fields (
			:0 (
				:AdminInfo (
					:chkpf_uid ("{B801A38C-C2EC-47C3-8247-1A28A636C3F4}")
					:ClassName (feature_field)
					)
				:name (http_enforce_sql_injection)
				:type (boolean)
			)
			:1 (
				:AdminInfo (
					:chkpf_uid ("{706D85FE-7493-4C13-AE24-04C60AD928D4}")
					:ClassName (feature_field)
					)
				:name (http_sql_injection_apply_on)
				:type (string)
			)
			:2 (
				:AdminInfo (
					:chkpf_uid ("{218C0E39-3391-4BBC-8FA2-3ACF4C67F91F}")
					:ClassName (feature_field)
					)
				:name (http_sql_injection_track)
				:type (string)
			)
			:3 (
				:AdminInfo (
					:chkpf_uid ("{EC14D93D-87BE-4A30-B0FB-B8E5BEE293F3}")
					:ClassName (feature_field)
					)
				:name (http_sql_injection_monitor_only)
				:type (boolean)
			)
			:4 (
				:AdminInfo (
					:chkpf_uid ("{5DA5EDB7-49CC-453F-B568-55EADE84E324}")
					:ClassName (feature_field)
					)
				:name (http_sql_injection_send_error)
				:type (boolean)
			)
			:5 (
				:AdminInfo (
					:chkpf_uid ("{62640D06-72A4-4786-BF39-4FAB89A27B15}")
					:ClassName (feature_field)
					)
				:name (http_sql_injection_level)
				:type (string)
			)
			:6 (
				:AdminInfo (
					:chkpf_uid ("{D9BCE858-6008-4B83-B632-E97CFD57CA4A}")
					:ClassName (regexp2_feature_field)
					)
				:name (http_sql_injection_distinct_commands_regexp_spii)
				:type (regexp2)
				:anchors (false)
				:case_sensitive (false)
				:basic (false)
			)
			:7 (
				:AdminInfo (
					:chkpf_uid ("{54D3231B-CD58-41F6-91B5-60A04702B346}")
					:ClassName (regexp2_feature_field)
					)
				:name (http_sql_injection_non_distinct_commands_regexp_spii)
				:type (regexp2)
				:anchors (false)
				:case_sensitive (false)
				:basic (false)
			)
			:8 (
				:AdminInfo (
					:chkpf_uid ("{BA6A01A7-3058-41DC-8347-FFC11FEBD7B6}")
					:ClassName (strlist_feature_field)
					)
				:name (http_sql_injection_seperator_vals)
				:case_sensitive (true)
				:type (strlist)
			)
			:9 (
				:AdminInfo (
					:chkpf_uid ("{6D96F21D-3992-4F5F-859D-54F7D48F6E7D}")
					:ClassName (strlist_feature_field)
					)
				:name (http_sql_injection_distinct_commands_spii)
				:type (strlist)
				:case_sensitive (false)
			)
			:10 (
				:AdminInfo (
					:chkpf_uid ("{9000ADF1-A2EF-41EF-B55C-7EE001E5CA15}")
					:ClassName (strlist_feature_field)
					)
				:name (http_sql_injection_non_distinct_commands_spii)
				:type (strlist)
				:case_sensitive (false)
			)
			:11 (
				:AdminInfo (
					:chkpf_uid ("{F3401A49-8CA1-4CE7-9B89-75EE5202F362}")
					:ClassName (strlist_feature_field)
					)
				:name (http_sql_injection_keepers_vals)
				:case_sensitive (true)
				:type (strlist)
			)
			:12 (
				:AdminInfo (
					:chkpf_uid ("{368E6B5F-1984-4900-8EA3-556559CB5923}")
					:ClassName (strlist_feature_field)
					)
				:name (http_sql_injection_reset_vals)
				:case_sensitive (true)
				:type (strlist)
			)
			:13 (
			       :AdminInfo (
			              :chkpf_uid ("{EA098CEB-0C24-4F9D-9110-C36A1B9FE370}")
			              :ClassName (feature_field)
			              )
			       :name (http_sql_injection_packet_capture)
			       :type (boolean)
			)
	  	)
	)

	: (http_command_stealth
		:AdminInfo (
			:chkpf_uid ("{B2FBAA08-0AF9-4829-B292-8BEB993F75A1}")
			:ClassName (spii_feature_definitions)
			:table (spii_params)
			)
		:feature_settings (ReferenceObject
			:Table (asm)
			:Name (AdvancedSecurityObject)
			:Uid ("{FCFD107B-35E2-11D6-A48B-00D0B7BE171D}")
			:path (
				: (asm_active_protection)
				: (HTTP_security_server)
				: (http_command_stealth)
			)
		)
		:type (spii_feature_definitions) 
		:id (9)
		:feature_fields (
			:0 (
				:AdminInfo (
					:chkpf_uid ("{646A573D-3BE7-49EA-9B0C-6A054C6655DA}")
					:ClassName (feature_field)
					)
				:name (http_enforce_command_stealth)
				:type (boolean)
			)
			:1 (
				:AdminInfo (
					:chkpf_uid ("{7C503389-2E4E-438C-890A-763CD37F4596}")
					:ClassName (feature_field)
					)
				:name (http_command_stealth_apply_on)
				:type (string)
			)
			:2 (
				:AdminInfo (
					:chkpf_uid ("{5035A60B-9D2F-45FC-973A-DF97B3249EE0}")
					:ClassName (feature_field)
					)
				:name (http_command_stealth_track)
				:type (string)
			)
			:3 (
				:AdminInfo (
					:chkpf_uid ("{05FAEE79-34A8-4A73-8B08-E874416492A1}")
					:ClassName (feature_field)
					)
				:name (http_command_stealth_monitor_only)
				:type (boolean)
			)
			:4 (
				:AdminInfo (
					:chkpf_uid ("{47D36E3A-C52D-4790-A7CC-8569D936FC86}")
					:ClassName (feature_field)
					)
				:name (http_command_stealth_send_error)
				:type (boolean)
			)
			:5 (
				:AdminInfo (
					:chkpf_uid ("{B4BDE400-001C-490E-88DC-704FD69F6B66}")
					:ClassName (feature_field)
					)
				:name (http_command_stealth_level)
				:type (string)
			)
			:6 (
				:AdminInfo (
					:chkpf_uid ("{CFCC349A-B532-4909-9297-B411703EBC4D}")
					:ClassName (regexp2_feature_field)
					)
				:name (http_command_stealth_distinct_commands_regexp_spii)
				:type (regexp2)
				:anchors (false)
				:case_sensitive (false)
				:basic (false)
			)
			:7 (
				:AdminInfo (
					:chkpf_uid ("{AD223E53-3098-4812-8691-C58676668320}")
					:ClassName (regexp2_feature_field)
					)
				:name (http_command_stealth_non_distinct_commands_regexp_spii)
				:type (regexp2)
				:anchors (false)
				:case_sensitive (false)
				:basic (false)
			)
			:8 (
				:AdminInfo (
					:chkpf_uid ("{D11DD0D6-8F76-41B3-BD69-981D8DC1E4DA}")
					:ClassName (strlist_feature_field)
					)
				:name (http_command_stealth_seperator_vals)
				:case_sensitive (true)
				:type (strlist)
			)
			:9 (
				:AdminInfo (
					:chkpf_uid ("{F95B33E2-F6FA-4D95-A969-038FA54165AD}")
					:ClassName (strlist_feature_field)
					)
				:name (http_command_stealth_distinct_commands_spii)
				:type (strlist)
				:case_sensitive (false)
			)
			:10 (
				:AdminInfo (
					:chkpf_uid ("{CFF4F036-253D-42DF-AB71-89B8010A852A}")
					:ClassName (strlist_feature_field)
					)
				:name (http_command_stealth_non_distinct_commands_spii)
				:type (strlist)
				:case_sensitive (false)
			)
			:11 (
				:AdminInfo (
					:chkpf_uid ("{8E6C707D-F9FF-4356-9398-DB8DE4BCCFB3}")
					:ClassName (strlist_feature_field)
					)
				:name (http_command_stealth_keepers_vals)
				:case_sensitive (true)
				:type (strlist)
			)
			:12 (
				:AdminInfo (
					:chkpf_uid ("{CF5FAEF4-BACC-419B-B7FF-18DFC16CE449}")
					:ClassName (strlist_feature_field)
					)
				:name (http_command_stealth_reset_vals)
				:case_sensitive (true)
				:type (strlist)
			)
			:13 (
			       :AdminInfo (
			              :chkpf_uid ("{2C4AA502-61CD-47E0-B652-61A2268D2E07}")
			              :ClassName (feature_field)
			              )
			       :name (http_command_stealth_packet_capture)
			       :type (boolean)
			)
	  	)
	)

	: (http_cross_site_scripting
		:AdminInfo (
			:chkpf_uid ("{0314526B-B12E-42FC-A3F0-49FB691450C3}")
			:ClassName (spii_feature_definitions)
			:table (spii_params)
			)
		:feature_settings (ReferenceObject
			:Table (asm)
			:Name (AdvancedSecurityObject)
			:Uid ("{FCFD107B-35E2-11D6-A48B-00D0B7BE171D}")
			:path (
				: (asm_active_protection)
				: (web_servers_enforcement)
			)
		)
		:type (spii_feature_definitions) 
		:id (7)
		:feature_fields (
			:0 (
				:AdminInfo (
					:chkpf_uid ("{056ADEBE-80BF-4CF1-87CF-F6982250408E}")
					:ClassName (feature_field)
					)
				:name (http_enforce_cross_sites_scripting)
				:type (boolean)
			)
			:1 (
				:AdminInfo (
					:chkpf_uid ("{9C471395-3F5B-4ABF-9722-887B7F1A9242}")
					:ClassName (feature_field)
					)
				:name (all_web_servers_cross_sites_scripting)
				:type (boolean)
			)
			:2 (
				:AdminInfo (
					:chkpf_uid ("{29D5070B-EBC7-4EE8-9C0C-EFE1F207D136}")
					:ClassName (feature_field)
					)
				:name (web_servers_cross_sites_log)
				:type (string)
			)
			:3 (
				:AdminInfo (
					:chkpf_uid ("{882FBAF4-E5DC-4093-B4C0-ADDF2C659C6C}")
					:ClassName (feature_field)
					)
				:name (http_cross_sites_scripting_monitor_only)
				:type (boolean)
			)
			:4 (
				:AdminInfo (
					:chkpf_uid ("{F51CA84E-C26B-4AA4-B464-FDA938C2D792}")
					:ClassName (feature_field)
					)
				:name (http_cross_sites_scripting_send_error)
				:type (boolean)
			)
			:5 (
				:AdminInfo (
					:chkpf_uid ("{48BCC17D-C368-4593-9EFF-31F18CB6A3A9}")
					:ClassName (feature_field)
					)
				:name (all_web_servers_strip)
				:type (string)
			)
			:6 (
				:AdminInfo (
					:chkpf_uid ("{ADCEF907-A728-4BE5-8048-9D9BB7159AF5}")
					:ClassName (strlist_feature_field)
					)
				:name (http_cross_site_scripting_words_spii)
				:type (strlist)
				:case_sensitive (false)
			)
			:7 (
				:AdminInfo (
					:chkpf_uid ("{D61B4855-1DA3-4CBC-A3D3-1701500203FE}")
					:ClassName (regexp2_feature_field)
					)
				:name (http_cross_site_scripting_regexps_spii)
				:type (regexp2)
				:anchors (false)
				:case_sensitive (false)
				:basic (false)
			)
			:8 (
				:AdminInfo (
					:chkpf_uid ("{79F486DC-1FAB-4265-9A4A-19296E62DA50}")
					:ClassName (feature_field)
				)
				:name (http_cross_site_scripting_keepers_vals)
				:case_sensitive (true)
				:type (strlist)
			)
			:9 (
				:AdminInfo (
					:chkpf_uid ("{BCF319DB-BC26-4D8D-ACA3-47DA5CD6C921}")
					:ClassName (feature_field)
				)
				:name (http_cross_site_scripting_reset_vals)
				:case_sensitive (true)
				:type (strlist)
			)
			:10 (
				:AdminInfo (
					:chkpf_uid ("{629135CE-8BF1-4C28-B457-F13953F5FDA8}")
					:ClassName (feature_field)
				)
				:name (http_cross_sites_scripting_apply)
				:type (string)
			)
			:11 (
			       :AdminInfo (
			              :chkpf_uid ("{4A344E5F-CD1A-4F58-A820-F3E48D6ABD8E}")
			              :ClassName (feature_field)
			              )
			       :name (web_servers_cross_sites_packet_capture)
			       :type (boolean)
			)
	  	)
	)

	: (http_allowed_methods
		:AdminInfo (
			:chkpf_uid ("{EEEBCC3F-08E8-4D98-9773-BB88CB730749}")
			:ClassName (spii_feature_definitions)
			:table (spii_params)
			)
		:feature_settings (ReferenceObject
			:Table (asm)
			:Name (AdvancedSecurityObject)
			:Uid ("{FCFD107B-35E2-11D6-A48B-00D0B7BE171D}")
			:path (
				: (asm_active_protection)
				: (HTTP_security_server)
				: (http_allowed_methods)
			)
		)
		:type (spii_feature_definitions) 
		:id (10)
		:feature_fields (
			:0 (
				:AdminInfo (
					:chkpf_uid ("{236120AE-B7E4-437B-8DBD-CE27918CEC4B}")
					:ClassName (feature_field)
					)
				:name (http_enforce_allowed_methods)
				:type (boolean)
			)
			:1 (
				:AdminInfo (
					:chkpf_uid ("{07CEF015-D2AD-451B-8044-500296716C84}")
					:ClassName (feature_field)
					)
				:name (http_allowed_methods_apply_on)
				:type (string)
			)
			:2 (
				:AdminInfo (
					:chkpf_uid ("{0556406E-632D-41E5-8A8E-3466A6C5528C}")
					:ClassName (feature_field)
					)
				:name (http_allowed_methods_track)
				:type (string)
			)
			:3 (
				:AdminInfo (
					:chkpf_uid ("{ECEBC857-E761-4AAC-BB88-FB380A934492}")
					:ClassName (feature_field)
					)
				:name (http_allowed_methods_monitor_only)
				:type (boolean)
			)
			:4 (
				:AdminInfo (
					:chkpf_uid ("{EC54B79D-1835-4063-895D-07D2006ED51B}")
					:ClassName (feature_field)
					)
				:name (http_allowed_methods_send_error)
				:type (boolean)
			)			
			:5 (
				:AdminInfo (
					:chkpf_uid ("{D2934C00-0577-4D36-B1E6-A69F4786BE62}")
					:ClassName (strlist_feature_field)
					)
				:name (http_allowed_methods_list_spii)
				:case_sensitive (false)
				:type (strlist)
			)
			:6 (
				:AdminInfo (
					:chkpf_uid ("{2663E9E1-9170-4039-A4A4-5F241BF14137}")
					:ClassName (strlist_feature_field)
					)
				:name (http_allowed_methods_list_with_attr_spii)
				:case_sensitive (false)
				:type (strlist)
			)
			:7 (
				:AdminInfo (
					:chkpf_uid ("{4CA02088-022F-479E-8086-DE56093B738E}")
					:ClassName (feature_field)
					)
				:name (http_allowed_methods_apply_default)
				:type (boolean)
			)			
			:8 (
				:AdminInfo (
					:chkpf_uid ("{06340552-E6B0-4BD5-BA33-E2FD0AD81442}")
					:ClassName (feature_field)
					)
				:name (http_allowed_methods_apply_safe)
				:type (boolean)
			)			
			:9 (
				:AdminInfo (
					:chkpf_uid ("{ECB9F744-0CEF-437A-A554-E849ACF4B48D}")
					:ClassName (feature_field)
					)
				:name (http_allowed_methods_apply_unsafe)
				:type (boolean)
			)			
			:10 (
				:AdminInfo (
					:chkpf_uid ("{7BC7806E-52B9-4BB8-8BFC-99546FC68876}")
					:ClassName (feature_field)
					)
				:name (http_allowed_methods_apply_webdav)
				:type (boolean)
			)			
			:11 (
			       :AdminInfo (
			              :chkpf_uid ("{BE0EC0DC-DC58-4991-A60D-404248CA73B9}")
			              :ClassName (feature_field)
			              )
			       :name (http_allowed_methods_packet_capture)
			       :type (boolean)
			)
		)
	)

	: (http_generic_header_spoofing
		:AdminInfo (
			:chkpf_uid ("{4DA2FFDA-7F12-4AE1-B99F-02521B519676}")
			:ClassName (spii_feature_definitions)
			:table (spii_params)
			)
		:feature_settings (ReferenceObject
			:Table (asm)
			:Name (AdvancedSecurityObject)
			:Uid ("{FCFD107B-35E2-11D6-A48B-00D0B7BE171D}")
			:path (
				: (asm_active_protection)
				: (HTTP_security_server)
				: (http_generic_header_spoofing)
			)
		)
		:type (spii_feature_definitions) 
		:id (11)
		:feature_fields (
			:0 (
				:AdminInfo (
					:chkpf_uid ("{95DEC3AB-9FFC-4673-9B6E-DD238188ABCD}")
					:ClassName (feature_field)
					)
				:name (http_enforce_header_spoofing)
				:type (boolean)
			)
			:1 (
				:AdminInfo (
					:chkpf_uid ("{6E90C9D2-95FA-4B65-9331-800F8B96DBE8}")
					:ClassName (feature_field)
					)
				:name (http_header_spoofing_apply_on)
				:type (string)
			)
			:2 (
				:AdminInfo (
					:chkpf_uid ("{ED0BBA40-971E-4204-A522-623ED1DF43F4}")
					:ClassName (feature_field)
					)
				:name (http_header_spoofing_track)
				:type (string)
			)
			:3 (
				:AdminInfo (
					:chkpf_uid ("{181628CD-4F72-4E84-856C-E9754126B859}")
					:ClassName (feature_field)
					)
				:name (http_header_spoofing_monitor_only)
				:type (boolean)
			)
			:4 (
			       :AdminInfo (
			              :chkpf_uid ("{B873EEB9-CE50-4DCE-8F3C-305418740B81}")
			              :ClassName (feature_field)
			              )
			       :name (http_header_spoofing_send_error)
			       :type (boolean)
			)
			:5 (
			       :AdminInfo (
			              :chkpf_uid ("{D2CA64BB-4853-4493-820B-C8E862B815A1}")
			              :ClassName (feature_field)
			              )
			       :name (http_header_spoofing_packet_capture)
			       :type (boolean)
			)
		)
	)


	: (http_capacity
		:AdminInfo (
			:chkpf_uid ("{D3031D31-0023-4540-A95D-0EADB04CCE83}")
			:ClassName (spii_feature_definitions)
			:table (spii_params)
			)
		:feature_settings (ReferenceObject
			:Table (properties)
			:Name (firewall_properties)
			:Uid ("{97AEB653-9AEA-11D5-BD16-0090272CCB30}")
			:path (
			)
		)
		:type (spii_feature_definitions) 
		:id (17)
		:feature_fields (
			:0 (
				:AdminInfo (
					:chkpf_uid ("{49175C9F-B77D-43AB-B3AE-72E8FB478498}")
					:ClassName (feature_field)
					)
				:name (http_max_concurrent_connections)
				:type (int)
			)
			:1 (
				:AdminInfo (
					:chkpf_uid ("{12F4B200-3794-469C-8C02-F50DDCDD544C}")
					:ClassName (feature_field)
					)
				:name (http_auto_calc_capacity_limits)
				:type (boolean)
			)
			:2 (
				:AdminInfo (
					:chkpf_uid ("{6CD425E3-18D0-4DC1-A21D-1DD797D528C0}")
					:ClassName (feature_field)
					)
				:name (http_session_pool_size)
				:type (int)
			)
			:3 (
				:AdminInfo (
					:chkpf_uid ("{C00169D4-B16C-4C03-829C-6CF796B84251}")
					:ClassName (feature_field)
					)
				:name (http_report_pool_size)
				:type (int)
			)
			:4 (
				:AdminInfo (
					:chkpf_uid ("{242628CD-C852-417B-BE4C-DD1CFE3FE68C}")
					:ClassName (feature_field)
					)
				:name (http_max_large_header_connection_percent)
				:type (int)
			)
		)
	)


	: (http_header_rejection
		:AdminInfo (
			:chkpf_uid ("{83CC8237-5786-4DBE-9147-E7765EEA310E}")
			:ClassName (spii_feature_definitions)
			:table (spii_params)
			)
		:feature_settings (ReferenceObject
			:Table (asm)
			:Name (AdvancedSecurityObject)
			:Uid ("{FCFD107B-35E2-11D6-A48B-00D0B7BE171D}")
			:path (
				: (asm_active_protection)
				: (HTTP_security_server)
				: (http_header_rejection)
			)
		)
		:type (spii_feature_definitions) 
		:id (13)
		:feature_fields (
			:0 (
				:AdminInfo (
					:chkpf_uid ("{EC078EF2-E0BB-4CF7-A16A-D29C9851D066}")
					:ClassName (feature_field)
					)
				:name (http_header_rejection_enforce)
				:type (boolean)
			)
			:1 (
				:AdminInfo (
					:chkpf_uid ("{A6B0AD1D-C55D-4856-BE49-22F6E690F99B}")
					:ClassName (feature_field)
					)
				:name (http_header_rejection_apply_on)
				:type (string)
			)
			:2 (
				:AdminInfo (
					:chkpf_uid ("{51CC8C8F-969D-4F7D-A16D-1F0DD87D397D}")
					:ClassName (feature_field)
					)
				:name (http_header_rejection_track)
				:type (string)
			)
			:3 (
				:AdminInfo (
					:chkpf_uid ("{83A9BBD4-948C-4ABD-A773-C5D1A2E413E7}")
					:ClassName (feature_field)
					)
				:name (http_header_rejection_monitor_only)
				:type (boolean)
			)
			:4 (
				:AdminInfo (
					:chkpf_uid ("{CA016620-3F76-4E95-B79A-810B9F59D5F8}")
					:ClassName (feature_field)
					)
				:name (http_header_rejection_send_error)
				:type (boolean)
			)
			:5 (
			       :AdminInfo (
			              :chkpf_uid ("{0D842F30-97AC-437D-8862-61C5657F56CB}")
			              :ClassName (feature_field)
			              )
			       :name (http_header_rejection_packet_capture)
			       :type (boolean)
			)
		)
	)	
	
	: (http_ws_error_configuration
		:AdminInfo (
			:chkpf_uid ("{F094F02B-AA1D-4BBD-B8D2-27770FAA2458}")
			:ClassName (spii_feature_definitions)
			:table (spii_params)
			)
		:feature_settings (ReferenceObject
			:Table (asm)
			:Name (AdvancedSecurityObject)
			:Uid ("{FCFD107B-35E2-11D6-A48B-00D0B7BE171D}")
			:path (
				: (asm_active_protection)
				: (html_error_file)
			)
		)
		:type (spii_feature_definitions) 
		:id (14)
		:feature_fields (
			:0 (
				:AdminInfo (
					:chkpf_uid ("{194DE7A8-D46E-45BE-AE01-633E3D42EA44}")
					:ClassName (feature_field)
					)
				:name (enable_company_logo_url)
				:type (boolean)
			)
			:1 (
				:AdminInfo (
					:chkpf_uid ("{58908CCB-C4C0-4A46-AF38-CBC776C85702}")
					:ClassName (feature_field)
					)
				:name (company_logo_url)
				:type (string)
			)
			:2 (
				:AdminInfo (
					:chkpf_uid ("{559E9053-D39C-435B-A7ED-7A07B7F09300}")
					:ClassName (feature_field)
					)
				:name (description)
				:type (string)
			)
			:3 (
				:AdminInfo (
					:chkpf_uid ("{B54E2319-7FE6-4367-BCC1-B59522D94EFC}")
					:ClassName (feature_field)
					)
				:name (event_id)
				:type (boolean)
			)
			:4 (
				:AdminInfo (
					:chkpf_uid ("{C922C571-EB1D-40B9-A321-C4F128A8496E}")
					:ClassName (feature_field)
					)
				:name (show_error_id)
				:type (boolean)
			)
			:5 (
				:AdminInfo (
					:chkpf_uid ("{BDF38284-1A20-4B4B-95AF-5DEBA55FA9CC}")
					:ClassName (feature_field)
					)
				:name (enable_redirect_url)
				:type (boolean)
			)
			:6 (
				:AdminInfo (
					:chkpf_uid ("{22A700F6-1EFC-4941-BF15-3E6EEDBEC187}")
					:ClassName (feature_field)
					)
				:name (redirect_url)
				:type (string)
			)
			:7 (
				:AdminInfo (
					:chkpf_uid ("{94C3EC19-C560-47B8-8181-A5113FEBCA5B}")
					:ClassName (feature_field)
					)
				:name (send_error_id)
				:type (boolean)
			)
			:8 (
				:AdminInfo (
					:chkpf_uid ("{8828D018-2AD0-4367-8D43-AA9E442E86F2}")
					:ClassName (feature_field)
					)
				:name (http_enable_error_response_code)
				:type (boolean)
			)
		)
	)

	: (http_general_configuration
		:AdminInfo (
			:chkpf_uid ("{FCD47B17-244E-4561-B557-9BB685763AD7}")
			:ClassName (spii_feature_definitions)
			:table (spii_params)
			)
		:feature_settings (ReferenceObject
			:Table (asm)
			:Name (AdvancedSecurityObject)
			:Uid ("{FCFD107B-35E2-11D6-A48B-00D0B7BE171D}")
			:path (
				: (asm_active_protection)
				: (HTTP_security_server)
			)
		)
		:type (spii_feature_definitions) 
		:id (15)
		:feature_fields (
			:0 (
				:AdminInfo (
					:chkpf_uid ("{7E225C8D-E4BF-40DE-90C3-79FC87AD8B74}")
					:ClassName (feature_field)
					)
				:name (ws_prefer_active_streaming)
				:type (boolean)
			)
			:1 (
				:AdminInfo (
					:chkpf_uid ("{BF10ABA4-9D08-4752-AA64-F0014CA62193}")
					:ClassName (feature_field)
					)
				:name (http_strict_request_parsing)
				:type (boolean)
			)
			:2 (
				:AdminInfo (
					:chkpf_uid ("{A9EF3380-BC00-4BDF-836F-159807B6CC9D}")
					:ClassName (feature_field)
					)
				:name (http_strict_response_parsing)
				:type (boolean)
			)
			:3 (
				:AdminInfo (
					:chkpf_uid ("{80CF1B18-E8CC-462A-934E-C60422EE3993}")
					:ClassName (feature_field)
					)
				:name (show_HTTP_active_streaming)
				:type (boolean)
			)
			:4 (
				:AdminInfo (
					:chkpf_uid ("{3CA7C6D2-6D18-45AD-80C3-C8BCE1A6711B}")
					:ClassName (feature_field)
				)
				:name (http_split_query_fragment_section)
				:type (boolean)
			)		
		)
	)
	
	: (http_buffer_overflow
		:AdminInfo (
			:chkpf_uid ("{B853697F-B337-4729-B07D-C7104B701F06}")
			:ClassName (spii_feature_definitions)
			:table (spii_params)
			)
		:feature_settings (ReferenceObject
			:Table (asm)
			:Name (AdvancedSecurityObject)
			:Uid ("{FCFD107B-35E2-11D6-A48B-00D0B7BE171D}")
			:path (
				: (asm_active_protection)
				: (HTTP_security_server)
				: (http_buffer_overflow)
			)
		)
		:type (spii_feature_definitions) 
		:id (16)
		:feature_fields (
			:0 (
				:AdminInfo (
					:chkpf_uid ("{33D1428E-3BBA-4B19-A427-41D77755FA35}")
					:ClassName (feature_field)
					)
				:name (http_enforce_buffer_overflow)
				:type (boolean)
			)
			:1 (
				:AdminInfo (
					:chkpf_uid ("{0B2316D3-F157-4886-AA45-B626C1383046}")
					:ClassName (feature_field)
					)
				:name (http_buffer_overflow_apply_on)
				:type (string)
			)
			:2 (
				:AdminInfo (
					:chkpf_uid ("{A7EFF08C-B784-4127-8A5C-85975F893758}")
					:ClassName (feature_field)
					)
				:name (http_buffer_overflow_track)
				:type (string)
			)
			:3 (
				:AdminInfo (
					:chkpf_uid ("{D6859D13-7EB3-45B6-B268-3A230B45C1D5}")
					:ClassName (feature_field)
					)
				:name (http_buffer_overflow_monitor_only)
				:type (boolean)
			)
			:4 (
				:AdminInfo (
					:chkpf_uid ("{15F3D25A-250C-41AD-B56D-DD0F6D283D6F}")
					:ClassName (feature_field)
					)
				:name (http_buffer_overflow_send_error)
				:type (boolean)
			)
			:5 (
				:AdminInfo (
					:chkpf_uid ("{C857D2CF-B24E-4CA5-A041-BA24807D1EEE}")
					:ClassName (feature_field)
					)
				:name (http_buffer_overflow_level)
				:type (string)
			)
			:6 (
				:AdminInfo (
					:chkpf_uid ("{8B4D50C7-D129-47D6-9D37-037E932AE4A0}")
					:ClassName (feature_field)
					)
				:name (buffer_overflow_code_threshold_x86)
				:type (int)
			)
			:7 (
				:AdminInfo (
					:chkpf_uid ("{7B578F12-A05C-424D-ACBD-9463551DA02C}")
					:ClassName (feature_field)
					)
				:name (buffer_overflow_code_threshold_sparc)
				:type (int)
			)
			:8 (
			       :AdminInfo (
			              :chkpf_uid ("{CDD41883-C7C5-4093-9745-C1FA44327BF5}")
			              :ClassName (feature_field)
			              )
			       :name (http_buffer_overflow_packet_capture)
			       :type (boolean)
			)
			:9 (
				:AdminInfo (
					:chkpf_uid ("{303AFAFD-BDFD-49AC-A3EE-EE3DCBDAF578}")
					:ClassName (feature_field)
					)
				:name (buffer_overflow_new_code_threshold_x86)
				:type (int)
			)

	  	)
	)
	
	: (http_ascii_only_response_protection
		:AdminInfo (
			:chkpf_uid ("{11FB045B-E571-4D12-9D97-4CD5AAE1C1BC}")
			:ClassName (spii_feature_definitions)
			:table (spii_params)
			)
		:feature_settings (ReferenceObject
			:Table (asm)
			:Name (AdvancedSecurityObject)
			:Uid ("{FCFD107B-35E2-11D6-A48B-00D0B7BE171D}")
			:path (
				: (asm_active_protection)
				: (HTTP_security_server)
			)
		)
		:type (spii_feature_definitions) 
		:id (18)
		:feature_fields (
			:0 (
				:AdminInfo (
					:chkpf_uid ("{897FD3A5-31CA-48F2-A3FF-00E8AA762447}")
					:ClassName (feature_field)
					)
				:name (http_check_response_validity)
				:type (boolean)
			)
			:1 (
				:AdminInfo (
					:chkpf_uid ("{87D28797-C3A6-434B-87DB-D8774F26B0F3}")
					:ClassName (feature_field)
					)
				:name (http_response_validity_track)
				:type (string)
			)
			:2 (
				:AdminInfo (
					:chkpf_uid ("{3B4F9581-E405-4D25-880E-3BEF971EE824}")
					:ClassName (feature_field)
					)
				:name (http_response_validity_monitor_only)
				:type (boolean)
			)
			:3 (
				:AdminInfo (
					:chkpf_uid ("{B606A26F-DC9D-482E-B45B-BEE1E17D860E}")
					:ClassName (feature_field)
					)
				:name (http_response_validity_send_error)
				:type (boolean)
			)
			:4 (
				:AdminInfo (
					:chkpf_uid ("{BA7ED3F6-72A6-49E1-AB75-16D1D2A14270}")
					:ClassName (feature_field)
				)
				:name (http_apply_response_validity_on)
				:type (string)
			)				
		)
	)
	
	: (buffer_overflow_protection_scheme
		:AdminInfo (
			:chkpf_uid ("{9C0DAFB8-CF2C-416D-97C0-E4F06A83D8FF}")
			:ClassName (spii_feature_definitions)
			:table (spii_params)
			)
		:feature_settings (ReferenceObject
			:Table (asm)
			:Name (AdvancedSecurityObject)
			:Uid ("{FCFD107B-35E2-11D6-A48B-00D0B7BE171D}")
			:path (
				: (asm_active_protection)
				: (buffer_overflow_protection)
			)
		)
		:type (spii_feature_definitions) 
		:id (30)
		:feature_fields (
			:0 (
				:AdminInfo (
					:chkpf_uid ("{DBF5ED80-7CC7-4CCE-A408-02C5198E1B63}")
					:ClassName (feature_field)
					)
				:name (buffer_overflow_disasm_anchor)
				:type (string)
			)
			:1 (
				:AdminInfo (
					:chkpf_uid ("{51D5AC89-B85E-4F28-BAB1-D89DD846512D}")
					:ClassName (feature_field)
					)
				:name (buffer_overflow_optimize_memory)
				:type (boolean)
			)
		)
	)

	: (http_ldap_injection
		:AdminInfo (
			:chkpf_uid ("{67DF1820-2197-431A-97D8-AB3A8BA2C652}")
			:ClassName (spii_feature_definitions)
			:table (spii_params)
			)
		:feature_settings (ReferenceObject
			:Table (asm)
			:Name (AdvancedSecurityObject)
			:Uid ("{FCFD107B-35E2-11D6-A48B-00D0B7BE171D}")
			:path (
				: (asm_active_protection)
				: (HTTP_security_server)
				: (http_ldap_injection)
			)
		)
		:type (spii_feature_definitions)
		:id (19)
		:feature_fields (
			:0 (
				:AdminInfo (
					:chkpf_uid ("{5704041C-7728-4BAA-B7A3-4D9746AD9B1B}")
					:ClassName (feature_field)
				)
				:name (http_enforce_ldap_injection)
				:type (boolean)
			)
			:1 (
				:AdminInfo (
					:chkpf_uid ("{5AA59A2E-5E07-45F8-BB19-21E24E32897D}")
					:ClassName (feature_field)
				)
				:name (http_ldap_injection_apply_on)
				:type (string)
			)
			:2 (
				:AdminInfo (
					:chkpf_uid ("{79BACD3A-34E2-4D23-9108-00102B287F53}")
					:ClassName (feature_field)
				)
				:name (http_ldap_injection_track)
				:type (string)
			)
			:3 (
				:AdminInfo (
					:chkpf_uid ("{965FF0D6-F953-47B8-8130-1B8A8A07E565}")
					:ClassName (feature_field)
				)
				:name (http_ldap_injection_monitor_only)
				:type (boolean)
			)
			:4 (
				:AdminInfo (
					:chkpf_uid ("{014E466C-1D35-480A-9828-90F99879D142}")
					:ClassName (feature_field)
				)
				:name (http_ldap_injection_send_error)
				:type (boolean)
			)
			:5 (
				:AdminInfo (
					:chkpf_uid ("{1D9CA410-988F-4D87-8365-A43C9B220EB0}")
					:ClassName (feature_field)
				)
				:name (http_ldap_injection_level)
				:type (string)
			)
			:6 (
				:AdminInfo (
					:chkpf_uid ("{BE081D86-0B77-45B3-9A98-AECEF1018E0F}")
					:ClassName (feature_field)
				)
				:name (http_ldap_injection_distinct_keywords_spii)
				:type (strlist)
			)
			:7 (
			       :AdminInfo (
			              :chkpf_uid ("{E4200A23-CEC0-4E40-B132-FC5F9A6B48C0}")
			              :ClassName (feature_field)
			              )
			       :name (http_ldap_injection_packet_capture)
			       :type (boolean)
			)

		)
	)

	: (http_directory_listing
		:AdminInfo (
			:chkpf_uid ("{E2CC12E9-BB59-4B26-8EDE-E3EED94EEFF5}")
			:ClassName (spii_feature_definitions)
			:table (spii_params)
			)
		:feature_settings (ReferenceObject
			:Table (asm)
			:Name (AdvancedSecurityObject)
			:Uid ("{FCFD107B-35E2-11D6-A48B-00D0B7BE171D}")
			:path (
				: (asm_active_protection)
				: (HTTP_security_server)
				: (http_directory_listing)
			)
		)
		:type (spii_feature_definitions) 
		:id (20)
		:feature_fields (
			:0 (
				:AdminInfo (
					:chkpf_uid ("{590369D6-9144-4653-9DDA-DE85A36CC0D8}")
					:ClassName (feature_field)
					)
				:name (http_enforce_directory_listing)
				:type (boolean)
			)
			:1 (
				:AdminInfo (
					:chkpf_uid ("{E36D15C8-63E9-4D2E-9D56-0317171E4E88}")
					:ClassName (feature_field)
					)
				:name (http_directory_listing_apply_on)
				:type (string)
			)
			:2 (
				:AdminInfo (
					:chkpf_uid ("{F3B86FBF-32DF-4C5F-BAC8-41FE88318B97}")
					:ClassName (feature_field)
					)
				:name (http_directory_listing_track)
				:type (string)
			)
			:3 (
				:AdminInfo (
					:chkpf_uid ("{C739DCEE-15F6-426D-B47B-E12485ED5721}")
					:ClassName (feature_field)
					)
				:name (http_directory_listing_monitor_only)
				:type (boolean)
			)
			:4 (
				:AdminInfo (
					:chkpf_uid ("{7937783F-1C77-48AE-82B7-95AD3EC8AE9A}")
					:ClassName (feature_field)
					)
				:name (http_directory_listing_send_error)
				:type (boolean)
			)
			:5 (
				:AdminInfo (
					:chkpf_uid ("{1C593A3A-B9C4-4C21-A9C0-6D3397464D4D}")
					:ClassName (feature_field)
					)
				:name (http_directory_listing_level)
				:type (string)
			)
			:6 (
				:AdminInfo (
					:chkpf_uid ("{2543B265-B880-4796-BF2B-7958856EC9DF}")
					:ClassName (feature_field)
					)
				:name (directory_listing_words_list_spii)
				:case_sensitive (false)
				:type (strlist)
			)
			:7 (
			       :AdminInfo (
			              :chkpf_uid ("{5FA4C1FE-37F9-4646-82ED-AD273BB3DAAC}")
			              :ClassName (feature_field)
			              )
			       :name (http_directory_listing_packet_capture)
			       :type (boolean)
			)
	  	)
	)
	

	: (http_error_concealment
		:AdminInfo (
			:chkpf_uid ("{AC4B7CDF-B7B1-43A9-90DA-38A9E12F6141}")
			:ClassName (spii_feature_definitions)
			:table (spii_params)
			)
		:feature_settings (ReferenceObject
			:Table (asm)
			:Name (AdvancedSecurityObject)
			:Uid ("{FCFD107B-35E2-11D6-A48B-00D0B7BE171D}")
			:path (
				: (asm_active_protection)
				: (HTTP_security_server)
				: (http_error_concealment)
			)
		)
		:type (spii_feature_definitions) 
		:id (21)
		:feature_fields (
			:0 (
				:AdminInfo (
					:chkpf_uid ("{6A0B2D8D-3F00-4782-ABF8-F682B417D14C}")
					:ClassName (feature_field)
					)
				:name (http_enforce_error_concealment)
				:type (boolean)
			)
			:1 (
				:AdminInfo (
					:chkpf_uid ("{43165C72-D7DB-4BA9-9AC2-79B1166AA2CF}")
					:ClassName (feature_field)
					)
				:name (http_error_concealment_apply_on)
				:type (string)
			)
			:2 (
				:AdminInfo (
					:chkpf_uid ("{91DBCD7F-24E5-4ED2-A8A6-114D5BB4D47B}")
					:ClassName (feature_field)
					)
				:name (http_error_concealment_track)
				:type (string)
			)
			:3 (
				:AdminInfo (
					:chkpf_uid ("{4F5ACA8C-3AC0-4489-9786-DA7EB44B5C90}")
					:ClassName (feature_field)
					)
				:name (http_error_concealment_monitor_only)
				:type (boolean)
			)
			:4 (
				:AdminInfo (
					:chkpf_uid ("{3497617D-271D-4134-B349-663504C7F685}")
					:ClassName (feature_field)
					)
				:name (http_error_detect_application_patterns)
				:type (boolean)
			)
			:5 (
				:AdminInfo (
					:chkpf_uid ("{36B56012-54A6-4E3C-8661-4F26FAC5240C}")
					:ClassName (feature_field)
					)
				:name (http_error_concealment_send_error)
				:type (boolean)
			)
			:6 (
				:AdminInfo (
					:chkpf_uid ("{909CFCF8-B6C6-4218-8B7B-5396FDB21C6D}")
					:ClassName (feature_field)
					)
				:name (http_error_concealment_response_status_codes_spii)
				:type (strlist)
			)
			:7 (
				:AdminInfo (
					:chkpf_uid ("{ACC916F8-90A2-48D8-B476-2A919FFD2BA4}")
					:ClassName (feature_field)
					)
				:name (http_error_concealment_engine_patterns_spii)
				:type (strlist)
			)
			:8 (
				:AdminInfo (
					:chkpf_uid ("{54363AA1-6841-4353-9702-A8683877C5C1}")
					:ClassName (feature_field)
					)
				:name (http_error_concealment_engine_names_spii)
				:type (strlist)
			)
			:9 (
			       :AdminInfo (
			              :chkpf_uid ("{2147FACB-E255-4F63-8A15-B5031A1F3DBF}")
			              :ClassName (feature_field)
			              )
			       :name (http_error_concealment_packet_capture)
			       :type (boolean)
			)
		)
	)

	: (max_http_header_field_length
		:AdminInfo (
			:chkpf_uid ("{276860AF-926B-4E60-87AA-B6E35D9CFD93}")
			:ClassName (spii_feature_definitions)
			:table (spii_params)
			)
		:type (spii_feature_definitions) 
		:id (35)
		:feature_fields (
		:0 (
			:AdminInfo (
				:chkpf_uid ("{1C25FEA1-D7D1-44B1-A317-FE539A57FA17}")
				:ClassName (feature_field)
				)
			:name (header_field_name)
			:type (string)
		)
		:1 (
			:AdminInfo (
				:chkpf_uid ("{3D4E14DC-8A6D-4F76-9E9F-1CF3FEBB634B}")
				:ClassName (feature_field)
				)
			:name (header_field_value_length)
			:type (int)
		)
		:2 (
			:AdminInfo (
				:chkpf_uid ("{B2CA3F77-B36B-4C33-B48D-A7ED30561DAE}")
				:ClassName (feature_field)
				)
			:name (header_field_length_enforce)
			:type (boolean)
		  	)
		)
		:feature_settings ()
	)
	: (http_header_spoofing_pattern
		:AdminInfo (
			:chkpf_uid ("{6913A0B4-81BE-419A-8F8E-66D0617E4BD4}")
			:ClassName (spii_feature_definitions)
			:table (spii_params)
			)
		:type (spii_feature_definitions) 
		:id (36)
		:feature_fields (
		:0 (
			:AdminInfo (
				:chkpf_uid ("{D446CCBA-7422-4ED4-A16B-40486BC0598E}")
				:ClassName (feature_field)
				)
			:name (header_spoofing_header_name)
			:type (string)
		)
		:1 (
			:AdminInfo (
				:chkpf_uid ("{A9C41BD9-04FA-424D-BC56-10C86FE58AB5}")
				:ClassName (feature_field)
				)
			:name (header_spoofing_header_value)
			:type (string)
		)
		:2 (
			:AdminInfo (
				:chkpf_uid ("{A10687F0-35BE-4B3B-A451-D4A5085A0D74}")
				:ClassName (feature_field)
				)
			:name (header_spoofing_replace_value)
			:type (string)
		)
		:3 (
			:AdminInfo (
				:chkpf_uid ("{CAA98EC9-92C5-4B3C-B532-45BB26977B0D}")
				:ClassName (feature_field)
				)
			:name (header_spoofing_pattern_enforce)
			:type (boolean)
		)
		:4 (
			:AdminInfo (
				:chkpf_uid ("{193CBAC6-3852-4594-A6D6-9E697CEE2FD4}")
				:ClassName (feature_field)
				)
			:name (header_spoofing_pattern_action)
			:type (string)
			)
		)
		:feature_settings ()
	)

	: (http_peer_to_peer
		:AdminInfo (
			:chkpf_uid ("{ECC89A16-489A-4163-9AFB-8245A473779E}")
			:ClassName (spii_feature_definitions)
			:table (spii_params)
			)
		:type (spii_feature_definitions) 
		:id (37)
		:feature_fields (
		:0 (
			:AdminInfo (
				:chkpf_uid ("{3592B0E0-1418-4835-B13D-FE5A3E0E1A72}")
				:ClassName (feature_field)
				)
			:name (p2p_log_info)
			:type (string)
		)
		:1 (
			:AdminInfo (
				:chkpf_uid ("{BB07F0AE-D6DD-4E0B-A5EC-3DDD4AE24E86}")
				:ClassName (feature_field)
				)
			:name (p2p_match_string)
			:type (string)
		)
		:2 (
			:AdminInfo (
				:chkpf_uid ("{472C925A-CEBA-430A-812C-F7772B77A466}")
				:ClassName (feature_field)
				)
			:name (p2p_regular_exp)
			:type (string)
		)
		:3 (
			:AdminInfo (
				:chkpf_uid ("{2AFF8B7E-EE0A-47F7-B79A-4999176709DD}")
				:ClassName (feature_field)
				)
			:name (p2p_monitor_only)
			:type (boolean)
		)
		:4 (
			:AdminInfo (
				:chkpf_uid ("{B0176933-B927-41EA-8743-9828D4A6FE45}")
				:ClassName (feature_field)
				)
			:name (p2p_track_options)
			:type (string)
			)
		)
		:feature_settings ()
	)
	
	: (SNMPConfiguration
		:AdminInfo (
			:chkpf_uid ("{2054F5C3-9918-40AF-8D47-AD2ECD8D33F8}")
			:ClassName (spii_feature_definitions)
			:table (spii_params)
			)
		:type (spii_feature_definitions) 
		:id (51)
		:feature_settings (ReferenceObject
			:Table (asm)
			:Name (AdvancedSecurityObject)
			:Uid ("{FCFD107B-35E2-11D6-A48B-00D0B7BE171D}")
			:path (
				: (asm_active_protection)
				: (snmp_protection)
			)
		)
		:feature_fields (
			:0 (
				:AdminInfo (
					:chkpf_uid ("{B2581FD6-77A4-4425-80A0-6B0C2F77DDB0}")
					:ClassName (strlist_feature_field)
					)
				:name (snmp_default_communities_list)
				:case_sensitive (true)
				:type (strlist)
			)
			:1 (
				:AdminInfo (
					:chkpf_uid ("{C5A015D6-980D-473F-8E94-66BEF4DAF622}")
					:ClassName (strlist_feature_field)
					)
				:name (snmp_default_communities_list)
				:case_sensitive (true)
				:type (strhash)
			)
		)
	)

	: (DNSBlackListConfiguration
		:AdminInfo (
			:chkpf_uid ("{2CC61671-BBB1-470A-BA2A-06693B6F1676}")
			:ClassName (spii_feature_definitions)
			:table (spii_params)
		)
		:type (spii_feature_definitions) 
                :id (52)
                :feature_settings (ReferenceObject
                        :Table (asm)
                        :Name (AdvancedSecurityObject)
			:Uid ("{FCFD107B-35E2-11D6-A48B-00D0B7BE171D}")
                        :path (
                                : (asm_active_protection)
                                : (dns_black_list)
                        )
                )
                :feature_fields (
                        :0 (
				:AdminInfo (
					:chkpf_uid ("{97C9FD1E-9B23-42EF-87F0-310EE9F04F01}")
					:ClassName (strhash_feature_field)
				)
                                :name (converted_domains_black_list)
                                :case_sensitive (false)
                                :type (strhash)
                        )
                       	:1 (
                                :AdminInfo (
                                        :chkpf_uid ("{F0AA44E6-BB6C-4a40-AD01-A1929699DEA0}")
                                        :ClassName (strlist_feature_field)
                                )
                                :case_sensitive (false)
                                :name (converted_domains_black_list)
                                :type (strlist)
                        )
                )
        )
        : (DNSServerMultiSetDefinitions
		:AdminInfo (
			:chkpf_uid ("{A594CC8A-04B8-48D4-BAB5-E6A1C06AFF9A}")
			:ClassName (spii_feature_definitions)
			:table (spii_params)
		)
		:type (spii_feature_definitions) 
              :id (53)
              :feature_settings ()
              :feature_fields (
                        :0 (
				    :AdminInfo (
					:chkpf_uid ("{9FB9C635-BD66-4143-AAB8-366B813DF22A}")
					:ClassName (feature_field)
				    )
                                :name (external_domain_requests)
                                :type (boolean)
                        )
                        :1 (
				    :AdminInfo (
					:chkpf_uid ("{DC2B1BCB-6F7D-4252-AAA6-113B163F44F4}")
					:ClassName (feature_field)
				    )
                                :name (randomization)
                                :type (boolean)
                        )
                        :2 (
				    :AdminInfo (
					:chkpf_uid ("{FC667BA5-B606-491B-B273-256689A177B3}")
					:ClassName (feature_field)
				    )
                                :name (redirect_internal_requests)
                                :type (boolean)
                        )
                        :3 (
				    :AdminInfo (
					:chkpf_uid ("{877355C6-1582-4973-8643-75F1D6E82FFB}")
					:ClassName (feature_field)
				    )
                                :name (converted_auth_domains_list)
                                :type (strhash)
                        )
                        :4 (
                                    :AdminInfo (
                                        :chkpf_uid ("{BCCF92E2-5DCF-4c76-809B-A1C63F83D907}")
                                        :ClassName (feature_field)
                                    )
                                :name (converted_auth_domains_list)
                                :type (strlist)
                        )
                )
        )	
        : (Service_arr
		:AdminInfo (
			:chkpf_uid ("{855C67DC-60EF-448C-9546-6DE03A24A429}")
			:ClassName (spii_feature_definitions)
			:table (spii_params)
		)
		:type (spii_feature_definitions) 
		:id (55)
		:feature_fields (
			:0 (
				:AdminInfo (
					:chkpf_uid ("{24BB9A7F-00D0-49B5-89E2-5A0B6E575A74}")
					:ClassName (strlist_feature_field)
					)
				:name (service_list)
				:type (strlist)
			)
		)
		:feature_settings ()
	)
	: (http_peer_to_peer_extended
		:AdminInfo (
			:ClassName (spii_feature_definitions)
			:table (spii_params)
			:chkpf_uid ("{634533E5-47ED-4F35-AAA2-C97F3ED70E36}")
		)
		:dynamic_object (false)
		:feature_fields (
			:0 (
				:AdminInfo (
					:ClassName (feature_field)
				)
				:name (p2p_log_info)
				:type (string)
			)
			:1 (
				:AdminInfo (
					:ClassName (feature_field)
				)
				:name (p2p_match_string)
				:type (string)
			)
			:2 (
				:AdminInfo (
					:ClassName (feature_field)
				)
				:name (p2p_regular_exp)
				:type (string)
			)
			:3 (
				:AdminInfo (
					:ClassName (feature_field)
				)
				:name (p2p_monitor_only)
				:type (boolean)
			)
			:4 (
				:AdminInfo (
					:ClassName (feature_field)
				)
				:name (p2p_track_options)
				:type (string)
			)
			:5 (
				:AdminInfo (
					:ClassName (feature_field)
				)
				:name (p2p_packet_capture)
				:type (string)
			)
		)
		:feature_settings ()
		:unsupported_compatibility_packages ()
		:id (57)
		:type (spii_feature_definitions)
	)
	: (inspect_streaming_extended_feature
                 :AdminInfo (
                        :ClassName (spii_feature_definitions)
                        :table (spii_params)
                        :chkpf_uid ("{D1E4F0FC-EAED-4042-A608-BDF52936AAB5}")
                  )
                :id (58)
                :type (spii_feature_definitions)
                :feature_fields (
                        :0 (
                                :AdminInfo (
                                        :ClassName (feature_field)
                                )
                                :name (streaming_type)
                                :type (string)
                        )
                        :1 (
                                :AdminInfo (
                                        :ClassName (feature_field)
                                )
                                :name (max_buffer_size)
                                :type (int)
                        )
                        :2 (
                                :AdminInfo (
                                        :ClassName (feature_field)
                                )
                                :name (init_buffer_size)
                                :type (int)
                        )
                        :3 (
                                :AdminInfo (
                                        :ClassName (feature_field)
                                )
                                :name (min_message_size)
                                 :type (int)
                        )
                        :4 (
                                :AdminInfo (
                                        :ClassName (feature_field)
                               )
                                :name (parse_handler)
                                        :type (inspect_handler)
                        )
                        :5 (
                                :AdminInfo (
                                        :ClassName (feature_field)
                                )
                                :name (inspection_handler)
                                :type (inspect_handler)
                        )
                        :6 (
                                :AdminInfo (
                                        :ClassName (feature_field)
                                )
                                :name (end_handler)
                                :type (inspect_handler)
                        )
                        :7 (
                                :AdminInfo (
                                        :ClassName (feature_field)
                                )
                                :name (error_handler)
                                :type (inspect_handler)
                        )
                        :8 (
                                :AdminInfo (
                                        :ClassName (feature_field)
                                )
                                :name (kernel_index)
                                :type (int)
                        )
                        :9 (
                                :AdminInfo (
                                        :ClassName (feature_field)
                                )
                                :name (streaming_type_id)
                                :type (int)
                        )
                        :10 (
                                :AdminInfo (
                                        :ClassName (feature_field)
                                )
                                :name (history_size)
                                :type (int)
                   )
                )
		:feature_settings ()
        )
       : (Dynamic_update_list
		:AdminInfo (
			:ClassName (spii_feature_definitions)
			:table (spii_params)
			:chkpf_uid ("{C20D4B3E-FC55-4AB8-8840-2ADE7AF578A9}")
		)
                :type (spii_feature_definitions)
                :id (62)
                :feature_settings ()
                :feature_fields (
                        :0 (
			        :AdminInfo (
				    :ClassName (strlist_feature_field)
			        )
                                :name (dynamic_list)
                                :type (strlist)
                                :case_sensitive (false)
                        )
                )

        )

        : (Dynamic_update_hash
		:AdminInfo (
			:ClassName (spii_feature_definitions)
			:table (spii_params)
			:chkpf_uid ("{61F6F28D-2A73-40E2-9C6D-8303D2CED0C1}")
		)
                :type (spii_feature_definitions)
                :id (63)
                :feature_settings ()
                :feature_fields (
                        :0 (
			        :AdminInfo (
				    :ClassName (strhash_feature_field)
			        )
                                :name (dynamic_hash)
                                :type (strhash)
                                :case_sensitive (false)
                        )
                )
        )

	: (Dynamic_update_hash_case
		:AdminInfo (
			:ClassName (spii_feature_definitions)
			:table (spii_params)
			:chkpf_uid ("{8C68222E-EF63-4C96-A694-2CF98E15126B}")
		)
		:feature_fields (
			:0 (
				:AdminInfo (
					:ClassName (strhash_feature_field)
				)
				:case_sensitive (true)
				:name (dynamic_hash)
				:type (strhash)
			)
		)
		:feature_settings ()
		:id (64)
		:type (spii_feature_definitions)
	)	

	: (cmi_protection_policy
		:AdminInfo (
			:ClassName (spii_feature_definitions)
			:table (spii_params)
			:chkpf_uid ("{37F120C8-75D2-416A-988B-22CC5A675F56}")
		)
		:feature_fields (
			:0 (
				:AdminInfo (
					:chkpf_uid ("{FA7D0014-C501-46F6-862A-F554133E8E5B}")
					:ClassName (feature_field)
				)
				:name (signature_id)
				:type (int)
			)

			:1 (
				:AdminInfo (
					:chkpf_uid ("{666076B6-1125-44CB-8810-82E95A01FBB1}")
					:ClassName (feature_field)
				)
				:name (monitor_only)
				:type (boolean)
			)
			:2 (
				:AdminInfo (
					:chkpf_uid ("{A5B3B4FD-3539-4BD0-9D46-036456B8E0CD}")
					:ClassName (feature_field)
				)
				:name (packet_capture)
				:type (boolean)
			)
			:3 (
				:AdminInfo (
					:chkpf_uid ("{7F26CE8F-83D7-4B7D-9A7B-417751ACB0AA}")
					:ClassName (feature_field)
				)
				:name (track)
				:type (string)
			)
			:4 (
				:AdminInfo (
					:chkpf_uid ("{D39C9169-4F12-4455-9171-3E357E447A02}")
					:ClassName (feature_field)
				)
				:name (log_id)
				:type (int)
			)
			:5 (
				:AdminInfo (
					:chkpf_uid ("{3C5CFE66-3FC2-428D-89F5-2DBF6B648193}")
					:ClassName (feature_field)
				)
				:name (exclusion_rule)
				:type (int)
			)
			:6 (
				:AdminInfo (
					:chkpf_uid ("{3CE88521-7058-44C7-9B1C-B5C7E910F23A}")
					:ClassName (feature_field)
				)
				:name (handler)
				:type (inspect_handler)
			)
			:7 (
				:AdminInfo (
					:chkpf_uid ("{CD9BF8A9-EB64-416E-883E-8A1E65DABDBF}")
					:ClassName (feature_field)
				)
				:name (additional_params)
				:type (int)
			)
		)
		:unsupported_compatibility_packages ()
		:dynamic_object (false)
		:feature_settings ()
		:id (60)
		:type (spii_feature_definitions)
	)

	: (http_malformed_http
			:AdminInfo (
				:chkpf_uid ("{71D7AE3B-E869-4B7A-BC3A-1E9FCF191E1C}")
				:ClassName (spii_feature_definitions)
				:table (spii_params)
				)
			:feature_settings (ReferenceObject
				:Table (asm)
				:Name (AdvancedSecurityObject)
				:Uid ("{756A6ADA-B21D-11DC-8314-0800200C9A66}")
				:path (
					: (asm_active_protection)
					: (HTTP_security_server)
				)
			)
			:type (spii_feature_definitions)
            			:id (22)
			:feature_fields (
			:0 (
				   :AdminInfo (
						  :chkpf_uid ("{43EBD2E4-C724-4131-8434-BFCFBAE4A868}")
						  :ClassName (feature_field)
						  )
				   :name (block_malformed_protocol_name)
				   :type (boolean)
			)
			:1 (
				   :AdminInfo (
						  :chkpf_uid ("{7D3F941B-6607-46DB-B754-5226642BA1AC}")
						  :ClassName (feature_field)
						  )
				   :name (block_no_colon_header)
				   :type (boolean)
			)
			:2 (
				   :AdminInfo (
						  :chkpf_uid ("{961B503D-A979-4F46-B7FE-EDA6BB950B72}")
						  :ClassName (feature_field)
						  )
				   :name (block_tab_separator)
				   :type (boolean)
			)
			:3 (
				   :AdminInfo (
						  :chkpf_uid ("{A56EFEEC-1D37-4766-9B65-118679CC977C}")
						  :ClassName (feature_field)
						  )
				   :name (block_content_len_same_val)
				   :type (boolean)
			)
			:4 (
				   :AdminInfo (
						  :chkpf_uid ("{8F613BD1-68ED-4A2B-94C9-C4A23AF605E5}")
						  :ClassName (feature_field)
						  )
				   :name (block_host_same_val)
				   :type (boolean)
			)
			:5 (
				   :AdminInfo (
						  :chkpf_uid ("{03980DA3-93ED-4519-A3D5-E018E0309FAD}")
						  :ClassName (feature_field)
						  )
				   :name (block_content_len_transfer_enc)
				   :type (boolean)
			)
			:6 (
				   :AdminInfo (
						  :chkpf_uid ("{C6A36462-B4C0-4D1B-A3A1-5DE011FFB3FA}")
						  :ClassName (feature_field)
						  )
				   :name (block_invalid_chunks)
				   :type (boolean)
			)
			:7 (
				   :AdminInfo (
						  :chkpf_uid ("{D910A5AA-0D91-4B3B-B7C9-3C510E7D8BEE}")
						  :ClassName (feature_field)
						  )
				   :name (http_block_non_protocol_compliant_enabled)
				   :type (boolean)
			)
			:8 (
				   :AdminInfo (
						  :chkpf_uid ("{04D76119-ED09-4619-B4EF-248CC4E9B631}")
						  :ClassName (feature_field)
						  )
				   :name (http_block_non_protocol_compliant_send_error)
				   :type (boolean)
			)
			:9 (
				   :AdminInfo (
						  :chkpf_uid ("{0E406870-8DD4-4C02-AE4E-3BF29B2687A1}")
						  :ClassName (feature_field)
						  )
				   :name (http_block_non_protocol_compliant_monitor_only)
				   :type (boolean)
			)
			:10 (
				   :AdminInfo (
						  :chkpf_uid ("{9DBF0EB4-A652-4703-BF57-655B3C6AE6F4}")
						  :ClassName (feature_field)
						  )
				   :name (http_block_non_protocol_compliant_packet_capture)
				   :type (boolean)
			)
			:11 (
				   :AdminInfo (
						  :chkpf_uid ("{1341E7F1-C159-4B2F-8491-877B2E2927CA}")
						  :ClassName (feature_field)
						  )
				   :name (http_block_non_protocol_compliant_track)
				   :type (string)
			)
			:12 (
                   		   :AdminInfo (
                                            :chkpf_uid ("{2FF66462-9A79-8551-BA2F-9CEFC6EC975B}")
                                            :ClassName (feature_field)
						  )
                               :name (block_post_without_content_type)
                               :type (boolean)
           	       )
			:13 (
                               :AdminInfo (
                                            :chkpf_uid ("{DD880FB8-0BA2-ECEA-232D-3B40F8AB45E1}")
                                            :ClassName (feature_field)
                                            )
                               :name (block_empty_header_value)
                               :type (boolean)
           	       )
			:14 (
                               :AdminInfo (
                                            :chkpf_uid ("{B3858A83-68CA-D614-F414-FD179ABF34DE}")
                                            :ClassName (feature_field)
                                            )
                               :name (block_recursive_encoding_requests)
                               :type (boolean)
           	       )
			:15 (
				:AdminInfo (
					:chkpf_uid ("{B667C8B4-0B0C-6C97-41F1-49D329EE27BD}")
					:ClassName (feature_field)
				)
				:name (block_header_with_leading_whitespace)
				:type (boolean)
			)
			:16 (
				:AdminInfo (
					:chkpf_uid ("{A3D9E125-0932-9171-C9A8-F1F735739AC3}")
					:ClassName (feature_field)
				)
				:name (block_header_name_with_trailing_whitespace)
				:type (boolean)
			)
		)
	)
)

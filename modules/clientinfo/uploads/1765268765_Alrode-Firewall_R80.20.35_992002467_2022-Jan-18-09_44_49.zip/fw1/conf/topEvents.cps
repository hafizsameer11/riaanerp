#
# OS configuration file for the non-cpmi command line.
#
#
# Syntax (of complicated fields. The rest is obvious):
#
# SIMPLE-OID,    Name, OID, Type
#
# COLUMN,        Name, OID, Type, Index-order, Display, Display-Totals
#
# SUM-COLUMN,    Name, Display-Totlas, Column-Name-1, Column-Name-2, ....
#
# OUTPUT-FORMAT, "DEFAULT"/"LIST"    *If does not exist - assumed "DEFAULT"  
#
# OID-BASE takes effect only within the section it is in.
#

START-BLOCK

	BLOCK-NAME, "TOP.APPI"

	OID-BASE, 1.3.6.1.4.1.2620.1

	#################################################


# ========= hour ==

	START-FLAVOUR
		FLAVOUR-NAME, "top_last_hour"
		ADD-OID-ATOM, 41

		#SIMPLE-OID, "Total Sessions", 1.1.4.1.3.1, UINT64, 1
		#SIMPLE-OID, "Total Bandwidth", 1.1.4.1.4.1, UINT64, 1
		#SIMPLE-OID, "Total Blocked Sessions", 1.1.4.1.9.1, UINT64, 1
		#SIMPLE-OID, "Total Up bandwidth",     1.1.4.1.10.1, UINT64, 1
		#SIMPLE-OID, "Total Down Bandwidth",   1.1.4.1.11.1, UINT64, 1
		
		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOTAL_APPS"
				TABLE-OID,         1.1.4.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32,  1, FALSE, FALSE 
			COLUMN,     "Sessions",     	    3, UINT64,  0, TRUE,   FALSE
			COLUMN,     "Bytes",                4, UINT64,  0, TRUE,   FALSE
			COLUMN,     "Blocked",             9, UINT64,  0, TRUE,   FALSE
			COLUMN,     "Up Bytes",         10, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Down Bytes",       11, UINT64, 0, TRUE,  FALSE
		END-TABLE

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_APPS_BY_SESSIONS"
				TABLE-OID,         1.1.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32,  1, FALSE, FALSE 
			COLUMN,     "Application ID",    2, STRING, 0, TRUE,   FALSE
			COLUMN,     "Sessions",     	    3, UINT64,  0, TRUE,   FALSE
			COLUMN,     "Bytes",                4, UINT64,  0, TRUE,   FALSE
			COLUMN,     "Risk",                  5, INT32,    0, TRUE,   FALSE
			COLUMN,     "Name",                6, STRING, 0, TRUE,   FALSE
			COLUMN,     "Description",        7, STRING, 0, TRUE,   FALSE
			COLUMN,     "Category",           8, STRING, 0, TRUE,   FALSE
			COLUMN,     "Blocked",             9, UINT64,  0, TRUE,   FALSE
		END-TABLE
		
		#SIMPLE-OID, "Total Hi-Risk Sessions", 1.1.5.1.3.1, UINT64, 1
		#SIMPLE-OID, "Total Hi-Risk Bandwidth", 1.1.5.1.4.1, UINT64, 1
		#SIMPLE-OID, "Total Hi-Risk Blocked Sessions", 1.1.5.1.9.1, UINT64, 1
		
		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOTAL_HIGH_RISK_APPS"
				TABLE-OID,         1.1.5.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32,  1, FALSE, FALSE 
			COLUMN,     "Sessions",     	    3, UINT64,  0, TRUE,   FALSE
			COLUMN,     "Bytes",                4, UINT64,  0, TRUE,   FALSE
			COLUMN,     "Blocked",             9, UINT64,  0, TRUE,   FALSE
		END-TABLE

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_APPS_BY_BANDWIDTH"
				TABLE-OID,         1.1.2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Application ID",        2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Bytes",     3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     	    4, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Risk",                  5, INT32,    0, TRUE,   FALSE
			COLUMN,     "Name",                6, STRING, 0, TRUE,   FALSE
			COLUMN,     "Description",        7, STRING, 0, TRUE,   FALSE
			COLUMN,     "Category",           8, STRING, 0, TRUE,   FALSE
			COLUMN,     "Blocked",             9, UINT64,  0, TRUE,   FALSE
			COLUMN,     "Up Bytes",         10, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Down Bytes",       11, UINT64, 0, TRUE,  FALSE
		END-TABLE
		
		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_HIGH_RISK_APPS_BY_SESSIONS"
				TABLE-OID,         1.1.3.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Application ID",        2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     	    3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Bytes",     4, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Risk",                  5, INT32,    0, TRUE,   FALSE
			COLUMN,     "Name",                6, STRING, 0, TRUE,   FALSE
			COLUMN,     "Description",        7, STRING, 0, TRUE,   FALSE
			COLUMN,     "Category",           8, STRING, 0, TRUE,   FALSE
			COLUMN,     "Blocked",             9, UINT64,  0, TRUE,   FALSE
		END-TABLE
		
		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_USERS_BY_SESSIONS"
				TABLE-OID,         2.1.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "User",        2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",    3, UINT64,     0, TRUE,  FALSE
			COLUMN,     "Bytes",     4, UINT64, 0, TRUE,  FALSE
		END-TABLE
		
		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_USERS_BY_BANDWIDTH"
				TABLE-OID,         2.1.2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "User",        	    2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Bytes",     3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Sessions",    4, UINT64,     0, TRUE,  FALSE
			COLUMN,     "Up Bytes",         10, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Down Bytes",       11, UINT64, 0, TRUE,  FALSE
		END-TABLE

		START-TABLE
			START-TABLE-HEADER
		
				TABLE-NAME,        "CHART_TITLE.TOP_HIGH_RISK_USERS_BY_SESSIONS"
				TABLE-OID,         2.1.3.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Application ID",        2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     	    3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Bytes",     4, UINT64, 0, TRUE,  FALSE
		END-TABLE
		
		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_CATEGORIES_BY_SESSIONS"
				TABLE-OID,         3.1.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Category ID",        	    2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Bytes",     4, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Risk",                  5, INT32,    0, TRUE,   FALSE
			COLUMN,     "Name",           8, STRING, 0, TRUE,   FALSE
			COLUMN,     "Blocked",             9, UINT64,  0, TRUE,   FALSE
		END-TABLE

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_CATEGORIES_BY_BANDWIDTH"
				TABLE-OID,         3.1.2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Category ID",        	    2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Bytes",     3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     4, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Risk",                  5, INT32,    0, TRUE,   FALSE
			COLUMN,     "Name",           8, STRING, 0, TRUE,   FALSE
			COLUMN,     "Blocked",             9, UINT64,  0, TRUE,   FALSE
			COLUMN,     "Up Bytes",         10, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Down Bytes",       11, UINT64, 0, TRUE,  FALSE
		END-TABLE
		
		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_SITES_BY_SESSIONS"
				TABLE-OID,         4.1.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Site",        	    2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Bytes",     4, UINT64, 0, TRUE,  FALSE
		END-TABLE

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_SITES_BY_BANDWIDTH"
				TABLE-OID,         4.1.2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Site",        	    2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Bytes",     3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     4, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Up Bytes",         10, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Down Bytes",       11, UINT64, 0, TRUE,  FALSE
		END-TABLE
		
		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOTAL_BANDWIDTH"
				TABLE-OID,         1.1.6.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",            1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Time",             2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Bytes",            4, UINT64,  0, TRUE,   FALSE
			COLUMN,     "Up Bytes",         10, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Down Bytes",       11, UINT64, 0, TRUE,  FALSE
		END-TABLE

		REMOVE-OID-ATOM
		
		ADD-OID-ATOM, 48

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_PROTECTIONS_BY_SESSIONS"
				TABLE-OID,         1.1.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	          1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Protection name",       2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     	          3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Severity",     	          4, INT32, 0, TRUE,  FALSE
			COLUMN,     "Confidence",              5, INT32, 0, TRUE,  FALSE
			COLUMN,     "Performance Impact", 6, INT32, 0, TRUE,  FALSE
			COLUMN,     "CVE",                        7, STRING, 0, TRUE,   FALSE
			COLUMN,     "Protection Type",        8, STRING, 0, TRUE,   FALSE
			COLUMN,     "Blocked Sessions",      9, UINT64, 0, TRUE,  FALSE
		END-TABLE

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOTAL_PROTECTIONS"
				TABLE-OID,         1.1.2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	          1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Total Detected Connections",  3, UINT64, 0, TRUE,  FALSE
		END-TABLE

		REMOVE-OID-ATOM
		
		ADD-OID-ATOM, 49

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_VIRUSES"
				TABLE-OID,         1.1.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	          1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Virus name",       2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     	          3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Severity",     	          4, INT32, 0, TRUE,  FALSE
			COLUMN,     "Blocked Sessions",      5, UINT64, 0, TRUE,  FALSE
		END-TABLE

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOTAL_VIRUSES"
				TABLE-OID,         1.1.2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	          1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Total Detected",  5, UINT64, 0, TRUE,  FALSE
		END-TABLE

		REMOVE-OID-ATOM
		
		ADD-OID-ATOM, 47
		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,	"CHART_TITLE.AMW_TOTAL_INCIDENTS"
				TABLE-OID,	1.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,	DEFAULT
			END-TABLE-HEADER
			COLUMN,	"Index",	1, UINT32, 1, TRUE, FALSE
			COLUMN,	"AV-Low",	2, UINT64, 0, TRUE, FALSE
			COLUMN,	"AV-Medium",	3, UINT64, 0, TRUE, FALSE
			COLUMN,	"AV-High",	4, UINT64, 0, TRUE, FALSE
			COLUMN,	"AV-Critical",	5, UINT64, 0, TRUE, FALSE
			COLUMN,	"AB-Low",	6, UINT64, 0, TRUE, FALSE
			COLUMN,	"AB-Medium",	7, UINT64, 0, TRUE, FALSE
			COLUMN,	"AB-High",	8, UINT64, 0, TRUE, FALSE
			COLUMN,	"AB-Critical",	9, UINT64, 0, TRUE, FALSE
			COLUMN,	"TE-Low",	10, UINT64, 0, TRUE, FALSE
			COLUMN,	"TE-Medium",	11, UINT64, 0, TRUE, FALSE
			COLUMN,	"TE-High",	12, UINT64, 0, TRUE, FALSE
			COLUMN,	"TE-Critical",	13, UINT64, 0, TRUE, FALSE
			COLUMN,	"TE-Scanned",	14, UINT64, 0, TRUE, FALSE
		END-TABLE

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,	"CHART_TITLE.AMW_TOP_HOSTS_BY_INCIDENTS"
				TABLE-OID,	1.11.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,	DEFAULT
			END-TABLE-HEADER
			COLUMN,	"Index",	1, UINT32, 1, FALSE, FALSE
			COLUMN,	"Host",		2, STRING, 0, TRUE, FALSE
			COLUMN,	"Incidents",	3, UINT64, 0, TRUE, FALSE
		END-TABLE

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,	"CHART_TITLE.AMW_TOP_MALWARES_BY_INCIDENTS"
				TABLE-OID,	1.15.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,	DEFAULT
			END-TABLE-HEADER
			COLUMN,	"Index",	1, UINT32, 1, FALSE, FALSE
			COLUMN,	"Malware",	2, STRING, 0, TRUE, FALSE
			COLUMN,	"Incidents",	3, UINT64, 0, TRUE, FALSE
			COLUMN,	"Severity",	4, INT32, 0, TRUE, FALSE
		END-TABLE
		
		# infected hosts aggregates weekly data regardless of report type (optimization as part of CR01600396)
		START-TABLE
			START-TABLE-HEADER
		
				TABLE-NAME,        "CHART_TITLE.INFECTED_HOSTS"
				TABLE-OID,         1.19.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",			1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Host",        		2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Incidents",    		3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Highest severity",    	4, INT32, 0, TRUE,  FALSE
			COLUMN,     "Protection name",    	5, STRING, 0, TRUE,  FALSE
			COLUMN,     "Protection activity", 6, STRING, 0, TRUE,  FALSE
			COLUMN,     "Highest incident type",    	7, STRING, 0, TRUE,  FALSE
			COLUMN,     "Last incident",    	8, INT32, 0, TRUE,  FALSE
		END-TABLE

		REMOVE-OID-ATOM
		
	END-FLAVOUR

# ========= day ==

	START-FLAVOUR
		FLAVOUR-NAME, "top_last_day"
		ADD-OID-ATOM, 41

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOTAL_APPS"
				TABLE-OID,         1.2.4.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32,  1, FALSE, FALSE 
			COLUMN,     "Sessions",     	    3, UINT64,  0, TRUE,   FALSE
			COLUMN,     "Bytes",                4, UINT64,  0, TRUE,   FALSE
			COLUMN,     "Blocked",             9, UINT64,  0, TRUE,   FALSE
			COLUMN,     "Up Bytes",            10, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Down Bytes",          11, UINT64, 0, TRUE,  FALSE
		END-TABLE

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_APPS_BY_SESSIONS"
				TABLE-OID,         1.2.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Application ID",        2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     	    3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Bytes",     4, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Risk",                  5, INT32,    0, TRUE,   FALSE
			COLUMN,     "Name",                6, STRING, 0, TRUE,   FALSE
			COLUMN,     "Description",        7, STRING, 0, TRUE,   FALSE
			COLUMN,     "Category",           8, STRING, 0, TRUE,   FALSE
			COLUMN,     "Blocked",             9, UINT64,  0, TRUE,   FALSE
		END-TABLE
		
		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOTAL_HIGH_RISK_APPS"
				TABLE-OID,         1.2.5.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32,  1, FALSE, FALSE 
			COLUMN,     "Sessions",     	    3, UINT64,  0, TRUE,   FALSE
			COLUMN,     "Bytes",                4, UINT64,  0, TRUE,   FALSE
			COLUMN,     "Blocked",             9, UINT64,  0, TRUE,   FALSE
		END-TABLE

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_APPS_BY_BANDWIDTH"
				TABLE-OID,         1.2.2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Application ID",        2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Bytes",     3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     	    4, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Risk",                  5, INT32,    0, TRUE,   FALSE
			COLUMN,     "Name",                6, STRING, 0, TRUE,   FALSE
			COLUMN,     "Description",        7, STRING, 0, TRUE,   FALSE
			COLUMN,     "Category",           8, STRING, 0, TRUE,   FALSE
			COLUMN,     "Blocked",             9, UINT64,  0, TRUE,   FALSE
			COLUMN,     "Up Bytes",         10, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Down Bytes",       11, UINT64, 0, TRUE,  FALSE
		END-TABLE
		
		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_HIGH_RISK_APPS_BY_SESSIONS"
				TABLE-OID,         1.2.3.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Application ID",        2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     	    3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Bytes",     4, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Risk",                  5, INT32,    0, TRUE,   FALSE
			COLUMN,     "Name",                6, STRING, 0, TRUE,   FALSE
			COLUMN,     "Description",        7, STRING, 0, TRUE,   FALSE
			COLUMN,     "Category",           8, STRING, 0, TRUE,   FALSE
			COLUMN,     "Blocked",             9, UINT64,  0, TRUE,   FALSE
		END-TABLE
		
		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_USERS_BY_SESSIONS"
				TABLE-OID,         2.2.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "User",        2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",    3, UINT64,     0, TRUE,  FALSE
			COLUMN,     "Bytes",     4, UINT64, 0, TRUE,  FALSE
		END-TABLE
		
		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_USERS_BY_BANDWIDTH"
				TABLE-OID,         2.2.2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "User",        	    2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Bytes",     3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Sessions",    4, UINT64,     0, TRUE,  FALSE
			COLUMN,     "Up Bytes",         10, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Down Bytes",       11, UINT64, 0, TRUE,  FALSE
		END-TABLE

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_HIGH_RISK_USERS_BY_SESSIONS"
				TABLE-OID,         2.2.3.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Application ID",        2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     	    3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Bytes",     4, UINT64, 0, TRUE,  FALSE
		END-TABLE
		
		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_CATEGORIES_BY_SESSIONS"
				TABLE-OID,         3.2.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Category ID",        	    2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Bytes",     4, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Risk",                  5, INT32,    0, TRUE,   FALSE
			COLUMN,     "Name",           8, STRING, 0, TRUE,   FALSE
			COLUMN,     "Blocked",             9, UINT64,  0, TRUE,   FALSE
		END-TABLE

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_CATEGORIES_BY_BANDWIDTH"
				TABLE-OID,         3.2.2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Category ID",        	    2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Bytes",     3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     4, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Risk",                  5, INT32,    0, TRUE,   FALSE
			COLUMN,     "Name",           8, STRING, 0, TRUE,   FALSE
			COLUMN,     "Blocked",             9, UINT64,  0, TRUE,   FALSE
			COLUMN,     "Up Bytes",         10, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Down Bytes",       11, UINT64, 0, TRUE,  FALSE
		END-TABLE
		
		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_SITES_BY_SESSIONS"
				TABLE-OID,         4.2.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Site",        	    2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Bytes",     4, UINT64, 0, TRUE,  FALSE
		END-TABLE

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_SITES_BY_BANDWIDTH"
				TABLE-OID,         4.2.2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Site",        	    2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Bytes",     3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     4, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Up Bytes",         10, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Down Bytes",       11, UINT64, 0, TRUE,  FALSE
		END-TABLE
		
		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOTAL_BANDWIDTH"
				TABLE-OID,         1.2.6.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",            1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Time",             2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Bytes",            4, UINT64,  0, TRUE,   FALSE
			COLUMN,     "Up Bytes",         10, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Down Bytes",       11, UINT64, 0, TRUE,  FALSE
		END-TABLE

		REMOVE-OID-ATOM
		
		ADD-OID-ATOM, 48

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_PROTECTIONS_BY_SESSIONS"
				TABLE-OID,         1.2.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	          1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Protection name",       2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     	          3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Severity",     	          4, INT32, 0, TRUE,  FALSE
			COLUMN,     "Confidence",              5, INT32, 0, TRUE,  FALSE
			COLUMN,     "Performance Impact", 6, INT32, 0, TRUE,  FALSE
			COLUMN,     "CVE",                        7, STRING, 0, TRUE,   FALSE
			COLUMN,     "Protection Type",        8, STRING, 0, TRUE,   FALSE
			COLUMN,     "Blocked Sessions",      9, UINT64, 0, TRUE,  FALSE
		END-TABLE

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOTAL_PROTECTIONS"
				TABLE-OID,         1.2.2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	          1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Total Detected Connections",  3, UINT64, 0, TRUE,  FALSE
		END-TABLE

		REMOVE-OID-ATOM
		
		ADD-OID-ATOM, 49

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_VIRUSES"
				TABLE-OID,         1.2.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	          1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Virus name",       2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     	          3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Severity",     	          4, INT32, 0, TRUE,  FALSE
			COLUMN,     "Blocked Sessions",      5, UINT64, 0, TRUE,  FALSE
		END-TABLE

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOTAL_VIRUSES"
				TABLE-OID,         1.2.2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	          1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Total Detected",  5, UINT64, 0, TRUE,  FALSE
		END-TABLE

		REMOVE-OID-ATOM
		
		ADD-OID-ATOM, 47
		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,	"CHART_TITLE.AMW_TOTAL_INCIDENTS"
				TABLE-OID,	1.2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,	DEFAULT
			END-TABLE-HEADER
			COLUMN,	"Index",	1, UINT32, 1, TRUE, FALSE
			COLUMN,	"AV-Low",	2, UINT64, 0, TRUE, FALSE
			COLUMN,	"AV-Medium",	3, UINT64, 0, TRUE, FALSE
			COLUMN,	"AV-High",	4, UINT64, 0, TRUE, FALSE
			COLUMN,	"AV-Critical",	5, UINT64, 0, TRUE, FALSE
			COLUMN,	"AB-Low",	6, UINT64, 0, TRUE, FALSE
			COLUMN,	"AB-Medium",	7, UINT64, 0, TRUE, FALSE
			COLUMN,	"AB-High",	8, UINT64, 0, TRUE, FALSE
			COLUMN,	"AB-Critical",	9, UINT64, 0, TRUE, FALSE
			COLUMN,	"TE-Low",	10, UINT64, 0, TRUE, FALSE
			COLUMN,	"TE-Medium",	11, UINT64, 0, TRUE, FALSE
			COLUMN,	"TE-High",	12, UINT64, 0, TRUE, FALSE
			COLUMN,	"TE-Critical",	13, UINT64, 0, TRUE, FALSE
			COLUMN,	"TE-Scanned",	14, UINT64, 0, TRUE, FALSE
		END-TABLE

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,	"CHART_TITLE.AMW_TOP_HOSTS_BY_INCIDENTS"
				TABLE-OID,	1.12.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,	DEFAULT
			END-TABLE-HEADER
			COLUMN,	"Index",	1, UINT32, 1, FALSE, FALSE
			COLUMN,	"Host",		2, STRING, 0, TRUE, FALSE
			COLUMN,	"Incidents",	3, UINT64, 0, TRUE, FALSE
		END-TABLE

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,	"CHART_TITLE.AMW_TOP_MALWARES_BY_INCIDENTS"
				TABLE-OID,	1.16.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,	DEFAULT
			END-TABLE-HEADER
			COLUMN,	"Index",	1, UINT32, 1, FALSE, FALSE
			COLUMN,	"Malware",	2, STRING, 0, TRUE, FALSE
			COLUMN,	"Incidents",	3, UINT64, 0, TRUE, FALSE
			COLUMN,	"Severity",	4, INT32, 0, TRUE, FALSE
		END-TABLE
		
		# infected hosts aggregates weekly data regardless of report type (optimization as part of CR01600396)
		START-TABLE
			START-TABLE-HEADER
		
				TABLE-NAME,        "CHART_TITLE.INFECTED_HOSTS"
				TABLE-OID,         1.19.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",			1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Host",        		2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Incidents",    		3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Highest severity",    	4, INT32, 0, TRUE,  FALSE
			COLUMN,     "Protection name",    	5, STRING, 0, TRUE,  FALSE
			COLUMN,     "Protection activity", 6, STRING, 0, TRUE,  FALSE
			COLUMN,     "Highest incident type",    	7, STRING, 0, TRUE,  FALSE
			COLUMN,     "Last incident",    	8, INT32, 0, TRUE,  FALSE
		END-TABLE

		REMOVE-OID-ATOM
		
	END-FLAVOUR

# ========= week ==
	
	START-FLAVOUR
		FLAVOUR-NAME, "top_last_week"
		ADD-OID-ATOM, 41

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOTAL_APPS"
				TABLE-OID,         1.3.4.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32,  1, FALSE, FALSE 
			COLUMN,     "Sessions",     	    3, UINT64,  0, TRUE,   FALSE
			COLUMN,     "Bytes",                4, UINT64,  0, TRUE,   FALSE
			COLUMN,     "Blocked",             9, UINT64,  0, TRUE,   FALSE
			COLUMN,     "Up Bytes",         10, UINT64,  0, TRUE,  FALSE
			COLUMN,     "Down Bytes",       11, UINT64,  0, TRUE,  FALSE
		END-TABLE

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_APPS_BY_SESSIONS"
				TABLE-OID,         1.3.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Application ID",        2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     	    3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Bytes",     4, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Risk",                  5, INT32,    0, TRUE,   FALSE
			COLUMN,     "Name",                6, STRING, 0, TRUE,   FALSE
			COLUMN,     "Description",        7, STRING, 0, TRUE,   FALSE
			COLUMN,     "Category",           8, STRING, 0, TRUE,   FALSE
			COLUMN,     "Blocked",             9, UINT64,  0, TRUE,   FALSE
		END-TABLE
		
		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOTAL_HIGH_RISK_APPS"
				TABLE-OID,         1.3.5.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32,  1, FALSE, FALSE 
			COLUMN,     "Sessions",     	    3, UINT64,  0, TRUE,   FALSE
			COLUMN,     "Bytes",                4, UINT64,  0, TRUE,   FALSE
			COLUMN,     "Blocked",             9, UINT64,  0, TRUE,   FALSE
		END-TABLE

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_APPS_BY_BANDWIDTH"
				TABLE-OID,         1.3.2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Application ID",        2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Bytes",     3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     	    4, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Risk",                  5, INT32,    0, TRUE,   FALSE
			COLUMN,     "Name",                6, STRING, 0, TRUE,   FALSE
			COLUMN,     "Description",        7, STRING, 0, TRUE,   FALSE
			COLUMN,     "Category",           8, STRING, 0, TRUE,   FALSE
			COLUMN,     "Blocked",             9, UINT64,  0, TRUE,   FALSE
			COLUMN,     "Up Bytes",         10, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Down Bytes",       11, UINT64, 0, TRUE,  FALSE
		END-TABLE
		
		START-TABLE
			START-TABLE-HEADER
		
				TABLE-NAME,        "CHART_TITLE.TOP_HIGH_RISK_APPS_BY_SESSIONS"
				TABLE-OID,         1.3.3.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Application ID",        2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     	    3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Bytes",     4, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Risk",                  5, INT32,    0, TRUE,   FALSE
			COLUMN,     "Name",                6, STRING, 0, TRUE,   FALSE
			COLUMN,     "Description",        7, STRING, 0, TRUE,   FALSE
			COLUMN,     "Category",           8, STRING, 0, TRUE,   FALSE
			COLUMN,     "Blocked",             9, UINT64,  0, TRUE,   FALSE
		END-TABLE
		
		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_USERS_BY_SESSIONS"
				TABLE-OID,         2.3.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "User",        2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",    3, UINT64,     0, TRUE,  FALSE
			COLUMN,     "Bytes",     4, UINT64, 0, TRUE,  FALSE
		END-TABLE
		
		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_USERS_BY_BANDWIDTH"
				TABLE-OID,         2.3.2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "User",        	    2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Bytes",     3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     	    4, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Up Bytes",         10, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Down Bytes",       11, UINT64, 0, TRUE,  FALSE
		END-TABLE

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_HIGH_RISK_USERS_BY_SESSIONS"
				TABLE-OID,         2.3.3.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Application ID",        2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     	    3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Bytes",     4, UINT64, 0, TRUE,  FALSE
		END-TABLE
		
		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_CATEGORIES_BY_SESSIONS"
				TABLE-OID,         3.3.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Category ID",        	    2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Bytes",     4, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Risk",                  5, INT32,    0, TRUE,   FALSE
			COLUMN,     "Name",           8, STRING, 0, TRUE,   FALSE
			COLUMN,     "Blocked",             9, UINT64,  0, TRUE,   FALSE
		END-TABLE

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_CATEGORIES_BY_BANDWIDTH"
				TABLE-OID,         3.3.2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Category ID",        	    2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Bytes",     3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     4, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Risk",                  5, INT32,    0, TRUE,   FALSE
			COLUMN,     "Name",           8, STRING, 0, TRUE,   FALSE
			COLUMN,     "Blocked",             9, UINT64,  0, TRUE,   FALSE
			COLUMN,     "Up Bytes",         10, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Down Bytes",       11, UINT64, 0, TRUE,  FALSE
		END-TABLE
		
		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_SITES_BY_SESSIONS"
				TABLE-OID,         4.3.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Site",        	    2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Bytes",     4, UINT64, 0, TRUE,  FALSE
		END-TABLE

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_SITES_BY_BANDWIDTH"
				TABLE-OID,         4.3.2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Site",        	    2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Bytes",     3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     4, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Up Bytes",         10, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Down Bytes",       11, UINT64, 0, TRUE,  FALSE
		END-TABLE
		
		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOTAL_BANDWIDTH"
				TABLE-OID,         1.3.6.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",            1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Time",             2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Bytes",            4, UINT64,  0, TRUE,   FALSE
			COLUMN,     "Up Bytes",         10, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Down Bytes",       11, UINT64, 0, TRUE,  FALSE
		END-TABLE

		REMOVE-OID-ATOM
		
		ADD-OID-ATOM, 48

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_PROTECTIONS_BY_SESSIONS"
				TABLE-OID,         1.3.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	          1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Protection name",       2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     	          3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Severity",     	          4, INT32, 0, TRUE,  FALSE
			COLUMN,     "Confidence",              5, INT32, 0, TRUE,  FALSE
			COLUMN,     "Performance Impact", 6, INT32, 0, TRUE,  FALSE
			COLUMN,     "CVE",                        7, STRING, 0, TRUE,   FALSE
			COLUMN,     "Protection Type",        8, STRING, 0, TRUE,   FALSE
			COLUMN,     "Blocked Sessions",      9, UINT64, 0, TRUE,  FALSE
		END-TABLE

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOTAL_PROTECTIONS"
				TABLE-OID,         1.3.2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	          1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Total Detected Connections",  3, UINT64, 0, TRUE,  FALSE
		END-TABLE

		REMOVE-OID-ATOM
		
		ADD-OID-ATOM, 49

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_VIRUSES"
				TABLE-OID,         1.3.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	          1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Virus name",       2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     	          3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Severity",     	          4, INT32, 0, TRUE,  FALSE
			COLUMN,     "Blocked Sessions",      5, UINT64, 0, TRUE,  FALSE
		END-TABLE

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOTAL_VIRUSES"
				TABLE-OID,         1.3.2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	          1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Total Detected",  5, UINT64, 0, TRUE,  FALSE
		END-TABLE

		REMOVE-OID-ATOM
		
		ADD-OID-ATOM, 47
		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,	"CHART_TITLE.AMW_TOTAL_INCIDENTS"
				TABLE-OID,	1.3.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,	DEFAULT
			END-TABLE-HEADER
			COLUMN,	"Index",	1, UINT32, 1, TRUE, FALSE
			COLUMN,	"AV-Low",	2, UINT64, 0, TRUE, FALSE
			COLUMN,	"AV-Medium",	3, UINT64, 0, TRUE, FALSE
			COLUMN,	"AV-High",	4, UINT64, 0, TRUE, FALSE
			COLUMN,	"AV-Critical",	5, UINT64, 0, TRUE, FALSE
			COLUMN,	"AB-Low",	6, UINT64, 0, TRUE, FALSE
			COLUMN,	"AB-Medium",	7, UINT64, 0, TRUE, FALSE
			COLUMN,	"AB-High",	8, UINT64, 0, TRUE, FALSE
			COLUMN,	"AB-Critical",	9, UINT64, 0, TRUE, FALSE
			COLUMN,	"TE-Low",	10, UINT64, 0, TRUE, FALSE
			COLUMN,	"TE-Medium",	11, UINT64, 0, TRUE, FALSE
			COLUMN,	"TE-High",	12, UINT64, 0, TRUE, FALSE
			COLUMN,	"TE-Critical",	13, UINT64, 0, TRUE, FALSE
			COLUMN,	"TE-Scanned",	14, UINT64, 0, TRUE, FALSE
		END-TABLE

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,	"CHART_TITLE.AMW_TOP_HOSTS_BY_INCIDENTS"
				TABLE-OID,	1.13.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,	DEFAULT
			END-TABLE-HEADER
			COLUMN,	"Index",	1, UINT32, 1, FALSE, FALSE
			COLUMN,	"Host",		2, STRING, 0, TRUE, FALSE
			COLUMN,	"Incidents",	3, UINT64, 0, TRUE, FALSE
		END-TABLE

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,	"CHART_TITLE.AMW_TOP_MALWARES_BY_INCIDENTS"
				TABLE-OID,	1.17.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,	DEFAULT
			END-TABLE-HEADER
			COLUMN,	"Index",	1, UINT32, 1, FALSE, FALSE
			COLUMN,	"Malware",	2, STRING, 0, TRUE, FALSE
			COLUMN,	"Incidents",	3, UINT64, 0, TRUE, FALSE
			COLUMN,	"Severity",	4, INT32, 0, TRUE, FALSE
		END-TABLE
		
		# infected hosts aggregates weekly data regardless of report type (optimization as part of CR01600396)
		START-TABLE
			START-TABLE-HEADER
		
				TABLE-NAME,        "CHART_TITLE.INFECTED_HOSTS"
				TABLE-OID,         1.19.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",			1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Host",        		2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Incidents",    		3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Highest severity",    	4, INT32, 0, TRUE,  FALSE
			COLUMN,     "Protection name",    	5, STRING, 0, TRUE,  FALSE
			COLUMN,     "Protection activity", 6, STRING, 0, TRUE,  FALSE
			COLUMN,     "Highest incident type",    	7, STRING, 0, TRUE,  FALSE
			COLUMN,     "Last incident",    	8, INT32, 0, TRUE,  FALSE
		END-TABLE

		REMOVE-OID-ATOM
		
	END-FLAVOUR

# ========= month ==

	START-FLAVOUR
		FLAVOUR-NAME, "top_last_month"
		ADD-OID-ATOM, 41

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOTAL_APPS"
				TABLE-OID,         1.4.4.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32,  1, FALSE, FALSE 
			COLUMN,     "Sessions",     	    3, UINT64,  0, TRUE,   FALSE
			COLUMN,     "Bytes",                4, UINT64,  0, TRUE,   FALSE
			COLUMN,     "Blocked",             9, UINT64,  0, TRUE,   FALSE
			COLUMN,     "Up Bytes",         10, UINT64,  0, TRUE,  FALSE
			COLUMN,     "Down Bytes",       11, UINT64,  0, TRUE,  FALSE
		END-TABLE

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_APPS_BY_SESSIONS"
				TABLE-OID,         1.4.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Application ID",        2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     	    3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Bytes",     4, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Risk",                  5, INT32,    0, TRUE,   FALSE
			COLUMN,     "Name",                6, STRING, 0, TRUE,   FALSE
			COLUMN,     "Description",        7, STRING, 0, TRUE,   FALSE
			COLUMN,     "Category",           8, STRING, 0, TRUE,   FALSE
			COLUMN,     "Blocked",             9, UINT64,  0, TRUE,   FALSE
		END-TABLE
		
		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOTAL_HIGH_RISK_APPS"
				TABLE-OID,         1.4.5.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32,  1, FALSE, FALSE 
			COLUMN,     "Sessions",     	    3, UINT64,  0, TRUE,   FALSE
			COLUMN,     "Bytes",                4, UINT64,  0, TRUE,   FALSE
			COLUMN,     "Blocked",             9, UINT64,  0, TRUE,   FALSE
		END-TABLE

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_APPS_BY_BANDWIDTH"
				TABLE-OID,         1.4.2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Application ID",        2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Bytes",     3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     	    4, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Risk",                  5, INT32,    0, TRUE,   FALSE
			COLUMN,     "Name",                6, STRING, 0, TRUE,   FALSE
			COLUMN,     "Description",        7, STRING, 0, TRUE,   FALSE
			COLUMN,     "Category",           8, STRING, 0, TRUE,   FALSE
			COLUMN,     "Blocked",             9, UINT64,  0, TRUE,   FALSE
			COLUMN,     "Up Bytes",         10, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Down Bytes",       11, UINT64, 0, TRUE,  FALSE
		END-TABLE
		
		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_HIGH_RISK_APPS_BY_SESSIONS"
				TABLE-OID,         1.4.3.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Application ID",        2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     	    3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Bytes",     4, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Risk",                  5, INT32,    0, TRUE,   FALSE
			COLUMN,     "Name",                6, STRING, 0, TRUE,   FALSE
			COLUMN,     "Description",        7, STRING, 0, TRUE,   FALSE
			COLUMN,     "Category",           8, STRING, 0, TRUE,   FALSE
			COLUMN,     "Blocked",             9, UINT64,  0, TRUE,   FALSE
		END-TABLE
		
		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_USERS_BY_SESSIONS"
				TABLE-OID,         2.4.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "User",        2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",    3, UINT64,     0, TRUE,  FALSE
			COLUMN,     "Bytes",     4, UINT64, 0, TRUE,  FALSE
		END-TABLE
		
		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_USERS_BY_BANDWIDTH"
				TABLE-OID,         2.4.2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "User",        	    2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Bytes",     3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     4, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Up Bytes",         10, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Down Bytes",       11, UINT64, 0, TRUE,  FALSE
		END-TABLE

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_HIGH_RISK_USERS_BY_SESSIONS"
				TABLE-OID,         2.4.3.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Application ID",        2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     	    3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Bytes",     4, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Risk",                  5, INT32,    0, TRUE,   FALSE
			COLUMN,     "Name",                6, STRING, 0, TRUE,   FALSE
			COLUMN,     "Description",        7, STRING, 0, TRUE,   FALSE
			COLUMN,     "Category",           8, STRING, 0, TRUE,   FALSE
			COLUMN,     "Blocked",             9, UINT64,  0, TRUE,   FALSE
		END-TABLE
		
		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_CATEGORIES_BY_SESSIONS"
				TABLE-OID,         3.4.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Category ID",        	    2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Bytes",     4, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Risk",                  5, INT32,    0, TRUE,   FALSE
			COLUMN,     "Name",           8, STRING, 0, TRUE,   FALSE
			COLUMN,     "Blocked",             9, UINT64,  0, TRUE,   FALSE
		END-TABLE

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_CATEGORIES_BY_BANDWIDTH"
				TABLE-OID,         3.4.2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Category ID",        	    2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Bytes",     3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     4, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Risk",                  5, INT32,    0, TRUE,   FALSE
			COLUMN,     "Name",           8, STRING, 0, TRUE,   FALSE
			COLUMN,     "Blocked",             9, UINT64,  0, TRUE,   FALSE
			COLUMN,     "Up Bytes",         10, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Down Bytes",       11, UINT64, 0, TRUE,  FALSE
		END-TABLE
		
		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_SITES_BY_SESSIONS"
				TABLE-OID,         4.4.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Site",        	    2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Bytes",     4, UINT64, 0, TRUE,  FALSE
		END-TABLE

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_SITES_BY_BANDWIDTH"
				TABLE-OID,         4.4.2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Site",        	    2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Bytes",     3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     4, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Up Bytes",         10, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Down Bytes",       11, UINT64, 0, TRUE,  FALSE
		END-TABLE
		
		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOTAL_BANDWIDTH"
				TABLE-OID,         1.4.6.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",            1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Time",             2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Bytes",            4, UINT64,  0, TRUE,   FALSE
			COLUMN,     "Up Bytes",         10, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Down Bytes",       11, UINT64, 0, TRUE,  FALSE
		END-TABLE

		REMOVE-OID-ATOM
		
		ADD-OID-ATOM, 48

		#SIMPLE-OID, "Total Detected Connections", 1.4.2.1.3.1, UINT64, 1

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_PROTECTIONS_BY_SESSIONS"
				TABLE-OID,         1.4.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	          1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Protection name",       2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     	          3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Severity",     	          4, INT32, 0, TRUE,  FALSE
			COLUMN,     "Confidence",              5, INT32, 0, TRUE,  FALSE
			COLUMN,     "Performance Impact", 6, INT32, 0, TRUE,  FALSE
			COLUMN,     "CVE",                        7, STRING, 0, TRUE,   FALSE
			COLUMN,     "Protection Type",        8, STRING, 0, TRUE,   FALSE
			COLUMN,     "Blocked Sessions",      9, UINT64, 0, TRUE,  FALSE
		END-TABLE

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOTAL_PROTECTIONS"
				TABLE-OID,         1.4.2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	          1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Total Detected Connections",  3, UINT64, 0, TRUE,  FALSE
		END-TABLE

		REMOVE-OID-ATOM
		
		ADD-OID-ATOM, 49

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOP_VIRUSES"
				TABLE-OID,         1.4.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	          1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Virus name",       2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     	          3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Severity",     	          4, INT32, 0, TRUE,  FALSE
			COLUMN,     "Blocked Sessions",      5, UINT64, 0, TRUE,  FALSE
		END-TABLE

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,        "CHART_TITLE.TOTAL_VIRUSES"
				TABLE-OID,         1.4.2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT
			END-TABLE-HEADER
			COLUMN,     "Index",       	          1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Total Detected",  5, UINT64, 0, TRUE,  FALSE
		END-TABLE

		REMOVE-OID-ATOM
		
		ADD-OID-ATOM, 47
		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,	"CHART_TITLE.AMW_TOTAL_INCIDENTS"
				TABLE-OID,	1.4.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,	DEFAULT
			END-TABLE-HEADER
			COLUMN,	"Index",	1, UINT32, 1, TRUE, FALSE
			COLUMN,	"AV-Low",	2, UINT64, 0, TRUE, FALSE
			COLUMN,	"AV-Medium",	3, UINT64, 0, TRUE, FALSE
			COLUMN,	"AV-High",	4, UINT64, 0, TRUE, FALSE
			COLUMN,	"AV-Critical",	5, UINT64, 0, TRUE, FALSE
			COLUMN,	"AB-Low",	6, UINT64, 0, TRUE, FALSE
			COLUMN,	"AB-Medium",	7, UINT64, 0, TRUE, FALSE
			COLUMN,	"AB-High",	8, UINT64, 0, TRUE, FALSE
			COLUMN,	"AB-Critical",	9, UINT64, 0, TRUE, FALSE
			COLUMN,	"TE-Low",	10, UINT64, 0, TRUE, FALSE
			COLUMN,	"TE-Medium",	11, UINT64, 0, TRUE, FALSE
			COLUMN,	"TE-High",	12, UINT64, 0, TRUE, FALSE
			COLUMN,	"TE-Critical",	13, UINT64, 0, TRUE, FALSE
			COLUMN,	"TE-Scanned",	14, UINT64, 0, TRUE, FALSE
		END-TABLE

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,	"CHART_TITLE.AMW_TOP_HOSTS_BY_INCIDENTS"
				TABLE-OID,	1.14.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,	DEFAULT
			END-TABLE-HEADER
			COLUMN,	"Index",	1, UINT32, 1, FALSE, FALSE
			COLUMN,	"Host",		2, STRING, 0, TRUE, FALSE
			COLUMN,	"Incidents",	3, UINT64, 0, TRUE, FALSE
		END-TABLE

		START-TABLE
			START-TABLE-HEADER
				TABLE-NAME,	"CHART_TITLE.AMW_TOP_MALWARES_BY_INCIDENTS"
				TABLE-OID,	1.18.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,	DEFAULT
			END-TABLE-HEADER
			COLUMN,	"Index",	1, UINT32, 1, FALSE, FALSE
			COLUMN,	"Malware",	2, STRING, 0, TRUE, FALSE
			COLUMN,	"Incidents",	3, UINT64, 0, TRUE, FALSE
			COLUMN,	"Severity",	4, INT32, 0, TRUE, FALSE
		END-TABLE
		
		# infected hosts aggregates weekly data regardless of report type (optimization as part of CR01600396)
		START-TABLE
			START-TABLE-HEADER
		
				TABLE-NAME,        "CHART_TITLE.INFECTED_HOSTS"
				TABLE-OID,         1.19.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",			1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Host",        		2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Incidents",    		3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Highest severity",    	4, INT32, 0, TRUE,  FALSE
			COLUMN,     "Protection name",    	5, STRING, 0, TRUE,  FALSE
			COLUMN,     "Protection activity", 6, STRING, 0, TRUE,  FALSE
			COLUMN,     "Highest incident type",    	7, STRING, 0, TRUE,  FALSE
			COLUMN,     "Last incident",    	8, INT32, 0, TRUE,  FALSE
		END-TABLE

		REMOVE-OID-ATOM
		
	END-FLAVOUR

END-BLOCK



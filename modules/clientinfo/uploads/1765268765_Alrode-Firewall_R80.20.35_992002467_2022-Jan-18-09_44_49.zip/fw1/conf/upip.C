(
	:manifest ("manifest.C")
	:implicit_rule ("implicit_rule.C")
	:fileslist (
		: (
			:name ("local.fileslist")
			:mode ("mandatory")
			:light (true)
		)
		: (
			:name ("local.mab_fileslist")
			:mode ("optional")
			:light (false)
		)
		: (
			:name ("local.robo_fileslist")
			:mode ("optional")
			:light (false)
		)
	)
)

(
     : (local.index_by_uuid
		:metadata (
			:module ("xgen")
			:class ("CXGenIndex_by_uuidUpdb")
			:skip (true)
		)
	)

     : (local.index_by_type
		:metadata (
			:module ("xgen")
			:class ("CXGenIndex_by_typeUpdb")
			:skip (true)
		)
	)

     : (local.index_rulebase_global_table
		:metadata (
			:module ("xgen")
			:class ("CXGenIndex_rulebase_global_tableUpdb")
			:skip (true)
		)
	)

     : (local.active_sync_application
		:metadata (
			:module ("mgen")
			:class ("CMGenActive_sync_applicationUpdb")
		)
	)

     : (local.file_share_application
		:metadata (
			:module ("mgen")
			:class ("CMGenFile_share_applicationUpdb")
		)
	)

     : (local.mail_service_application
		:metadata (
			:module ("mgen")
			:class ("CMGenMail_service_applicationUpdb")
		)
	)

     : (local.hosts_and_services_for_native_application
		:metadata (
			:module ("mgen")
			:class ("CMGenHosts_and_services_for_native_applicationUpdb")
		)
	)

     : (local.native_application
		:metadata (
			:module ("mgen")
			:class ("CMGenNative_applicationUpdb")
		)
	)

     : (local.connectra_web_application
		:metadata (
			:module ("mgen")
			:class ("CMGenConnectra_web_applicationUpdb")
		)
	)

     : (local.citrix_service
		:metadata (
			:module ("mgen")
			:class ("CMGenCitrix_serviceUpdb")
		)
	)

     : (local.business_mail_application
		:metadata (
			:module ("mgen")
			:class ("CMGenBusiness_mail_applicationUpdb")
		)
	)

     : (local.data_awareness_settings
		:metadata (
			:module ("dgen")
			:class ("CDGenData_awareness_settingsUpdb")
		)
	)

     : (local.cpmi_file
		:metadata (
			:module ("dgen")
			:class ("CDGenCpmi_fileUpdb")
		)
	)

     : (local.file_type
		:metadata (
			:module ("dgen")
			:class ("CDGenFile_typeUpdb")
		)
	)

     : (local.hybrid_data_type
		:metadata (
			:module ("dgen")
			:class ("CDGenHybrid_data_typeUpdb")
		)
	)

     : (local.message_attributes_data_type
		:metadata (
			:module ("dgen")
			:class ("CDGenMessage_attributes_data_typeUpdb")
		)
	)

     : (local.compound_data_type
		:metadata (
			:module ("dgen")
			:class ("CDGenCompound_data_typeUpdb")
		)
	)

     : (local.group_data_type
		:metadata (
			:module ("dgen")
			:class ("CDGenGroup_data_typeUpdb")
		)
	)

     : (local.words_data_type
		:metadata (
			:module ("dgen")
			:class ("CDGenWords_data_typeUpdb")
		)
	)

     : (local.weighted_words_data_type
		:metadata (
			:module ("dgen")
			:class ("CDGenWeighted_words_data_typeUpdb")
		)
	)

     : (local.file_data_type
		:metadata (
			:module ("dgen")
			:class ("CDGenFile_data_typeUpdb")
		)
	)

     : (local.pattern_data_type
		:metadata (
			:module ("dgen")
			:class ("CDGenPattern_data_typeUpdb")
		)
	)

     : (local.custom_data_type
		:metadata (
			:module ("dgen")
			:class ("CDGenCustom_data_typeUpdb")
		)
	)

     : (local.mab_user_at_location
		:metadata (
			:module ("sgen")
			:class ("CSGenUser_at_locationUpdb")
		)
	)

     : (local.user_at_location
		:metadata (
			:module ("sgen")
			:class ("CSGenUser_at_locationUpdb")
		)
	)

     : (local.updatable_obj
		:metadata (
			:module ("sgen")
			:class ("CSGenUpdatable_objUpdb")
		)
	)

     : (local.dynobj
		:metadata (
			:module ("sgen")
			:class ("CSGenDynobjUpdb")
		)
	)

     : (local.domain
		:metadata (
			:module ("sgen")
			:class ("CSGenDomainUpdb")
		)
	)

     : (local.mab_vpn_directional_element
		:metadata (
			:module ("sgen")
			:class ("CSGenVpn_directional_elementUpdb")
		)
	)

     : (local.vpn_directional_element
		:metadata (
			:module ("sgen")
			:class ("CSGenVpn_directional_elementUpdb")
		)
	)

     : (local.mab_sr_community
		:metadata (
			:module ("sgen")
			:class ("CSGenSr_communityUpdb")
		)
	)

     : (local.sr_community
		:metadata (
			:module ("sgen")
			:class ("CSGenSr_communityUpdb")
		)
	)

     : (local.intranet_community
		:metadata (
			:module ("sgen")
			:class ("CSGenIntranet_communityUpdb")
		)
	)

     : (local.logical_server
		:metadata (
			:module ("sgen")
			:class ("CSGenLogical_serverUpdb")
		)
	)

     : (local.service_group
		:metadata (
			:module ("sgen")
			:class ("CSGenService_groupUpdb")
		)
	)

     : (local.dcerpc_service
		:metadata (
			:module ("sgen")
			:class ("CSGenDcerpc_serviceUpdb")
		)
	)

     : (local.rpc_service
		:metadata (
			:module ("sgen")
			:class ("CSGenRpc_serviceUpdb")
		)
	)

     : (local.other_service
		:metadata (
			:module ("sgen")
			:class ("CSGenOther_serviceUpdb")
		)
	)

     : (local.icmpv6_service
		:metadata (
			:module ("sgen")
			:class ("CSGenIcmpv6_serviceUpdb")
		)
	)

     : (local.icmp_service
		:metadata (
			:module ("sgen")
			:class ("CSGenIcmp_serviceUpdb")
		)
	)

     : (local.sctp_service
		:metadata (
			:module ("sgen")
			:class ("CSGenSctp_serviceUpdb")
		)
	)

     : (local.udp_service
		:metadata (
			:module ("sgen")
			:class ("CSGenUdp_serviceUpdb")
		)
	)

     : (local.tcp_service
		:metadata (
			:module ("sgen")
			:class ("CSGenTcp_serviceUpdb")
		)
	)

     : (local.udp_protocol
		:metadata (
			:module ("sgen")
			:class ("CSGenUdp_protocolUpdb")
		)
	)

     : (local.tcp_protocol
		:metadata (
			:module ("sgen")
			:class ("CSGenTcp_protocolUpdb")
		)
	)

     : (local.group_with_exception
		:metadata (
			:module ("sgen")
			:class ("CSGenGroup_with_exceptionUpdb")
		)
	)

     : (local.network_group
		:metadata (
			:module ("sgen")
			:class ("CSGenNetwork_groupUpdb")
		)
	)

     : (local.user_category
		:metadata (
			:module ("sgen")
			:class ("CSGenUser_categoryUpdb")
		)
	)

     : (local.category
		:metadata (
			:module ("sgen")
			:class ("CSGenCategoryUpdb")
		)
	)

     : (local.category_match_settings
		:metadata (
			:module ("sgen")
			:class ("CSGenCategory_match_settingsUpdb")
		)
	)

     : (local.user_application
		:metadata (
			:module ("sgen")
			:class ("CSGenUser_applicationUpdb")
		)
	)

     : (local.application_group
		:metadata (
			:module ("sgen")
			:class ("CSGenApplication_groupUpdb")
		)
	)

     : (local.scada_application
		:metadata (
			:module ("sgen")
			:class ("CSGenScada_applicationUpdb")
		)
	)

     : (local.application
		:metadata (
			:module ("sgen")
			:class ("CSGenApplicationUpdb")
		)
	)

     : (local.application_match_settings
		:metadata (
			:module ("sgen")
			:class ("CSGenApplication_match_settingsUpdb")
		)
	)

     : (local.multicast_ip_range
		:metadata (
			:module ("sgen")
			:class ("CSGenMulticast_ip_rangeUpdb")
		)
	)

     : (local.ip_range
		:metadata (
			:module ("sgen")
			:class ("CSGenIp_rangeUpdb")
		)
	)

     : (local.voip_skinny
		:metadata (
			:module ("sgen")
			:class ("CSGenVoip_skinnyUpdb")
		)
	)

     : (local.voip_mgcp
		:metadata (
			:module ("sgen")
			:class ("CSGenVoip_mgcpUpdb")
		)
	)

     : (local.voip_gw
		:metadata (
			:module ("sgen")
			:class ("CSGenVoip_gwUpdb")
		)
	)

     : (local.voip_gk
		:metadata (
			:module ("sgen")
			:class ("CSGenVoip_gkUpdb")
		)
	)

     : (local.voip_sip
		:metadata (
			:module ("sgen")
			:class ("CSGenVoip_sipUpdb")
		)
	)

     : (local.vsx_cluster_member
		:metadata (
			:module ("sgen")
			:class ("CSGenVsx_cluster_memberUpdb")
		)
	)

     : (local.vs_cluster_member
		:metadata (
			:module ("sgen")
			:class ("CSGenVs_cluster_memberUpdb")
		)
	)

     : (local.vsx_cluster_netobj
		:metadata (
			:module ("sgen")
			:class ("CSGenVsx_cluster_netobjUpdb")
		)
	)

     : (local.vs_cluster_netobj
		:metadata (
			:module ("sgen")
			:class ("CSGenVs_cluster_netobjUpdb")
		)
	)

     : (local.vsx_netobj
		:metadata (
			:module ("sgen")
			:class ("CSGenVsx_netobjUpdb")
		)
	)

     : (local.vs_netobj
		:metadata (
			:module ("sgen")
			:class ("CSGenVs_netobjUpdb")
		)
	)

     : (local.utm_cluster_member
		:metadata (
			:module ("sgen")
			:class ("CSGenUtm_cluster_memberUpdb")
		)
	)

     : (local.cluster_member
		:metadata (
			:module ("sgen")
			:class ("CSGenCluster_memberUpdb")
		)
	)

     : (local.robo_cluster_member
		:metadata (
			:module ("sgen")
			:class ("CSGenCluster_memberUpdb")
		)
	)

     : (local.gateway_cluster
		:metadata (
			:module ("sgen")
			:class ("CSGenGateway_clusterUpdb")
		)
	)

     : (local.robo_gateway_cluster
		:metadata (
			:module ("sgen")
			:class ("CSGenGateway_clusterUpdb")
		)
	)

     : (local.gateway_plain
		:metadata (
			:module ("sgen")
			:class ("CSGenGateway_plainUpdb")
		)
	)

     : (local.host_ckp
		:metadata (
			:module ("sgen")
			:class ("CSGenHost_ckpUpdb")
		)
	)

     : (local.ose_device
		:metadata (
			:module ("sgen")
			:class ("CSGenOse_deviceUpdb")
		)
	)

     : (local.sofaware_gateway
		:metadata (
			:module ("sgen")
			:class ("CSGenSofaware_gatewayUpdb")
		)
	)

     : (local.gateway
		:metadata (
			:module ("sgen")
			:class ("CSGenGatewayUpdb")
		)
	)

     : (local.robo_gateway
		:metadata (
			:module ("sgen")
			:class ("CSGenGatewayUpdb")
		)
	)

     : (local.host
		:metadata (
			:module ("sgen")
			:class ("CSGenHostUpdb")
		)
	)

     : (local.identity_role
		:metadata (
			:module ("sgen")
			:class ("CSGenIdentity_roleUpdb")
		)
	)

     : (local.security_zone
		:metadata (
			:module ("sgen")
			:class ("CSGenSecurity_zoneUpdb")
		)
	)

     : (local.network
		:metadata (
			:module ("sgen")
			:class ("CSGenNetworkUpdb")
		)
	)

     : (local.wildcard
		:metadata (
			:module ("sgen")
			:class ("CSGenWildcardUpdb")
		)
	)

     : (local.identity_tag
		:metadata (
			:module ("sgen")
			:class ("CSGenIdentity_tagUpdb")
		)
	)

     : (local.ad_user
		:metadata (
			:module ("sgen")
			:class ("CSGenAd_userUpdb")
		)
	)

     : (local.ad_machine
		:metadata (
			:module ("sgen")
			:class ("CSGenAd_machineUpdb")
		)
	)

     : (local.ad_group
		:metadata (
			:module ("sgen")
			:class ("CSGenAd_groupUpdb")
		)
	)

     : (local.ad_branch
		:metadata (
			:module ("sgen")
			:class ("CSGenAd_branchUpdb")
		)
	)

     : (local.user_group
		:metadata (
			:module ("sgen")
			:class ("CSGenUser_groupUpdb")
		)
	)

     : (local.external_group
		:metadata (
			:module ("sgen")
			:class ("CSGenExternal_groupUpdb")
		)
	)

     : (local.any_object
		:metadata (
			:module ("sgen")
			:class ("CSGenAny_objectUpdb")
		)
	)

     : (local.global_preferences
		:metadata (
			:module ("sgen")
			:class ("CSGenGlobal_preferencesUpdb")
		)
	)

     : (local.cp_gateway_profile
		:metadata (
			:module ("sgen")
			:class ("CSGenCp_gateway_profileUpdb")
		)
	)

     : (local.lsm_gateway_profile
		:metadata (
			:module ("sgen")
			:class ("CSGenLsm_gateway_profileUpdb")
		)
	)

     : (local.cp_cluster_profile
		:metadata (
			:module ("sgen")
			:class ("CSGenCp_cluster_profileUpdb")
		)
	)

     : (local.cp_cluster_member_profile
		:metadata (
			:module ("sgen")
			:class ("CSGenCp_cluster_member_profileUpdb")
		)
	)

     : (local.gateway_general_properties
		:metadata (
			:module ("sgen")
			:class ("CSGenGateway_general_propertiesUpdb")
		)
	)

     : (local.mab_track
		:metadata (
			:module ("sgen")
			:class ("CSGenTrackUpdb")
		)
	)

     : (local.track
		:metadata (
			:module ("sgen")
			:class ("CSGenTrackUpdb")
		)
	)

     : (local.tcp_citrix_service
		:metadata (
			:module ("sgen")
			:class ("CSGenTcp_citrix_serviceUpdb")
		)
	)

     : (local.compound_tcp_service
		:metadata (
			:module ("sgen")
			:class ("CSGenCompound_tcp_serviceUpdb")
		)
	)

     : (local.gtp_service
		:metadata (
			:module ("sgen")
			:class ("CSGenGtp_serviceUpdb")
		)
	)

     : (local.gtp_v1_service
		:metadata (
			:module ("sgen")
			:class ("CSGenGtp_v1_serviceUpdb")
		)
	)

     : (local.gtp_mm_v0_service
		:metadata (
			:module ("sgen")
			:class ("CSGenGtp_mm_v0_serviceUpdb")
		)
	)

     : (local.gtp_mm_v1_service
		:metadata (
			:module ("sgen")
			:class ("CSGenGtp_mm_v1_serviceUpdb")
		)
	)

     : (local.gsn_handover_group
		:metadata (
			:module ("sgen")
			:class ("CSGenGsn_handover_groupUpdb")
		)
	)

     : (local.cifs_resource
		:metadata (
			:module ("sgen")
			:class ("CSGenCifs_resourceUpdb")
		)
	)

     : (local.uri_resource
		:metadata (
			:module ("sgen")
			:class ("CSGenUri_resourceUpdb")
		)
	)

     : (local.uri_qos_resource
		:metadata (
			:module ("sgen")
			:class ("CSGenUri_qos_resourceUpdb")
		)
	)

     : (local.ftp_resource
		:metadata (
			:module ("sgen")
			:class ("CSGenFtp_resourceUpdb")
		)
	)

     : (local.mms_resource
		:metadata (
			:module ("sgen")
			:class ("CSGenMms_resourceUpdb")
		)
	)

     : (local.smtp_resource
		:metadata (
			:module ("sgen")
			:class ("CSGenSmtp_resourceUpdb")
		)
	)

     : (local.tcp_resource
		:metadata (
			:module ("sgen")
			:class ("CSGenTcp_resourceUpdb")
		)
	)

     : (local.limit
		:metadata (
			:module ("sgen")
			:class ("CSGenLimitUpdb")
		)
	)

     : (local.rule
		:metadata (
			:module ("sgen")
			:class ("CSGenRuleUpdb")
		)
	)

     : (local.mab_rule
		:metadata (
			:module ("sgen")
			:class ("CSGenMab_ruleUpdb")
			:light (false)
		)
	)

     : (local.implied_rules
		:metadata (
			:module ("sgen")
			:class ("CSGenImplied_ruleUpdb")
			:force (true)
			:index (false)
			:light (false)
		)
	)

     : (local.rulebase
		:metadata (
			:module ("sgen")
			:class ("CSGenRulebaseUpdb")
		)
	)

     : (local.policy
		:metadata (
			:module ("sgen")
			:class ("CSGenPolicyUpdb")
		)
	)

     : (local.up_global_general_settings
		:metadata (
			:module ("sgen")
			:class ("CSGenUp_global_general_settingsUpdb")
			:skip (true)
		)
	)

     : (local.httpsi_dynobj
		:metadata (
			:module ("sgen")
			:class ("CSGenHttpsi_dynobjUpdb")
			:index (false)
			:light (false)
		)
	)

     : (local.encrypt_action
		:metadata (
			:module ("sgen")
			:class ("CSGenEncrypt_actionUpdb")
		)
	)

     : (local.client_encrypt_action
		:metadata (
			:module ("sgen")
			:class ("CSGenClient_encrypt_actionUpdb")
		)
	)

     : (local.client_auth_action
		:metadata (
			:module ("sgen")
			:class ("CSGenClient_auth_actionUpdb")
		)
	)

     : (local.user_auth_action
		:metadata (
			:module ("sgen")
			:class ("CSGenUser_auth_actionUpdb")
		)
	)

     : (local.time
		:metadata (
			:module ("sgen")
			:class ("CSGenTimeUpdb")
		)
	)

     : (local.scheduled_event
		:metadata (
			:module ("sgen")
			:class ("CSGenScheduled_eventUpdb")
		)
	)

     : (local.time_group
		:metadata (
			:module ("sgen")
			:class ("CSGenTime_groupUpdb")
		)
	)

     : (local.intranet_community
		:metadata (
			:module ("vgen")
			:class ("CVGenIntranet_communityUpdb")
			:skip (true)
		)
	)

     : (local.sr_community
		:metadata (
			:module ("vgen")
			:class ("CVGenSr_communityUpdb")
			:skip (true)
		)
	)

     : (local.vpn_directional_element
		:metadata (
			:module ("vgen")
			:class ("CVGenVpn_directional_elementUpdb")
			:skip (true)
		)
	)

)

#
# PA configuration file for the non-cpmi command line.
#
#
# Syntax (of complicated fields. The rest is obvious):
#
# SIMPLE-OID,    Name, OID, Type
#
# COLUMN,        Name, OID, Type, Index-order, Display, Display-Totals
#
# SUM-COLUMN,    Name, Display-Totlas, Column-Name-1, Column-Name-2, ....
#
# OUTPUT-FORMAT, "DEFAULT"/"LIST"    *If does not exist - assumed "DEFAULT"
#
# OID-BASE takes effect only within the section it is in.
#

START-BLOCK

        BLOCK-NAME, "mg"

        OID-BASE, 1.3.6.1.4.1.2620.1


        #################################################

        START-FLAVOUR

        FLAVOUR-NAME, "default"
		
	ADD-OID-ATOM, 1.25
		
               	SIMPLE-OID, robo_policy_name,  		1, STRING
                SIMPLE-OID, install_time, 		2, STRING
    
        REMOVE-OID-ATOM
	REMOVE-OID-ATOM
			
	ADD-OID-ATOM, 33


                SIMPLE-OID, last_received_settings_sig, 12, STRING
                SIMPLE-OID, last_applied_settings_sig,  13, STRING
                SIMPLE-OID, last_received_action_id,    14, STRING
                SIMPLE-OID, last_run_action_id,         15, STRING
                SIMPLE-OID, next_window_date,           16, UINT32
                SIMPLE-OID, last_sync_date,             17, UINT32
                SIMPLE-OID, next_sync_date,             18, UINT32
                SIMPLE-OID, pa_state,                   19, INT32
                SIMPLE-OID  settings_status,            20, INT32
                SIMPLE-OID, settings_error_message,     21, STRING

		
	REMOVE-OID-ATOM

        END-FLAVOUR


END-BLOCK
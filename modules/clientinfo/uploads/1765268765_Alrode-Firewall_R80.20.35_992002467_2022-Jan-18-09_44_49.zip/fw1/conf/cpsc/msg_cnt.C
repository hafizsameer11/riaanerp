(content
	: (en_us			# English
		: ("cpsc")
	)
)

#
# OS configuration file for the non-cpmi command line.
#
#
# Syntax (of complicated fields. The rest is obvious):
#
# SIMPLE-OID,    Name, OID, Type
#
# COLUMN,        Name, OID, Type, Index-order, Display, Display-Totals
#
# SUM-COLUMN,    Name, Display-Totlas, Column-Name-1, Column-Name-2, ....
#
# OUTPUT-FORMAT, "DEFAULT"/"LIST"    *If does not exist - assumed "DEFAULT"  
#
# OID-BASE takes effect only within the section it is in.
#

START-BLOCK

	BLOCK-NAME, "fw"

	OID-BASE, 1.3.6.1.4.1.2620.1

	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "fw"
				
		ADD-OID-ATOM, 1.25			
			SIMPLE-OID, "Packets dropped ", 16, UINT64, 1        
			SIMPLE-OID, "Peak number of connections", 4, UINT32, 0          
			SIMPLE-OID, "Number of connections", 3, UINT32, 0			
		
		REMOVE-OID-ATOM

	END-FLAVOUR
	
END-BLOCK

START-BLOCK

	BLOCK-NAME, "Accepted Data"

	OID-BASE, 1.3.6.1.4.1.2620.1

	#################################################
	

	START-FLAVOUR

		FLAVOUR-NAME, "accepted_data"

		ADD-OID-ATOM, 1.25
			SIMPLE-OID, "Packets accepted", 6, UINT64, 1
			SIMPLE-OID, "Bytes accepted", 8, UINT64, 1
		REMOVE-OID-ATOM

	END-FLAVOUR
	
END-BLOCK


START-BLOCK

	BLOCK-NAME, "service_count"

	OID-BASE, 1.3.6.1.4.1.2620.1

	#################################################
	

	START-FLAVOUR

		FLAVOUR-NAME, "service_count"

			ADD-OID-ATOM, 1.25
			ADD-OID-ATOM, 18

				START-TABLE

					START-TABLE-HEADER

						TABLE-NAME, "Service Count"
						TABLE-OID, 1
						PRINT-ONLY-TOTALS, FALSE
						OUTPUT-FORMAT, DEFAULT

					END-TABLE-HEADER

					COLUMN,    "Index",       	 1, UINT32, 	1, FALSE, 	FALSE 
					COLUMN,    "service index",   2, STRING, 	0, TRUE,  	FALSE
					COLUMN,    "service count",	 3, UINT32, 	0, TRUE, 		FALSE
					
				END-TABLE

			REMOVE-OID-ATOM
			REMOVE-OID-ATOM

	END-FLAVOUR
	
END-BLOCK

START-BLOCK

	BLOCK-NAME, "ips"

	OID-BASE, 1.3.6.1.4.1.2620.1

	#################################################


	START-FLAVOUR

		FLAVOUR-NAME, "ips"

			ADD-OID-ATOM, 1.25
			ADD-OID-ATOM, 19

				SIMPLE-OID, "Attacks Detected", 2, UINT32, 0

			REMOVE-OID-ATOM
			REMOVE-OID-ATOM

	END-FLAVOUR

END-BLOCK

START-BLOCK                                                                     
                                                                                
        BLOCK-NAME, "av"
		OID-BASE, 1.3.6.1.4.1.2620.1                                            
                                                                                
######################################################################          
                                                                                
        START-FLAVOUR                                                           

			FLAVOUR-NAME, "av"
			
			ADD-OID-ATOM, 24                                   
				
				# the next 2 lines are taken from a table, but it contains only one line, so we take the first line (oid is *.1)
				SIMPLE-OID, "Signature last updated", 1.1.7.1, UINT32, 0, 1
			REMOVE-OID-ATOM    # Removes the atom

			SIMPLE-OID, "Viruses detected",          1.26.9.10.1,  UINT32, 1


		END-FLAVOUR
END-BLOCK

START-BLOCK                                                                     
                                                                                
        BLOCK-NAME, "urlf"
		OID-BASE, 1.3.6.1.4.1.2620.1                                            
                                                                                
######################################################################          
                                                                                
        START-FLAVOUR                                                           

			FLAVOUR-NAME, "urlf"
				
			ADD-OID-ATOM, 29                                      
				SIMPLE-OID, "URLs blocked",    	 2.3, UINT32, 1
				SIMPLE-OID, "URLs scanned",     	2.2, UINT32, 1	
			REMOVE-OID-ATOM    # Removes the atom

		END-FLAVOUR
END-BLOCK

START-BLOCK                                                                     
                                                                                
        BLOCK-NAME, "vpn"
		OID-BASE, 1.3.6.1.4.1.2620.1                                            
                                                                                
######################################################################          
                                                                                
        START-FLAVOUR                                                           
                FLAVOUR-NAME, "vpn"                                    

             		ADD-OID-ATOM, 2                                                      
				SIMPLE-OID, "Total tunnels:",   5.2.1, 		UINT64, 0
				SIMPLE-OID, "Remote Access tunnels",   5.4.23, UINT64, 1
                           SIMPLE-OID, "Packets encrypted",   4.1.1, UINT64, 1
                           SIMPLE-OID, "Packets decrypted",   4.1.2, UINT64, 1
                 	REMOVE-OID-ATOM             # end of general statistics 
        END-FLAVOUR
END-BLOCK


START-BLOCK                                                                     
                                                                                
        BLOCK-NAME, "aspm"
		OID-BASE, 1.3.6.1.4.1.2620.1                                            
                                                                                
######################################################################          
                                                                                
        START-FLAVOUR                                                           

			FLAVOUR-NAME, "aspm"
				
			ADD-OID-ATOM, 30                                           
				SIMPLE-OID, "Emails scanned",  		 6.1, UINT32, 1			
				SIMPLE-OID, "Spam Emails found",  		 6.2, UINT32, 1
			REMOVE-OID-ATOM    # Removes the atom

		END-FLAVOUR
END-BLOCK


# Package number:

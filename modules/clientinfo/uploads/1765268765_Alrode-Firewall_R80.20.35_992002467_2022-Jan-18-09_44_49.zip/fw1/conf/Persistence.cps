#
# Persistency configuration file for the non-cpmi command line.
#
#
# Syntax (of complicated fields. The rest is obvious):
#
# SIMPLE-OID,    Name, OID, Type
#
# COLUMN,        Name, OID, Type, Index-order, Display, Display-Totals
#
# SUM-COLUMN,    Name, Display-Totlas, Column-Name-1, Column-Name-2, ....
#
# OUTPUT-FORMAT, "DEFAULT"/"LIST"    *If does not exist - assumed "DEFAULT"  
#
# OID-BASE takes effect only within the section it is in.
#

START-BLOCK

	BLOCK-NAME, "persistence"

	OID-BASE, 1.3.6.1.4.1.2620.1.14



	START-FLAVOUR

		FLAVOUR-NAME, "product"
	
		SIMPLE-OID, "Product",         	1, 	STRING
		SIMPLE-OID, "Version",         	10, 	STRING
		SIMPLE-OID, "Activation flag",    	20,	UINT16
		SIMPLE-OID, "Status Code",     	101, 	UINT32
		SIMPLE-OID, "Status state short",   102, 	STRING
		SIMPLE-OID, "Status state long",    103, 	STRING

	END-FLAVOUR

	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "TableConfig"

		START-TABLE

			START-TABLE-HEADER
			
				TABLE-NAME,        "Persistence tables"
				TABLE-OID,         30.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index dummy",   			1, UINT16,  1, FALSE,  FALSE 
			COLUMN,     "Index",    			2, UINT16,  0, TRUE,  FALSE 
			COLUMN,     "Target OID",       			3, STRING,  0, TRUE,  FALSE 
			COLUMN,     "Source OID",       			4, STRING,  0, TRUE,  FALSE 
			COLUMN,     "Display string", 			5, STRING,  0, TRUE,  FALSE
			COLUMN,     "Filter",        				6, STRING,  0, TRUE,  FALSE
			COLUMN,     "Number of samples",    		7, UINT32,  0, TRUE,  FALSE
			COLUMN,     "Polling interval",   			8, UINT32,  0, TRUE,  FALSE
			COLUMN,     "Period interval",   			9, UINT32,  0, TRUE,  FALSE
			COLUMN,     "Active flag"	,   			10, UINT16,  0, TRUE,  FALSE
			COLUMN,     "Table type (RTM=0,OID=1)", 	11, UINT16,  0, TRUE,  FALSE


		END-TABLE

	END-FLAVOUR


	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "SourceConfig"

		START-TABLE

			START-TABLE-HEADER
			
				TABLE-NAME,        "Persistence source table"
				TABLE-OID,         40.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Dummy Index",   		1, UINT16,  1, FALSE,  FALSE 
			COLUMN,     "Table index",       		2, UINT16,  0, TRUE,  FALSE 
			COLUMN,     "Target index",       	3, UINT16,  0, TRUE,  FALSE 
			COLUMN,     "Source OID", 		4, STRING,  0, TRUE,  FALSE
			COLUMN,     "Source display string",5, STRING,  0, TRUE,  FALSE
			COLUMN,     "Source type",		6, UINT16,  0, TRUE,  FALSE

		END-TABLE

	END-FLAVOUR


END-BLOCK

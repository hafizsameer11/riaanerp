(
	: (Custom_Application_Site
		:AdminInfo (
			:chkpf_uid ("{C2FDFA26-2FBC-456D-87F0-B92874485943}")
			:ClassName (appfw_property)
			:table (appfw_objects)
			:icon ("ApplicationFirewall/custom_category")
		)
		:category (user_defined)
		:color (black)
		:comments ()
		:cp_id (20000001)
		:description ()
		:display_name ("Custom Application/Site")
		:is_rad (false)
		:type (appfw_property)
	)
)

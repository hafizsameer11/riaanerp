CPDIR=/opt/fw1 ; export CPDIR
FWDIR=/opt/fw1 ; export FWDIR
CPAPACHEDIR=/opt/fw1/web/Apache/apache2 ; export CPAPACHEDIR
UCPORTALDIR_HOME=/opt/CPUserCheckPortal ; export UCPORTALDIR_HOME
export PATH=/usr/local/bin:/usr/bin:/bin:/pfrm2.0/bin:.:/usr/local/sbin:/usr/sbin:/sbin:$FWDIR/bin:/pfrm2.0/bin/cli
export LD_LIBRARY_PATH=.:/pfrm2.0/lib:/pfrm2.0/lib/iptables
if test -d $FWDIR/lib; then
	export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$FWDIR/lib
fi
hash 1>/dev/null 2>&1

if test -f /etc/setIdleTimeOut.sh; then
    . /etc/setIdleTimeOut.sh; export TMOUT;
    # /etc/setIdleTimeOut.sh shall contain single line 'export TMOUT=N'
fi

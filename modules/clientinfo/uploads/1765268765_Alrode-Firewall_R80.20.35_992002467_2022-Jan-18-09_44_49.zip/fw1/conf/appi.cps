#
# APPI configuration file for the non-cpmi command line.
#
#
# Syntax (of complicated fields. The rest is obvious):
#
# SIMPLE-OID,    Name, OID, Type
#
# COLUMN,        Name, OID, Type, Index-order, Display, Display-Totals
#
# SUM-COLUMN,    Name, Display-Totlas, Column-Name-1, Column-Name-2, ....
#
# OUTPUT-FORMAT, "DEFAULT"/"LIST"    *If does not exist - assumed "DEFAULT"  
#
# OID-BASE takes effect only within the section it is in.
#

START-BLOCK

	BLOCK-NAME, "APPI"

	OID-BASE, 1.3.6.1.4.1.2620.1.39

	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "default"

		SIMPLE-OID, "Status",               	  101, UINT32
		SIMPLE-OID, "Status short description",               	  102, STRING
		SIMPLE-OID, "Status long description",               	  103, STRING

	END-FLAVOUR
	
	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "subscription_status"
		
		ADD-OID-ATOM, 1

		SIMPLE-OID, "Subscription status",      1, STRING
		SIMPLE-OID, "Subscription expiration date",       2, STRING
		SIMPLE-OID, "Subscription description",      3, STRING
		
		REMOVE-OID-ATOM

	END-FLAVOUR
	
	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "update_status"
		
		ADD-OID-ATOM, 2

		SIMPLE-OID, "Update status",      1, STRING
		SIMPLE-OID, "Update description",       2, STRING
		SIMPLE-OID, "Next update description",      3, STRING
		SIMPLE-OID, "DB version",      4, STRING

		
		REMOVE-OID-ATOM

	END-FLAVOUR
	
	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "RAD_status"
		
		ADD-OID-ATOM, 3

		SIMPLE-OID, "RAD status",      1, UINT32
		SIMPLE-OID, "RAD status description",       2, STRING
		
		REMOVE-OID-ATOM

	END-FLAVOUR
	
	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "top_last_hour"

		REMOVE-OID-ATOM
		ADD-OID-ATOM, 41
		
		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Top applications by sessions (last hour)"
				TABLE-OID,         1.1.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Application ID",        2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     	    3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Bytes",     4, UINT64, 0, TRUE,  FALSE
		
		END-TABLE
		
		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Top applications by bandwidth (last hour)"
				TABLE-OID,         1.1.2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Application ID",        2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Bytes",     3, UINT64, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     	    4, UINT64, 0, TRUE,  FALSE
		
		END-TABLE
		
		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Top high-risk applications by sessions (last hour)"
				TABLE-OID,         1.1.3.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Application ID",        2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     	    3, UINT64, 0, TRUE,  FALSE
		
		END-TABLE
		
		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Top users by sessions (last hour) - APPI & URLF"
				TABLE-OID,         2.1.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "User",        2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",    3, UINT64,     0, TRUE,  FALSE
		
		END-TABLE
		
		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Top users by bandwidth (last hour) - APPI & URLF"
				TABLE-OID,         2.1.2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "User",        	    2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Bandwidth (bytes)",     3, UINT64, 0, TRUE,  FALSE
		
		END-TABLE

		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Top high-risk users by sessions (last hour)"
				TABLE-OID,         2.1.3.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Application ID",        2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     	    3, UINT64, 0, TRUE,  FALSE
		
		END-TABLE
		
		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Top categories by session (last hour) - APPI & URLF"
				TABLE-OID,         3.1.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Category",        	    2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     3, UINT64, 0, TRUE,  FALSE
		
		END-TABLE

		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Top categories by bandwidth (last hour) - APPI & URLF"
				TABLE-OID,         3.1.2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Category",        	    2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Bandwidth (bytes)",     3, UINT64, 0, TRUE,  FALSE
		
		END-TABLE

		
		REMOVE-OID-ATOM

	END-FLAVOUR
	
	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "top_last_day"

		REMOVE-OID-ATOM
		ADD-OID-ATOM, 41
		
		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Top application by sessions (last day)"
				TABLE-OID,         1.2.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Application ID",        2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     	    3, UINT64, 0, TRUE,  FALSE
		
		END-TABLE
		
		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Top application by bandwidth (last day)"
				TABLE-OID,         1.2.2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Application ID",        2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Bandwidth (bytes)",     3, UINT64, 0, TRUE,  FALSE
		
		END-TABLE
		
		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Top users by sessions (last day) - APPI & URLF"
				TABLE-OID,         2.2.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "User",        2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",    3, UINT64,     0, TRUE,  FALSE
		
		END-TABLE
		
		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Top users by bandwidth (last day) - APPI & URLF"
				TABLE-OID,         2.2.2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "User",        	    2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Bandwidth (bytes)",     3, UINT64, 0, TRUE,  FALSE
		
		END-TABLE

		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Top categories by session (last day) - APPI & URLF"
				TABLE-OID,         3.2.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Category",        	    2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     3, UINT64, 0, TRUE,  FALSE
		
		END-TABLE

		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Top categories by bandwidth (last day) - APPI & URLF"
				TABLE-OID,         3.2.2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Category",        	    2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Bandwidth (bytes)",     3, UINT64, 0, TRUE,  FALSE
		
		END-TABLE
		
		REMOVE-OID-ATOM

	END-FLAVOUR
	
	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "top_last_week"

		REMOVE-OID-ATOM
		ADD-OID-ATOM, 41
		
		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Top application by sessions (last week)"
				TABLE-OID,         1.3.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Application ID",        2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     	    3, UINT64, 0, TRUE,  FALSE
		
		END-TABLE
		
		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Top application by bandwidth (last week)"
				TABLE-OID,         1.3.2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Application ID",        2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Bandwidth (bytes)",     3, UINT64, 0, TRUE,  FALSE
		
		END-TABLE
		
		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Top users by sessions (last week) - APPI & URLF"
				TABLE-OID,         2.3.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "User",        2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",    3, UINT64,     0, TRUE,  FALSE
		
		END-TABLE
		
		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Top users by bandwidth (last week) - APPI & URLF"
				TABLE-OID,         2.3.2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "User",        	    2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Bandwidth (bytes)",     3, UINT64, 0, TRUE,  FALSE
		
		END-TABLE

		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Top categories by session (last week) - APPI & URLF"
				TABLE-OID,         3.3.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Category",        	    2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     3, UINT64, 0, TRUE,  FALSE
		
		END-TABLE

		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Top categories by bandwidth (last week) - APPI & URLF"
				TABLE-OID,         3.3.2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Category",        	    2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Bandwidth (bytes)",     3, UINT64, 0, TRUE,  FALSE
		
		END-TABLE
		
		REMOVE-OID-ATOM

	END-FLAVOUR
	
	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "top_last_month"

		REMOVE-OID-ATOM
		ADD-OID-ATOM, 41
		
		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Top application by sessions (last month)"
				TABLE-OID,         1.4.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Application ID",        2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     	    3, UINT64, 0, TRUE,  FALSE
		
		END-TABLE
		
		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Top application by bandwidth (last month)"
				TABLE-OID,         1.4.2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Application ID",        2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Bandwidth (bytes)",     3, UINT64, 0, TRUE,  FALSE
		
		END-TABLE
		
		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Top users by sessions (last month) - APPI & URLF"
				TABLE-OID,         2.4.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "User",        2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",    3, UINT64,     0, TRUE,  FALSE
		
		END-TABLE
		
		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Top users by bandwidth (last month) - APPI & URLF"
				TABLE-OID,         2.4.2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "User",        	    2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Bandwidth (bytes)",     3, UINT64, 0, TRUE,  FALSE
		
		END-TABLE

		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Top categories by session (last month) - APPI & URLF"
				TABLE-OID,         3.4.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Category",        	    2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",     3, UINT64, 0, TRUE,  FALSE
		
		END-TABLE

		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Top categories by bandwidth (last month) - APPI & URLF"
				TABLE-OID,         3.4.2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Category",        	    2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Bandwidth (bytes)",     3, UINT64, 0, TRUE,  FALSE
		
		END-TABLE
		
		REMOVE-OID-ATOM

	END-FLAVOUR

END-BLOCK

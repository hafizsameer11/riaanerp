#
# FW configuration file for the non-cpmi command line.
#
#
# Syntax (of complicated fields. The rest is obvious):
#
# SIMPLE-OID,    Name, OID, Type
#
# COLUMN,        Name, OID, Type, Index-order, Display, Display-Totals
#
# SUM-COLUMN,    Name, Display-Totlas, Column-Name-1, Column-Name-2, ....
#
# OUTPUT-FORMAT, "DEFAULT"/"LIST"    *If does not exist - assumed "DEFAULT"  
#
# OID-BASE takes effect only within the section it is in.
#


START-BLOCK

	BLOCK-NAME, "CI"

	OID-BASE, 1.3.6.1.4.1.2620.1

######################################################################

	START-FLAVOUR
		FLAVOUR-NAME, "default"

		ADD-OID-ATOM, 24
			SIMPLE-OID, "AV Stat code",  101, UINT32
			SIMPLE-OID, "AV Short Desc", 102, STRING
			SIMPLE-OID, "AV Long Desc",  103, STRING

			START-TABLE
				START-TABLE-HEADER
					TABLE-NAME,        "AV Engine table"
					TABLE-OID,         1.1
					PRINT-ONLY-TOTALS, FALSE
					OUTPUT-FORMAT,     DEFAULT
				END-TABLE-HEADER
				COLUMN,     "Index",       1, UINT32, 1, FALSE, FALSE 
				COLUMN,     "name",        2, STRING, 0, TRUE,  FALSE
				COLUMN,     "ver",         3, STRING, 0, TRUE,  FALSE
				COLUMN,     "date",        4, UINT32, 0, TRUE,  FALSE
				COLUMN,     "sig name",    5, STRING, 0, TRUE,  FALSE
				COLUMN,     "sig ver",     6, STRING, 0, TRUE,  FALSE
				COLUMN,     "sig date",    7, UINT32, 0, TRUE,  FALSE
				COLUMN,     "check time",  8, UINT32, 0, TRUE,  FALSE
				COLUMN,     "sig loc",     9, STRING, 0, TRUE,  FALSE
				COLUMN,     "subs exp",   10, STRING, 0, TRUE,  FALSE
			END-TABLE
			
			START-TABLE
				START-TABLE-HEADER
					TABLE-NAME,        "top ever viruses"
					TABLE-OID,         3.1
					PRINT-ONLY-TOTALS, FALSE
					OUTPUT-FORMAT,     DEFAULT
				END-TABLE-HEADER
				COLUMN,     "Index",       1, UINT32, 1, FALSE, FALSE 
				COLUMN,     "Name",        2, STRING, 0, TRUE,  FALSE
				COLUMN,     "Count ",      3, UINT32, 0, TRUE,  FALSE
			END-TABLE
		REMOVE-OID-ATOM    # Removes the atom

		
		ADD-OID-ATOM, 29
			SIMPLE-OID, "UF Stat code",  101, UINT32
			SIMPLE-OID, "UF Short Desc", 102, STRING
			SIMPLE-OID, "UF Long Desc",  103, STRING

			SIMPLE-OID, "engine_name",          1.1, STRING
			SIMPLE-OID, "engine_ver",           1.2, STRING
			SIMPLE-OID, "engine_date",          1.3, UINT32
			SIMPLE-OID, "signature_date",       1.4, UINT32
			SIMPLE-OID, "signature_ver",        1.5, STRING
			SIMPLE-OID, "last_sig_check_time",  1.6, UINT32
			SIMPLE-OID, "last_sig_location",    1.7, STRING
			SIMPLE-OID, "lic_exp",              1.8, STRING

			SIMPLE-OID, "monitor mode",         2.1, STRING
			SIMPLE-OID, "scanned",              2.2, UINT32
			SIMPLE-OID, "blocked",              2.3, UINT32

			START-TABLE
				START-TABLE-HEADER
					TABLE-NAME,        "top blocked categories"
					TABLE-OID,         2.4.1
					PRINT-ONLY-TOTALS, FALSE
					OUTPUT-FORMAT,     DEFAULT
				END-TABLE-HEADER
				COLUMN,     "Index",       1, UINT32, 1, FALSE, FALSE 
				COLUMN,     "Category",    2, STRING, 0, TRUE,  FALSE
				COLUMN,     "Count ",      3, UINT32, 0, TRUE,  FALSE
			END-TABLE

			START-TABLE
				START-TABLE-HEADER
					TABLE-NAME,        "top blocked sites"
					TABLE-OID,         2.5.1
					PRINT-ONLY-TOTALS, FALSE
					OUTPUT-FORMAT,     DEFAULT
				END-TABLE-HEADER
				COLUMN,     "Index",       1, UINT32, 1, FALSE, FALSE 
				COLUMN,     "Site",        2, STRING, 0, TRUE,  FALSE
				COLUMN,     "Count ",      3, UINT32, 0, TRUE,  FALSE
			END-TABLE

			START-TABLE
				START-TABLE-HEADER
					TABLE-NAME,        "top blocked sources"
					TABLE-OID,         2.6.1
					PRINT-ONLY-TOTALS, FALSE
					OUTPUT-FORMAT,     DEFAULT
				END-TABLE-HEADER
				COLUMN,     "Index",       1, UINT32, 1, FALSE, FALSE 
				COLUMN,     "Source",      2, STRING, 0, TRUE,  FALSE
				COLUMN,     "Count ",      3, UINT32, 0, TRUE,  FALSE
			END-TABLE
		REMOVE-OID-ATOM    # Removes the atom

		ADD-OID-ATOM, 1.26.9
			SIMPLE-OID, "HTTP blocked by UF cat",     1.54, UINT32
			SIMPLE-OID, "HTTP blocked by UF list",    1.55, UINT32
			SIMPLE-OID, "HTTP blocked by AV",         1.39, UINT32
			SIMPLE-OID, "HTTP blocked by File-Type",  1.42, UINT32
			SIMPLE-OID, "HTTP blocked by AV settings",1.52, UINT32
			SIMPLE-OID, "HTTP blocked total",         1.40, UINT32
			SIMPLE-OID, "HTTP passed by UF list",     1.56, UINT32
			SIMPLE-OID, "HTTP passed by AV",          1.46, UINT32
			SIMPLE-OID, "HTTP passed by File Type",   1.47, UINT32
			SIMPLE-OID, "HTTP passed by AV settings", 1.53, UINT32
			SIMPLE-OID, "HTTP passed total",          1.51, UINT32
			SIMPLE-OID, "HTTP scanned total",         1.41, UINT32

			SIMPLE-OID, "FTP blocked by AV",         2.24, UINT32
			SIMPLE-OID, "FTP blocked by File-Type",  2.27, UINT32
			SIMPLE-OID, "FTP blocked by AV settings",2.37, UINT32
			SIMPLE-OID, "FTP blocked total",         2.25, UINT32
			SIMPLE-OID, "FTP passed by AV",          2.31, UINT32
			SIMPLE-OID, "FTP passed by File Type",   2.32, UINT32
			SIMPLE-OID, "FTP passed by AV settings", 2.38, UINT32
			SIMPLE-OID, "FTP passed total",          2.36, UINT32
			SIMPLE-OID, "FTP scanned total",         2.26, UINT32

			SIMPLE-OID, "SMTP blocked by AV",         6.28, UINT32
			SIMPLE-OID, "SMTP blocked by File-Type",  6.31, UINT32
			SIMPLE-OID, "SMTP blocked by AV settings",6.41, UINT32
			SIMPLE-OID, "SMTP blocked total",         6.29, UINT32
			SIMPLE-OID, "SMTP passed by AV",          6.35, UINT32
			SIMPLE-OID, "SMTP passed by File Type",   6.36, UINT32
			SIMPLE-OID, "SMTP passed by AV settings", 6.42, UINT32
			SIMPLE-OID, "SMTP passed total",          6.40, UINT32
			SIMPLE-OID, "SMTP scanned total",         6.30, UINT32

			SIMPLE-OID, "POP3 blocked by AV",         7.28, UINT32
			SIMPLE-OID, "POP3 blocked by File-Type",  7.31, UINT32
			SIMPLE-OID, "POP3 blocked by AV settings",7.41, UINT32
			SIMPLE-OID, "POP3 blocked total",         7.29, UINT32
			SIMPLE-OID, "POP3 passed by AV",          7.35, UINT32
			SIMPLE-OID, "POP3 passed by File Type",   7.36, UINT32
			SIMPLE-OID, "POP3 passed by AV settings", 7.42, UINT32
			SIMPLE-OID, "POP3 passed total",          7.40, UINT32
			SIMPLE-OID, "POP3 scanned total",         7.30, UINT32

			SIMPLE-OID, "TOTAL blocked by AV",         10.1,  UINT32
			SIMPLE-OID, "TOTAL blocked by File-Type",  10.4,  UINT32
			SIMPLE-OID, "TOTAL blocked by AV settings",10.14, UINT32
			SIMPLE-OID, "TOTAL blocked total",         10.2,  UINT32
			SIMPLE-OID, "TOTAL passed by AV",          10.8,  UINT32
			SIMPLE-OID, "TOTAL passed by File Type",   10.9,  UINT32
			SIMPLE-OID, "TOTAL passed by AV settings", 10.15, UINT32
			SIMPLE-OID, "TOTAL passed total",          10.13, UINT32
			SIMPLE-OID, "TOTAL scanned total",         10.3,  UINT32
		REMOVE-OID-ATOM    # Removes the atom

	END-FLAVOUR

######################################################################
END-BLOCK

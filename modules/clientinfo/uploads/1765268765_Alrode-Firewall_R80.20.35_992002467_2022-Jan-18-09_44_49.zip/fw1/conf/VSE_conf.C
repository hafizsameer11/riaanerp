(VSE_CONF
	: (producers
		: (
			:producer (rad_tp)
			:server ("fw,6465,0x4edab68")
			:timestamp (1642409736)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,6465,0x4edab68")
			:timestamp (1642409737)
		)
		: (
			:producer (rad_tp)
			:server ("fw,5939,0x53f1b98")
			:timestamp (1642411127)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,5939,0x53f1b98")
			:timestamp (1642411128)
		)
		: (
			:producer (rad_tp)
			:server ("fw,5957,0x52de698")
			:timestamp (1642487872)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,5957,0x52de698")
			:timestamp (1642487872)
		)
	)
)

#### Auto Generated file. Use script /pfrm2.0/bin/properties_edit.sh to edit its content ####
isPreUpgradePolicyNonDefault="true"
isPreUpgradePolicyNameLocal="false"

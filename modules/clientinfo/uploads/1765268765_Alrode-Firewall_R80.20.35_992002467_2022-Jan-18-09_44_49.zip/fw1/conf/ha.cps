#
# HA configuration file for the non-cpmi command line.
#
#
# Syntax (of complicated fields. The rest is obvious):
#
# SIMPLE-OID,    Name, OID, Type
#
# COLUMN,        Name, OID, Type, Index-order, Display, Display-Totals
#
# SUM-COLUMN,    Name, Display-Totlas, Column-Name-1, Column-Name-2, ....
#
# OUTPUT-FORMAT, "DEFAULT"/"LIST"    *If does not exist - assumed "DEFAULT"  
#
# OID-BASE takes effect only within the section it is in.
#

START-BLOCK

	BLOCK-NAME, "ha"

	OID-BASE, 1.3.6.1.4.1.2620.1.5

	START-FLAVOUR

		FLAVOUR-NAME, "default"

		SIMPLE-OID, "Product name",     1, STRING
		SIMPLE-OID, "Version",         14, STRING
		SIMPLE-OID, "Status",         102, STRING
		SIMPLE-OID, "HA installed",     2, UINT16
		SIMPLE-OID, "Working mode",    11, STRING
		SIMPLE-OID, "HA started",       5, STRING

	END-FLAVOUR

	START-FLAVOUR

		FLAVOUR-NAME, "all"

		SIMPLE-OID, "Product name",              1, STRING
		SIMPLE-OID, "Major version",             3, UINT16
		SIMPLE-OID, "Minor version",             4, UINT16
		SIMPLE-OID, "Service pack",            104, UINT16
		SIMPLE-OID, "Version string",           14, STRING
		SIMPLE-OID, "Status code",             101, UINT16
		SIMPLE-OID, "Status short",            102, STRING
		SIMPLE-OID, "Status long",             103, STRING
		SIMPLE-OID, "HA installed",              2, UINT16
		SIMPLE-OID, "Working mode",             11, STRING
		SIMPLE-OID, "HA protocol version",      10, UINT16
		SIMPLE-OID, "HA started",                5, STRING
		SIMPLE-OID, "HA state",                  6, STRING
		SIMPLE-OID, "HA identifier",             8, UINT16

		START-TABLE

			START-TABLE-HEADER
				
				TABLE-NAME,        "Interface table"
				TABLE-OID,         12.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN, "Index",       	1, UINT32, 1, FALSE, FALSE 
			COLUMN, "Name",        	2, STRING, 0, TRUE,  FALSE
			COLUMN, "IP",          	3, IP,     0, TRUE,  FALSE
			COLUMN, "Status",      	4, STRING, 0, TRUE,  FALSE
			COLUMN, "Verified",    	5, UINT32, 0, TRUE,  FALSE
			COLUMN, "Trusted",     	6, UINT16, 0, TRUE,  FALSE
			COLUMN, "Shared",      	7, UINT16, 0, TRUE,  FALSE
			COLUMN, "Netmask",     	8, IP,     0, TRUE,  FALSE

			
		END-TABLE

		START-TABLE

			START-TABLE-HEADER
				
				TABLE-NAME,        "Problem Notification table"
				TABLE-OID,         13.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN, "Index",       	1, UINT32, 1, FALSE, FALSE 
			COLUMN, "Name",        	2, STRING, 0, TRUE,  FALSE
			COLUMN, "Status",      	3, STRING, 0, TRUE,  FALSE
			COLUMN, "Priority",    	4, UINT16, 0, TRUE,  FALSE
			COLUMN, "Verified",    	5, UINT32, 0, TRUE,  FALSE
			COLUMN, "Descr",       	6, STRING, 0, TRUE,  FALSE
			
		END-TABLE

		START-TABLE

			START-TABLE-HEADER
				
				TABLE-NAME,        "Cluster IPs table"
				TABLE-OID,         15.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN, "Index",       		1, UINT32, 1, FALSE, FALSE 
			COLUMN, "Name",        		2, STRING, 0, TRUE,  FALSE
			COLUMN, "IP",      			3, IP,     0, TRUE,  FALSE
			COLUMN, "Netmask",    		4, IP,     0, TRUE,  FALSE
			COLUMN, "Member Network",  	5, IP,     0, TRUE,  FALSE
			COLUMN, "Member Netmask", 	6, IP,     0, TRUE,  FALSE
			
		END-TABLE

		START-TABLE

			START-TABLE-HEADER
				
				TABLE-NAME,        "Sync table"
				TABLE-OID,         16.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN, "Index",       		1, UINT32, 1, FALSE, FALSE 
			COLUMN, "Name",        		2, STRING, 0, TRUE,  FALSE
			COLUMN, "IP",      			3, IP,     0, TRUE,  FALSE
			COLUMN, "Netmask",    		4, IP,     0, TRUE,  FALSE
			
		END-TABLE

	END-FLAVOUR

END-BLOCK

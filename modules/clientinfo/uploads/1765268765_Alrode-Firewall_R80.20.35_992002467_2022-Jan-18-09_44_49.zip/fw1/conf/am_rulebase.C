(
	: (IPS
		:AdminInfo (
			:chkpf_uid ("{C21E051C-4A0E-4E1A-83A4-F4E1AECB1FF8}")
			:ClassName (anti_malware_rulebase)
			:global_level (0)
			:table (anti_malware_rulebases)
			:LastModified (
				:Time ()
				:last_modified_utc (0)
				:By ()
				:From (localhost)
			)
			:name (IPS)
		)
		:custom_fields ()
		:rulebase (
			:AdminInfo (
				:chkpf_uid ("{C21E051C-4A0E-4E1A-83A4-F4E1AECB1FF8}")
				:ClassName (anti_malware_rulebase_object)
				:global_level (0)
			)
			:uid ("{c21e051c-4a0e-4e1a-83a4-f4e1aecb1ff8}")
			:num_format ("%d")
		)
		:rule ()
		:sections (
			: (
				:AdminInfo (
					:chkpf_uid ("{F633856C-B5F6-45F6-99C6-C45C395C66F0}")
					:ClassName (anti_malware_rulebase_section)
					:global_level (0)
				)
				:entity_name ()
				:rulebase_name ()
				:is_shared (false)
				:parent_section ("{c21e051c-4a0e-4e1a-83a4-f4e1aecb1ff8}")
				:num_rules_this_section (0)
			)
		)
	)
	: (Vb267f23c-ff59-4062-923f-605c371d15d3
		:AdminInfo (
			:chkpf_uid ("{B267F23C-FF59-4062-923F-605C371D15D3}")
			:ClassName (anti_malware_rulebase)
			:global_level (0)
			:table (anti_malware_rulebases)
			:LastModified (
				:Time ()
				:last_modified_utc (0)
				:By ()
				:From (localhost)
			)
			:name ("Standard Threat Prevention")
		)
		:custom_fields ()
		:rulebase (
			:AdminInfo (
				:chkpf_uid ("{B267F23C-FF59-4062-923F-605C371D15D3}")
				:ClassName (anti_malware_rulebase_object)
				:global_level (0)
			)
			:uid ("{b267f23c-ff59-4062-923f-605c371d15d3}")
			:num_format ("%d")
		)
		:rule (
			:0 (
				:AdminInfo (
					:chkpf_uid ("{38AA1A71-9BB4-4A14-BC35-B138262A707D}")
					:ClassName (anti_malware_rulebase_rule)
					:global_level (0)
				)
				:rule_type (REGULAR)
				:parent_section ("{f0b5179e-1813-4b75-9fbd-134e16553ee5}")
				:rule_number (1)
				:rule_number_formatted (1)
				:entity_name ()
				:enable_event_app (false)
				:rule_name ()
				:am_action (ReferenceObject
					:Uid ("{781AB460-F0D8-4BFB-B83D-E6754A93FBD6}")
					:Name ("Optimized (Clone)")
					:Table (am_profiles)
				)
				:action (ReferenceObject
					:Uid ("{C32A540A-D96C-4283-BB86-BDBB05D83734}")
					:Name (Allow)
					:Table (rulebase_actions)
				)
				:disabled (false)
				:ips_action ()
				:Exceptions (ReferenceObject
					:Uid ("{62499F2D-95A1-4AA5-9EEB-0721B3881603}")
					:Name (ThreatStandardSubRulebase)
					:Table (NO_CPMI_TABLE)
				)
				:enable_packet_capture (true)
				:track (ReferenceObject
					:Uid ("{6057E8D5-5185-453B-A416-4029C8ECA6D0}")
					:Name (Log)
					:Table (rulebase_tracks)
				)
				:num_for_audit ()
				:protection (
					:AdminInfo (
						:chkpf_uid ("{5005FBFE-A76D-4B93-9615-89E7C7B7A264}")
						:ClassName (armada_protection_field_not_relevant_t)
						:global_level (0)
					)
					:ReferenceObject (
						: (ReferenceObject
							:Uid ("{A478A9E4-18FC-4204-AD0D-58EC143A5CE6}")
							:Name (not_applicable)
							:Table (globals)
						)
					)
				)
				:dst (
					:AdminInfo (
						:chkpf_uid ("{63E897CD-9714-4868-83D5-74803197230B}")
						:ClassName (anti_malware_dst_field_t)
						:global_level (0)
					)
					:op (false)
					:ReferenceObject (
						: (ReferenceObject
							:Uid ("{97AEB369-9AEA-11D5-BD16-0090272CCB30}")
							:Name (Any)
							:Table (globals)
						)
					)
				)
				:src (
					:AdminInfo (
						:chkpf_uid ("{141EC96D-D2FB-400C-A23B-F37DA70E39F7}")
						:ClassName (anti_malware_src_field_t)
						:global_level (0)
					)
					:op (false)
					:ReferenceObject (
						: (ReferenceObject
							:Uid ("{97AEB369-9AEA-11D5-BD16-0090272CCB30}")
							:Name (Any)
							:Table (globals)
						)
					)
				)
				:services (
					:AdminInfo (
						:chkpf_uid ("{32F8E440-F001-44FC-9DCC-A69E8B94954D}")
						:ClassName (armada_service_field_t)
						:global_level (0)
					)
					:op (false)
					:ReferenceObject (
						: (ReferenceObject
							:Uid ("{97AEB369-9AEA-11D5-BD16-0090272CCB30}")
							:Name (Any)
							:Table (globals)
						)
					)
				)
				:scope (
					:AdminInfo (
						:chkpf_uid ("{C096055D-1ECB-4851-8C47-A8B2D650D6B9}")
						:ClassName (anti_malware_scope_field_t)
						:global_level (0)
					)
					:op (false)
					:ReferenceObject (
						: (ReferenceObject
							:Uid ("{97AEB369-9AEA-11D5-BD16-0090272CCB30}")
							:Name (Any)
							:Table (globals)
						)
					)
				)
				:identity_settings (
					:AdminInfo (
						:chkpf_uid ("{597D04EA-7AFC-406C-B0C4-B6AEAA80F0CB}")
						:ClassName (identity_action_settings)
						:global_level (0)
					)
					:type (identity_action_settings)
					:allow_identity_agent (true)
					:require_packet_tagging (false)
					:allow_ad_query (true)
					:allow_captive_portal (true)
					:allowed_sources ("All Sources")
					:redirect_to_captive_portal (false)
				)
				:install (
					: (ReferenceObject
						:Uid ("{97AEB368-9AEA-11D5-BD16-0090272CCB30}")
						:Name (All)
						:Table (globals)
					)
				)
				:performance_optimized (false)
			)
		)
		:sections (
			: (
				:AdminInfo (
					:chkpf_uid ("{F0B5179E-1813-4B75-9FBD-134E16553EE5}")
					:ClassName (anti_malware_rulebase_section)
					:global_level (0)
				)
				:entity_name ()
				:rulebase_name ()
				:is_shared (false)
				:parent_section ("{b267f23c-ff59-4062-923f-605c371d15d3}")
				:num_rules_this_section (0)
			)
		)
		:orig_invalid_name ("Standard Threat Prevention")
	)
)

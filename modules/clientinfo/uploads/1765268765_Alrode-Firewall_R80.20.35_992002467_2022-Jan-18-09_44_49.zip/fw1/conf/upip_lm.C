(
	:manifest ("manifest.C")
	:implicit_rule ("implicit_rule_lm.conv")
	:fileslist (
		: (
			:name ("fileslist.conv")
			:mode ("mandatory")
			:light (true)
		)
	)
)

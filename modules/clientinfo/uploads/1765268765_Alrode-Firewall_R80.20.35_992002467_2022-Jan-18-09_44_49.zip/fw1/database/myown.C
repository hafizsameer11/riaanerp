(
	:name (myown_obj)
	:uuid (a3fc91bb-1046-e741-8319-633a981e7996)
)

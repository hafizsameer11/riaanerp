#ifndef	__UPIS_TABLE_IDS_H__
#define	__UPIS_TABLE_IDS_H__

#ifndef __INSPECT__
#include <kerntabs_ranges.h>
#endif

#define UP_TABLES_LIGHT_NTABS 5000 /* number of IDs reserved for light install policy tables */
#define UP_TABLES_FULL_NTABS 1000 /* number of IDs reserved for full-only install policy tables */
#define UP_TABLES_STATIC_NTABS 100 /* number of IDs reserved for static tables (e.g. rpc_prog_nums) */

/*
	This MACRO defines from where UP tables, that are created during install policy and have dynamic IDs will be created from
*/
#define UP_TABLES_DYNAMIC_ID_START 	(UP_TABLES_LOW_ID + UP_TABLES_STATIC_NTABS)

/* 
   Add here the static IDs in use, which are created during install policy (for static tables)
   The static IDs range is [UP_TABLES_LOW_ID, UP_TABLES_DYNAMIC_ID_START-1] 
 */

#define UP_RB_SIP_SERVICE_ON 1
#define UP_RB_MGCP_SERVICE_ON 2
#define UP_RB_DELAYED_NOTIFY_ON 3
#define UP_RB_URLLOG_QUICKUFP_ON 4
#define UP_RB_CIFS_RESOURCE_ON 5



#define RPC_PROG_NUMS_TABLE_ID 9001
#define RPC_PROG_NUMS_TABLE_NAME	"rpc_prog_nums"

#define UP_RB_INSPECT_SUPPORT_TABLE_ID 9002
#define UP_RB_INSPECT_SUPPORT_TABLE_NAME	"up_rb_inspect_support"


#endif /* __UPIS_TABLE_IDS_H__ */


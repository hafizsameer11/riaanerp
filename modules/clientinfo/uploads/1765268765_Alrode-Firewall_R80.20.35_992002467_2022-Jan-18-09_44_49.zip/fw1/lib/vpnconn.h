#ifndef __h_vpnconn__
#define __h_vpnconn__

/*
 * (c) Copyright 1993-2005 Check Point Software Technologies Ltd.
 * All rights reserved.
 * 
 * This is proprietary information of Check Point Software Technologies
 * Ltd., which is provided for informational purposes only and for use
 * solely in conjunction with the authorized use of Check Point Software
 * Technologies Ltd. products.  The viewing and use of this information is
 * subject, to the extent appropriate, to the terms and conditions of the
 * license agreement that authorizes the use of the relevant product.
 */

/*
 * the partition of the r_ctype 32 bit field :
 * 
 * 01234567    01234567 0123    4567    0123     456    7
 * >      <    >           <    >  <    >  <     >  <  >  <
 *  ip comp         fw   	    match    exm     is		type
 *   args          bits  	    values   bits   comm.  values
 *
 */

#define CONN_NO_ENTRY				(0)
#define CONN_NOENC					(1)
#define CONN_ENC_NO_ENTRY			(2)
#define CONN_ENC_NO_ENTRY_SR		(5)	/*	SR server only */
#define CONN_ENCRYPTED				(6)

/* For backwards compatibility */
#define CONN_ENC_A					(3)
#define CONN_ENC_B					(4)

/*
 * For the new community-tagging mechanism.
 * (we use the values of CONN_ENC_A and CONN_ENC_B which are 
 * not used anymore).
 */
#define CONN_ENC_CLIENT				(3)	/* client side completed */
#define CONN_ENC_SERVER				(7)
#define CONN_ENC_DATA				(4) /* data connection - pending */

#define MATCH_BY_PROTOCOL	(0)
#define MATCH_BY_OFFSET		(1)
#define MATCH_BY_RPC		(2)
#define MATCH_BY_GETPORT	(3)
#define MATCH_BY_CALLIT		(4)
#define MATCH_BY_SEQACK_CHG	(5)

#define OFFICE_MODE_NO_NAT (8)

/*
 * MAKE_VPN_ENTRY is kept for backward compatibility of the API -
 * Note that arg is no longer used, and that it does not include the
 * exm and ip comp fields.
 */
#define	MAKE_VPN_ENTRY(type,match,arg)	((type) | ((match) << 8))
#define	ENTRY_TYPE(entry)			((entry) & 0x07)
#define	IS_COMMUNITY(entry)			(((entry) & 0x8) >> 3)
#define ENTRY_MATCH(entry)			(((entry) >>  8) & 0xf)
#define ENTRY_IPCOMP(entry)			((entry) >> 24)
#define CHANGE_TYPE(entry,type)		(((entry) & 0xfffffff8) | (type))
#define CHANGE_MATCH(entry,match)   (((entry) & 0xfffff0ff) | ((match) <<  8))
#define CHANGE_IPCOMP(entry,ipcomp) (((entry) & 0x00ffffff) | ((ipcomp) << 24))
#define ADD_TYPE(entry,type)		((entry) | (type))
#define ADD_MATCH(entry,match)      ((entry) | ((match) <<  8))
#define ADD_IPCOMP(entry,ipcomp)    ((entry) | ((ipcomp) << 24))
#define REMOVE_TYPE(entry,type)		((entry) & ~(type))
#define REMOVE_MATCH(entry,match)   ((entry) & ~((match) <<  8))
#define REMOVE_IPCOMP(entry,ipcomp) ((entry) & ~((ipcomp) << 24))

#define ALL_COMMUNITIES_INDEX			0xffffffff
#define COMM_MY_ENC_DOAMIN				0xfffffffe
#define COMM_NOT_IN_ANY_COMMUNITY		0xfffffffd

/* community for vpn_rulematch for SR rules                                       */
/* meaning: any community and anything that is not a community at all */
#define COMM_ANY                        0xfffffffb
#define COMM_ALL_GWS_COMMUNITIES        0xfffffffa
#define COMM_ALL_COMMUNITIES            0xfffffff9

/*
 * Interfaces groups objects
 * Assumption: 
 * Interfaces group objects begin with 0xffff.... 
 * (required by the macros to set/get them in the vpn opaque)
 */
#define INTERNAL_INTERFACES				0xfffffff8
#define EXTERNAL_INTERFACES				0xfffffff7

#define DEFAULT_RA_COMMUNITY				0x00000002
/* Connectra RA community is created in the conversion for supporting Connectra on VPN-1 gateway */
#define DEFAULT_CONNECTRA_RA_COMMUNITY	0x00000003

/* vpn_rulematch table constants */
#define VPN_RULEMATCH_CHECK_USER_SRC  1
#define VPN_RULEMATCH_CHECK_USER_DST  2
#define VPN_RULEMATCH_CHECK_USER_BOTH (VPN_RULEMATCH_CHECK_USER_SRC | VPN_RULEMATCH_CHECK_USER_DST)
#define VPN_RULEMATCH_NKEYS           3

/* rule_info */

#define CLIENT_SIDE_ANY					0x00000001
#define CLIENT_SIDE_IFS					0x00000002
#define SERVER_SIDE_ANY					0x00000004
#define SERVER_SIDE_IFS					0x00000008

/*userc_rules  RELEVANT_IN_FIELD values - these are important for inspect*/
#define USERC_RULES_REL_FIELD_VALUE_NO_VALUE        (0)
#define USERC_RULES_REL_FIELD_VALUE_SRC             (1)
#define USERC_RULES_REL_FIELD_VALUE_DST             (2)
#define USERC_RULES_REL_FIELD_VALUE_BOTH            (3)

#define	SHIFT_COMMUNITY_CLIENT(id)		((id) >>16)
#define	SHIFT_COMMUNITY_SERVER(id)		((id) & 0x0000ffff)

#define DEFAULT_ROUTER_FLAG				0x00000100
#define CONDITIONAL_ROUTING_FLAG		0x00000200
#define MULTICAST_LISTENER_FLAG			0x00000400
#define MULTICAST_SENDER_FLAG			0x00000800
#define LSV_ROUTING_FLAG				0x00001000


#define GW_CONF_MASK						0x000000ff
#define GW_CONF(flags)						(flags & GW_CONF_MASK)
#define SET_GW_CONF(flags, gw_conf)			(flags |= (gw_conf & GW_CONF_MASK))

#endif /* __h_vpnconn__ */

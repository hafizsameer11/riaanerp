(service_modules
	: (VPNAuthenticationServices
		:argc (1)
		:args (
			:arg0 (VPNAuthenticationServices)
		)
	)
	: (vpn_http_services
		:argc (1)
		:args (
			:arg0 (vpn_http_services)
		)
	)
	: (TracClientServices
		:argc (1)
		:args (
			:arg0 (TracClientServices)
		)
	)
	: (CertEnrollServices
		:argc (1)
		:args (
			:arg0 (CertEnrollServices)
		)
	)
	: (LogUploadServices
		:argc (1)
		:args (
			:arg0 (LogUploadServices)
		)
	)
	: (VPNClientSettings
		:argc (1)
		:args (
			:arg0 (VPNClientSettings)
		)
	)
	: (NACServices
		:argc (1)
		:args (
			:arg0 (NACServices)
		)
	)

)

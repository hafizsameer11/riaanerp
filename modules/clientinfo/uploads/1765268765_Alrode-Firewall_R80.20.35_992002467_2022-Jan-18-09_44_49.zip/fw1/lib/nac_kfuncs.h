//
// (c) Copyright 1993-2009 Check Point Software Technologies Ltd.
// All rights reserved.
//
// This is proprietary information of Check Point Software Technologies
// Ltd., which is provided for informational purposes only and for use
// solely in conjunction with the authorized use of Check Point Software
// Technologies Ltd. products.  The viewing and use of this information is
// subject, to the extent appropriate, to the terms and conditions of the
// license agreement that authorizes the use of the relevant product.
//

#ifndef _fwnac_kfuncs_h_
#define _fwnac_kfuncs_h_

#define KFUNC_NAC_MATCH                            0
#define KFUNC_NAC_SET_CAPTIVE_REQUIRED             1
#define KFUNC_NAC_IS_CAPTIVE_REQUIRED              2

#endif/*_fwnac_kfuncs_h_*/


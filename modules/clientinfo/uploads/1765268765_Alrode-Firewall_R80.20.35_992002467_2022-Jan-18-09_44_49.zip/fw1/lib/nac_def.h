
#ifndef _nac_userspace_defines_h_
#define _nac_userspace_defines_h_


#define NAC_IDENTITY_CONTROL_PORT 15105

#define NAC_NETWORK_CONTROL_PORT 28581

#define NAC_PORTAL_DEFAULT_INTERNAL_PORT 5908

#define NAC_MULTI_HOST_MACHINE_CLIENT_ID 0xF


#endif


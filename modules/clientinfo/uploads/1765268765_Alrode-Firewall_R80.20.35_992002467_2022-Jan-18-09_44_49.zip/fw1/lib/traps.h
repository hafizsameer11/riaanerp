/*
 * (c) Copyright 1993-2008 Check Point Software Technologies Ltd.
 * All rights reserved.
 *
 * This is proprietary information of Check Point Software Technologies
 * Ltd., which is provided for informational purposes only and for use
 * solely in conjunction with the authorized use of Check Point Software
 * Technologies Ltd. products.  The viewing and use of this information is
 * subject, to the extent appropriate, to the terms and conditions of the
 * license agreement that authorizes the use of the relevant product.
 *
 *
 */

#ifndef __traps_h__
#define __traps_h__


#ifndef __INSPECT__
#include "up/up_traps.h" /* UP format */
#endif /* __INSPECT__ */
/*
 * Ranges:
 *
 *         Product 		| Range (Dec.)  |	Range (Hex)   |  file 
 *      ----------------+---------------+-----------------
 *      IoT             |   512 - 513   |    200 - 201
 *      FW logs (override)|   400 - 415	|	 190 - 19F
 *      NAC logs        |   508 - 511   |    1FD - 1FF
 *      FW logs     	|   506 - 507	|    1FA - 1FC
 *      CP logs     	|   501 - 505	|    1F5 - 1F9
 *      tp logs         |   482 - 500   |    1E2 - 1F4
 *      FW logs     	|   480 - 481	|    1E0 - 1E1    |
 *      Unified	Policy	|   451 - 479	|    1C3 - 1DF    		| up_traps.h  
 *      Table formats  	|   351 - 450	|    15F - 1C2 		| up_traps.h  // notice - the table formats, are format of a row
 *      CP logs     	|   331 - 350	|    14B - 15E
 *      FW logs		|   321 - 330   |    141 - 14A
 *      ASM logs	|   299 - 320 	|    12B - 140		; and new FW logs
 *      FW logs     	|   289 - 298	|    121 - 12A
 *      Anti Malware	|   294 - 312 	|    126 - 138
 *      Appi logs	|   256 - 288 	|    100 - 120
 *      Daemon traps	|   201 - 254 	|    C9 - FE
 *      VPN logs    	|   181 - 200	|    B5 - C8
 *      FG logs    	|   161 - 180	|    A1 - B4
 *      ASM logs   	|   160 - 160	|    A0 - A0
 *      FW logs     	|   153 - 159	|    99 - 9F
 *      CP logs     	|   152 - 152	|    98 - 98
 *      FW logs     	|   141 - 151	|    8D - 97
 *      CP logs     	|   122 - 140	|    80 - 8C
 *      ASM logs    	|   101 - 121	|    65 - 79
 *      FW logs     	|    90 - 100	|    5A - 64
 *      INSPECT logs	|    89 -  89	|    59 - 59
 *      ASM logs        |    88 -  88	|    58 - 58
 *      INSPECT logs	|    87 -  87	|    57 - 57
 *      ASM logs        |    86 - 86	|    56 - 56
 *      INSPECT logs	|    81 - 85	|    51 - 55
 *      FW logs         |    76 - 80	|    4C - 50
 *      ASM logs        |    70 - 75	|    46 - 4B
 *      FW logs         |    61 - 69	|    3D - 45
 *      ASM logs        |    60 - 60	|    3C - 3C
 *      ASM logs       	|    58	- 58	|    3A	- 3A
 *      FW logs	        |    54  - 57	|    36 - 39
 *      GX logs         |    32 - 50    |    20 - 32
 *      GX logs         |    07 - 31    |    07 - 1F 
 */

/*
 * Daemon traps
 */

/* Sys commands */
#ifdef SFW
#define FWSYSCMD_INTERNET_CONNECTION_REFRESH	0x117
#endif
#define FWSYSCMD_NETFLOW6                       0x116
#define FWSYSCMD_NETFLOW                        0x115
#define FWSYSCMD_ARP_REFRESH			0x114
#define FWSYSCMD_HMEM_EXTEND			0x113
#define FWSYSCMD_TOO_MANY_HOSTS			0x112
#define FWSYSCMD_LOAD					0x111
#define FWSYSCMD_UNLOAD					0x110
#define FWSYSCMD_NDP_REFRESH			0x109
#define FWSYSCMD_WAN_LINE_UP			0x108
#define FWSYSCMD_WAN_LINE_DOWN			0x107
#define FWSYSCMD_NEW_IF					0x106
#define FWSYSCMD_UNKNOWN_IF				0x105
#define FWSYSCMD_NO_FORWARDING			0x104
#define FWSYSCMD_GENERIC_STRING			0x103
#define FWSYSCMD_BLOCK_TRAFFIC			0x102

#define KLOG_HANDLE     				0x101
#define LOG_HANDLE      				0x100
#define KLOG_HANDLE_IPV6   				0x0ff

#define SCV_VERIFICATION_REQUEST		0xf0
#define FWCI_UF_REQ						0xf1
#define	SESSION_AUTH_INVOKE				0xef
#define AUTH_KCONN_INVOKE				0xec
#define	PMAP_FETCH						0xeb
#define	UFPCHECK_INVOKE					0xe9
#define URLOG_LOG_URL					0xe8
#define QUICKUFP_INVOKE					0xe7
#define ASPAM_SYN_TRAP					0xe6
#define USERC_LOG						0xe4
#define USERC_DISCARD					0xe3
#define EPQ_TRAP						0xe2
#define CLIENT_AUTH_LOG					0xd6
#define LOG_POOL						0xd2

#define HA_SET_MAC_ADDS 				0xc1
#define HA_MC_RELOAD					0xca
#define CPHACONF_START					0xcb
#define EMPTY_VS						0xe1

#define CXL_UPDATE_STATUS				0xd4

#define KTHREAD_SET_AFFINITY			0xd5
#define IPS_LOG_PROTECTION_DATA			0xd6
#define EVENT_APP_EMAIL_RESOLVE			0xd7

/* AV match flags */
#define AV_MATCH_FTP_SERVICE  			0x01
#define AV_MATCH_SMTP_SERVICE 			0x02
#define AV_MATCH_HTTP_SERVICE 			0x03
#define AV_MATCH_POP3_SERVICE 			0x04
#define AV_MATCH_CONNECTRA_PORTAL_SERVICE 	0x05

/* AV enabled flag */

#define AV_FLAG							0x10

/* URL Filtering enabled flag */

#define UF_FLAG							0x08

/* Anti Spam enabled flag */

#define ASPAM_FLAG						0x20

/* DLP enabled flag */

#define DLP_FLAG						0x40

/* DLP "by direction" scan enabled */

#define DLP_BY_DIRECTION_FLAG			0x80

/* DLP "by direction" scan dmz included */

#define DLP_BY_DIRECTION_INCLUDE_DMZ	0x100

/* DLP scan VPN traffic */

#define DLP_SCAN_VPN					0x200

/* GX */
#define FW_GX_LDAP_TRAP					0xd3
#define FW_GX_SAM_TRAP					0xd7


/*
 * User Encryption (PC side):
 *
 * The daemon running on the PC is requested to RDP several GWs and establish a session with
 * the first that answers.
 */

#define ENCRYPT_INVOKE_MUL				0xd1
#define	DEBUG_TUNNEL					0xd0

/*
 * SecureIP
 */
#define CLAUTH_SRCNAME_RESOLVE			0xcf
#define CLAUTH_INVOKE 					0xce
#define BALANCE_INVOKE					0xcd
#define BALANCE_DOMAIN					0xcc
/* no longer used - #define HOST_REPORT						0xcb */
/* no longer used - #define SYNATK_REPORT					0xca */
#define TRAP_EXECUTE   					0xc9
#define ACCT_REPORT     				0xc8
#define CHECK_DOMAIN					0xc7
#define ACCT_LIVECONN_UPDATE 			0xc6
/* no longer used - #define DYNOBJ_RESOLVE					0xc5 */
#define SYNC_INIT     					0xc4
#define RESOLVE_HOSTBYNAME 				0xc3
#define RESOLVE_HOSTBYADDR  			0xc2
#define INTEGRITY_SRV_AUTH_REQ			0xc0	/* Integrity Server Auth request */

#define IOT_STATS_COLLECT_UPDATE        0x200
#define IOT_STATS_COLLECT_URL_UPDATE    0x201

/* SPII action flags. resereved flags are 0x00000000 - 0x00000007 inclusive*/
#define SPII_ACTION_NONE					0x00000000
#define SPII_ACTION_DROP					0x00000001
#define SPII_ACTION_REJECT					0x00000002
#define SPII_ACTION_ACCEPT					0x00000003
#define SPII_ACTION_INJECT					0x00000004
#define SPII_ACTION_SAVE_HISTORY			0x00000005
#define SPII_ACTION_RESET_HISTORY			0x00000006
#define SPII_ACTION_DROP_FROM_FW			0x00000007
#define SPII_ACTION_ACCEPT_CONTEXT		SPII_ACTION_ACCEPT

 /* SPII return value flags */
#define SPII_REQUEST_FNA				0x00000010
#define SPII_KEEP_PARAMS				0x00000020
/* #define SPII_STR_REPARSE				0x00000040 		Deprecated since R80 */
#define SPII_STR_PARSE_FAILURE			0x00000080
#define SPII_STR_CALL_ERROR_H			0x00000100
#define SPII_STR_IGNORE					0x00000200
/* #define SPII_RERUN_THIS				0x00000400		Deprecated since R80 */
#define SPII_STR_SAVE_HISTORY			0x00000800
#define SPII_STR_RESET_HISTORY			0x00001000

/* CMI dynamic contexts flags */
#define CMI_CONTEXT_EXEC_WITH_HISTORY	0x00000001

/* Definitions for MCP Kfunc */
#define	INSPECT_MCP_PROTECTION_LEVEL_LOW		0
#define	INSPECT_MCP_PROTECTION_LEVEL_MEDIUM		1
#define	INSPECT_MCP_PROTECTION_LEVEL_HIGH 		2

#define	INSPECT_MCP_SERVER_OS_WINDOWS 			0
#define	INSPECT_MCP_SERVER_OS_LINUX				1
#define	INSPECT_MCP_SERVER_OS_SOLARIS			2
#define	INSPECT_MCP_SERVER_OS_OTHER				3


/* Definitions for pattern search kfunc (KFUNC_SEARCH_PATTERN) - DO NOT CHANGE values*/

/*---- Data Transform types ----*/
#define INSPECT_PS_TRANSFORM_NONE			(0)
#define INSPECT_PS_TRANSFORM_TOUPPER		(1)
#define INSPECT_PS_TRANSFORM_TOLOWER		(2)
#define INSPECT_PS_TRANSFORM_BASE64			(3)

#define INSPECT_PS_TRANSFORM_UNICODE16_LE	(10) /* currently not implemented */
#define INSPECT_PS_TRANSFORM_UNICODE16_BE	(11) /* currently not implemented */
#define INSPECT_PS_TRANSFORM_ASN1			(20)	/* currently not implemented */
#define	INSPECT_PS_TRANSFORM_EBCDIC			(30)	/* currently not implemented */

#define INSPECT_PS_TRANSFORM_LAST_SUPPORTED		INSPECT_PS_TRANSFORM_BASE64

/*---- Delimiter ids bitmasks ----*/
#define DELIMETER_MASK(_bit)				(1 << _bit)
#define INSPECT_PS_DELIM_NONE				(0)
#define INSPECT_PS_DELIM_NULL				DELIMETER_MASK(0)		/* ASCII code: 0 	'\0'	*/
#define INSPECT_PS_DELIM_HTAB				DELIMETER_MASK(1)		/* ASCII code: 9 	'\t'	*/
#define INSPECT_PS_DELIM_LF					DELIMETER_MASK(2)		/* ASCII code: 10 	'\n'	*/
#define INSPECT_PS_DELIM_VTAB				DELIMETER_MASK(3)		/* ASCII code: 11 	'\v'	*/
#define INSPECT_PS_DELIM_FORMFEED			DELIMETER_MASK(4)		/* ASCII code: 12 	'\f'	*/
#define INSPECT_PS_DELIM_CR					DELIMETER_MASK(5)		/* ASCII code: 13 	'\r'	*/
#define INSPECT_PS_DELIM_SPACE 				DELIMETER_MASK(6)		/* ASCII code: 32 	' '		*/
#define INSPECT_PS_DELIM_OxFF 				DELIMETER_MASK(7)		/* ASCII code: 255 			*/
#define INSPECT_PS_DELIM_CRLF 				DELIMETER_MASK(8)		/* 					'\r\n'	*/

#define INSPECT_PS_DELIM_WHITECHAR	(INSPECT_PS_DELIM_HTAB 	| 		\
									INSPECT_PS_DELIM_LF | 			\
									 INSPECT_PS_DELIM_VTAB |		\
									 INSPECT_PS_DELIM_FORMFEED |	\
									 INSPECT_PS_DELIM_CR |			\
									 INSPECT_PS_DELIM_SPACE)

#define INSPECT_PS_SUPPORTED_DELIM (INSPECT_PS_DELIM_NULL | INSPECT_PS_DELIM_WHITECHAR | INSPECT_PS_DELIM_OxFF | INSPECT_PS_DELIM_CRLF)

/*---- Pattern search using : ----*/
#define INSPECT_PS_TYPE_STRLIST		(0)
#define INSPECT_PS_TYPE_STRHASH		(1)
#define INSPECT_PS_TYPE_REGEXP_CPRX	(2)

#define INSPECT_PS_TYPE_LAST		INSPECT_PS_TYPE_REGEXP_CPRX

/*---- Pattern search kfunc return codes ----*/
#define INSPECT_PS_RC_NO_MATCH						(0xffffffff)  /* -1 */
#define INSPECT_PS_RC_UNSUPPORTED_TRANSFORM			(0xffffffff)  /* -1 */
#define INSPECT_PS_RC_UNSUPPORTED_SEARCH_METHOD		(0xffffffff)  /* -1 */
#define INSPECT_PS_RC_UNSUPPORTED_DELIMETER			(0xffffffff)  /* -1 */
#define INSPECT_PS_RC_TRANSFORM_FAILURE				(0xffffffff)  /* -1 */
#define INSPECT_PS_RC_DELIM_NOT_FOUND				(0xffffffff)  /* -1 */
#define INSPECT_PS_RC_OTHER_FAILURE					(0xffffffff)  /* -1 */

#define EXTERNAL_INTERFACE				0
#define INTERNAL_INTERFACE_UNDEFINED	1
#define INTERNAL_INTERFACE_THIS_NET		2
#define INTERNAL_INTERFACE_SPECIFIC_NET	3
#define INTERNAL_INTERFACE_AUTO_NET		4
#define INTERNAL_INTERFACE_DMZ_BIT		0x80



/*
 * Output for KFUNC_SEARCH_STR
 */
#define STR_NOT_FOUND		0xffffffff
#define CMI_NO_MATCH		STR_NOT_FOUND


/********************************************************************
 *					SmartDefense Static Feature IDs					*
 * 			(cross platform - to be used with SD_I_S_NONE) 			*
 *																	*
 *	NOTE: you can use IDs 1-99 (higher IDs are for SD update use	*
 ********************************************************************/
#define SD_DNS_SID_TO_RAND_FEATURE_ID	1
#define SD_DNS_RAND_TO_SID_FEATURE_ID	2
#define SD_P2P_BITTORRENT_FEATURE_ID	3
#define SD_P2P_EDONKEY_FEATURE_ID		4
#define SD_P2P_GNUTELLA_FEATURE_ID		5
#define SD_P2P_YAHOO_FEATURE_ID			6
#define SD_IM_ICQ_FEATURE_ID			7
#define SD_DCERPC_FEATURE_ID			8
#define SD_DCERPC_EPM_TBL_ID			9
#define SD_FTP_NO_OPCODE_BUF_ID			10

#define FW_LOG_FORMAT_multiportal      0xC8
#define FW_LOG_FORMAT_multiportal_SIZE 6

/* Tables format. notice that a format is a format of a row.*/

/* NAC logs formats ID and num of fields */
#define FW_LOG_FORMAT_nac_identity_dst		0x15B	 /* Format ID*/
#define FW_LOG_FORMAT_nac_identity_dst_SIZE     3    /* Number Of Fields*/

#define FW_LOG_FORMAT_nac_identity_src		0x15A 	/* Format ID*/
#define FW_LOG_FORMAT_nac_identity_src_SIZE     5	/* Number Of Fields*/

#define FW_LOG_FORMAT_nac_identity_proxy		0x1F5 	/* Format ID*/
#define FW_LOG_FORMAT_nac_identity_proxy_SIZE     3	/* Number Of Fields*/

/* IP address log formats. Use these when adding a fields of type ipaddr or ipv6addr */

#define CP_LOG_FORMAT_voip_session_ipv4			0x150
#define	CP_LOG_FORMAT_voip_session_ipv6			0x14F
#define CP_LOG_FORMAT_voip_session_ip_SIZE		2	

#define CP_LOG_FORMAT_scope_ipv6				0x14E	/* Format ID */
#define CP_LOG_FORMAT_scope_ipv4				0x14D	/* Format ID */
#define CP_LOG_FORMAT_scope_SIZE				1		/* Number Of Fields */

#define CP_LOG_FORMAT_proxy_src_ipv6			0x14C	/* Format ID */
#define CP_LOG_FORMAT_proxy_src_ipv4			0x14B	/* Format ID */
#define CP_LOG_FORMAT_proxy_src_ip_SIZE			1		/* Number Of Fields */

#ifdef KERNEL
#ifdef FW_IPV6
/* Dummy format ID to use in code */
#define FW_LOG_FORMAT_xlate_log			FW_LOG_FORMAT_xlate_log_ipv6
#define CP_LOG_FORMAT_src				CP_LOG_FORMAT_src_ipv6
#define CP_LOG_FORMAT_dst				CP_LOG_FORMAT_dst_ipv6
#define CP_LOG_FORMAT_scope				CP_LOG_FORMAT_scope_ipv6
#define CP_LOG_FORMAT_proxy_src_ip		CP_LOG_FORMAT_proxy_src_ipv6
#define CP_LOG_FORMAT_voip_session_ip	CP_LOG_FORMAT_voip_session_ipv6
#define FW_LOG_FORMAT_cgnat_account_log FW_LOG_FORMAT_cgnat_account_log_ipv6
#else
#define FW_LOG_FORMAT_xlate_log			FW_LOG_FORMAT_xlate_log_ipv4
#define CP_LOG_FORMAT_src				CP_LOG_FORMAT_src_ipv4
#define CP_LOG_FORMAT_dst				CP_LOG_FORMAT_dst_ipv4
#define CP_LOG_FORMAT_scope				CP_LOG_FORMAT_scope_ipv4
#define CP_LOG_FORMAT_proxy_src_ip		CP_LOG_FORMAT_proxy_src_ipv4
#define CP_LOG_FORMAT_voip_session_ip	CP_LOG_FORMAT_voip_session_ipv4
#define FW_LOG_FORMAT_cgnat_account_log FW_LOG_FORMAT_cgnat_account_log_ipv4
#endif /* FW_IPV6 */
#endif /* KERNEL */

/*
 * FW logs formats ID and num of fields (high range)
 */

#define FW_LOG_FORMAT_protocol				0x154	/* Format ID */
#define FW_LOG_FORMAT_protocol_SIZE			2	 /* Number Of Fields */

#define FW_LOG_FORMAT_ws_msg_failure				0x153 	/* Format ID*/
#define FW_LOG_FORMAT_ws_msg_failure_SIZE			2    	/* Number Of Fields*/

#define FW_LOG_FORMAT_conn_expire_time				0x152 	/* Format ID*/
#define FW_LOG_FORMAT_conn_expire_time_SIZE			1    	/* Number Of Fields*/

#define FW_LOG_FORMAT_conn_state					0x151 	/* Format ID*/
#define FW_LOG_FORMAT_conn_state_SIZE				1    	/* Number Of Fields*/

#define FW_LOG_FORMAT_mab_app_info					0x16A 	/* Format ID*/
#define FW_LOG_FORMAT_mab_app_info_SIZE				2    	/* Number Of Fields*/

#define FW_LOG_FORMAT_mab_request_info					0x140 	/* Format ID*/
#define FW_LOG_FORMAT_mab_request_info_SIZE				5    	/* Number Of Fields*/

#define FW_LOG_FORMAT_mab_session_info					0x149 	/* Format ID*/
#define FW_LOG_FORMAT_mab_session_info_SIZE				2    	/* Number Of Fields*/

#define FW_LOG_FORMAT_optimize_drops_msg_info          			0x148 	/* Format ID*/
#define FW_LOG_FORMAT_optimize_drops_msg_info_SIZE     			1    	/* Number Of Fields*/

/* VoIP logs formats ID and num of fields */
#define FW_LOG_FORMAT_http_proxy	 			0x147 	/* Format ID*/
#define FW_LOG_FORMAT_http_proxy_SIZE			2		/* Number Of Fields */ 

#define FW_LOG_FORMAT_content_type	 			0x146 	/* Format ID*/
#define FW_LOG_FORMAT_content_type_SIZE			1		/* Number Of Fields */

#define FW_LOG_FORMAT_voip_bad					0x145	/* Format ID*/
#define FW_LOG_FORMAT_voip_bad_SIZE 			15		/* Number Of Fields*/

#define FW_LOG_FORMAT_voip_first_pkt			0x144	/* Format ID*/
#define FW_LOG_FORMAT_voip_first_pkt_SIZE 		1		/* Number Of Fields*/

#define FW_LOG_FORMAT_voip_other_session		0x143	/* Format ID*/
#define FW_LOG_FORMAT_voip_other_session_SIZE 	10		/* Number Of Fields*/

#define FW_LOG_FORMAT_voip_call_session			0x142	/* Format ID*/
#define FW_LOG_FORMAT_voip_call_session_SIZE 	15		/* Number Of Fields*/

#define FW_LOG_FORMAT_voip_register_session		0x141	/* Format ID*/
#define FW_LOG_FORMAT_voip_register_session_SIZE 8		/* Number Of Fields*/

/*
 * FW logs formats ID and num of fields (high range)
 */

#define FW_LOG_FORMAT_conn_stats_mig				0x14A 	/* Format ID*/
#define FW_LOG_FORMAT_conn_stats_mig_SIZE			1    	/* Number Of Fields*/

#define FW_LOG_FORMAT_conn_stats_heavy				0x120 	/* Format ID*/
#define FW_LOG_FORMAT_conn_stats_heavy_SIZE			1    	/* Number Of Fields*/

#define FW_LOG_FORMAT_diameter_unallowed_cmd		0xE /* Format ID*/
#define FW_LOG_FORMAT_diameter_unallowed_cmd_SIZE	5    /* Number Of Fields*/

#define FW_LOG_FORMAT_sctp_out_of_state				0x1FF /* Format ID*/
#define FW_LOG_FORMAT_sctp_out_of_state_SIZE	3	 /* Number Of Fields */

#define FW_LOG_FORMAT_hitcount_report          					0x123 	/* Format ID*/
#define FW_LOG_FORMAT_hitcount_report_SIZE     					7    	/* Number Of Fields*/

#define FW_LOG_FORMAT_https_inspection_rulebase_info          	0x121 	/* Format ID*/
#define FW_LOG_FORMAT_https_inspection_rulebase_info_SIZE     	7    	/* Number Of Fields*/

#define FW_LOG_FORMAT_msg_info          	0x9F /* Format ID*/
#define FW_LOG_FORMAT_msg_info_SIZE     	1    /* Number Of Fields*/

#define FW_LOG_FORMAT_rule              	0x9E /* Format ID*/
#define FW_LOG_FORMAT_rule_SIZE         	3    /* Number Of Fields*/

#ifdef SFW
#define FW_LOG_FORMAT_fw_localrule              0x181   /* Format ID*/
#define FW_LOG_FORMAT_fw_localrule_SIZE         1       /* Number Of Fields */
#endif

#define FW_LOG_FORMAT_user              	0x9D /* Format ID*/
#define FW_LOG_FORMAT_user_SIZE         	1    /* Number Of Fields*/

#define FW_LOG_FORMAT_sxl_mcast_enforce                 0x2A /* Format ID*/
#define FW_LOG_FORMAT_sxl_mcast_enforce_SIZE            2    /* Number Of Fields*/

#define FW_LOG_FORMAT_nac_identity              	0x2B /* Format ID*/
#define FW_LOG_FORMAT_nac_identity_SIZE         	6    /* Number Of Fields*/

#define FW_LOG_FORMAT_outbound_https_inspection     	0x2C /* Format ID*/
#define FW_LOG_FORMAT_outbound_https_inspection_SIZE    1    /* Number Of Fields*/

#define FW_LOG_FORMAT_outbound_https_validation     	0x2D /* Format ID*/
#define FW_LOG_FORMAT_outbound_https_validation_SIZE    3    /* Number Of Fields*/

#define FW_LOG_FORMAT_xlate_log_ipv6         	0x12A /* Format ID*/
#define FW_LOG_FORMAT_xlate_log_ipv4         	0x9C /* Format ID*/
#define FW_LOG_FORMAT_xlate_log_SIZE    		6    /* Number Of Fields*/

#define FW_LOG_FORMAT_xlate_msg_info          	0x177 /* Format ID*/
#define FW_LOG_FORMAT_xlate_msg_info_SIZE     	1    /* Number Of Fields*/

#define FW_LOG_FORMAT_nat64_log					0x1FD	/* Format ID*/
#define FW_LOG_FORMAT_nat64_log_SIZE			6		/* Number Of Fields*/

#define FW_LOG_FORMAT_cgnat_xlate_log         	0x1FE /* Format ID*/
#define FW_LOG_FORMAT_cgnat_xlate_log_SIZE    	5    /* Number Of Fields*/

#define FW_LOG_FORMAT_cgnat_account_log_ipv6        0x11E /* Format ID*/
#define FW_LOG_FORMAT_cgnat_account_log_ipv4        0x11C /* Format ID*/
#define FW_LOG_FORMAT_cgnat_account_log_SIZE    	5    /* Number Of Fields*/

#define FW_LOG_FORMAT_nat46_log					0x11B	/* Format ID*/
#define FW_LOG_FORMAT_nat46_log_SIZE			3		/* Number Of Fields*/

#define FW_LOG_FORMAT_th_flags          	0x9A /* Format ID*/
#define FW_LOG_FORMAT_th_flags_SIZE     	1    /* Number Of Fields*/

#define FW_LOG_FORMAT_vrtl_dfrg_err_product_fw       	0x9B /* Format ID*/
#define FW_LOG_FORMAT_vrtl_dfrg_err_product_fw_SIZE  	6    /* Number Of Fields*/

#define FW_LOG_FORMAT_vrtl_dfrg_err       	0x99 /* Format ID*/
#define FW_LOG_FORMAT_vrtl_dfrg_err_SIZE  	6    /* Number Of Fields*/

#define FW_LOG_FORMAT_h323   	        	0x97 /* Format ID*/
#define FW_LOG_FORMAT_h323_SIZE				3    /* Number Of Fields*/

#define FW_LOG_FORMAT_bad_port_cmd      	0x96 /* Format ID*/
#define FW_LOG_FORMAT_bad_port_cmd_SIZE 	3    /* Number Of Fields*/

#define FW_LOG_FORMAT_sip_call		  		0x95 /* Format ID*/
#define FW_LOG_FORMAT_sip_call_SIZE   		3    /* Number Of Fields*/

#define FW_LOG_FORMAT_sync					0x94 /* Format ID */
#define FW_LOG_FORMAT_sync_SIZE				1

#define FW_LOG_FORMAT_voip_register        	0x93 /* Format ID*/
#define FW_LOG_FORMAT_voip_register_SIZE   	2    /* Number Of Fields*/

#define FW_LOG_FORMAT_sip_reason        	0x92 /* Format ID*/
#define FW_LOG_FORMAT_sip_reason_SIZE   	1    /* Number Of Fields*/

#define FW_LOG_FORMAT_gtp_basic				0x91 /* Format ID */
#define FW_LOG_FORMAT_gtp_basic_SIZE		1	 /* Number Of Fields */

#define FW_LOG_FORMAT_gtp_extended			0x90 /* Format ID */
#define FW_LOG_FORMAT_gtp_extended_SIZE		7	 /* Number Of Fields */

#define FW_LOG_FORMAT_gtpv2_extended		0x5  /* Format ID */
#define FW_LOG_FORMAT_gtpv2_extended_SIZE	5	  /* Number Of Fields */

#define FW_LOG_FORMAT_gtp_code_description		0x8F /* Format ID */
#define FW_LOG_FORMAT_gtp_code_description_SIZE	1	 /* Number Of Fields */

#define FW_LOG_FORMAT_gtp_account			0x8E /* Format ID */
#define FW_LOG_FORMAT_gtp_account_SIZE		2	 /* Number Of Fields */

#define FW_LOG_FORMAT_gtp_create_req		0x8D /* Format ID */
#define FW_LOG_FORMAT_gtp_create_req_SIZE   6	 /* Number Of Fields */

#define IPS_LOG_FORMAT_general				0x13e /*Format ID*/
#define IPS_LOG_FORMAT_general_SIZE			11

#define IPS_LOG_FORMAT_malware_header   	0x13f /* Format ID*/
#define IPS_LOG_FORMAT_malware_header_SIZE      1 /* Number Of Fields */

/*
 * FW logs formats ID and num of fields (low range)
 */

#define FW_LOG_FORMAT_scv_user_drop		  	0x64 /* Format ID */
#define FW_LOG_FORMAT_scv_user_drop_SIZE 	2	 /* Number Of Fields */

#define FW_LOG_FORMAT_dns					0x63 /* Format ID*/
#define FW_LOG_FORMAT_dns_SIZE				2	 /* Number Of Fields */

#define FW_LOG_FORMAT_tcp_out_of_state      0x62 /* Format ID*/
#define FW_LOG_FORMAT_tcp_out_of_state_SIZE	2	 /* Number Of Fields */

#define FW_LOG_FORMAT_fw_string             0x61 /* Format ID*/
#define FW_LOG_FORMAT_fw_string_SIZE	    1	 /* Number Of Fields */

#define FW_LOG_FORMAT_cifs					0x60 /* Format ID*/
#define FW_LOG_FORMAT_cifs_SIZE				2	 /* Number Of Fields */

#define FW_LOG_FORMAT_citrix_ica_detect       0x5f /* Format ID*/
#define FW_LOG_FORMAT_citrix_ica_detect_SIZE  2	   /* Number Of Fields */

#define FW_LOG_FORMAT_cluster 				0x5e /* Format ID*/
#define FW_LOG_FORMAT_cluster_SIZE			1	 /* Number Of Fields */

#define FW_LOG_FORMAT_dns_with_type			0x5d /* Format ID*/
#define FW_LOG_FORMAT_dns_with_type_SIZE	3	 /* Number Of Fields */

#define FW_LOG_FORMAT_misp_link_down		0x5c	/* Format ID*/
#define FW_LOG_FORMAT_misp_link_down_SIZE	4		/* Number Of Fields */

#define FW_LOG_FORMAT_mgcp_reason			0x5b /* Format ID*/
#define FW_LOG_FORMAT_mgcp_reason_SIZE		1    /* Number Of Fields*/

#define FW_LOG_FORMAT_mail_security			0x5a /* Format ID*/
#define FW_LOG_FORMAT_mail_security_SIZE		7    /* Number Of Fields*/

#define FW_LOG_FORMAT_mail_data				0x137 /* Format ID*/
#define FW_LOG_FORMAT_mail_data_SIZE		5    /* Number Of Fields*/

#define FW_LOG_FORMAT_tp_matched_rules		0x1E8 /* Format ID*/
#define FW_LOG_FORMAT_tp_matched_rules_SIZE	5    /* Number Of Fields*/

#define FW_LOG_FORMAT_misp_link_up			0x50	/* Format ID*/
#define FW_LOG_FORMAT_misp_link_up_SIZE		3		/* Number Of Fields */

#define FW_LOG_FORMAT_mgcp_call_cli			0x4f /* Format ID*/
#define FW_LOG_FORMAT_mgcp_call_cli_SIZE	2    /* Number Of Fields*/

#define FW_LOG_FORMAT_rule_with_id			0x4e	/* Format ID*/
#define FW_LOG_FORMAT_rule_with_id_SIZE		5		/* Number Of Fields */

#ifdef SFW
#define FW_LOG_FORMAT_localrule_with_id                0x180   /* Format ID*/
#define FW_LOG_FORMAT_localrule_with_id_SIZE           3       /* Number Of Fields */
#endif

#define FW_LOG_FORMAT_mgcp_call_ser			0x4d /* Format ID*/
#define FW_LOG_FORMAT_mgcp_call_ser_SIZE	1    /* Number Of Fields*/

#define FW_LOG_FORMAT_skinny_reason			0x4c /* Format ID*/
#define FW_LOG_FORMAT_skinny_reason_SIZE	1    /* Number Of Fields*/

#define FW_LOG_FORMAT_sxl_agg_drop 		0x45 	/* Format ID*/
#define FW_LOG_FORMAT_sxl_agg_drop_SIZE		3	/* Number Of Fields */

#define FW_LOG_FORMAT_sxl_agg_monitor		0x198 	/* Format ID*/
#define FW_LOG_FORMAT_sxl_agg_monitor_SIZE	3	/* Number Of Fields */

#define FW_LOG_FORMAT_sxl_single_drop 		0x44 	/* Format ID*/
#define FW_LOG_FORMAT_sxl_single_drop_SIZE	1	/* Number Of Fields */

#define FW_LOG_FORMAT_sxl_single_monitor	0x197 	/* Format ID*/
#define FW_LOG_FORMAT_sxl_single_monitor_SIZE	1	/* Number Of Fields */

#define FW_LOG_FORMAT_connect_level 		0x43 /* Format ID*/
#define FW_LOG_FORMAT_connect_level_SIZE	1	/* Number Of Fields */

#define FW_LOG_FORMAT_ip_options 			0x42 /* Format ID*/
#define FW_LOG_FORMAT_ip_options_SIZE		1	/* Number Of Fields */

#define FW_LOG_FORMAT_h323_reason			0x41	/* Format ID*/
#define FW_LOG_FORMAT_h323_reason_SIZE		1		/* Number Of Fields */

#define FW_LOG_FORMAT_h323_bad_redirect		0x40	/* Format ID*/
#define FW_LOG_FORMAT_h323_bad_redirect_SIZE 1		/* Number Of Fields */

#define FW_LOG_FORMAT_logid					0x3B	/* Format ID*/
#define FW_LOG_FORMAT_logid_SIZE 			1		/* Number Of Fields */

#define FW_LOG_FORMAT_aspam				0x3F	/* Format ID*/
#define FW_LOG_FORMAT_aspam_SIZE 			13		/* Number Of Fields */

#define FW_LOG_FORMAT_inzone			0x3D	/* Format ID*/
#define FW_LOG_FORMAT_inzone_SIZE 		1		/* Number Of Fields */

#define FW_LOG_FORMAT_outzone				0x3E	/* Format ID*/
#define FW_LOG_FORMAT_outzone_SIZE 			1		/* Number Of Fields */

#define FW_LOG_FORMAT_uf_info				0x37	/* Format ID*/
#define FW_LOG_FORMAT_uf_info_SIZE			4		/* Number Of Fields */

#define FW_LOG_FORMAT_dlp					0x38	/* Format ID*/
#define FW_LOG_FORMAT_dlp_SIZE				2		/* Number Of Fields */

#define FW_LOG_FORMAT_av_info				0x36	/* Format ID*/
#define FW_LOG_FORMAT_av_info_SIZE			7		/* Number Of Fields */

#define FW_LOG_FORMAT_dcerpc_uuid_rule		0x39 /* Format ID */
#define FW_LOG_FORMAT_dcerpc_uuid_rule_SIZE 5	 /* Number Of Fields */

#define FW_LOG_FORMAT_securexl_msg			0x35 /* Format ID*/
#define FW_LOG_FORMAT_securexl_msg_SIZE		1    /* Number Of Fields*/

#define FW_LOG_FORMAT_log_delay				0x34 /* Format ID*/
#define FW_LOG_FORMAT_log_delay_SIZE		1    /* Number Of Fields*/

#define FW_LOG_FORMAT_aggregated_info		0x33 /* Format ID*/
#define FW_LOG_FORMAT_aggregated_info_SIZE	2    /* Number Of Fields*/

#define FW_LOG_FORMAT_domain_info				0x1EE	/* Format ID*/
#define FW_LOG_FORMAT_domain_info_SIZE			2		/* Number Of Fields */

#define FW_LOG_FORMAT_domain_err				0x10E	/* Format ID*/
#define FW_LOG_FORMAT_domain_err_SIZE			2		/* Number Of Fields */

/*
 * APPI logs formats ID and num of fields
 */
#define FW_LOG_FORMAT_app_info				0x100	/* Format ID*/
#define FW_LOG_FORMAT_app_info_SIZE			15		/* Number Of Fields */

#define FW_LOG_FORMAT_app_fail				0x101	/* Format ID*/
#define FW_LOG_FORMAT_app_fail_SIZE			5		/* Number Of Fields */

#define FW_LOG_FORMAT_app_account           0x102   /* Format ID*/
#define FW_LOG_FORMAT_app_account_SIZE      5   	/* Number Of Fields*/

#define FW_LOG_FORMAT_app_conns           	0x103   /* Format ID*/
#define FW_LOG_FORMAT_app_conns_SIZE      	2   	/* Number Of Fields*/

#define FW_LOG_FORMAT_app_proxy_user        0x104   /* Format ID*/
#define FW_LOG_FORMAT_app_proxy_user_SIZE   6   	/* Number Of Fields*/

#define FW_LOG_FORMAT_app_resource        	0x105   /* Format ID*/
#define FW_LOG_FORMAT_app_resource_SIZE   	1   	/* Number Of Fields*/

#define FW_LOG_FORMAT_app_parser_err		0x10C	/* Format ID*/
#define FW_LOG_FORMAT_app_parser_err_SIZE	1		/* Number Of Fields */

#define FW_LOG_FORMAT_urlf_info				0x106	/* Format ID*/
#define FW_LOG_FORMAT_urlf_info_SIZE		16		/* Number Of Fields */

#define FW_LOG_FORMAT_urlf_fail				0x107	/* Format ID*/
#define FW_LOG_FORMAT_urlf_fail_SIZE		5		/* Number Of Fields */

#define FW_LOG_FORMAT_urlf_account			0x108   /* Format ID*/
#define FW_LOG_FORMAT_urlf_account_SIZE		5   	/* Number Of Fields*/

#define FW_LOG_FORMAT_urlf_conns           	0x109   /* Format ID*/
#define FW_LOG_FORMAT_urlf_conns_SIZE      	2   	/* Number Of Fields*/

#define FW_LOG_FORMAT_urlf_proxy_user       0x110   /* Format ID*/
#define FW_LOG_FORMAT_urlf_proxy_user_SIZE  6   	/* Number Of Fields*/

#define FW_LOG_FORMAT_urlf_resource        	0x111   /* Format ID*/
#define FW_LOG_FORMAT_urlf_resource_SIZE   	1   	/* Number Of Fields*/

#define FW_LOG_FORMAT_urlf_cert_validation        	0x19c   /* Format ID*/
#define FW_LOG_FORMAT_urlf_cert_validation_SIZE   	3   	/* Number Of Fields*/

#define FW_LOG_FORMAT_app_limit_account       	0x10A   /* Format ID*/
#define FW_LOG_FORMAT_app_limit_account_SIZE   	6   	/* Number Of Fields*/

#define FW_LOG_FORMAT_urlf_limit_account        	0x10B   /* Format ID*/
#define FW_LOG_FORMAT_urlf_limit_account_SIZE   	6   	/* Number Of Fields*/

#define FW_LOG_FORMAT_urlf_parser_err				0x10D	/* Format ID*/
#define FW_LOG_FORMAT_urlf_parser_err_SIZE			1		/* Number Of Fields */

#ifdef SFW
#define FW_LOG_FORMAT_sys_message 			0x182 /* Format ID*/
#define FW_LOG_FORMAT_sys_message_SIZE 1	 /* Number Of Fields*/

#define FW_LOG_FORMAT_rsn_mac 			0x183 /* Format ID*/
#define FW_LOG_FORMAT_rsn_mac_SIZE 2	 /* Number Of Fields*/
#endif

/* APPI Modbus is defined also in appi where used (appi/handlers/modbus_parser.c) */
#define CP_LOG_FORMAT_appi_modbus_data				0x10F	/* Format ID */
#define CP_LOG_FORMAT_appi_modbus_data_SIZE			6		/* Number Of Fields */

/* APPI Modbus is defined also in appi where used (appi/handlers/modbus_parser.c) */
#define CP_LOG_FORMAT_appi_modbus_data			0x10F	/* Format ID */
#define CP_LOG_FORMAT_appi_modbus_data_SIZE			6	/* Number Of Fields */


/* DLP */
#define FW_LOG_FORMAT_dlp_ex						0x112	/* Format ID*/
#define FW_LOG_FORMAT_dlp_ex_SIZE					6		/* Number Of Fields */ 

#define FW_LOG_FORMAT_urlf_zone						0x119	/* Format ID*/
#define FW_LOG_FORMAT_urlf_zone_SIZE				2		/* Number Of Fields */

#define FW_LOG_FORMAT_appi_zone						0x118	/* Format ID*/
#define FW_LOG_FORMAT_appi_zone_SIZE				2		/* Number Of Fields */

#define FW_LOG_FORMAT_fw_uc_incident_id				0x11A	/* Format ID*/
#define FW_LOG_FORMAT_fw_uc_incident_id_SIZE		1		/* Number Of Fields */

#define FW_LOG_FORMAT_fw_rematch_info				  	0x139	/* Format ID*/
#define FW_LOG_FORMAT_fw_rematch_info_SIZE			1		/* Number Of Fields */

/*
 * APPI logs formats ID and num of fields - continue
 */
#define FW_LOG_FORMAT_urlf_user_info				0x113	/* Format ID*/
#define FW_LOG_FORMAT_urlf_user_info_SIZE			15		/* Number Of Fields */

#define FW_LOG_FORMAT_urlf_user_override_info		0x114	/* Format ID*/
#define FW_LOG_FORMAT_urlf_user_override_info_SIZE	15		/* Number Of Fields */

#define FW_LOG_FORMAT_referrer_self_uuid 0x115   	/* referer feature self uuid*/
#define FW_LOG_FORMAT_referrer_parent_uuid 0x116	/* referer feature parent uuid*/

#ifndef __INSPECT__
#define FW_LOG_FORMAT_browse_time_flag             ADD_CPLOG_LF_LOGGING_LEVEL_FLAG(0x117, eLFLogingLevelAlwaysSuppress)
#endif /* __INSPECT__ */
#define FW_LOG_FORMAT_browse_time_flag_SIZE			1		/* Number Of Fields */

#define FW_LOG_FORMAT_blade_policy_installation_status			0x122	/* Format ID*/
#define FW_LOG_FORMAT_blade_policy_installation_status_SIZE 	2	/* Number Of Fields */

#define FW_LOG_FORMAT_malware				0x125	/* Format ID*/
#define FW_LOG_FORMAT_malware_SIZE 			18		/* Number Of Fields */

#define FW_LOG_FORMAT_malware_mail			0x126	/* Format ID*/
#define FW_LOG_FORMAT_malware_mail_SIZE 	1		/* Number Of Fields */

#define FW_LOG_FORMAT_malware_acc           0x127 /* Format ID*/
#define FW_LOG_FORMAT_malware_acc_SIZE      5     /* Number Of Fields */

#define FW_LOG_FORMAT_malware_stat			0x128 /* Format ID*/
#define FW_LOG_FORMAT_malware_stat_SIZE		12     /* Number Of Fields */

#define FW_LOG_FORMAT_malware_amw			0x129 /* Format ID*/
#define FW_LOG_FORMAT_malware_amw_SIZE		1     /* Number Of Fields */

#define FW_LOG_FORMAT_malware_av			0x130 /* Format ID*/
#define FW_LOG_FORMAT_malware_av_SIZE		1     /* Number Of Fields */

#define FW_LOG_FORMAT_malware_rb_av           0x131 /* Format ID*/
#define FW_LOG_FORMAT_malware_rb_av_SIZE      21     /* Number Of Fields */

#define FW_LOG_FORMAT_malware_rb_te			0x124 /* Format ID*/
#define FW_LOG_FORMAT_malware_rb_te_SIZE	4     /* Number Of Fields */

#define FW_LOG_FORMAT_malware_te			0x135 /* Format ID*/
#define FW_LOG_FORMAT_malware_te_SIZE		1     /* Number Of Fields */

#define FW_LOG_FORMAT_te_error				0x136	/* Format ID*/
#define FW_LOG_FORMAT_te_error_SIZE 		3		/* Number Of Fields */

#define FW_LOG_FORMAT_malware_error			0x132	/* Format ID*/
#define FW_LOG_FORMAT_malware_error_SIZE 	2		/* Number Of Fields */

#define FW_LOG_FORMAT_malware_info			0x133	/* Format ID*/
#define FW_LOG_FORMAT_malware_info_SIZE 	2		/* Number Of Fields */

#define FW_LOG_FORMAT_malware_dns 		0x134	/* Format ID*/
#define FW_LOG_FORMAT_malware_dns_SIZE 			1		/* Number Of Fields */

#define FW_LOG_FORMAT_malware_ips           0x138 /* Format ID*/
#define FW_LOG_FORMAT_malware_ips_SIZE      4     /* Number Of Fields */

#ifdef SFW
/* MAC filtering and Balcklist MAC filtering log info */
#define CP_LOG_FORMAT_fw_mac_filtering_log     0x184	 		/* Format ID*/
#define CP_LOG_FORMAT_fw_mac_filtering_log_SIZE 	2  			/* Number Of Fields */

#define FW_LOG_FORMAT_arp_spoof_detect			0x185 /* Format ID */
#define FW_LOG_FORMAT_arp_spoof_detect_SIZE 	2	 /* Number Of Fields */
#endif

/* DAF - FW & CP */
#define FW_LOG_FORMAT_daf_error			0x1E0 /* Format ID*/
#define FW_LOG_FORMAT_daf_error_SIZE    3     /* Number Of Fields */

#define CP_LOG_FORMAT_daf_info			0x155 /* Format ID*/
#define CP_LOG_FORMAT_daf_info_SIZE     1     /* Number Of Fields */

/* ICAP BLADE - FW */
#define FW_LOG_FORMAT_icap_blade_error			0x17F /* Format ID*/
#define FW_LOG_FORMAT_icap_blade_error_SIZE     5     /* Number Of Fields */

#define FW_LOG_FORMAT_icap_blade_enforcement			0x195 /* Format ID*/
#define FW_LOG_FORMAT_icap_blade_enforcement_SIZE     	5     /* Number Of Fields */

#define FW_LOG_FORMAT_icap_blade_service_action			0x196 /* Format ID*/
#define FW_LOG_FORMAT_icap_blade_service_action_SIZE   	5     /* Number Of Fields */

/*
 * CPKIS logs formats ID and num of fields
 */
#define CP_LOG_FORMAT_capture_uuid         0x98 /* Format ID*/
#define CP_LOG_FORMAT_capture_uuid_SIZE     1   /* Number Of Fields*/

#define CP_LOG_FORMAT_msg_info          	0x8C /* Format ID*/
#define CP_LOG_FORMAT_msg_info_SIZE     	1    /* Number Of Fields*/

#define CP_LOG_FORMAT_tcpudp            	0x8B /* Format ID*/
#define CP_LOG_FORMAT_tcpudp_SIZE       	5    /* Number Of Fields*/

#define CP_LOG_FORMAT_icmp              	0x8A /* Format ID*/
#define CP_LOG_FORMAT_icmp_SIZE         	2    /* Number Of Fields*/

#define CP_LOG_FORMAT_sun_rpc           	0x89 /* Format ID*/
#define CP_LOG_FORMAT_sun_rpc_SIZE      	1    /* Number Of Fields*/

#define CP_LOG_FORMAT_dce_rpc           	0x88 /* Format ID*/
#define CP_LOG_FORMAT_dce_rpc_SIZE      	4    /* Number Of Fields*/

#define CP_LOG_FORMAT_other_ip          	0x87 /* Format ID*/
#define CP_LOG_FORMAT_other_ip_SIZE     	3    /* Number Of Fields*/

#define CP_LOG_FORMAT_account           	0x86 /* Format ID*/
#define CP_LOG_FORMAT_account_SIZE      	20   /* Number Of Fields*/

#define CP_LOG_FORMAT_ipv6_tcpudp	    	0x85 /* Format ID*/
#define CP_LOG_FORMAT_ipv6_tcpudp_SIZE  	5    /* Number Of Fields*/

#define CP_LOG_FORMAT_string            	0x84 /* Format ID*/
#define CP_LOG_FORMAT_string_SIZE       	1    /* Number Of Fields*/

#define CP_LOG_FORMAT_recurrence			0x83 /* Format ID */
#define CP_LOG_FORMAT_recurrence_SIZE		1	 /* Number Of Fields*/

#define CP_LOG_FORMAT_ipv6_other_ip	    	0x82 /* Format ID*/
#define CP_LOG_FORMAT_ipv6_other_ip_SIZE 	3    /* Number Of Fields*/

#define CP_LOG_FORMAT_src_ipv4				0x81 /* Format ID*/
#define CP_LOG_FORMAT_src_ipv6				0x13A /* Format ID*/
#define CP_LOG_FORMAT_src_SIZE 				1    /* Number Of Fields*/

#define CP_LOG_FORMAT_sport					0x80 /* Format ID*/
#define CP_LOG_FORMAT_sport_SIZE			1    /* Number Of Fields*/

#define CP_LOG_FORMAT_dst_ipv4				0x7f /* Format ID*/
#define CP_LOG_FORMAT_dst_ipv6				0x13B /* Format ID*/
#define CP_LOG_FORMAT_dst_SIZE 				1    /* Number Of Fields*/

#define CP_LOG_FORMAT_dport					0x7e /* Format ID*/
#define CP_LOG_FORMAT_dport_SIZE			1    /* Number Of Fields*/

#define CP_LOG_FORMAT_ipp					0x7d /* Format ID*/
#define CP_LOG_FORMAT_ipp_SIZE				1    /* Number Of Fields*/

#define CP_LOG_FORMAT_excsv_log_report		0x7c
#define CP_LOG_FORMAT_excsv_log_report_SIZE	2

#define CP_LOG_FORMAT_icmp_desc				0x7b /* Format ID*/
#define CP_LOG_FORMAT_icmp_desc_SIZE		1   /* Number Of Fields*/

#define CP_LOG_FORMAT_service_id			0x7a /* Format ID*/
#define CP_LOG_FORMAT_service_id_SIZE		1   /* Number Of Fields*/

#define CP_LOG_FORMAT_web_security_error_log      		0x30	/* Format ID*/
#define CP_LOG_FORMAT_web_security_error_log_SIZE		1    		/* Number Of Fields */

#define CP_LOG_FORMAT_web_security_info_log      		0x2e 	/* Format ID*/
#define CP_LOG_FORMAT_web_security_info_log_SIZE		3    		/* Number Of Fields */

#define CP_LOG_FORMAT_web_security_resource_log			0x2f	/* Format ID*/
#define CP_LOG_FORMAT_web_security_resource_log_SIZE 	1		/* Number Of Fields */

#define CP_LOG_FORMAT_web_security_http_agg_log     	0x13c 		/* Format ID*/
#define CP_LOG_FORMAT_web_security_http_agg_log_SIZE 	4  			  /* Number Of Fields */

#define CP_LOG_FORMAT_fw_dns_agg_log     				0x13d	 		/* Format ID*/
#define CP_LOG_FORMAT_fw_dns_agg_log_SIZE 				2  			/* Number Of Fields */

#define CP_LOG_FORMAT_src_device_info_log    			0x16f	 	/* Format ID*/
#define CP_LOG_FORMAT_src_device_info_log_SIZE 			3  			/* Number Of Fields */

#define CP_LOG_FORMAT_dst_device_info_log    			0x16c	 		/* Format ID*/
#define CP_LOG_FORMAT_dst_device_info_log_SIZE 			3  			/* Number Of Fields */


/*
 * ASM logs formats ID and num of fields
 */
/* VoIP asm logs */
#define ASM_LOG_FORMAT_content_type 			0x12f 	/* Format ID*/
#define ASM_LOG_FORMAT_content_type_SIZE		1		/* Number Of Fields */

#define ASM_LOG_FORMAT_voip_security_log		0x12e 	/* Format ID*/
#define ASM_LOG_FORMAT_voip_security_log_SIZE	13	 	/* Number Of Fields*/

#define ASM_LOG_FORMAT_attack				0x78 /* Format ID*/
#define ASM_LOG_FORMAT_attack_SIZE			1	 /* Number Of Fields */

#define ASM_LOG_FORMAT_synatk            	0x77 /* Format ID*/
#define ASM_LOG_FORMAT_synatk_SIZE       	1    /* Number Of Fields*/

#define ASM_LOG_FORMAT_attack_info			0x76
#define ASM_LOG_FORMAT_attack_info_SIZE		1

#define ASM_LOG_FORMAT_worm_info			0x75
#define ASM_LOG_FORMAT_worm_info_SIZE		1

#define ASM_LOG_FORMAT_seqval				0x74 /* Format ID */
#define ASM_LOG_FORMAT_seqval_SIZE			3

#define ASM_LOG_FORMAT_bad_port_cmd      	0x73 /* Format ID*/
#define ASM_LOG_FORMAT_bad_port_cmd_SIZE	2    /* Number Of Fields*/

#define ASM_LOG_FORMAT_cifs_worm_info		0x72
#define ASM_LOG_FORMAT_cifs_worm_info_SIZE	1

#define ASM_LOG_FORMAT_packet_info			0x71
#define ASM_LOG_FORMAT_packet_info_SIZE		1

#define ASM_LOG_FORMAT_tcp_flags			0x70
#define ASM_LOG_FORMAT_tcp_flags_SIZE		1

#define ASM_LOG_FORMAT_portscan				0x6e 	/* Format ID*/
#define ASM_LOG_FORMAT_portscan_SIZE		2		/* Number Of Fields */

#define ASM_LOG_FORMAT_web_security_log      	0x6d /* Format ID*/
#define ASM_LOG_FORMAT_web_security_log_SIZE	5    /* Number Of Fields */

#define ASM_LOG_FORMAT_mail_security			0x6c
#define ASM_LOG_FORMAT_mail_security_SIZE		7

#define ASM_LOG_FORMAT_sam_dynamic_rule				0x6b
#define ASM_LOG_FORMAT_sam_dynamic_rule_SIZE		1

/* More GX log formats */
#define FW_LOG_FORMAT_gtp_path_mgmt			0x32/* Format ID */
#define FW_LOG_FORMAT_gtp_path_mgmt_SIZE	2	 /* Number Of Fields */

#define FW_LOG_FORMAT_gtp_signal_type		0x23 /* Format ID */
#define FW_LOG_FORMAT_gtp_signal_type_SIZE	1	 /* Number Of Fields */

#define FW_LOG_FORMAT_gtp_additional_info		0x22 /* Format ID */
#define FW_LOG_FORMAT_gtp_additional_info_SIZE	1	 /* Number Of Fields */

#define FW_LOG_FORMAT_gtp_eu_addr				0x24  /* Format ID */
#define FW_LOG_FORMAT_gtp_eu_addr_SIZE			1	 /* Number Of Fields */

#define FW_LOG_FORMAT_gtp_eu_addr_ipv6				0x178 /* Format ID */
#define FW_LOG_FORMAT_gtp_eu_addr_ipv6_SIZE			1	 /* Number Of Fields */

#define FW_LOG_FORMAT_gtp_teid_up			0x20  /* Format ID */
#define FW_LOG_FORMAT_gtp_teid_up_SIZE 		1	 /* Number Of Fields */

#define FW_LOG_FORMAT_gtp_teid_dn			0x26  /* Format ID */
#define FW_LOG_FORMAT_gtp_teid_dn_SIZE 		1	 /* Number Of Fields */

#define FW_LOG_FORMAT_gtp_cause			0x179 /* Format ID */
#define FW_LOG_FORMAT_gtp_cause_SIZE 		2	 /* Number Of Fields */


#define FW_LOG_FORMAT_gtp_nsapi			0x25
#define FW_LOG_FORMAT_gtp_nsapi_SIZE		1

#define FW_LOG_FORMAT_gtp_v0_ex				0x31/* Format ID */
#define FW_LOG_FORMAT_gtp_v0_ex_SIZE 		1	 /* Number Of Fields */

#define FW_LOG_FORMAT_gtp_linked_nsapi		0x15 /* Format ID */
#define FW_LOG_FORMAT_gtp_linked_nsapi_SIZE 1	 /* Number Of Fields */

#define FW_LOG_FORMAT_gtp_linked_ebi		0x16 /* Format ID */
#define FW_LOG_FORMAT_gtp_linked_ebi_SIZE	1	/* Number Of Fields */

#define FW_LOG_FORMAT_gtp_default_bearer_info		0x17 /* Format ID */
#define FW_LOG_FORMAT_gtp_default_bearer_info_SIZE	1	/* Number Of Fields */

#define FW_LOG_FORMAT_gtp_dedicated_bearer_info_1		0x18 /* Format ID */
#define FW_LOG_FORMAT_gtp_dedicated_bearer_info_1_SIZE	1	/* Number Of Fields */

#define FW_LOG_FORMAT_gtp_dedicated_bearer_info_2		0x19 /* Format ID */
#define FW_LOG_FORMAT_gtp_dedicated_bearer_info_2_SIZE	1	/* Number Of Fields */

#define FW_LOG_FORMAT_gtp_dedicated_bearer_info_3		0x1A /* Format ID */
#define FW_LOG_FORMAT_gtp_dedicated_bearer_info_3_SIZE	1	/* Number Of Fields */

#define FW_LOG_FORMAT_gtp_dedicated_bearer_info_4		0x1B /* Format ID */
#define FW_LOG_FORMAT_gtp_dedicated_bearer_info_4_SIZE	1	/* Number Of Fields */

#define FW_LOG_FORMAT_gtp_dedicated_bearer_info_5		0x1C /* Format ID */
#define FW_LOG_FORMAT_gtp_dedicated_bearer_info_5_SIZE	1	/* Number Of Fields */

#define FW_LOG_FORMAT_gtp_dedicated_bearer_info_6		0x1D /* Format ID */
#define FW_LOG_FORMAT_gtp_dedicated_bearer_info_6_SIZE	1	/* Number Of Fields */

#define FW_LOG_FORMAT_gtp_dedicated_bearer_info_7		0x1E /* Format ID */
#define FW_LOG_FORMAT_gtp_dedicated_bearer_info_7_SIZE	1	/* Number Of Fields */

#define FW_LOG_FORMAT_gtp_dedicated_bearer_info_8		0x1F /* Format ID */
#define FW_LOG_FORMAT_gtp_dedicated_bearer_info_8_SIZE	1	/* Number Of Fields */

#define FW_LOG_FORMAT_gtp_dedicated_bearer_info_9		0x20 /* Format ID */
#define FW_LOG_FORMAT_gtp_dedicated_bearer_info_9_SIZE	1	/* Number Of Fields */

#define FW_LOG_FORMAT_gtp_dedicated_bearer_info_10		0x9 /* Format ID */
#define FW_LOG_FORMAT_gtp_dedicated_bearer_info_10_SIZE	1	/* Number Of Fields */

#define FW_LOG_FORMAT_gtp_hplmn_info					0x8 /* Format ID */
#define FW_LOG_FORMAT_gtp_hplmn_info_SIZE 				1	/* Number Of Fields */

#define FW_LOG_FORMAT_gtp_vplmn_info					0x7 /* Format ID */
#define FW_LOG_FORMAT_gtp_vplmn_info_SIZE 				1	/* Number Of Fields */

#define FW_LOG_FORMAT_gtp_ho_sgsn_ggsn_info				0x11 /* Format ID */
#define FW_LOG_FORMAT_gtp_ho_sgsn_ggsn_info_SIZE 		2	/* Number Of Fields */

#define FW_LOG_FORMAT_gtp_ho_sgw_pgw_info				0x12 /* Format ID */ 
#define FW_LOG_FORMAT_gtp_ho_sgw_pgw_info_SIZE 			2	/* Number Of Fields */

#define FW_LOG_FORMAT_gtp_code							0x21 /* Format ID */
#define FW_LOG_FORMAT_gtp_code_SIZE 					3	/* Number Of Fields */

#define FW_LOG_FORMAT_gtp_imsi							0x13 /* Format ID */
#define FW_LOG_FORMAT_gtp_imsi_SIZE 					3	 /* Number Of Fields */

#define FW_LOG_FORMAT_gtp_imsi_string					0x10 /* Format ID  imsi string without mcc/mnc/misn breakdown*/
#define FW_LOG_FORMAT_gtp_imsi_string_SIZE 				1	 /* Number Of Fields */

#define FW_LOG_FORMAT_gtp_rat_type						0x27
#define FW_LOG_FORMAT_gtp_rat_type_SIZE 				1

#define FW_LOG_FORMAT_gtp_user_location					0x2B
#define FW_LOG_FORMAT_gtp_user_location_SIZE 			1

#define FW_LOG_FORMAT_gtp_ms_time_zone					0x29
#define FW_LOG_FORMAT_gtp_ms_time_zone_SIZE 			1

#define FW_LOG_FORMAT_gtp_imei							0x28
#define FW_LOG_FORMAT_gtp_imei_SIZE 					1

#define ASM_LOG_FORMAT_mgcp_reason					0x6a	/* Format ID*/
#define ASM_LOG_FORMAT_mgcp_reason_SIZE				1		/* Number Of Fields */

#define ASM_LOG_FORMAT_aggr_aging					0x69	/* Format ID*/
#define ASM_LOG_FORMAT_aggr_aging_SIZE				3		/* Number Of Fields */

#define ASM_LOG_FORMAT_aggr_aging_mem				0x68	/* Format ID*/
#define ASM_LOG_FORMAT_aggr_aging_mem_SIZE			1		/* Number Of Fields */

#define ASM_LOG_FORMAT_sam_L2_rule_full				0x67
#define ASM_LOG_FORMAT_sam_L2_rule_full_SIZE		5

#define ASM_LOG_FORMAT_sam_L2_rule					0x66
#define ASM_LOG_FORMAT_sam_L2_rule_SIZE				2

#define ASM_LOG_FORMAT_sam_L3_rule_full				0x65
#define ASM_LOG_FORMAT_sam_L3_rule_full_SIZE		5

#define ASM_LOG_FORMAT_sam_L3_rule					0x3c
#define ASM_LOG_FORMAT_sam_L3_rule_SIZE				2

#define ASM_LOG_FORMAT_ip_reputation				0x3a
#define ASM_LOG_FORMAT_ip_reputation_SIZE			2

#define ASM_LOG_FORMAT_sdprofile					0x6f /* Format ID*/
#define ASM_LOG_FORMAT_sdprofile_SIZE				3	 /* Number Of Fields*/

#define ASM_LOG_FORMAT_sd_ext_params				0x46 /* Format ID*/
#define ASM_LOG_FORMAT_sd_ext_params_SIZE			8	 /* Number Of Fields*/

#define ASM_LOG_FORMAT_sd_update_version			0x57 /* Format ID*/
#define ASM_LOG_FORMAT_sd_update_version_SIZE		1	 /* Number Of Fields*/

#define ASM_LOG_FORMAT_sd_rule_with_id				0x58	/* Format ID*/
#define ASM_LOG_FORMAT_sd_rule_with_id_SIZE		5		/* Number Of Fields */

#define ASM_LOG_FORMAT_aggr_aging_suppression		0x47
#define ASM_LOG_FORMAT_aggr_aging_suppression_SIZE	1

#define ASM_LOG_FORMAT_sd_bypass_stressed			0x79 /* Format ID*/
#define ASM_LOG_FORMAT_sd_bypass_stressed_SIZE		3	 /* Number Of Fields*/

#define ASM_LOG_FORMAT_sd_bypass_not_stressed		0x49 /* Format ID*/
#define ASM_LOG_FORMAT_sd_bypass_not_stressed_SIZE	1	 /* Number Of Fields*/

#define ASM_LOG_FORMAT_cmi_detected_pattern			0x48
#define ASM_LOG_FORMAT_cmi_detected_pattern_SIZE	1

#define ASM_LOG_FORMAT_more_details					0x12b
#define ASM_LOG_FORMAT_more_details_SIZE			1

#define ASM_LOG_FORMAT_bypass_th_edit				0x12c
#define ASM_LOG_FORMAT_bypass_th_edit_SIZE			5


/*
 * Capture log definitions
 */
#define LOG_CAP_DISABLE		0
#define LOG_CAP_ENABLE		1

/* Allowed applications log info. */
#define ASM_LOG_FORMAT_citrix_allowed_app				0x4a
#define ASM_LOG_FORMAT_citrix_allowed_app_SIZE			1

/* Packet is too long. */
#define ASM_LOG_FORMAT_citrix_packet_too_long			0x4b
#define ASM_LOG_FORMAT_citrix_packet_too_long_SIZE		2

/* Unsupported encryption version log info. */
#define ASM_LOG_FORMAT_citrix_unsupported_enc			0xa0
#define ASM_LOG_FORMAT_citrix_unsupported_enc_SIZE		1

#define ASM_LOG_FORMAT_DOS						0x56
#define ASM_LOG_FORMAT_DOS_SIZE					2

#define ASM_LOG_FORMAT_GEOIP					0x59
#define ASM_LOG_FORMAT_GEOIP_SIZE				3

#define ASM_LOG_FORMAT_aggregated_log			0x12d
#define ASM_LOG_FORMAT_aggregated_log_SIZE		1

// performance test for logs from kernel to user space
#define FW_LOG_FORMAT_test_table_with_obf			0x1c1
#define FW_LOG_FORMAT_test_table_with_obf_SIZE		5

#define FW_LOG_FORMAT_test_table_with_out_obf		0x1c2
#define FW_LOG_FORMAT_test_table_with_out_obf_SIZE	5

#define FW_LOG_FORMAT_test_string_id			0x15c
#define FW_LOG_FORMAT_test_string_id_SIZE		2

#define FW_LOG_FORMAT_test_string_types			0x15d
#define FW_LOG_FORMAT_test_string_types_SIZE	4

#define FW_LOG_FORMAT_test_string_size_changing			0x15e
#define FW_LOG_FORMAT_test_string_size_changing_SIZE	1

#define FW_LOG_FORMAT_fw1_resource 					ADD_CPLOG_LF_LOGGING_LEVEL_FLAG(0x1e1, eLFLogingLevelHighLevelLog)
#define FW_LOG_FORMAT_fw1_resource_SIZE				2

#define TP_LOG_FORMAT_dns		        			0x1E2
#define TP_LOG_FORMAT_dns_SIZE						10

#define TP_LOG_FORMAT_ftp							0x1E3
#define TP_LOG_FORMAT_ftp_SIZE						3

#define TP_LOG_FORMAT_av_file_info					0x1E4
#define TP_LOG_FORMAT_av_file_info_SIZE	        	2

#define TP_LOG_FORMAT_smtp							0x1E5
#define TP_LOG_FORMAT_smtp_SIZE						17

#define TP_LOG_FORMAT_http							0x1E6
#define TP_LOG_FORMAT_http_SIZE						22

#define TP_LOG_FORMAT_product_name					0x1E7
#define TP_LOG_FORMAT_product_SIZE					1

#define FW_LOG_FORMAT_static_prot					0x1FA 	/* Format ID*/
#define FW_LOG_FORMAT_static_prot_SIZE				7    	/* Number Of Fields*/

#define FW_LOG_FORMAT_geo_prot						0x1FB
#define FW_LOG_FORMAT_geo_prot_SIZE					6

#define FW_LOG_FORMAT_ips_parsing_error				0x1FC
#define FW_LOG_FORMAT_ips_parsing_error_SIZE		1

/*
 * Message id's
 */
#define FWCONNOXID_MSG					0x0ff

/*
 * Reason codes
 */
#define RCODE_TCP_SERV					1
#define RCODE_UDP_SERV					2
#define RCODE_SMALL_PORT				3
#define RCODE_TCP_FASTMODE_PORT			4
#define RCODE_WRONG_HOST				5
#define RCODE_LOCAL_SPOOF				6
#define RCODE_CONN_ONEWAY				7
#define RCODE_INVALID_TCP_SIZE			8
#define RCODE_INVALID_UDP_SIZE			9
#define RCODE_LAND_ATTACK				10
#define RCODE_INVALID_ICMP_SIZE			11
#define RCODE_TCP_EST					12
#define RCODE_STREAM_VIOLATION			13
#define RCODE_ADDRESS_SPOOFING			14

/*return code for netquota kfunc (fw_netquota_check)*/
#define FW_NET_QUOTA_OK 0
#define FW_NET_QUOTA_ERROR 1
#define FW_NET_QUOTA_LIMIT_LOG 2
#define FW_NET_QUOTA_LIMIT_DONT_LOG 3

/*PSL| urgent tcp ports*/
#define URGENT_DATA_STRIP 	1
#define URGENT_DATA_INLINE 	2
#define	URGENT_DATA_RESET	3

/*
 * IPS funcs
 */
#define SPII_RECORD_CONN_MATCH_IPS		0
#define DCERPC_IPS_CODE					1
#define DCERPC_IPS_ERROR				2

/*RPC DCERPC defines*/
#define RECORD_RPC_SERVICE_PARAMS 0
#define RECORD_DCERPC_SERVICE_PARAMS 1


/*
 * Kernel functions
 */
#define KFUNC_FTPPORT					0
#define KFUNC_GETNET					1
#define KFUNC_ENCRYPT					2
#define KFUNC_DECRYPT					3
#define KFUNC_CONN_EXPIRE				4
#define KFUNC_KBUF_DUP					5
#define KFUNC_MASK_GET          		6
#define KFUNC_TABLE_NOT_EMPTY			7
#define KFUNC_IS_MY_IPADDR              8
#define KFUNC_USERC_EXPIRE      		9
#define KFUNC_KBUF_SAFE_DUP				10
#define KFUNC_TCP_ESTABLISHED			11
#define	KFUNC_XLATE_FORW				12
#define	KFUNC_XLATE_FOLD				13
#define	KFUNC_XLATE_UNFOLD				14
#define KFUNC_XLATE_ANTICIPATE			15
#define KFUNC_ADD_ACCT					16
#define KFUNC_SQLNET					17
#define KFUNC_ACCEPT_FWZ_CLEAR			18
#define	KFUNC_IS_MUT_GW					19
/* REMOVED: #define KFUNC_DYNOBJ_EXPIRE	20*/
#define KFUNC_LOAD_BALANCE              21
#define KFUNC_GET_FOLD_CLIENT			22
#define KFUNC_XLATE_PREDICT				23
#define	KFUNC_IS_IN_GW					25
#define KFUNC_FIND_STR					26
#define KFUNC_UNUSED				    27 /* KFUNC_UNUSED - was KFUNC_IS_GWCLUSTER */
#define KFUNC_DNS_FILTER				28
#define KFUNC_RECORD_CONN				29
#define KFUNC_RECORD_DATA_CONN			30
#define KFUNC_CHECK_SR_USER				31
#define KFUNC_LOG_CONN					32
#define KFUNC_BALANCE_IS_ALIVE			33
#define KFUNC_CREATE_KBUF_MSG			34
#define KFUNC_URL_LOG					35
#define KFUNC_APPLY_IP_POOL 			36
#define KFUNC_FOLLOW_H323				37
#define KFUNC_H323_SAME_GW				38
#define KFUNC_SESSION_AUTH_INVOKE		39
#define KFUNC_UFPCHECK_INVOKE			40
#define KFUNC_DT_RULE_MATCH             41
#define KFUNC_SCV_UDP_HANDLE			42
#define KFUNC_SCV_CHECK_VERIFICATION	43
#define KFUNC_CLIENT_AUTH_EXPIRE		44
#define KFUNC_GET_EXTRANET_FLAG			45
#define KFUNC_SET_VPN_COMMUNITY_ID		46
#define KFUNC_MATCH_VPN_COMMUNITY		47
#define KFUNC_GET_VPN_COMMUNITY_ID		48
#define KFUNC_FW_IS_DAG_MODULE			49
#define KFUNC_FW_MODULE_VER				50
#define KFUNC_ADDRIP6_CONVERT			51
#define KFUNC_FTP6PORT					52
#define KFUNC_IPV6_ADDR_IN_PREFIX		53
#define KFUNC_H323_FOLLOW_RAS			54
#define KFUNC_H323_RECORD_DATA_CONN		55
#define KFUNC_NOTSERVER_PORT			56
#define KFUNC_KNOWN_SERVER_PORT			57
#define KFUNC_SMALL_PORT				58
#define KFUNC_SET_BITS					59
#define KFUNC_FILL_BITS					60
#define KFUNC_SIP_MANAGER				61
#define KFUNC_XLATE_CLISIDE_SERVER		62
#define KFUNC_SCV_SEND_DROP_LOG			63
#define KFUNC_POOLED_IP_IS_SR			64
#define KFUNC_GTP_FILTER				65
#define KFUNC_GTP_CHK_CREATE_PDPC		66
#define KFUNC_GTP_ALERT					67
#define KFUNC_GTP_RUN_RULEBASE			KFUNC_RUN_RULEBASE
#define KFUNC_SIP_GET_CALLEE_IP			69
#define KFUNC_CIFS_INIT 				70
#define KFUNC_GEN_LOG					71
#define KFUNC_GET_DST_POOLED_IP			72
#define KFUNC_CLAUTH_INVOKE				73
#define KFUNC_SSH2_VERSION				74
#define KFUNC_SET_HANDLER				75
#define KFUNC_GET_UUID					76
#define KFUNC_GTP_LOG					77
#define KFUNC_GET_BITS					78
#define KFUNC_TRUNCATE_DATA				79
#define KFUNC_HEADERFILTER				80
#define KFUNC_VALIDATE_SERVICE_PORT		81
#define KFUNC_FTP_CHECK_PACKET			82
#define KFUNC_C_ICA_HANDLER				83
#define KFUNC_C_ICA_INIT_STR			84
#define KFUNC_H323_REFRESH_ANCESTORS	85
#define KFUNC_RUN_RULEBASE              86
#define KFUNC_ASM_LOG_CONN				87
#define KFUNC_DO_VPN_RULE_MATCH 		88
#define KFUNC_ALLOW_TEMPLATE_ACCEL		89
#define KFUNC_MGCP_MANAGER				90
#define KFUNC_ADD_INSPECTION			91
#define KFUNC_PARAM_GET_INT				92
#define KFUNC_PARAM_IS_TRUE				KFUNC_PARAM_GET_INT
#define KFUNC_PARAM_SEARCH_STR_HASH		93
#define KFUNC_SET_REJECT_BOTH			94
#define KFUNC_PARAM_CHECK_REGEXP		95
#define KFUNC_PARAM_SEARCH_STR_LIST		96
#define KFUNC_GEN_DYN_LOG				97
#define KFUNC_DNS_STREAM				98
#define KFUNC_PPTP_ANTICIPATE_CONN		99
#define KFUNC_DELETE_CONN				100
#define KFUNC_IS_HANDLER_MATCH			101
#define KFUNC_PARAM_GET_HANDLER			102
#define KFUNC_INCREASE_COUNTER			103
#define KFUNC_FOLD_GET_DEST_IP 			104
#define KFUNC_H323_NEW_CPAS				105
#define KFUNC_SEARCH_STR				106
#define KFUNC_FILTER_MMS                107
#define KFUNC_H323_ANTICIPATE			108
#define KFUNC_STARTRULECODE				109
#define KFUNC_SCV_CHECK_EXCLUSION		110
#define KFUNC_MCP_EXECUTE				111
#define KFUNC_SPII_INIT_S2C				112
#define KFUNC_SPII_SEARCH_PATTERN		113
#define KFUNC_IS_MY_ACCEPT_ALL_ENCRYPTED	114
#define KFUNC_FLUSH_N_ACK				115
#define KFUNC_MATCH_AV_FOLD				116
#define KFUNC_IS_FOLDED					117
#define KFUNC_IPV6_MATCH_PARTIAL		118
#define KFUNC_MARK_IPV6_INTRA_TUNNEL_INSPECTION 119
#define KFUNC_ALLOW_DROP_TEMPLATES 		120
#define KFUNC_MGCP_GET_CALLEE_IP 		121
#define KFUNC_MGCP_UNDO_EARLY_NAT_PORT	122
#define	KFUNC_IS_NOTIFY					123
#define KFUNC_EPS_ENFORCE           	124
#define KFUNC_SIP_UNDO_EARLY_NAT_PORT	125
#define KFUNC_ADD_DYN_CONTEXT			126
#define KFUNC_SD_IS_NOT_IN_EXCEPTION	127
#define KFUNC_SEARCH_REGEXP				128
#define KFUNC_MT_DYNAMIC_TABLE_RECORD	129
#define KFUNC_ZERO_MT_COUNTER			130
#define KFUNC_INCREASE_MT_COUNTER		131
#define KFUNC_DECREASE_MT_COUNTER		132
#define KFUNC_GET_MT_COUNTER			133
#define KFUNC_SD_NOT_IN_GLOBAL_WHITE_LIST	134
#define KFUNC_BF_REPORT_EVENT			135
#define KFUNC_BF_CHECK_ATTACK			136
#define KFUNC_MSN_OVER_HTTP_PARSER		137
#define KFUNC_DOS_FIRST_PACKET			138
#define KFUNC_NET_QUOTA_CHECK 			139
#define KFUNC_ASPAM_CHECK_SYN			140
#define KFUNC_ASPAM_MATCH				141
#define KFUNC_SET_FLAG_MT_COUNTER		142
#define KFUNC_CMI_ADD_INSPECT_TO_CONTEXT	143
#define KFUNC_IS_CONNECTRA_PORTAL_AV		144
#define KFUNC_CONNECTRA_ENABLED			145
#define KFUNC_GET_PARENT_DPORT			146
#define KFUNC_FG_IS_URL_ENABLED			147
#define KFUNC_FW_NAC_KFUNC_ENTRY		148
#define KFUNC_GET_INTERFACE_TYPE		149
#define KFUNC_ADD_DYN_CONTEXT_WITH_SESSION	150
#define KFUNC_CSI_DEL_SESSION			151
#define KFUNC_CSI_CLONE_SESSION			152
#define KFUNC_HTTPS_INSPECTION_RB_MATCH 153
#define KFUNC_DNSTUNNEL_DETECT_EX			154
#define KFUNC_IS_HTTP_PROXY_CONN		155
#define KFUNC_APPI_ENABLED_ON_DATA_CONN		156
#define KFUNC_CMIK_LOADER_UPDATE_IREG_ARRAY	157
#define KFUNC_UA_MANAGER				158
#define KFUNC_GET_IFADDR				159
#define KFUNC_GET_FROM_TABLE			160
#define KFUNC_GET_FROM_TABLE_W_OFFSET	161
#define KFUNC_MAKE_IPV6_MASK			162
#define KFUNC_RUN_IPS_CODE				ERROR_DEPRECATED_IN_ZURICH_DO_NOT_USE
#define KFUNC_IS_IN_TABLE				164
#define KFUNC_TE_IS_INTERNAL_CONN		165
#define KFUNC_RECORD_MULTI_SERVICES_RELATED_PARAMS 166
#define KFUNC_IPS_PROTECTION_ACTION		167
#define KFUNC_NEEDS_SYNC_ACK			168
#define KFUNC_CMIK_LOADER_EXECUTE_CMI	169
#define KFUNC_GET_IPS_DYNATTR			170
#define KFUNC_GET_CONTEXT_STATUS		171
#define KFUNC_IPS_GEN_STATIC_LOG		172
#define KFUNC_DYNOBJ_IP_RANGES			173
#define KFUNC_DIAMETER_PACKET_FILTER	174
#define KFUNC_FW_HANDLERS_SET_OUTBOUND_PARAMS	175

#ifdef SFW
#define KFUNC_IS_INTERNAL_INTERFACE 176
#define KFUNC_SFW_CHECK_ACCESS_POLICY 177
#define KFUNC_IS_WEBUI_PORT 178
#define KFUNC_IS_BRIDGE_INTERFACE 179
#define KFUNC_IS_QUOTA_EXCEEDED 180
#define KFUNC_DST_INTF 181
#define KFUNC_FWMODE_INTERNAL_TRAFFIC 182
#define KFUNC_SYSTEM_ZONE 183
#define KFUNC_IS_CLUSTER_IP 184
#define KFUNC_SFW_IS_IDA_PORTAL_NEEDED 185
#define KFUNC_IS_DST_TRANSLATED 186
#endif

/* Event App */
#define EAPP_LOG_FORMAT_dns		        	0x1E2
#define EAPP_LOG_FORMAT_ftp					0x1E3
#define EAPP_LOG_FORMAT_av_file_info		0x1E4
#define EAPP_LOG_FORMAT_smtp				0x1E5
#define EAPP_LOG_FORMAT_http				0x1E6
#define EAPP_LOG_FORMAT_product_name		0x1E7

#endif /* __traps_h__ */

#ifndef __kerntabs_h__
#define __kerntabs_h__

/*
 * (c) Copyright 1993-2015 Check Point Software Technologies Ltd.
 * All rights reserved.
 *
 * This is proprietary information of Check Point Software Technologies
 * Ltd., which is provided for informational purposes only and for use
 * solely in conjunction with the authorized use of Check Point Software
 * Technologies Ltd. products.  The viewing and use of this information is
 * subject, to the extent appropriate, to the terms and conditions of the
 * license agreement that authorizes the use of the relevant product.
 *
 *
 */

#ifndef __INSPECT__
#include "kerntabs_ranges.h"
#endif

/* ######################################################################################
 *
 * IDs of special kernel tables (FWMAXTABS=16384)
 * Table IDs should be in between FW_TABLES_LOW_ID and FW_TABLES_HIGH_ID (7940 - 9000)
 * FW_TABLE_FIRST and FW_TABLE_LAST should be updated when a new ID is added.
 *
 * ######################################################################################
 */


#ifndef SFW
#define FW_TABLE_FIRST									8197
#else
#define NON_SFW_TABLE_FIRST								8197
#define FW_TABLE_FIRST									(NON_SFW_TABLE_FIRST+16)
#endif



#ifdef SFW

#define SSL_BYPASS_BY_MAC_TABLE_ID 			 (NON_SFW_TABLE_FIRST+17)
#define SSL_BYPASS_BY_MAC_TABLE_NAME 		     "ssl_bypass_by_mac_table"

#define IOT_STATS_ACTIVE_DEVICES_TABLE_ID			 (NON_SFW_TABLE_FIRST+16)
#define IOT_STATS_ACTIVE_DEVICES_TABLE_NAME		     "iot_stats_active_devices_table"

#define IOT_STATS_FILTER_TABLE_ID					(NON_SFW_TABLE_FIRST+15)
#define IOT_STATS_FILTER_TABLE_NAME					"iot_stats_filter_table"


/* SOFIA: Add more SFW tables here, update FW_TABLE_FIRST accordingly */

#define FWHOST_MONITOR_LAST_SEEN_TABLE_ID	(NON_SFW_TABLE_FIRST+14)

#define FWTRAFFIC_MONITOR_SESSIONS_TABLE_ID	(NON_SFW_TABLE_FIRST+13)

#define SFW_ACCESS_POLICY_INFO_TABLE_ID			(NON_SFW_TABLE_FIRST+12)
#define SFW_ACCESS_POLICY_INFO_TABLE_NAME		"sfw_access_policy_srcs"

#ifdef FW_MISP
#define FWPBR_IPRULE_TABLE_NAME					"pbr_iprule"
#endif

#define FWHOST_MONITOR_TABLE_ID				(NON_SFW_TABLE_FIRST+11)

#define SFW_HOTSPOT_SESSIONS_TABLE_ID			(NON_SFW_TABLE_FIRST+10)
#define SFW_HOTSPOT_SESSIONS_TABLE_NAME		"sfw_hotspot_sessions"


#define SFW_WIFI_ADMIN_ACCESS_TABLE_ID			(NON_SFW_TABLE_FIRST+9)
#define SFW_WIFI_ADMIN_ACCESS_TABLE_NAME		"sfw_wifi_admin_access"

#define SFW_FOLD_RULES_TABLE_ID					(NON_SFW_TABLE_FIRST+8)
#define SFW_FOLD_RULES_TABLE_NAME				"sfw_fold_rules"

#define FWEMAIL_AVSI_SESSIONS_TABLE_ID			(NON_SFW_TABLE_FIRST+7)
#define FWEMAIL_AVSI_SESSIONS_TABLE_NAME		"fwemail_avsi_sessions"

#define SFW_HOTSPOT_EXCEPTIONS_TABLE_ID		(NON_SFW_TABLE_FIRST+6)
#define SFW_HOTSPOT_EXCEPTIONS_TABLE_NAME		"sfw_hotspot_exceptions"

#define MAL_STAT_COUNTERS_TABLE_ID	(NON_SFW_TABLE_FIRST+5)
#define MAL_STAT_COUNTERS_TABLE_NAME "mal_stat_counters"

#define SFW_HOTSPOT_DST_EXCEPTIONS_TABLE_ID		(NON_SFW_TABLE_FIRST+4)
#define SFW_HOTSPOT_DST_EXCEPTIONS_TABLE_NAME		"sfw_hotspot_dst_exceptions"

#define SFW_MAC_FILTERING_TABLE_ID				(NON_SFW_TABLE_FIRST+3)
#define SFW_MAC_FILTERING_TABLE_NAME			"sfw_mac_filtering_table"

#define SW_8021X_AUTH_REQUESTS_TABLE_ID			(NON_SFW_TABLE_FIRST+2)
#define SW_8021X_AUTH_REQUESTS_TABLE_NAME 		"sfw_8021x_requests"

#define SW_8021X_MAC_TABLE_ID					(NON_SFW_TABLE_FIRST+1)
#define SW_8021X_MAC_TABLE_NAME 				"sfw_8021x_MACs"

#define SFW_BL_MAC_FILTERING_TABLE_NAME			"sfw_bl_mac_filtering_table"

#endif

#define FWX_PORT_EXHAUSTION_TABLE_ID					8197
#define FWX_PORT_EXHAUSTION_TABLE_NAME					"fwx_port_exhaustion"

#define CPTLS_HOST_NAME_CACHE_TABLE_ID						8196
#define CPTLS_HOST_NAME_CACHE_TABLE_NAME				"cptls_host_name_cache"

#ifdef HIGH_AVAIL
#define FWHA_HA_FAILOVER_COUNTER_TABLE_ID				8195
#define FWHA_HA_FAILOVER_COUNTER_TABLE_NAME				"failover_counter_table"
#endif

#define FW_TAB_TMPL_BLACKLISTED_IP_TABLE_ID				8194
#define FW_TAB_TMPL_BLACKLISTED_IP_TABLE_NAME			"tmpl_blacklisted_ip"

#define UP_COMPOUND_CLOB_LIST_CACHE_TABLE_ID	8193
#define UP_COMPOUND_CLOB_LIST_CACHE_TABLE_NAME "up_compound_clob_list_cache"

#define UP_OFFLINE_RULEBASE_EXEC_TABLE_ID	8192
#define UP_OFFLINE_RULEBASE_EXEC_TABLE_NAME "up_offline_rulebase_exec_data"

#define WS_PROXY_CONN_POOL_TABLE_ID	       				8191
#define WS_PROXY_CONN_POOL_TABLE_TABLE_NAME				"ws_proxy_srv_conn"

#define FWDOM_TABLE_ID									8190
#define FWX_FORW_TABLE_ID								8189
/*#define FWX_BACKW_TABLE_ID					8188 unused*/
#define FWX_ALLOC_TABLE_ID								8187
#define FWX_ARP_TABLE_ID								8186
#define FWLIC_TABLE_ID									8185
#define FWFRAG_TABLE_ID									8184
#define FWHOLD_TABLE_ID									8183
#define FWESTAB_TABLE_ID								8182

#define CMI_LOADER_DYN_PARSERS_PROTO_VIOL_TABLE_ID		8181
#define CMI_LOADER_DYN_PARSERS_PROTO_VIOL_TABLE_NAME	"parsers_is_proto_viol_map"
#define CMI_LOADER_DYN_PARSERS_ACCEL_TABLE_ID			8180
#define CMI_LOADER_DYN_PARSERS_ACCEL_TABLE_NAME			"parsers_is_accel_map"

/*#define FWSKIP_CONN_TABLE_ID					8179  unused*/
#define FW_OUT_MAC_ADDRS_TABLE_ID			            8178
#define FWHOST_IP_ADDRS									8177
/*#define FWMANUAL_TABLE_ID						8176  unused*/
/*#define FWX_FRAG_TABLE_ID						8175  unused*/
#define FWX_AUTH_TABLE_ID								8174
#define FWSYNATK_TABLE_ID								8173
#define FWH323_TABLE_ID             					8172
/*#define FWSKIP_KEYID_ID						8171  unused*/
/*#define FW_INBOUND_SPI_TABLE_ID				8170  unused*/
#ifdef HIGH_AVAIL
#define FWHA_FAILOVER_HISTORY_TABLE_ID						8169
#define FWHA_FAILOVER_HISTORY_TABLE_NAME 					"failover_history"
#endif
/*#define FW_SA_REQUESTS_TABLE_ID				8168  unused*/
/*#define FW_ISAKMP_AH_TABLE_ID					8167  unused*/
/*#define FW_CRYPTLOG_TABLE_ID					8166  unused*/
/*#define FW_IPSEC_USERC_DONT_TRAP_TABLE_ID		8165  unused*/
/*#define FWBRIDGE_TABLE_ID						8164  unused*/
/*#define FW_IPSEC_SHORTCUT_TABLE_ID			8163  unused*/
/*#define FWX_DYN_CONN_TABLE_ID					8162  unused*/
#define FWX_CTL_DYN_TABLE_ID							8161
/*#define FW_OUTBOUND_SPI_TABLE_ID				8160  unused*/
/*#define FW_IKE_SA_TABLE_ID					8159  unused*/
#define FW_CONNECTIONS_TABLE_ID							8158

#define FW_PARENT_CONN_TABLE_ID							8157
#define FW_PARENT_CONN_TABLE_NAME						"parent_conn"

#define FW_SON_CONNS_TABLE_ID							8156
#define FW_SON_CONNS_TABLE_NAME							"son_conns"

/*#define FWBB_RT_MAC_TABLE_ID					8155  unused*/
/*#define FWBB_RT_IP_TABLE_ID					8154  unused*/
/*#define FWBB_ARP_REQ_TAB_ID					8153  unused*/

#define FW_NRB_HITCOUNT_TABLE_ID						8152
#define FW_NRB_HITCOUNT_TABLE_NAME						"nrb_hitcount_table"

/*#define FW_CRYPTLOG_KBUF_TABLE_ID				8151  unused*/
/*#define FW_SR_UDP_ENC_GWS_TABLE_ID 			8150  unused*/
/*#define FW_SR_UDP_ENC_CLIENTS_TABLE_ID		8149  unused*/
/*#define FW_USERC_PENDING_TABLE_ID				8148  unused*/
#define FW_SAVED_KBUF_TABLE_ID							8147

#define FW_WS_PROTECTION_SCHEME_TABLE_ID				8146
#define FW_WS_PROTECTION_SCHEME_TABLE_NAME				"ws_protection_scheme_table"

#define FW_SPII_MULTI_PSET2KBUF_ID						8145
#define FW_SPII_MULTI_PSET2KBUF_NAME					"spii_multi_pset2kbuf_map"

#define FW_SPII_GLOBAL_PSET2KBUF_ID						8144
#define FW_SPII_GLOBAL_PSET2KBUF_NAME					"spii_global_pset2kbuf_map"

/*#define FW_TCP_STREAMS_TABLE_ID				8143  unused*/
/*#define FW_HA_FORWARD_TABLE_ID				8142  unused*/
#define FWSAM_BLOCKED_IPS_TABLE_ID						8141
#define FWSAM_REQUEST_TABLE_ID							8140
#define FWSAM_STATE_TABLE_ID							8139
#define FWSAM_NETMASK_TABLE_ID							8138
#define FWSAM_LOG_TABLE_ID								8137

/*#define FW_NRB_ASYNC_PENDING_TABLE_ID			8136  unused*/
/*#define FW_NRB_ASYNC_PENDING_TABLE_NAME		"nrb_async_pending_table"  unused*/

#define FWSCV_GW_TABLE_ID								8134
#define FWSCV_GW_TABLE_NAME								"scv_gw_table"

#define FWSCV_PS_TABLE_ID								8133
#define FWSCV_PS_TABLE_NAME								"scv_ps_table"

#define FW_PACKET_HASH_TABLE_ID							8132
#define FWX_PENDING_TABLE_ID							8131

#define FW_CHAIN_LOG_UNIFICATION_TABLE_ID				8130
#define FW_CHAIN_LOG_UNIFICATION_TABLE_NAME				"chain_log_unification_table"

#define FW_CONN_INFO_TABLE_ID							8129
#define FW_CONN_INFO_TABLE_NAME							"conn_info"

#define FW_TAB_UNCOMMITTED_NAME_TABLE_ID				8128
#define FW_TAB_UNCOMMITTED_NAME_TABLE_NAME				"Uncommitted_tab_name_table"

#define FWSCV_HELD_PACKETS_TABLE_ID						8127
#define FWSCV_HELD_PACKETS_TABLE_NAME					"scv_held_packets_table"

#define FWEXCSV_TABLE_ID								8126
#define FWEXCSV_TABLE_NAME								"excessive_table"

#define FWHOST_IP_ADDRS_ALL_ID							8125
#define FWHOST_IP_ADDRS_ALL_NAME						"host_ip_addrs_all"

#define CPHWD_DEV_IDENTITY_TABLE_ID						8124
#define CPHWD_VPNDB_TABLE_ID							8123
#define CPHWD_DB_TABLE_ID								8122
#define CPHWD_TIMER_DB_TABLE_ID             			8121
#define CPHWD_DEV_CONN_TABLE_ID             			8120

#define FWX_DHCP_RELAY_TABLE_ID			    			8119

#define FWH323_GATEKEEPER_PENDING_TABLE_ID				8118
#define FW_CONN_REDIRECTED_CONNS_TABLE_ID				8117
#define FWX_CACHE_TABID									8116

/* 8115 free */

#define FW_TAB_NAME_TABLE_ID							8114
#define FW_TAB_NAME_TABLE_NAME							"tab_name_table"

#define FW_UID_2_KBUF_TAB_ID							8113
#define FW_UID_2_KBUF_TAB_NAME							"uid2kbuf"

#define FW_RULES_UID_NEW_TABLE_ID						8112
#define FW_RULES_UID_NEW_TABLE_NAME						"rules_uid_new_table"

#define CPHWD_DB_TEMPLATE_TABLE_ID						8111

#define FWH323_REGISTRATION_TABLE_ID					8110

#ifdef HIGH_AVAIL
#define FW_HA_PIVOT_TABLE_ID							8109
#define FW_HA_PIVOT_TABLE_NAME							"pivot_select_table"
#endif

#define FWMISP_CACHE_TABLE_ID							8108

#define CPAS_PMTU_ID									8107
#define CPAS_COOKIE_HASH								8106

#define FWTAB_CHUNK_ITERATOR_TABLE_ID					8105
#define FWTAB_CHUNK_ITERATOR_TABLE_NAME					"tab_iterators_table"

#define FWPORTSCN_ACCESSED_PORTS_TABLE_ID 				8103
#define FWPORTSCN_ACCESSED_PORTS_TABLE_NAME 			"portscn_accessed_ports_table"
#define FWPORTSCN_VERTICAL_PORT_COUNT_TABLE_ID 			8102
#define FWPORTSCN_VERTICAL_PORT_COUNT_TABLE_NAME 		"portscn_vertical_port_count"
#define FWPORTSCN_HORIZONTAL_PORT_COUNT_TABLE_ID 		8101
#define FWPORTSCN_HORIZONTAL_PORT_COUNT_TABLE_NAME 		"portscn_horizontal_port_count"
#ifdef FW_IPV6
#define FWPORTSCN_VERTICAL_HOST_EXCLUDE_TABLE_NAME 		"fwportscn_vertical_exclude6"
#else
#define FWPORTSCN_VERTICAL_HOST_EXCLUDE_TABLE_NAME		"fwportscn_vertical_exclude"
#endif
#define FWPORTSCN_HORIZONTAL_PORT_EXCLUDE_TABLE_NAME	"fwportscn_horizontal_exclude"

#define FWSTRMAP_TABLE_ID								8100
#define FWSTRMAP_TABLE_NAME								"strmap_table"

#define FW_RESET_COUNT_TABLE_ID							8099
#define FW_RESET_COUNT_TABLE_NAME						"rst_count_table"

#define DNS_CONN_NOK_TABLE_ID		       				8098
#define DNS_CONN_NOK_TABLE_NAME 						"dns_nok_connections"


/*#define FW_TAB_IRPQ_ID					8097	unused*/

#define FWMISP_DNS_PACKETS_ID							8096

#define FW_DBG_TRACE_CONN_TABLE_ID          			8095
#define FW_DBG_TRACE_CONN_TABLE_NAME        			"dbg_trace_conn"

#define FW_CLOSED_CONNS_TABLE_ID            			8094
#define FW_CLOSED_CONNS_TABLE_NAME          			"closed_conns"

#define	CPHWD_ANT_DB_TABLE_ID							8093

#define FW_MRT_SYNC_ID									8092
#define FW_MRT_SYNC_NAME								"mrt_sync_table"

#define GEOLOCATION_BLOCK_COUNTIES_IPS_TABLE_ID			8091
#define GEOLOCATION_BLOCK_COUNTIES_IPS_TABLE_NAME		"geolocation_block_static_table"

#define FWSAM_L2_SRC_DST_REQUEST_TABLE_ID				8090
#define FWSAM_UID_TABLE_ID								8089
#define FWSAM_REQUEST_V2_TABLE_ID						8088
#define FWSAM_BLOCKED_IPS_V2_TABLE_ID					8087
#define FWSAM_L2_REQUEST_TABLE_ID						8086

#define FW_INTEGRITY_REQUESTS_TABLE_ID      			8085
#define FW_INTEGRITY_REQUESTS_TABLE_NAME    			"integrity_requests"
#define FW_INTEGRITY_STATUS_TABLE_ID        			8084
#define FW_INTEGRITY_STATUS_TABLE_NAME      			"integrity_clients_status"

#define FW_MSN_CMD_TAB_ID								8083
#define FW_MSN_CMD_TAB_NAME								"fw_msn_cmd"
#define FW_MSN_VERSION_TAB_ID							8082
#define FW_MSN_VERSION_TAB_NAME 						"fw_msn_version"

#define FWMULTIK_LOCAL_QUOTA_TAB_ID						8079
#define FWMULTIK_LOCAL_QUOTA_TAB_NAME					"fwmultik_local_quota"

#define	ADVP_MASK_TAB_LAST							8078
#define ADVP_TCP_RANGE_C2S_TABLE_ID						8078
#define ADVP_TCP_RANGE_C2S_TABLE_NAME					"advp_tcp_range_c2s_pm_masks_tab"
#define ADVP_TCP_RANGE_S2C_TABLE_ID						8077
#define ADVP_TCP_RANGE_S2C_TABLE_NAME					"advp_tcp_range_s2c_pm_masks_tab"
#define ADVP_UDP_RANGE_C2S_TABLE_ID						8076
#define ADVP_UDP_RANGE_C2S_TABLE_NAME					"advp_udp_range_c2s_pm_masks_tab"
#define ADVP_UDP_RANGE_S2C_TABLE_ID						8075
#define ADVP_UDP_RANGE_S2C_TABLE_NAME					"advp_udp_range_s2c_pm_masks_tab"
#define ADVP_MASK_TAB_FIRST							8075

#define ICAP_CLIENT_CONNS_TABLE_ID                      8074
#define ICAP_CLIENT_CONNS_TABLE_NAME                    "icap_client_conns_timeout_table"


#ifdef HIGH_AVAIL
#define FW_HA_FAILOVER_TABLE_ID							8073
#define FW_HA_FAILOVER_TABLE_NAME						"failover_table"
#endif

#define FWMULTIK_LD_GCONN_DUMP_TABLE_SECTION_ID			8072
#define FWMULTIK_LD_GCONN_DUMP_TABLE_SECTION_NAME		"fwmultik_gconn_dmp_sec"

#define FWMULTIK_LD_GCONN_DUMP_TABLE_ID 				8071
#define FWMULTIK_LD_GCONN_DUMP_TABLE_NAME				"fw_multik_ld_gconn_table"


#define HTTPS_INSPECTION_HOLD_TAB_ID					8069
#define HTTPS_INSPECTION_HOLD_TAB_NAME					"https_inspection_hold_tab"

#define CVPND_PORTAL_LOGIN_ATTEMPTS_TABLE_ID			8070
#define CVPND_PORTAL_LOGIN_ATTEMPTS_TABLE_NAME			"cvpn_portal_login_attempts"

#define FWZONE_ASSERTION_TABLE_ID      					8068

#define FW_MTCOUNTER_SYNC_HTAB_TABLE_ID					8066
#define FW_MTCOUNTER_SYNC_HTAB_TABLE_NAME				"fw_mtcounter_sync_htab_table"

#define CVPND_SESSION_TABLE_ID							8065
#define CVPND_SESSION_TABLE_NAME						"cvpn_session"

#define CVPND_EXPIRED_SESSION_TABLE_ID					8064
#define CVPND_EXPIRED_SESSION_TABLE_NAME				"cvpn_expired_session"

#define CVPND_USER_SETTINGS_TABLE_ID					8063
#define CVPND_USER_SETTINGS_TABLE_NAME					"cvpn_user_settings"

#define CVPND_SNX_SESSION_TABLE_ID						8062
#define CVPND_SNX_SESSION_TABLE_NAME					"cvpn_snx_session"

#define CVPND_ACTIVE_SESSION_TABLE_ID					8061
#define CVPND_ACTIVE_SESSION_TABLE_NAME					"cvpn_active_session"

#define CVPND_ICS_SCAN_RESULT_XML_TABLE_ID				8060
#define CVPND_ICS_SCAN_RESULT_XML_TABLE_NAME			"cvpn_ics_scan_result_xml"

#define CVPND_ACTIVE_SYNC_DEVICES_TABLE_ID				8059
#define CVPND_ACTIVE_SYNC_DEVICES_TABLE_NAME			"cvpn_active_sync_devices"

#define CVPND_CERT_TO_SESSIONS_TABLE_ID					8058
#define CVPND_CERT_TO_SESSIONS_TABLE_NAME				"cvpn_cert_to_sessions"

#define CVPND_PENDING_WIPE_ID_TABLE_ID					8057
#define CVPND_PENDING_WIPE_ID_TABLE_NAME				"cvpn_pending_wipe_id"

#define CVPND_MOB_SESSION_TABLE_ID						8056
#define CVPND_MOB_SESSIONS_TABLE_NAME					"mob_session"

#define FWMULTIK_ANTICIPATED_USERMODE_CONNS_TABLE_ID	8055
#define FWMULTIK_ANTICIPATED_USERMODE_CONNS_TABLE_NAME	"fwmultik_anticipated_usermode"

#define FW_SOCKSTRESS_ATTACKERS_TABLE_ID				8054
#define FW_SOCKSTRESS_LOCAL_TABLE_ID					8053
#define FW_SOCKSTRESS_TABLE_ID							8052
#define FW_SOCKSTRESS_BLOCK_TABLE_ID					8051

#define CPHWD_DEV_REVOKED_IPS_TABLE_ID					8050

#define MULTIPORTAL_PORTS_TABLE_ID         				8049
#define MULTIPORTAL_PORTS_TABLE_NAME       				"multiportal_ports"

#define TCPT_INSTANCE_ID		        				8048
#define TCPT_INSTANCE_NAME	           					"tcpt_instance"

#define FW_UID_2_KBUF_TEMP_TAB_ID						8047
#define FW_UID_2_KBUF_TEMP_TAB_NAME						"uid2kbuf_temp"

#define CMI_LOADER_SAA_SKIP_TABLE_ID					8046
#define CMI_LOADER_SAA_SKIP_TABLE_NAME					"cmi_loader_stop_and_accept_skip_map"

#define DLP_SESSIONS_TABLE_ID							8045
#define DLP_SESSIONS_TABLE_NAME							"dlp_sessions"

#define CMI_LOADER_SKIP_MAP_TABLE_ID					8044
#define CMI_LOADER_SKIP_MAP_TABLE_NAME					"cmi_loader_skip_val_map"

/* advanced patterns, usermode temp transfer tables */
#define ADVP_TEMP_TCP_PORT_RANGE_C2S_TABLE_ID			8043
#define ADVP_TEMP_TCP_PORT_RANGE_C2S_TABLE_NAME			"advp_port_range_tcp_c2s"
#define ADVP_TEMP_TCP_PORT_RANGE_S2C_TABLE_ID			8042
#define ADVP_TEMP_TCP_PORT_RANGE_S2C_TABLE_NAME			"advp_port_range_tcp_s2c"
#define ADVP_TEMP_UDP_PORT_RANGE_C2S_TABLE_ID			8041
#define ADVP_TEMP_UDP_PORT_RANGE_C2S_TABLE_NAME			"advp_port_range_udp_c2s"
#define ADVP_TEMP_UDP_PORT_RANGE_S2C_TABLE_ID			8040
#define ADVP_TEMP_UDP_PORT_RANGE_S2C_TABLE_NAME			"advp_port_range_udp_s2c"

#define ADVP_TEMP_TCP_IP_RANGE_C2S_TABLE_ID				8039
#define ADVP_TEMP_TCP_IP_RANGE_C2S_TABLE_NAME			"advp_temp_ip_range_tcp_c2s"
#define ADVP_TEMP_TCP_IP_RANGE_S2C_TABLE_ID				8038
#define ADVP_TEMP_TCP_IP_RANGE_S2C_TABLE_NAME			"advp_temp_ip_range_tcp_s2c"
#define ADVP_TEMP_UDP_IP_RANGE_C2S_TABLE_ID				8037
#define ADVP_TEMP_UDP_IP_RANGE_C2S_TABLE_NAME			"advp_temp_ip_range_udp_c2s"
#define ADVP_TEMP_UDP_IP_RANGE_S2C_TABLE_ID				8036
#define ADVP_TEMP_UDP_IP_RANGE_S2C_TABLE_NAME			"advp_temp_ip_range_udp_s2c"

/* advanced patterns live ip ranges tables */
#define ADVP_MASK_TAB_IP_LAST						8035
#define ADVP_TCP_IP_RANGE_C2S_TABLE_ID					8035
#define ADVP_TCP_IP_RANGE_C2S_TABLE_NAME				"advp_ip_range_tcp_c2s"
#define ADVP_TCP_IP_RANGE_S2C_TABLE_ID					8034
#define ADVP_TCP_IP_RANGE_S2C_TABLE_NAME				"advp_ip_range_tcp_s2c"
#define ADVP_UDP_IP_RANGE_C2S_TABLE_ID					8033
#define ADVP_UDP_IP_RANGE_C2S_TABLE_NAME				"advp_ip_range_udp_c2s"
#define ADVP_UDP_IP_RANGE_S2C_TABLE_ID					8032
#define ADVP_UDP_IP_RANGE_S2C_TABLE_NAME				"advp_ip_range_udp_s2c"
#define ADVP_MASK_TAB_IP_FIRST						8032

/* Failed SMTP connections table */
#define FWDLP_FAILED_SMTP_CONNS_TABLE_ID				8031
#define FWDLP_FAILED_SMTP_CONNS_TABLE_NAME				"dlp_failed_smtp_conns"

#define DLPK_SESSION_TABLE_ID							8030
#define DLPK_SESSION_TABLE_NAME							"dlpk_session_table"

#define DLP_FOLDING_TAB_ID								8029
#define DLP_FOLDING_TAB_NAME							"DLP_folding_tab"

#define DLP_EXCLUSION_TAB_ID							8028
#define DLP_EXCLUSION_TAB_NAME							"DLP_exclusion_tab"

/* mapping of parsers and cmi_apps registered to it */
#define CMI_LOADER_PARSER_APPS_TABLE_ID					8027
#define CMI_LOADER_PARSER_APPS_TABLE_NAME				"cmi_loader_parser_apps"

/* Appi sync ghtab table */
#define APPI_SYNC_HTAB_TABLE_ID							8026
#define APPI_SYNC_HTAB_TABLE_NAME						"appi_sync_htab_table"
#define FW_IPV6_SERIALIZE_ID							8025
#define FW_IPV6_SERIALIZE_NAME							"ipv6_serialization"

/* Contains pointers to av session data for sessions which are still being processed by the user mode */
#define AV_UM_HASH_TAB_ID								8024
#define AV_UM_HASH_TAB_NAME								"AV_UM_pending_sessions_hash_tab"

/* Tables added for blades statistics */
#define FWRULE_COUNT_TABLE_ID							8023
#define FWRULE_COUNT_TABLE_NAME							"rule_count"

#define SD_STATS_PROT_COUNT_TABLE_ID	    			8022
#define SD_STATS_PROT_COUNT_TABLE_NAME	    			"sd_stats_prot_count"

#define FWSERVICE_COUNT_TABLE_ID						8021
#define FWSERVICE_COUNT_TABLE_NAME						"service_count"
/* END (Tables added for blades statistics) */

/* dlp My Org folding tables */
#define DLP_MY_ORG_FOLDING_TAB_ID						8020
#define DLP_MY_ORG_FOLDING_TAB_NAME						"DLP_my_org_folding_tab"
#define DLP_MY_ORG_EXCLUSION_TAB_ID						8019
#define DLP_MY_ORG_EXCLUSION_TAB_NAME					"DLP_my_org_exclusion_tab"

/* dlp redirection white list table */
#define DLP_SRC_REDIRECTION_WHITE_LIST_TAB_ID			8018
#define DLP_SRC_REDIRECTION_WHITE_LIST_TAB_NAME			"DLP_SRC_rd_white_list_tab"
#define DLP_DST_REDIRECTION_WHITE_LIST_TAB_ID			8017
#define DLP_DST_REDIRECTION_WHITE_LIST_TAB_NAME			"DLP_DST_rd_white_list_tab"

#define FILEAPP_PARTIAL_FILES_CACHE_TAB_ID				8016
#define FILEAPP_PARTIAL_FILES_CACHE_TAB_NAME			"fileapp_partial_files_cache_tab"

#define UP_MANAGER_HOLD_TAB_ID              			8015
#define UP_MANAGER_HOLD_TAB_NAME            			"up_manager_hold_tab"

#define FILEAPP_UPLOAD_FILES_CACHE_TAB_ID				8014
#define FILEAPP_UPLOAD_FILES_CACHE_TAB_NAME				"fileapp_files_cache_tab"

#define FILEAPP_UPLOAD_HASH_TAB_ID                      8013
#define FILEAPP_UPLOAD_HASH_TAB_NAME                    "fileapp_upload_pending_sessions"

#define CMI_STREAMING_APP_HOLD_OPAQUE_TABLE_ID			8012
#define CMI_STREAMING_APP_HOLD_OPAQUE_TABLE_NAME 		"cmi_streaming_app_hold_opaque"

#define FA_FREE_DISK_SPACE_TABLE_ID	       				8011
#define FA_FREE_DISK_SPACE_TABLE_NAME					"fa_free_disk_space"

#define OS_CACHE_TABLE_ID								8010
#define OS_CACHE_TABLE_NAME								"os_cache"

#define MAL_CONN_TABLE_ID								8009
#define MAL_CONN_TABLE_NAME								"mal_conns"

#define MAL_DNS_INFO_TABLE_ID							8008
#define MAL_DNS_INFO_TABLE_NAME							"mal_dns_info"

#define MAL_STAT_SRC_HR_TABLE_ID						8007
#define MAL_STAT_SRC_HR_TABLE_NAME						"mal_stat_src_hour"
#define MAL_STAT_SRC_DY_TABLE_ID						8006
#define MAL_STAT_SRC_DY_TABLE_NAME						"mal_stat_src_day"
#define MAL_STAT_SRC_WK_TABLE_ID						8005
#define MAL_STAT_SRC_WK_TABLE_NAME						"mal_stat_src_week"

#define MAL_STAT_NAMES_HR_TABLE_ID						8004
#define MAL_STAT_NAMES_HR_TABLE_NAME					"mal_stat_names_hour"
#define MAL_STAT_NAMES_DY_TABLE_ID						8003
#define MAL_STAT_NAMES_DY_TABLE_NAME					"mal_stat_names_day"
#define MAL_STAT_NAMES_WK_TABLE_ID						8002
#define MAL_STAT_NAMES_WK_TABLE_NAME					"mal_stat_names_week"

#define MAL_STAT_VALS_TABLE_ID							8001
#define MAL_STAT_VALS_TABLE_NAME						"mal_stat_vals"

#define CPAS_PENDING_OPQ_DB_TABLE_ID					8000
#define CPAS_PENDING_OPQ_DB_TABLE_NAME					"cpas_pending_opq_db"

#define CMIK_LOADER_SYNC_HTAB_TABLE_ID					7999
#define CMIK_LOADER_SYNC_HTAB_TABLE_NAME				"cmik_loader_sync_htab_table"

/* Vacant 7998 */

#define FWASPAM_SCANNED_MAILS_ID						7997
#define FWASPAM_SCANNED_MAILS_NAME						"aspam_scanned_mails"

#define FWHA_FDB_SHADOW_TABLE_ID						7996
#define FWHA_FDB_SHADOW_TABLE_NAME						"fdb_shadow"

#define FW_SIP_RATE_LIMITING_TAB_ID						7995
#define FW_SIP_RATE_LIMITING_TAB_NAME					"sip_rate_limiting_table"

#define CPTLS_SERVER_CN_CACHE_TABLE_ID					7994
#define CPTLS_SERVER_CN_CACHE_TABLE_NAME				"cptls_server_cn_cache"

#define RAD_KERNEL_PENDING_REQUEST_TABLE_ID    			7993
#define RAD_KERNEL_PENDING_REQUEST_TABLE_NAME 			"rad_kernel_pending_request"

#define CMI_UM_TIMEOUT_TABLE_ID							7992
#define CMI_UM_TIMEOUT_TABLE_NAME						"cmi_um_timeout"

/* Contains pointer to dlpda_slowpath's application for files which are still being processed by the user mode */
#define DLPDA_SLOWPATH_HASH_TAB_ID						7991
#define DLPDA_SLOWPATH_HASH_TAB_NAME					"dlpda_slowpath_pending_sessions_hash_tab"

#define UP_RULEBASE_CLOB_SCHEME_CACHE_TBL_ID			7990

#define FW_BRIDGE_REROUTE_CKSUM_TABLE_ID				7988
#define FW_BRIDGE_REROUTE_CKSUM_TABLE_NAME				"bridge_reroute_cksum"

#define FWX_NDP_TABLE_ID								7987
#define FWX_NDP_TABLE_NAME								"ndp_table"

#define IPS_STR_ID_TO_FW_TAB_ID_TABLE_ID				7986
#define IPS_STR_ID_TO_FW_TAB_ID_TABLE_NAME				"ips_str_id_to_fw_tab_id"

#define RPC_SERV_HOSTS_TABLE_ID							7985
#define	RPC_SERV_HOSTS_TABLE_NAME						"rpc_serv_hosts"

#define RPC_SERV_TABLE_ID								7984
#define	RPC_SERV_TABLE_NAME								"rpc_serv"

#define IPS_GLOBAL_PROFILES_IDS_ID						7983
#define IPS_GLOBAL_PROFILES_IDS_TABLE_NAME 				"ips_global_profiles_ids"

#define CVPND_EXCHANGE_CONNECTED_USERS_TABLE_ID			7982
#define CVPND_EXCHANGE_CONNECTED_USERS_TABLE_NAME		"cvpn_exchange_connected_users"

#define CVPND_EXCHANGE_EXPIRED_USERS_TABLE_ID			7981
#define CVPND_EXCHANGE_EXPIRED_USERS_TABLE_NAME			"cvpn_exchange_expired_users"

#define CVPND_PN_TOKENS_SUBSCRIBED_TABLE_ID				7980
#define CVPND_PN_TOKENS_SUBSCRIBED_TABLE_NAME			"cvpn_pn_tokens_subscribed"

#define CVPND_PN_MAIL_DATA_TABLE_ID						7979
#define CVPND_PN_USER_MAIL_DATA_TABLE_NAME				"cvpn_pn_user_mail_data"

#define CVPND_PN_MAIL_CONTROL_TABLE_ID					7978
#define CVPND_PN_USER_MAIL_CONTROL_TABLE_NAME			"cvpn_pn_user_mail_control"

#define CVPND_MOB_MAIL_SESSION_TABLE_ID					7977
#define CVPND_MOB_MAIL_SESSIONS_TABLE_NAME				"mob_mail_session"

#define CI_AV_MD5_RAD_STATISTICS_HASH_TAB_ID			7976
#define CI_AV_MD5_RAD_STATISTICS_HASH_TAB_NAME			"av_md5_rad_statistics_hash_tab"

#define EMAIL_UNIFIED_APP_HOLD_OPAQUE_TABLE_ID			7975
#define EMAIL_UNIFIED_APP_HOLD_OPAQUE_TABLE_NAME 		"email_unified_app_hold_opaque"

#define MAL_IP_REP_TABLE_ID								7974
#define MAL_IP_REP_TABLE_NAME							"mal_ip_reputation"

#define SUSPICIOUS_MAIL_TABLE_ID						7973
#define SUSPICIOUS_MAIL_TABLE_NAME						"suspicious_mails"

#define CPHWD_DEV_NOMATCH_RANGES_TABLE_ID				7972

#define FWGXSAM_BLOCKED_ATTR_TABLE_ID	        		7971
#define FWGXSAM_REQUEST_TABLE_ID						7970

#define FWGTP_LOG_MEMBER_TAB_ID							7969
#define FWGTP_LOG_MEMBER_TAB_NAME						"gtp_log_member"

#define FWGTP_VER_TAB_ID								7968
#define FWGTP_VER_TAB_NAME								"gtp_ver_tab"

#define FWX_CGNAT_SUBSCRIBERS_TAB_ID					7967
#define FWX_CGNAT_SUBSCRIBERS_TAB_NAME					"fwx_cgnat_subscribers"

#define FWX_CGNAT_HAIRPINNING_MAPPINGS_TAB_ID			7966
#define FWX_CGNAT_HAIRPINNING_MAPPINGS_TAB_NAME			"fwx_cgnat_hairpinning_mappings"

#define FWSYSLOG_SERVERS_TAB_ID							7965
#define FWSYSLOG_SERVERS_TAB_NAME						"fwsyslog_servers"

#define CMI_LOADER_GRANULAR_CONTEXTS_MAP_TABLE_ID 		7964
#define CMI_LOADER_GRANULAR_CONTEXTS_MAP_TABLE_NAME 	"cmi_loader_granular_ctx_map"

/**********************  Session IS tables [begin] ******************************/

#define SESSIONIS_CVPN_DIFF_TABLE_ID					7963
#define SESSIONIS_CVPN_DIFF_TABLE_NAME					"cvpn_diff_table"

#define SESSIONIS_VPN_DIFF_TABLE_ID						7962
#define SESSIONIS_VPN_DIFF_TABLE_NAME					"vpn_diff_table"

#define SESSIONIS_SESSIOND_DIFF_TABLE_ID				7961
#define SESSIONIS_SESSIOND_DIFF_TABLE_NAME				"sessiond_diff_table"

#define SESSIONIS_RA_GLOBAL_COUNTER_TABLE_ID			7960
#define SESSIONIS_RA_GLOBAL_COUNTER_TABLE_NAME			"ra_global_counter"

/**********************  Session IS tables [end] ********************************/

#define IMAP_MAIL_TABLE_ID								7959
#define IMAP_MAIL_TABLE_NAME							"imap_mails"

#define LINK_LOCAL_VIP6_TABLE_NAME	"link_local_vip6"
#define LINK_LOCAL_VIP6_TABLE_ID	7967

#define MAB_SNX_HOLD_CONNECTIONS_TABLE_ID				7957 /* also defined in upmab/kernel/mabk_cmi.c */
#define	MAB_SNX_HOLD_CONNECTIONS_TABLE_NAME				"mab_hold_connections"

#define SYNATK_SECRET_TABLE_ID						7956
#define SYNATK_SECRET_TABLE_NAME					"synatk_secret_table"


#define FW_TABLE_LAST							    7956

/* Blades ranges moved to kerntabs_ranges.h */

/*
 * Defining dynamic table attributes
 * ---------------------------------
 * This I/S allows defining attributes on a table, "behind the back" of the Inspect compiler.
 * It allows SmartDefense updates to set attruibutes that are supported by the kernel, but not
 *  by the Inspect compiler.
 * This is done by defining the table names in a special table. Each line in that table describe
 *  the special attributes needed for a specific table. The kernel would iterate the table and
 *  actually apply these properties. If the kernel is old and doesn't support this, nothing will
 *  happen.
 * We use it for local sync in Hydra machines. This allows SmartDefense updates to choose
 *  enable local sync on tables, in a way that would not require the management to support it,
 *  and would do no harm on non-Hydra machines.
 *
 * Usage:
 * Define the attribute table, initialized with an entry per table. The key would be the table
 *  ID (generated by the compiler), the data is a single integer with the attributes. Example:
 * sdupdate_dynamic_tab_attrs = {
 *		<my_table; DYNAMIC_ATTR_LOCAL_SYNC>
 * }
 *
 * Note: SmartDefense updates should not rely on these definitions, because the management may
 *  not include them. They should be defined again in the update, under ifndef.
 */

/* This is the table name, to be used for defining dynamic attributes */
#define DYNAMIC_ATTR_TAB_NAME "sdupdate_dynamic_tab_attrs"

/* These are the possible attributes */
#define DYNAMIC_ATTR_LOCAL_SYNC 0x01
#define DYNAMIC_ATTR_GLOBAL_TAB 0x02

#endif /* __kerntabs_h__ */

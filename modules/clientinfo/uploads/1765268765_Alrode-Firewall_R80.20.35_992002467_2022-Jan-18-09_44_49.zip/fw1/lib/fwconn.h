
#ifndef __h_fwconn__
#define __h_fwconn__

/*
 * the partition of the r_ctype 32 bit field :
 *
 * 01234567    01234567    0123  4567    01234567
 * >                  <    >  <  >              <
 *      VPN bits           ctrl       VPN bits
 *    (vpnconn.h)          bits      (vpnconn.h)
 */


#define CTRL_SRC_FIN          (1<<0)  /* bit mask ! */
#define CTRL_DST_FIN          (1<<1)  /* bit mask ! */
#define CTRL_TCP_ESTABLISHED  (1<<2)  /* bit mask ! */
#define CTRL_UDP_ESTABLISHED  (1<<2)  /* bit mask ! */
#define CTRL_SYN_ACK          (1<<3)  /* bit mask ! */

#define MATCH_BY_PROTOCOL	(0)	/* Obsolete */
#define MATCH_BY_OFFSET		(1) /* Obsolete */
#define MATCH_BY_RPC		(2) /* Obsolete */
#define MATCH_BY_GETPORT	(3) /* Obsolete */
#define MATCH_BY_CALLIT		(4) /* Obsolete */
#define MATCH_BY_SEQACK_CHG	(5) /* Obsolete */
#define MATCH_BY_NULL		(6) /* Obsolete */
#define MATCH_BY_GETTIME	(7) /* Obsolete */
#define MATCH_BY_DUMP		(8) /* Obsolete */

#define	MAKE_ENTRY(type,ctrl,match,arg)	(MAKE_VPN_ENTRY(type,match,arg) | ((ctrl) << 12) )

#define ENTRY_CTRL(entry)			(((entry) >> 12) & 0xf)
#define CHANGE_CTRL(entry,ctrl)		(((entry) & 0xffff0fff) | ((ctrl)  << 12))
#define ADD_CTRL(entry,ctrl)        ((entry) | ((ctrl)  << 12))
#define REMOVE_CTRL(entry,ctrl)     ((entry) & ~((ctrl)  << 12))

#define ENTRY_KTYPE(entry)			(((entry) >> 16) & 0xff)
#define ADD_KTYPE(entry,ktype)      ((entry) | ((ktype)  << 16))
#define REMOVE_KTYPE(entry,ktype) ((entry) & ~((ktype)  << 16))

#define _TCP_ESTABLISHED   MAKE_ENTRY(0, CTRL_TCP_ESTABLISHED, 0, 0)
#define _UDP_ESTABLISHED   MAKE_ENTRY(0, CTRL_UDP_ESTABLISHED, 0, 0)
#define _SRC_FIN	MAKE_ENTRY(0, CTRL_SRC_FIN, 0, 0)
#define _DST_FIN	MAKE_ENTRY(0, CTRL_DST_FIN, 0, 0)
#define _SYN_ACK	MAKE_ENTRY(0, CTRL_SYN_ACK, 0, 0)
#define _BOTH_FIN	(_SRC_FIN | _DST_FIN)
#define _TCP_STATE_MASK	(_SYN_ACK | _TCP_ESTABLISHED | _SRC_FIN | _DST_FIN)

#define MAKE_COMMUNITY_ENTRY(type,ctrl,match,arg)	(MAKE_ENTRY(type,ctrl,match,arg) | 0x8)

/*
 * the partition of the r_cflags 32 bit field :
 *
 * 01234567    01234567    01234567    01234567
 * >                  <    >                 <
 *  room for new flags            flags
 */
#define NO_CONN_ONEWAY			(0x00000000) /* No unidirectionality enforced */
#define CONN_ONEWAY_A			(0x00000001) /* One way connection, CLIENT -> SERVER */
#define CONN_ONEWAY_B			(0x00000002) /* One way connection, SERVER -> CLIENT */
#define CONN_ONEWAY_EITHER		(0x00000003) /* One way connection, direction still unknown and will be updated later */
#define IS_H323_CONN			(0x00000004) /* Connection is H.323 */
#define IS_SEQVALID_TRANS		(0x00000008) /* Should sequence verifier's sequence translation be applied? */
#define IS_PENDING				(0x00000010) /* Data connection still to be opened - source port still unknown (zero) */
#define IS_DATA_CONN			(0x00000020) /* Data connection */
#define IS_REVERSED				(0x00000040) /* Data connection - real direction is reversed to the one in conn. table */
#define IS_REVERSED_DATA_CONN	(IS_REVERSED|IS_DATA_CONN)
#define IS_LOGGED				(0x00000080) /* FW-1? logged the connection */
#define IS_OLD_CONN				(0x00000100) /* Connection from previous policy, not yet recovered */
#define NOTIFY_FIRST_S2C		(0x00000200) /* Notify on first server to client packet */
#define IS_PROXIED				(0x00000400) /* Connection from/to security server */
#define IS_LOAD_PROOF			(0x00000800) /* Connection should survive policy reload, so it won't go over the policy again */
#define REFRESH_CONT_CONN		(0x00001000) /* Packet from data connection should refresh the control connection */
#define SRS_OUTBOUND_SEEN		(0x00002000) /* A packet was encountered on the server-side outbound chain (real server, which may be the client of a parent connection) */
#define ENABLE_REPLIES			(0x00004000) /* */
#define ENABLE_REPLIES_ANY_PORT	(0x00008000) /* */
#define NEEDS_SCV				(0x00010000) /* */
#define PENDING_LOG				(0x00020000) /* */
#define SYN_SENT                (0x00040000) /* We saw TCP SYN packet sent - SYN-ACK or RST are only allowed as response */
#define IS_RTP_CONN             (0x00080000) /* RTP based connection */
#define IS_TRULY_ONEWAY			(0x00100000) /* Is the connection truly one-way? */
#define IS_EARLY_NAT			(0x00200000) /* */
#define CHECK_REDIRECT 			(0x00400000) /*check redirect */
#define IS_WIRE_MODE			(0x00800000) /* Is connection in wire mode */
#define TEX_TCP_HNDSK_ENFORCE	(0x01000000) /*Transport Expert API - disable TCP handshake enforcement */
#define PARENT_MUST_EXIST		(0x02000000) /* check parent existence for pending data connections */
#define DELETE_ON_RESPONSE		(0x04000000) /*Connections that should be removed from table after reply*/
#define POSSIBLE_CONN_REUSE		(0x08000000) /* SYN on established connection encountered. Maybe this connection is being reused */
#define REJECT_ALL_PACKETS  	(0x10000000) /* Reject all connection's packets */
#define DELETE_CONN         	(0x20000000) /* Delete the entry from connection after the packet leaves the machine */
/* 0x40000000  available after removing ACK_AFTER_SYN */
#define DROP_CONN_TRAFFIC		(0x80000000) /* Drop connection traffic while waiting for flush and ack to finish*/

#define ENTRY_ONEWAY(entry) 		((entry) & 0x03)
#define ENTRY_ACCEPTED(entry)		((entry) & 0x0c)
#define CHANGE_ONEWAY(entry,way)	(((entry) & 0xfffffffc) | (way))
#define CHANGE_ACCEPTED(entry,acpt)	(((entry) & 0xfffffff3) | (acpt))

#define FW_TRUST_RST_ON_ALL_PORTS -1
#define FW_UNTRUST_RST            -2

/* Operational flags for record_data_conn */
#define FWCONN_DATA_CONN_DONT_LIMIT_PENDING_DATA_CONNS	(0x00000001)
#define FWCONN_DATA_CONN_IGNORE_COLLISION					(0x00000002)
#define FWCONN_DATA_CONN_COMPLETE_MEMORY_CHECK			(0x00000004)

/*
 * the partition of the r_pflags 32 bit field :
 *
 * 01234567    0123 4567    01234567    01234567
 * >      <    >  < >  <    >                  <
 *            action log            flags
 */

#define TCP_FAST_MODE		(0x0002)
#define CONN_ONEWAY_VIOLATE (0x0004)
#define P_MORE_INSPECTION	(0x0010)

/*
 * flags for the r_mflags (match flags) register
 */
#define MFLAGS_OK								0x00000001
#define MFLAGS_MATCH_FOR_ANY					0x00000002
#define MFLAGS_UDP_REPLY						0x00000004
#define MFLAGS_UDP_REPLY_ANY					0x00000008
#define MFLAGS_OTHER_REPLY						0x00000010
#define MFLAGS_NO_SYNC							0x00000020
#define MFLAGS_LOAD_PROOF						0x00000040
#define MFLAGS_DELETE_ON_RESPONSE				0x00000080
#define MFLAGS_SRC_MATCHED_SC_RULE				0x00000100
#define MFLAGS_DST_MATCHED_SC_RULE				0x00000200
#define MFLAGS_FOLDED							0x00000400
#define MFLAGS_SHOULD_APPI_ACCT					0x00000800
#define MFLAGS_PASS_USER_AUTH					0x00001000
#define MFLAGS_SHOULD_BEEN_LOGGED				0x00002000
#define MFLAGS_WENT_THROUGH_RB					0x00004000
#define MFLAGS_PASS_CA_SERVERS_ENROLMENT 		0x00008000
#define MFLAGS_SIP_CONN							0x00010000
#define MFLAGS_MGCP_CONN						0x00020000
#define MFLAGS_IS_PROXIED_CONN					0x00040000
#define MFLAGS_LOGICAL_SERVER_CONN				0x00080000
#define MFLAGS_ALLOW_CONNLESS_PACKET  			0x00100000
#define MFLAGS_NAC_IS_CAPTIVE_CONN				0x00200000
#define MFLAGS_TE_INTERNAL_CONN					0x00400000
#define MFLAGS_FORCE_UNIDIRECTIONAL				0x00800000
#define MFLAGS_PROTOCOL_DETECTION_NO_HANDLER	0x01000000 	/*indicates not to set handler - handler will be determined accoring to protocol detection*/
#define MFLAGS_MATCH_ON_SYN						0x02000000		/* should be set during record conn, according to the matched service */
#define MFLAGS_SCTP_INSPECTION					0x04000000

#define ENTRY_TCP_FAST_MODE(entry)				((entry) & 0x0002)
#define ENTRY_CONN_ONEWAY_VIOLATE(entry)		((entry) & 0x0004)
#define ENTRY_ACTION(entry)						(((entry) >> 20)  & 0xf)
#define ENTRY_LOG(entry)						(((entry) >> 16)  & 0xf)
#define ADD_ACTION(entry,action)   				((entry) | ((action) <<  20))
#define ADD_LOG(entry,log)   					((entry) | ((log) <<  16))

#define ENTRY_RULE(rule) (rule & 0x00ffffff)
#define MAKE_RULENUM(rule,src) \
				(((src << 24) & 0xff000000) | (rule & 0x00ffffff))
#define ENTRY_RULE_SRC(rule) \
				(((rule) >> 24) & 0x000000ff)



#define NOACCT              (0)
#define ACCT                (1)

/* XXX */
#define	X_TCPSEQ			(4)

#define EX_INFINITE 0x7fffffff

#define INSPECT_ALL		0xffffffff

/*
 * SecuRemote security modes bit mask
 */
#define USERC_OUTBOUND_VPN			0x00000001
#define USERC_OUTBOUND				0x00000010
#define USERC_INBOUND_VPN_PRIV		0x00000100
#define USERC_INBOUND_VPN			0x00000200
#define USERC_INBOUND_PRIV			0x00001000
#define USERC_INBOUND				0x00002000
#define	USERC_FORWARD				0x00004000
#define USERC_ENABLE_LOGS			0x00020000

/* Accounting mode flags */
/**
move to up 
#define FW_ACCT						0x00000001
#define APPI_ACCT					0x00000002
*/
/* Implied rule matching */
#define COM_TAG_MATCH_MAGIC 336698

/* URL logging:
   This values are shared between the fwurlog module and Inspect.
   It is written in inspect (fwauth.def) to the url_log_conns table in the
   following format:
   <conn; tcp_seq, flags, rule_no, ufp_mask>

   tcp_seq	- sequence # at which streaming will be started (SYN+1)
   flags	:
		LOG_ALL				all URLs in connection should be logged
		LOG_FIRST			only first URL should be logged
		SECURE_LOG_FIRST	same as LOG_FIRST but streaming is continued for
							additional security
		WITH_AUTH			indicated that the connection was with client
							authentication and therefore the username should
							also be logged
		USE_ACTIVE_STREAMING	use active TCP streaming (the default is
							passive)

		Internal use only:
		NO_UFP              used when URL logging is done without the UFP
		                    cache feature


		URLOG_FILTER		use the URL FILTER module to rejects the unauthorized
							URL pattern (code red)
 */

/*
 * proxied_conns table actions
 */
#define PROXIED_ACTCODE_ENCRYPT		1
#define PROXIED_ACTCODE_ACCOUNT		2
#define PROXIED_ACTCODE_UNFOLD		4
#define PROXIED_ACTCODE_KEEP		8
#define PROXIED_ACTCODE_LOG         16

#define	MAKE_PVAL(acode,pid)	( (acode) /*| ((pid) << 4)*/) /* Does nothing */
#define	PVAL_ACT(pval)	((pval) & 0xffff )
#define	PVAL_ID(pval)	0 /*((pval) >> 4)*/

#define URLOG_CONNS_NVALS			4

#define URLOG_LOG_METHOD_MASK		0x300

#define URLOG_LOG_ALL				0
#define URLOG_LOG_FIRST				0x00000100
#define URLOG_LOG_SECURE			0x00000200
#define URLOG_LOG_FIRST_SECURE		0x00000300
#define URLOG_LOG_URL_NOHOST		0x01000000
#define URLOG_LOG_HOST				0x02000000
#define URLOG_LOG_HEADERS			0x04000000
#define URLOG_LOG_COMMAND			0x08000000
#define URLOG_LOG_PARTIAL_BODY		0x10000000
#define URLOG_LOG_HEADERS_DONE		0x20000000
#define URLOG_LOG_BODY_DONE			0x40000000
#define URLOG_LOG_STARTLINE			0x80000000
#define URLOG_WITH_AUTH				0x00010000
#define URLOG_NO_UFP				0x00020000
#define URLOG_FILTER				0x00040000
#define HTTP_VERIFY					0x00080000
#define URLOG_QUICKUFP				0x00100000
#define URLOG_WS_PASSIVE			0x00200000
#define URLOG_WEB_SERVER_MONITOR_ONLY	0x00400000
#define URLOG_CI_UF					0x00800000

/*
 * Dynamic Object types
 */
#define IP_RANGES_DYNOBJ_TYPE 		0
#define XRM_IP_RANGES_DYNOBJ_TYPE 	1


/*
 * KFUNC_XLATE_ANTICIPATE methods
 */
#define XLATE_DATA_CONN				0
#define XLATE_AS_CLIENT				1
#define XLATE_AS_SERVER				2
#define XLATE_SPORT					3

/*
 * KFUNC_XLATE_ANTICIPATE flags
 */
#define XLATE_CONT_REV				0x00000001
#define XLATE_PORT_EVEN				0x00000002
#define XLATE_RTPRTCP_MODE			0x00000010
#define XLATE_CHANGE_DATA_MODE		0x00000020
#define XLATE_ACTIVATE_STICKY		0x00000040
#define XLATE_RUN_RULE_MATCH		0x00000080
#define XLATE_IS_INCOMING			0x00000100
#define XLATE_DONT_ALLOCATE_PORT	0x00000200
#define XLATE_USE_STR_BUFFER		0x00000400
#define XLATE_READ_ONLY_BUFFER		0x00000800


/*
* fwxlate_change_content flags
*/

#define XLATE_CONTENT_RUN_RULE_MATCH			0x1
#define XLATE_CONTENT_IS_INCOMING				0x2


/*
 * KFUNC_FTP_CHECK_PACKET flags
 */
#define FTP_NO_CLIENT_227     0x01
#define FTP_NO_TELNET_OPTIONS 0x02

/* KFUNC_LOG_CONN flags */
#define FW_LOG_CONN_IS_DATA_CONN		0x00000001 /* Data connection */
#define FW_LOG_CONN_IS_COMPLEMENTARY	0x00000002 /* Complementary logging */

/* KFUNC_DOS_FIRST_PACKET actions  */
#define FW_DOS_ACCEPT	1

/* KFUNC_DIAMETER_PACKET_FILTER actions  */
#define FW_DIAMETER_REJECT 	0
#define FW_DIAMETER_ACCEPT	1

/**********************************************************************************
 * Connection Table Bits Definitions
 * To add a bit category:
 *	1) Define a bit category id as the next available integer id in sequential increasing order **
 *	2) Define the start bit of the category (make sure that bit category does not traverse two u_int BITS values).
 *	3) Define the number of bits in the category
 *	4) Define the bits that will be copied from the control to the data connection (bit mask).
 *	5) Add an entry to the fwconn_bits array in fwconn.c in the cell corresponding to the id
 *
 * **Note: When adding bit categories keep the following in mind:
 *		Bits in one bit category may NOT overlap a u_int boundary (ex. bits 30-40 overlap - can't do this).
 *		Also, if adding your bit category causes another u_int value to be needed by the connections table
 *		you must add a C_BITS field and update C_BITSLAST accordingly.  Also update
 *		FW_CONN_MANDATORY_VALS and FW_CONN_MAX_MODULES. Make sure that adding
 *		this field doesn't cause the connection entry structure (hitem) or the chain structure to go over
 *		the maximum bytes that can be allocated by the hmem mechanism.
 **********************************************************************************/

/*
 *	CK_DIR: 1 bit interface indication
 *               	15 bits interface number
 *               	15 bits reserved
 *               	1 bit direction
 *
 */
#define CK_HASIF_MASK	0x80000000
#define CK_IFNUM_MASK	0x7fff0000
#define CK_DIR_MASK		0x00000001

#define FWCONN_HAS_IF(conn_)                             (fwconn_get_dir(conn_) & CK_HASIF_MASK)        

#define FWCONN_IFNUM(conn_)                              (((u_int)(fwconn_get_dir(conn_) & CK_IFNUM_MASK))>>16) 

#define FWCONN_SET_IFNUM(conn_, ifnum_)         fwconn_set_dir((conn_), fwconn_get_dir(conn_) | (CK_HASIF_MASK|(ifnum_<<16)))

#define FWCONN_DIR(conn)                                        (conn[CK_DIR] & CK_DIR_MASK)
#define	FWCONN_KEY_DIR(conn_dir)		(conn_dir & CK_DIR_MASK)

/*ip pool bit category*/
#define IP_POOL_ID				0
#define IP_POOL_START			0
#define IP_POOL_NUM_BITS		1

/* Sequence verifier's sequence translation bits */
#define SEQVALID_BIT_ID			1
#define SEQVALID_BIT_START		1
#define SEQVALID_BIT_NUM_BITS	2

/* L2TP connection bit*/
#define L2TP_ID					2
#define L2TP_START				3
#define L2TP_NUM_BITS			1

/* "fw will enc" SecureXL bit */
#define VPNSXL_BIT_ID         3
#define VPNSXL_BIT_START      4
#define VPNSXL_BIT_NUM_BITS   2

/* Template is allowed for this connection */
#define CPHWD_ALLOW_TEMPLATE_ID			4
#define CPHWD_ALLOW_TEMPLATE_START		6
#define CPHWD_ALLOW_TEMPLATE_NUM_BITS	1

/* Connection has encountered ACK response to SYN */
#define ACK_RESP_TO_SYN_ID			5
#define ACK_RESP_TO_SYN_START		7
#define ACK_RESP_TO_SYN_NUM_BITS	1

/* RTP/RTCP media type - audio and video type */
#define RTP_TYPE_ID				6
#define RTP_TYPE_START			8
#define RTP_TYPE_NUM_BITS		2

/* reserved for Inspect use*/
#define INSPECT_ID				7
#define INSPECT_START			10
#define INSPECT_NUM_BITS		2

/* Marking rpc connections*/
#define RPC_BIT_ID				8
#define RPC_BIT_START			12
#define RPC_BIT_NUM_BITS		1

/* Does the connection's handler remain intact upon policy installation? */
#define LOAD_PROOF_HANDLER_ID       9
#define LOAD_PROOF_HANDLER_START	13
#define LOAD_PROOF_HANDLER_NUM_BITS	1

#define MISP_ID						10
#define MISP_START					14
#define MISP_NUM_BITS				1

#define FWHA_CCL_ID					11
#define FWHA_CCL_ID_START			15
#define FWHA_CCL_ID_NUM_BITS			6

#define VPN_POLICY_COMPLETED_ID			12
#define VPN_POLICY_COMPLETED_START		21
#define VPN_POLICY_COMPLETED_NUM_BITS	1

/* Saved for BC */
/* CPAS is active bit */
#define __CPAS_CONN_ID_BC				13
#define __CPAS_CONNBITS_START_BC		22
#define __CPAS_CONNBITS_NUM_BITS_BC		1

/* DNS connections needs session ID and port randomization */
#define DNS_RANDOMIZE_ID			14
#define DNS_RANDOMIZE_START			23
#define DNS_RANDOMIZE_NUM_BITS		1

/* tagging info */
#define VPN_TAGGING_ID				15
#define VPN_TAGGING_START			24
#define VPN_TAGGING_NUM_BITS		6

/* Saved for BC */
/* The connection has spawned a data connection using fwconn_record_data_conn() */
#define __IS_CONTROL_CONN_ID_BC				16 /* Should not be copied to data connection, should be merged during post-sync */
#define __IS_CONTROL_CONN_ID_BC_START		30
#define __IS_CONTROL_CONN_ID_BC_NUM_BITS	1

/* Complementary logging */
#define COMPLEMENTARY_LOG_ID		17
#define COMPLEMENTARY_LOG_START		31
#define COMPLEMENTARY_LOG_NUM_BITS	1

/* non-dynamic vpn connection */
#define VPN_NON_DYNAMIC_ID			18
#define VPN_NON_DYNAMIC_START		32
#define VPN_NON_DYNAMIC_NUM_BITS	1

/* Should all packets of the connection be forwarded to firewall by SXL? */
#define CPHWD_CONN_FORWARD_TO_FIREWALL_ID		19
#define CPHWD_CONN_FORWARD_TO_FIREWALL_START		33
#define CPHWD_CONN_FORWARD_TO_FIREWALL_NUM_BITS		1

/* Saved for BC */
/* Is timeout stored on the connection? (instead of service ID) */
#define __CONN_TIMEOUT_ID_BC					20
#define __CONN_TIMEOUT_ID_BC_START			34
#define __CONN_TIMEOUT_ID_BC_NUM_BITS		1

/* Is the rule which appears on the connection table,old? */
#define CONN_IS_OLD_RULE_ID			21
#define CONN_IS_OLD_RULE_START		35
#define CONN_IS_OLD_RULE_NUM_BITS	1


/* Was the IS_OLD_CONN set at some point on the connection? */
#define WAS_OLD_CONN_ID			22
#define WAS_OLD_CONN_START		36
#define WAS_OLD_CONN_NUM_BITS	1

/* Do we encounter link collision in RTSP */
#define IS_RTSP_LINK_COLLISION_ID		23
#define IS_RTSP_LINK_COLLISION_START		37
#define IS_RTSP_LINK_COLLISION_NUM_BITS	1

/* Should the connection be unified with the sister connection.
 * Data connection of VoIP HNT user that is behind NAT device, should be unified with its sister's data connection */
#define VOIP_HNT_UNIFY_DATA_CONN_ID			24
#define VOIP_HNT_UNIFY_DATA_CONN_START		38
#define	VOIP_HNT_UNIFY_DATA_CONN_NUM_BITS	1

/* Dont close this conn under SAM close */
#define SAM_DONT_CLOSE_ID 		25
#define SAM_DONT_CLOSE_START 	39
#define SAM_DONT_CLOSE_NUM_BITS 1

/* Is the connection an rtsp connection? */
#define IS_RTSP_CONN_ID		26
#define IS_RTSP_CONN_START		40
#define IS_RTSP_CONN_NUM_BITS	1

/* Is this a cpas connection? */
#define IS_CPAS_CONN_ID						27
#define IS_CPAS_CONN_START					41
#define IS_CPAS_CONN_NUM_BITS				3

/* mark that conn is matched on a rule below a domain/dynamic object rule */
#define CPHWD_ALLOW_TEMPLATE_DYNOBJ_ID				28
#define CPHWD_ALLOW_TEMPLATE_DYNOBJ_START			44
#define CPHWD_ALLOW_TEMPLATE_DYNOBJ_NUM_BITS		1

/* mark that conn is matched on a rule below a time object rule */
#define CPHWD_ALLOW_TEMPLATE_TIMEOBJ_ID	29
#define CPHWD_ALLOW_TEMPLATE_TIMEOBJ_START			45
#define CPHWD_ALLOW_TEMPLATE_TIMEOBJ_NUM_BITS			1

/* mark that conn is matched on a rule below a tracerout service rule */
#define CPHWD_ALLOW_TEMPLATE_TRACEROUTE_ID	30
#define CPHWD_ALLOW_TEMPLATE_TRACEROUTE_START			46
#define CPHWD_ALLOW_TEMPLATE_TRACEROUTE_NUM_BITS			1

/* mark that conn is matched on a rule below a security zone rule */
#define CPHWD_ALLOW_TEMPLATE_SECURITY_ZONE_ID	31
#define CPHWD_ALLOW_TEMPLATE_SECURITY_ZONE_START			47
#define CPHWD_ALLOW_TEMPLATE_SECURITY_ZONE_NUM_BITS			1

/* mark that conn is matched on a rule below a dhcp service rule */
#define CPHWD_ALLOW_TEMPLATE_DHCP_ID	32
#define CPHWD_ALLOW_TEMPLATE_DHCP_START			48
#define CPHWD_ALLOW_TEMPLATE_DHCP_NUM_BITS			1

/* indicates that CMI Handlers  can can/work on the connection */
#define IS_CMI_HANDLERS_SUPPORTED_ID			33
#define IS_CMI_HANDLERS_SUPPORTED_START		49
#define IS_CMI_HANDLERS_SUPPORTED_NUM_BITS	2

/* indicates that CMI Handlers  can can/work on the connection */
#define CPHWD_ALLOW_TEMPLATE_DOMAIN_OBJ_ID				34
#define CPHWD_ALLOW_TEMPLATE_DOMAIN_OBJ_START			51
#define CPHWD_ALLOW_TEMPLATE_DOMAIN_OBJ_NUM_BITS		1

#ifdef SFW
/* Is policy based-routing disabled for this connection? */
#define PBR_ID					35
#define PBR_START				57
#define PBR_NUM_BITS				1

/* TODO maximf: !!! verify masks for children/post sync are updated correctly (57-th bit = 1 in both cases ) */
#endif

/* 
 * The following mask indicates fields that should be inherited by connection's children
 */
                                /* BIT_ID    01123345 66778901 11111111 11111111 */
#define C_BITS_DATA_MASK       0x1C03FFFF /* 00011100 00000011 11111111 11111111 */
								/* BIT_ID      23444456 66666789 01234567 xxxxxxxx */
#define C_BITS2_DATA_MASK		0x81F9AE00 /* 10000001 11111001 10101110 10000000 */

/*
 * The following mask indicates fields that should be merged (instead of being stepped upon) in
 * post sync context
 */
									 /* BIT_ID	  01123345 66778901 11111111 11111111 */
#define C_BITS_PSYNC_MERGE_MASK 0x60040000     /* 01100000 00000100 00000000 00000000 */
									 /* BIT_ID	   23444456 66666789 01234567 ?xxxxxxx */
#define C_BITS2_PSYNC_MERGE_MASK 0x00040080	   /* 00000000 00000100 00000000 10000000 */

/*
 *  fw_gen_log dictionary information
 */
#define LOG_TYPE_NO_NL 					0	/* Port command ended without new line */
#define LOG_TYPE_ILLEGAL_PSV_CMD		1 	/* Passive command while working in Active mode */
#define LOG_TYPE_ILLEGAL_ACT_CMD		2 	/* Active command while working in Passive mode */
#define LOG_TYPE_PORT_CMD_0				3	/* Port command shouldn't be 0 */
#define LOG_TYPE_X11					4     /* X11 warning */
#define LOG_TYPE_SSH2					5	/* SSH not version 2 */
#define LOG_TYPE_BAD_PORT_COMMAND		6	  /*Port command not at the packet beginning*/
#define LOG_TYPE_NOT_SSL_V3				7	  /*Not SSL version 3*/
#define LOG_TYPE_NET_QUOTA				8	/* Net Quota exceeded */
#define LOG_TYPE_IMPLIED				9     /* Implied rules log */
#define LOG_TYPE_TCPT					10   /* Outgoing TCPT disabled log */
#define LOG_TYPE_MSRPC_COMPLIANT		11	/* MS-RPC Non Compliant Major or Minor Version */
#define LOG_TYPE_OUTGOING_POLICY_VIOLATION		12	/* Outgoing Policy violation (drop in new initial policy) */

/* number of logs type add your'e new log type above and increase the LAST_LOG_TYPE */

#define LOG_TYPE_LAST					12

#define LOG_TYPE_NONE					0xffff

/*
 * PPTP state table key types
 */
#define PPTP_KEY_T_CLI_ID				1
#define PPTP_KEY_T_SRV_ID				2
#define PPTP_KEY_T_CLI_TUNNEL			3
#define PPTP_KEY_T_SRV_TUNNEL			4

/*
 * SPII INSPECT Streaming error codes
 */
#define SPII_ERR_BUFFER_EXCEEDED		0
#define SPII_ERR_INSPECTION_ERROR		1
#define SPII_ERR_PARSE_FAILURE			2
#define SPII_ERR_REPARSE_EXCEEDED		3
#define SPII_ERR_INTERNAL_ERROR			4

/*
 * Flags for fw_search_str() (KFUNC_SEARCH_STR)
 */
#define SPII_CASE_SENSITIVE		0x01
#define SPII_SEARCH_BACKWARDS	0x02
#define SPII_NEGATE				0x04
#define SPII_USE_MAX_OFFSET		0x08
#define SPII_USE_SHIFTOR		0x10

/*
 * ASM Counters for Inspect
 */
#define ASM_CNT_P2P_OTHER				1
#define ASM_CNT_P2P_KAZAA				2
#define ASM_CNT_P2P_EMULE				3
#define ASM_CNT_P2P_GNUTELLA			4
#define ASM_CNT_P2P_SKYPE				5
#define ASM_CNT_P2P_BITTORRENT		6
#define ASM_CNT_P2P_YAHOO				7
#define ASM_CNT_P2P_ICQ				8

/*
 * SCV status values
 */
#define SCV_INITIAL_VALUE			-1
#define SCV_NOT_VERIFIED			0
#define SCV_VERIFIED				1
#define SCV_PENDING_VERIFICATION	2
#define SCV_DONT_VERIFY				3

/*
* Register Definitions for IPv6 addresses
*/
#define F_R_IPV6_KFUNC_RET			4
#define F_R_IPV6_ORIGSRC			5
#define F_R_IPV6_ORIGDST			6
#define F_R_IPV6_ORIG_CONN_SRC		7
#define F_R_IPV6_ORIG_CONN_DST		8
#define F_R_IPV6_STR_SRC			9
#define F_R_IPV6_STR_DST			10
#define F_R_IPV6_HOST				11
#define F_R_IPV6_IFHOST				12

#define MEMORY_CHECK_DONT_DEL_NOW	0x01
#define MEMORY_CHECK_JUST_CHECK		0x02

#define CONNECTIVITY_HANDLER 0x01
#define VERIFICATION_HANDLER 0x02
#define CMI_SUPPORTED_HANDLER 0x04


#endif /*_fwconn_h_*/


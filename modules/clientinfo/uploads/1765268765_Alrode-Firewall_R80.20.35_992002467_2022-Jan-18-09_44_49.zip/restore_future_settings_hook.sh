#!/bin/bash

# This script will run on an aplliance with an older firmware version, 			 #
# while it attempts to restore settings which were backed up using this firmware version.#

if [ -z "$2" ]; then
	exit -1
fi

if [ "$2" == "verify" ]; then
	# In verify mode, we return:
	# -1 on error
	# 0 If we don't allow to use these settings
	# 1 If we allow to use these settings
	# 2 If we do all verification ourselves successfully

	# Place verification code here #


	exit 1 # Allow older firmware versions to use settings from this version
	
elif [ $2 == "restore" ]; then

	# In restore mode, we return:
	# -1 on error
	# 0 If this script performed the entire restore procedure itself
	# 1 If this script allows the script from the past (which runs this script) to continue with its restore procedure.

	# Place restore code here #	
	
	exit 1 # Let the calling script continue
fi
	
# Error, not a valid option given
echo "Invalid option: $2"
exit -1
(VSE_CONF
	: (producers
		: (
			:producer (ida_userspace)
			:server ("fw,5429,0x3b32dc0")
			:timestamp (1571345962)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,5020,0x3b32dc0")
			:timestamp (1573456227)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,5045,0x3b32dc0")
			:timestamp (1573468110)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4968,0x3b32dc0")
			:timestamp (1578488782)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4790,0x3b32dc0")
			:timestamp (1600352622)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4903,0x3b32dc0")
			:timestamp (1600353031)
		)
	)
)

(
	:clientID (101)
	:dcUrl ("https://updates.checkpoint.com/WebService/services/DownloadMetaDataService")
	:clientVersion (700_R77.20.87_990172908)
	:clientProduct (700_appliance)
	:clientOS (All)
	:description ("{              
'description': 'R77.20 HFA 87 Build 990172908 - What's New:'
, 'notes': [
{'text': 'Gateway support for WatchTower Mobile App notification in Hebrew German Spanish Japanese Portuguese'}
,{'text': 'Gateway support for SMP Email Notifications '}
,{'text': 'Stability and security fixes'}
]
}")
	:CertificateKey (CK-00-1C-7F-7B-E3-EF)
)

(VSE_CONF
	: (producers
		: (
			:producer (RAD)
			:server ("fw,5252,0x3ab20a0")
			:timestamp (1542335833)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,5252,0x3ab20a0")
			:timestamp (1542335833)
		)
		: (
			:producer (RAD)
			:server ("fw,4742,0x3ab20a0")
			:timestamp (1542687228)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4742,0x3ab20a0")
			:timestamp (1542687349)
		)
		: (
			:producer (RAD)
			:server ("fw,4748,0x3ab20a0")
			:timestamp (1544029912)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4748,0x3ab20a0")
			:timestamp (1544029913)
		)
		: (
			:producer (RAD)
			:server ("fw,4741,0x3ab20a0")
			:timestamp (1544036269)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4741,0x3ab20a0")
			:timestamp (1544036270)
		)
		: (
			:producer (RAD)
			:server ("fw,4747,0x3ab20a0")
			:timestamp (1546487750)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4747,0x3ab20a0")
			:timestamp (1546487750)
		)
		: (
			:producer (RAD)
			:server ("fw,4751,0x3ab20a0")
			:timestamp (1547807750)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4751,0x3ab20a0")
			:timestamp (1547807752)
		)
		: (
			:producer (RAD)
			:server ("fw,4746,0x3ab20a0")
			:timestamp (1550549631)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4746,0x3ab20a0")
			:timestamp (1550549631)
		)
		: (
			:producer (RAD)
			:server ("fw,4736,0x3ab20a0")
			:timestamp (1551154192)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4736,0x3ab20a0")
			:timestamp (1551154193)
		)
		: (
			:producer (RAD)
			:server ("fw,6443,0x3ab0858")
			:timestamp (1552363895)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,6443,0x3ab0858")
			:timestamp (1552363895)
		)
		: (
			:producer (RAD)
			:server ("fw,6467,0x3ab0858")
			:timestamp (1553202038)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,6467,0x3ab0858")
			:timestamp (1553202039)
		)
		: (
			:producer (RAD)
			:server ("fw,6447,0x3ab0858")
			:timestamp (1558409891)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,6447,0x3ab0858")
			:timestamp (1558409891)
		)
		: (
			:producer (RAD)
			:server ("fw,4802,0x3ab20a0")
			:timestamp (1562734558)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4802,0x3ab20a0")
			:timestamp (1562734566)
		)
		: (
			:producer (RAD)
			:server ("fw,4803,0x3ab20a0")
			:timestamp (1562747456)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4803,0x3ab20a0")
			:timestamp (1562747466)
		)
		: (
			:producer (RAD)
			:server ("fw,4740,0x3ab20a0")
			:timestamp (1570501975)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4740,0x3ab20a0")
			:timestamp (1570501975)
		)
		: (
			:producer (RAD)
			:server ("fw,18260,0x3ab0858")
			:timestamp (1571357769)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,18260,0x3ab0858")
			:timestamp (1571357769)
		)
		: (
			:producer (RAD)
			:server ("fw,7034,0x3ab0858")
			:timestamp (1578122330)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,7034,0x3ab0858")
			:timestamp (1578122330)
		)
		: (
			:producer (RAD)
			:server ("fw,4806,0x3ab20a0")
			:timestamp (1581996657)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4806,0x3ab20a0")
			:timestamp (1581996658)
		)
		: (
			:producer (RAD)
			:server ("fw,4753,0x3ab20a0")
			:timestamp (1582596177)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4753,0x3ab20a0")
			:timestamp (1582596178)
		)
		: (
			:producer (RAD)
			:server ("fw,30796,0x3ab0858")
			:timestamp (1589848780)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,30796,0x3ab0858")
			:timestamp (1589848780)
		)
		: (
			:producer (RAD)
			:server ("fw,4805,0x3ab20a0")
			:timestamp (1596682798)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4805,0x3ab20a0")
			:timestamp (1596682806)
		)
		: (
			:producer (RAD)
			:server ("fw,6497,0x3ab0858")
			:timestamp (1598924158)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,6497,0x3ab0858")
			:timestamp (1598924158)
		)
	)
)

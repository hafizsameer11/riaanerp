{              
"description": "R77.20 HFA 87 Build 990172908 - What's New:"
, "notes": [
{"text": "Gateway support for WatchTower Mobile App notification in Hebrew German Spanish Japanese Portuguese"}
,{"text": "Gateway support for SMP Email Notifications "}
,{"text": "Stability and security fixes"}
]
}
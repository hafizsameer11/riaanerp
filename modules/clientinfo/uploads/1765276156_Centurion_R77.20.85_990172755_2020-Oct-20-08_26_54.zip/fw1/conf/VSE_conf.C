(VSE_CONF
	: (producers
		: (
			:producer (RAD)
			:server ("fw,5427,0x3b2bdc0")
			:timestamp (1553123298)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,5427,0x3b2bdc0")
			:timestamp (1553123300)
		)
		: (
			:producer (RAD)
			:server ("fw,4986,0x3b2bdc0")
			:timestamp (1557116269)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4986,0x3b2bdc0")
			:timestamp (1557116271)
		)
		: (
			:producer (RAD)
			:server ("fw,4946,0x3b2bdc0")
			:timestamp (1560950881)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4946,0x3b2bdc0")
			:timestamp (1560950884)
		)
		: (
			:producer (RAD)
			:server ("fw,4987,0x3b2bdc0")
			:timestamp (1561544090)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4987,0x3b2bdc0")
			:timestamp (1561544093)
		)
		: (
			:producer (RAD)
			:server ("fw,4887,0x3b2bdc0")
			:timestamp (1564392297)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4887,0x3b2bdc0")
			:timestamp (1564392298)
		)
		: (
			:producer (RAD)
			:server ("fw,21035,0x3b2a598")
			:timestamp (1566012360)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,21035,0x3b2a598")
			:timestamp (1566012362)
		)
		: (
			:producer (RAD)
			:server ("fw,4974,0x3b2bdc0")
			:timestamp (1566274742)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4974,0x3b2bdc0")
			:timestamp (1566274743)
		)
		: (
			:producer (RAD)
			:server ("fw,4957,0x3b2bdc0")
			:timestamp (1566311460)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4957,0x3b2bdc0")
			:timestamp (1566311463)
		)
		: (
			:producer (RAD)
			:server ("fw,4951,0x3b2bdc0")
			:timestamp (1567050602)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4951,0x3b2bdc0")
			:timestamp (1567050605)
		)
		: (
			:producer (RAD)
			:server ("fw,4956,0x3b2bdc0")
			:timestamp (1567145761)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4956,0x3b2bdc0")
			:timestamp (1567145764)
		)
		: (
			:producer (RAD)
			:server ("fw,4981,0x3b2bdc0")
			:timestamp (1567480616)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4981,0x3b2bdc0")
			:timestamp (1567480619)
		)
		: (
			:producer (RAD)
			:server ("fw,6375,0x3b2a598")
			:timestamp (1569097033)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,6375,0x3b2a598")
			:timestamp (1569097033)
		)
		: (
			:producer (RAD)
			:server ("fw,4908,0x3b2bdc0")
			:timestamp (1569433738)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4908,0x3b2bdc0")
			:timestamp (1569433739)
		)
		: (
			:producer (RAD)
			:server ("fw,23841,0x3b2a598")
			:timestamp (0)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,23841,0x3b2a598")
			:timestamp (1571133358)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,26858,0x3b2a598")
			:timestamp (1571983551)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,30133,0x3b2a598")
			:timestamp (1572751048)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,2933,0x3b2a598")
			:timestamp (1573460343)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,3660,0x3b2a598")
			:timestamp (1574172037)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,24105,0x3b2a598")
			:timestamp (1574884031)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,19564,0x3b2a598")
			:timestamp (1575599326)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,7585,0x3b2a598")
			:timestamp (1576340422)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,29635,0x3b2a598")
			:timestamp (1577070717)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,21161,0x3b2a598")
			:timestamp (1577810313)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,19426,0x3b2a598")
			:timestamp (1578540009)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,21750,0x3b2a598")
			:timestamp (1579275104)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,634,0x3b2a598")
			:timestamp (1580002999)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,6218,0x3b2a598")
			:timestamp (1580732096)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,10857,0x3b2a598")
			:timestamp (1581584497)
		)
		: (
			:producer (RAD)
			:server ("fw,10857,0x3b2a598")
			:timestamp (1583459426)
		)
		: (
			:producer (RAD)
			:server ("fw,8822,0x3b2a598")
			:timestamp (1583459645)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,8822,0x3b2a598")
			:timestamp (1583459648)
		)
		: (
			:producer (RAD)
			:server ("fw,4970,0x3b2bdc0")
			:timestamp (1583828734)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4970,0x3b2bdc0")
			:timestamp (1583828736)
		)
		: (
			:producer (RAD)
			:server ("fw,4969,0x3b2bdc0")
			:timestamp (1583830703)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4969,0x3b2bdc0")
			:timestamp (1583830706)
		)
		: (
			:producer (RAD)
			:server ("fw,27490,0x3b2a598")
			:timestamp (1585355538)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,27490,0x3b2a598")
			:timestamp (1585355540)
		)
		: (
			:producer (RAD)
			:server ("fw,11857,0x3b2a598")
			:timestamp (1586905322)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,11857,0x3b2a598")
			:timestamp (1586905325)
		)
		: (
			:producer (RAD)
			:server ("fw,22730,0x3b2a598")
			:timestamp (1588504628)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,22730,0x3b2a598")
			:timestamp (1588504630)
		)
		: (
			:producer (RAD)
			:server ("fw,7914,0x3b2a598")
			:timestamp (1590041864)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,7914,0x3b2a598")
			:timestamp (1590041866)
		)
		: (
			:producer (RAD)
			:server ("fw,4964,0x3b2bdc0")
			:timestamp (1590043768)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4964,0x3b2bdc0")
			:timestamp (1590043770)
		)
		: (
			:producer (RAD)
			:server ("fw,11159,0x3b2a598")
			:timestamp (1591571050)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,11159,0x3b2a598")
			:timestamp (1591571052)
		)
		: (
			:producer (RAD)
			:server ("fw,27804,0x3b2a598")
			:timestamp (1593155172)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,27804,0x3b2a598")
			:timestamp (1593155174)
		)
		: (
			:producer (RAD)
			:server ("fw,4967,0x3b2bdc0")
			:timestamp (1594624777)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4967,0x3b2bdc0")
			:timestamp (1594624780)
		)
		: (
			:producer (RAD)
			:server ("fw,4995,0x3b2bdc0")
			:timestamp (1594976702)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4995,0x3b2bdc0")
			:timestamp (1594976704)
		)
		: (
			:producer (RAD)
			:server ("fw,14485,0x3b2a598")
			:timestamp (1596510449)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,14485,0x3b2a598")
			:timestamp (1596510452)
		)
		: (
			:producer (RAD)
			:server ("fw,31144,0x3b2a598")
			:timestamp (1598029710)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,31144,0x3b2a598")
			:timestamp (1598029712)
		)
		: (
			:producer (RAD)
			:server ("fw,5899,0x3b2bdc0")
			:timestamp (1598944693)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,5899,0x3b2bdc0")
			:timestamp (1598944696)
		)
		: (
			:producer (RAD)
			:server ("fw,4939,0x3b2bdc0")
			:timestamp (1599034493)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4939,0x3b2bdc0")
			:timestamp (1599034496)
		)
		: (
			:producer (RAD)
			:server ("fw,15509,0x3b2a598")
			:timestamp (1600555717)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,15509,0x3b2a598")
			:timestamp (1600555719)
		)
		: (
			:producer (RAD)
			:server ("fw,4965,0x3b2bdc0")
			:timestamp (1600783683)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4965,0x3b2bdc0")
			:timestamp (1600783686)
		)
		: (
			:producer (RAD)
			:server ("fw,24835,0x3b2a598")
			:timestamp (1602368047)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,24835,0x3b2a598")
			:timestamp (1602368050)
		)
	)
)

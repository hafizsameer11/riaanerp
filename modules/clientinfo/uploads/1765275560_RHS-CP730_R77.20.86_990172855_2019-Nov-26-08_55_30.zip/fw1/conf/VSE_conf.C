(VSE_CONF
	: (producers
		: (
			:producer (ida_userspace)
			:server ("fw,5294,0x3b32dc0")
			:timestamp (1571526202)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,14865,0x3b315a8")
			:timestamp (1571980956)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,8179,0x3b315a8")
			:timestamp (1572010921)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,25302,0x3b315a8")
			:timestamp (1572332988)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,11446,0x3b315a8")
			:timestamp (1572416424)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,28410,0x3b315a8")
			:timestamp (1572847845)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4831,0x3b32dc0")
			:timestamp (1574248749)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4762,0x3b32dc0")
			:timestamp (1574251446)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4823,0x3b32dc0")
			:timestamp (1574433067)
		)
	)
)

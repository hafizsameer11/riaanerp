(VSE_CONF
	: (producers
		: (
			:producer (RAD)
			:server ("fw,6530,0x6791b008")
			:timestamp (1597299198)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,6530,0x6791b008")
			:timestamp (1597299199)
		)
		: (
			:producer (RAD)
			:server ("fw,4767,0x3aaf010")
			:timestamp (1601380139)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4767,0x3aaf010")
			:timestamp (1601380140)
		)
		: (
			:producer (RAD)
			:server ("fw,4768,0x3aaf010")
			:timestamp (1601381460)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4768,0x3aaf010")
			:timestamp (1601381461)
		)
		: (
			:producer (RAD)
			:server ("fw,4760,0x3aaf010")
			:timestamp (1601382719)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4760,0x3aaf010")
			:timestamp (1601382720)
		)
		: (
			:producer (RAD)
			:server ("fw,4755,0x3aaf010")
			:timestamp (1601445180)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4755,0x3aaf010")
			:timestamp (1601445181)
		)
		: (
			:producer (RAD)
			:server ("fw,4873,0x3aaf010")
			:timestamp (1601457002)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4873,0x3aaf010")
			:timestamp (1601457003)
		)
		: (
			:producer (RAD)
			:server ("fw,4847,0x3aaf010")
			:timestamp (1601460119)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4847,0x3aaf010")
			:timestamp (1601460120)
		)
		: (
			:producer (RAD)
			:server ("fw,4918,0x3aaf010")
			:timestamp (1601464320)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4918,0x3aaf010")
			:timestamp (1601464321)
		)
		: (
			:producer (RAD)
			:server ("fw,6657,0x3aad7f0")
			:timestamp (1601465841)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,6657,0x3aad7f0")
			:timestamp (1601465842)
		)
		: (
			:producer (RAD)
			:server ("fw,4914,0x3aaf010")
			:timestamp (1601657041)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4914,0x3aaf010")
			:timestamp (1601657043)
		)
		: (
			:producer (RAD)
			:server ("fw,4919,0x3aaf010")
			:timestamp (1602408721)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4919,0x3aaf010")
			:timestamp (1602408722)
		)
		: (
			:producer (RAD)
			:server ("fw,5358,0x3aaf010")
			:timestamp (1603095002)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,5358,0x3aaf010")
			:timestamp (1603095003)
		)
		: (
			:producer (RAD)
			:server ("fw,4878,0x3aaf010")
			:timestamp (1603183562)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4878,0x3aaf010")
			:timestamp (1603183562)
		)
	)
)

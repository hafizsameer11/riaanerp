(VSE_CONF
	: (producers
		: (
			:producer (ida_userspace)
			:server ("fw,7046,0x27120b8")
			:timestamp (1525943868)
		)
		: (
			:producer (RAD)
			:server ("fw,7046,0x27120b8")
			:timestamp (1525945252)
		)
		: (
			:producer (RAD)
			:server ("fw,3070,0x27120c0")
			:timestamp (1525958007)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,3070,0x27120c0")
			:timestamp (1525958009)
		)
		: (
			:producer (RAD)
			:server ("fw,8754,0x2711248")
			:timestamp (1526041270)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,8754,0x2711248")
			:timestamp (1526041271)
		)
		: (
			:producer (RAD)
			:server ("fw,16136,0x2711248")
			:timestamp (1526301779)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,16136,0x2711248")
			:timestamp (1526301780)
		)
		: (
			:producer (RAD)
			:server ("fw,18757,0x2711248")
			:timestamp (1526377277)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,18757,0x2711248")
			:timestamp (1526377278)
		)
		: (
			:producer (RAD)
			:server ("fw,24560,0x2711248")
			:timestamp (1526449490)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,24560,0x2711248")
			:timestamp (1526449491)
		)
		: (
			:producer (RAD)
			:server ("fw,16442,0x2711248")
			:timestamp (1526474217)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,16442,0x2711248")
			:timestamp (1526474218)
		)
		: (
			:producer (RAD)
			:server ("fw,958,0x2711248")
			:timestamp (1526550642)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,958,0x2711248")
			:timestamp (1526550643)
		)
		: (
			:producer (RAD)
			:server ("fw,23979,0x2711248")
			:timestamp (1526627373)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,23979,0x2711248")
			:timestamp (1526627374)
		)
		: (
			:producer (RAD)
			:server ("fw,1121,0x2711248")
			:timestamp (1526778651)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,1121,0x2711248")
			:timestamp (1526778652)
		)
		: (
			:producer (RAD)
			:server ("fw,10099,0x2711248")
			:timestamp (1526935352)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,10099,0x2711248")
			:timestamp (1526935353)
		)
		: (
			:producer (RAD)
			:server ("fw,16570,0x2711248")
			:timestamp (1527007586)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,16570,0x2711248")
			:timestamp (1527007587)
		)
		: (
			:producer (RAD)
			:server ("fw,402,0x2711248")
			:timestamp (1527069892)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,402,0x2711248")
			:timestamp (1527069893)
		)
		: (
			:producer (RAD)
			:server ("fw,6999,0x2711248")
			:timestamp (1527157167)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,6999,0x2711248")
			:timestamp (1527157168)
		)
		: (
			:producer (RAD)
			:server ("fw,29971,0x2711248")
			:timestamp (1527238425)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,29971,0x2711248")
			:timestamp (1527238426)
		)
		: (
			:producer (RAD)
			:server ("fw,26704,0x2711248")
			:timestamp (1527487164)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,26704,0x2711248")
			:timestamp (1527487165)
		)
		: (
			:producer (RAD)
			:server ("fw,16705,0x2711248")
			:timestamp (1527572638)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,16705,0x2711248")
			:timestamp (1527572638)
		)
		: (
			:producer (RAD)
			:server ("fw,29456,0x2711248")
			:timestamp (1527593765)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,29456,0x2711248")
			:timestamp (1527593766)
		)
		: (
			:producer (RAD)
			:server ("fw,29938,0x2711248")
			:timestamp (1527666307)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,29938,0x2711248")
			:timestamp (1527666308)
		)
		: (
			:producer (RAD)
			:server ("fw,24742,0x2711248")
			:timestamp (1527697055)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,24742,0x2711248")
			:timestamp (1527697056)
		)
		: (
			:producer (RAD)
			:server ("fw,15598,0x2711248")
			:timestamp (1527771108)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,15598,0x2711248")
			:timestamp (1527771114)
		)
		: (
			:producer (RAD)
			:server ("fw,6481,0x2711248")
			:timestamp (1527930253)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,6481,0x2711248")
			:timestamp (1527930254)
		)
		: (
			:producer (RAD)
			:server ("fw,5304,0x2711248")
			:timestamp (1528117363)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,5304,0x2711248")
			:timestamp (1528117364)
		)
		: (
			:producer (RAD)
			:server ("fw,12137,0x2711248")
			:timestamp (1528211575)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,12137,0x2711248")
			:timestamp (1528211576)
		)
		: (
			:producer (RAD)
			:server ("fw,15408,0x2711248")
			:timestamp (1528351483)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,15408,0x2711248")
			:timestamp (1528351484)
		)
		: (
			:producer (RAD)
			:server ("fw,22788,0x2711248")
			:timestamp (1528444794)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,22788,0x2711248")
			:timestamp (1528444795)
		)
		: (
			:producer (RAD)
			:server ("fw,23708,0x2711248")
			:timestamp (1528700481)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,23708,0x2711248")
			:timestamp (1528700482)
		)
		: (
			:producer (RAD)
			:server ("fw,9253,0x2711248")
			:timestamp (1528794993)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,9253,0x2711248")
			:timestamp (1528794994)
		)
		: (
			:producer (RAD)
			:server ("fw,3608,0x2711248")
			:timestamp (1528798781)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,3608,0x2711248")
			:timestamp (1528798783)
		)
		: (
			:producer (RAD)
			:server ("fw,16915,0x2711248")
			:timestamp (1528954105)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,16915,0x2711248")
			:timestamp (1528954112)
		)
		: (
			:producer (RAD)
			:server ("fw,16420,0x2711248")
			:timestamp (1529046526)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,16420,0x2711248")
			:timestamp (1529046527)
		)
		: (
			:producer (RAD)
			:server ("fw,18848,0x2711248")
			:timestamp (1529316353)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,18848,0x2711248")
			:timestamp (1529316354)
		)
		: (
			:producer (RAD)
			:server ("fw,1561,0x2711248")
			:timestamp (1529414783)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,1561,0x2711248")
			:timestamp (1529414784)
		)
		: (
			:producer (RAD)
			:server ("fw,27550,0x2711248")
			:timestamp (1529561026)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,27550,0x2711248")
			:timestamp (1529561027)
		)
	)
)

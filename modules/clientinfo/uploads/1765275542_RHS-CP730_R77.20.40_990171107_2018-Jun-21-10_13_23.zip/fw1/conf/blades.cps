#
# OS configuration file for the non-cpmi command line.
#
#
# Syntax (of complicated fields. The rest is obvious):
#
# SIMPLE-OID,	Name, OID, Type
#
# COLUMN,		Name, OID, Type, Index-order, Display, Display-Totals
#
# SUM-COLUMN,	Name, Display-Totlas, Column-Name-1, Column-Name-2, ....
#
# OUTPUT-FORMAT, "DEFAULT"/"LIST"	*If does not exist - assumed "DEFAULT"  
#
# OID-BASE takes effect only within the section it is in.
#
START-BLOCK

	BLOCK-NAME, "BLADE.IPS"

	OID-BASE, 1.3.6.1.4.1.2620.1

	#################################################


	START-FLAVOUR

		FLAVOUR-NAME, "ips"

			ADD-OID-ATOM, 1
			ADD-OID-ATOM, 25
			ADD-OID-ATOM, 19
				SIMPLE-OID, "Attacks Detected", 2, UINT32, 1, 4
			REMOVE-OID-ATOM
			REMOVE-OID-ATOM
			REMOVE-OID-ATOM
			
			ADD-OID-ATOM, 48

			START-TABLE
				START-TABLE-HEADER
					TABLE-NAME,			"Top Protections by sessions (last hour)"
					TABLE-OID,			1.1.1.1
					PRINT-ONLY-TOTALS,	FALSE
					OUTPUT-FORMAT,		DEFAULT
				END-TABLE-HEADER
				
				COLUMN, "Index",		1, UINT32, 1, FALSE, FALSE
				COLUMN, "Protection",	2, STRING, 0, TRUE,  FALSE
				COLUMN, "Sessions",		3, UINT64, 0, TRUE,  FALSE
			END-TABLE

		REMOVE-OID-ATOM

	END-FLAVOUR

END-BLOCK


START-BLOCK

	BLOCK-NAME, "BLADE.FW"

	OID-BASE, 1.3.6.1.4.1.2620.1

	#################################################
	

	START-FLAVOUR

		FLAVOUR-NAME, "fw"

		ADD-OID-ATOM, 1.25

			SIMPLE-OID, "Packets accepted ", 6, UINT64, 1
			SIMPLE-OID, "Packets dropped ", 16, UINT64, 1
			SIMPLE-OID, "Packets rejected", 14, UINT64, 1
			SIMPLE-OID, "Peak number of connections", 4, UINT32, 1
			SIMPLE-OID, "Number of connections", 3, UINT32, 1

			ADD-OID-ATOM, 17

				START-TABLE

					START-TABLE-HEADER

						TABLE-NAME,			"Top Rule Hits"
						TABLE-OID,			1
						PRINT-ONLY-TOTALS,	FALSE
						OUTPUT-FORMAT,		DEFAULT

					END-TABLE-HEADER

					COLUMN, "Index",		1, UINT32, 1, FALSE, FALSE
					COLUMN, "rule index",	2, STRING, 0, TRUE, FALSE
					COLUMN, "rule count",	3, UINT32, 0, TRUE, FALSE
					
				END-TABLE

			REMOVE-OID-ATOM
		REMOVE-OID-ATOM

	END-FLAVOUR

END-BLOCK

START-BLOCK

		BLOCK-NAME, "BLADE.ANTI_VIRUS"
		OID-BASE, 1.3.6.1.4.1.2620.1

######################################################################

		START-FLAVOUR

			FLAVOUR-NAME, "av"

			SIMPLE-OID, "Viruses detected", 1.26.9.10.1, UINT32, 1
			SIMPLE-OID, "Scanned files", 1.26.9.10.3, UINT32, 1

			ADD-OID-ATOM, 24 

				START-TABLE
					START-TABLE-HEADER
						TABLE-NAME,			"Top Viruses"
						TABLE-OID,			3.1
						PRINT-ONLY-TOTALS,	FALSE
						OUTPUT-FORMAT,		DEFAULT
					END-TABLE-HEADER
					COLUMN, "Index",	1, UINT32, 1, FALSE, FALSE
					COLUMN, "Name",		2, STRING, 0, TRUE, FALSE
					COLUMN, "Count ",	3, UINT32, 0, TRUE, FALSE
				END-TABLE

			REMOVE-OID-ATOM # Removes the atom

		END-FLAVOUR
END-BLOCK

START-BLOCK

		BLOCK-NAME, "BLADE.ANTI_MALWARE"
		OID-BASE, 1.3.6.1.4.1.2620.1

######################################################################

		START-FLAVOUR

			FLAVOUR-NAME, "amw"

			SIMPLE-OID, "AV detected", 1.25.20.1.1, UINT32, 1
			SIMPLE-OID, "AV blocked", 1.25.20.1.2, UINT32, 1
			SIMPLE-OID, "AB detected", 1.25.20.2.1, UINT32, 1
			SIMPLE-OID, "AB blocked", 1.25.20.2.2, UINT32, 1

			ADD-OID-ATOM, 47
				START-TABLE
					START-TABLE-HEADER
						TABLE-NAME,     "Top malwares (last hour)"
						TABLE-OID,      1.15.1
						PRINT-ONLY-TOTALS, FALSE
						OUTPUT-FORMAT,  DEFAULT
					END-TABLE-HEADER
					COLUMN, "Index",        1, UINT32, 1, FALSE, FALSE
					COLUMN, "Malware",      2, STRING, 0, TRUE, FALSE
					COLUMN, "Incidents",    3, UINT64, 0, TRUE, FALSE
					COLUMN, "Severity",     4, INT32, 0, TRUE, FALSE
				END-TABLE
			REMOVE-OID-ATOM

		END-FLAVOUR
END-BLOCK

START-BLOCK

		BLOCK-NAME, "BLADE.VPN_SITE_TO_SITE"
		OID-BASE, 1.3.6.1.4.1.2620.1

######################################################################

		START-FLAVOUR
			FLAVOUR-NAME, "vpn"

			ADD-OID-ATOM, 2
				SIMPLE-OID, "Current tunnels", 5.2.1, UINT64, 1 # i think the oid should be 5.4.21
				SIMPLE-OID, "Current initiated tunnels", 9.1.2, UINT64, 1 
				SIMPLE-OID, "Current responded tunnels", 9.1.3, UINT64, 1 
			REMOVE-OID-ATOM # end of general statistics 
        END-FLAVOUR
END-BLOCK

START-BLOCK

		BLOCK-NAME, "BLADE.VPN_REMOTE_ACCESS"
		OID-BASE, 1.3.6.1.4.1.2620.1

######################################################################

		START-FLAVOUR
			FLAVOUR-NAME, "vpn"

			ADD-OID-ATOM, 2
				SIMPLE-OID, "Remote Access tunnels", 5.4.23, UINT64, 1
				SIMPLE-OID, "Max concurrent remote access tunnels", 5.4.24, UINT64, 1
			REMOVE-OID-ATOM # end of general statistics 
		END-FLAVOUR
END-BLOCK

START-BLOCK

		BLOCK-NAME, "BLADE.ANTI_SPAM"
		OID-BASE, 1.3.6.1.4.1.2620.1

######################################################################

		START-FLAVOUR

			FLAVOUR-NAME, "aspm"

			ADD-OID-ATOM, 30
				SIMPLE-OID, "Emails scanned", 6.1, UINT32, 1
				SIMPLE-OID, "Spam Emails found", 6.2, UINT32, 1
			REMOVE-OID-ATOM # Removes the atom

		END-FLAVOUR
END-BLOCK


START-BLOCK

		BLOCK-NAME, "BLADE.IDENTITY_AWARENESS"
		OID-BASE, 1.3.6.1.4.1.2620.1

######################################################################

		START-FLAVOUR

			FLAVOUR-NAME, "ia"

			ADD-OID-ATOM, 38
				SIMPLE-OID, "Authenticated Users", 2, UINT32, 1
				SIMPLE-OID, "Unauthenticated Guests", 3, UINT32, 1
			REMOVE-OID-ATOM # Removes the atom

			START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Top Users by sessions (last hour)"
				TABLE-OID,         2.1.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "User",        2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Sessions",    3, UINT64,     0, TRUE,  FALSE
		
		END-TABLE
		
		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Top Users by bandwidth (last hour)"
				TABLE-OID,         2.1.2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       	    1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "User",        	    2, STRING, 0, TRUE,  FALSE
			COLUMN,     "Bytes",     3, UINT64, 0, TRUE,  FALSE
		
		END-TABLE

		END-FLAVOUR
END-BLOCK

START-BLOCK

		BLOCK-NAME, "BLADE.APPLICATION_CONTROL"
		OID-BASE, 1.3.6.1.4.1.2620.1

######################################################################

		START-FLAVOUR
			FLAVOUR-NAME, "apcl"
			
			ADD-OID-ATOM, 41

			START-TABLE
				START-TABLE-HEADER
					TABLE-NAME,			"Top applications by sessions (last hour)"
					TABLE-OID,			1.1.1.1
					PRINT-ONLY-TOTALS,	FALSE
					OUTPUT-FORMAT,		DEFAULT
				END-TABLE-HEADER
				
				COLUMN, "Index",	1, UINT32, 1, FALSE, FALSE 
				COLUMN, "Category",	2, STRING, 0, TRUE,	 FALSE
				COLUMN, "Sessions",	3, UINT64, 0, TRUE,	 FALSE
				COLUMN, "Bytes",	4, UINT64, 0, TRUE,	 FALSE
				COLUMN, "Risk",     5, INT32,    0, TRUE,   FALSE
				COLUMN, "Name",     6, STRING, 0, TRUE,   FALSE    
				COLUMN, "Description", 7, STRING, 0, TRUE,   FALSE     
				COLUMN, "Category", 8, STRING, 0, TRUE,   FALSE     
				COLUMN, "Blocked",  9, UINT64,  0, TRUE,   FALSE

			END-TABLE

			START-TABLE
				START-TABLE-HEADER
					TABLE-NAME,			"Top applications by bandwidth (last hour)"
					TABLE-OID,			1.1.2.1
					PRINT-ONLY-TOTALS,	FALSE
					OUTPUT-FORMAT,		DEFAULT
				END-TABLE-HEADER
				
				COLUMN, "Index",	1, UINT32, 1, FALSE, FALSE 
				COLUMN, "Category",	2, STRING, 0, TRUE,	 FALSE
				COLUMN, "Bytes",	3, UINT64, 0, TRUE,	 FALSE
				COLUMN, "Sessions", 4, UINT64,    0, TRUE,   FALSE
				COLUMN, "Risk",     5, INT32,    0, TRUE,   FALSE
				COLUMN, "Name",     6, STRING, 0, TRUE,   FALSE    
				COLUMN, "Description", 7, STRING, 0, TRUE,   FALSE     
				COLUMN, "Category", 8, STRING, 0, TRUE,   FALSE     
				COLUMN, "Blocked",  9, UINT64,  0, TRUE,   FALSE 

			END-TABLE

			REMOVE-OID-ATOM # Removes the atom
		END-FLAVOUR

END-BLOCK
START-BLOCK

	BLOCK-NAME, "Scrub"

	OID-BASE, 1.3.6.1.4.1.2620.1.50

	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "default"

	END-FLAVOUR

END-BLOCK

# Package number:

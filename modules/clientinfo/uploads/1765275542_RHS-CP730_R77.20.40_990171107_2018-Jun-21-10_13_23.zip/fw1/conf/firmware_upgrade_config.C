(
	:clientID (101)
	:dcUrl ("https://updates.checkpoint.com/WebService/services/DownloadMetaDataService")
	:clientVersion (700_R77.20.75_990172320)
	:clientProduct (700_appliance)
	:clientOS (All)
	:description ("{              
'description': 'R77.20 HFA 75 Build 990172320 - What's New:'
, 'notes': [
{'text': 'Stability fixes'}
,{'text': 'For more information, refer to sk121758'}
]
}")
	:CertificateKey (CK-00-1C-7F-7C-50-55)
)

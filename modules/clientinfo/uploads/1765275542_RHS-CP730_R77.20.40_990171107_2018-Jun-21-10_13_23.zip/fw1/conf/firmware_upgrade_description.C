{              
"description": "R77.20 HFA 75 Build 990172320 - What's New:"
, "notes": [
{"text": "Stability fixes"}
,{"text": "For more information, refer to sk121758"}
]
}
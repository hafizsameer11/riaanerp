(
	:clientID (101)
	:dcUrl ("https://updates.checkpoint.com/WebService/services/DownloadMetaDataService")
	:clientVersion (700_R77.20.87_990173004)
	:clientProduct (700_appliance)
	:clientOS (All)
	:description ("{              
'description': 'R77.20 HFA 87 Build 9990173004 - What's New:'
, 'notes': [
{'text': ''}
]
}")
	:CertificateKey (CK-00-1C-7F-7C-52-56)
)

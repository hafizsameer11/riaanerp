(VSE_CONF
	: (producers
		: (
			:producer (RAD)
			:server ("fw,5304,0x3b2bdc0")
			:timestamp (1553036772)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,5304,0x3b2bdc0")
			:timestamp (1553036775)
		)
		: (
			:producer (RAD)
			:server ("fw,4880,0x3b2bdc0")
			:timestamp (1553249805)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4880,0x3b2bdc0")
			:timestamp (1553249807)
		)
		: (
			:producer (RAD)
			:server ("fw,4876,0x3b2bdc0")
			:timestamp (1553325822)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4876,0x3b2bdc0")
			:timestamp (1553325825)
		)
		: (
			:producer (RAD)
			:server ("fw,16366,0x3b2a598")
			:timestamp (1555049292)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,16366,0x3b2a598")
			:timestamp (1555049295)
		)
		: (
			:producer (RAD)
			:server ("fw,25031,0x3b2a598")
			:timestamp (1556802620)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,25031,0x3b2a598")
			:timestamp (1556802623)
		)
		: (
			:producer (RAD)
			:server ("fw,4850,0x3b2bdc0")
			:timestamp (1558679036)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4850,0x3b2bdc0")
			:timestamp (1558679039)
		)
		: (
			:producer (RAD)
			:server ("fw,4893,0x3b2bdc0")
			:timestamp (1558684125)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4893,0x3b2bdc0")
			:timestamp (1558684128)
		)
		: (
			:producer (RAD)
			:server ("fw,24335,0x3b2a598")
			:timestamp (1560761779)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,24335,0x3b2a598")
			:timestamp (1560761781)
		)
		: (
			:producer (RAD)
			:server ("fw,9636,0x3b2a598")
			:timestamp (1562455228)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,9636,0x3b2a598")
			:timestamp (1562455231)
		)
		: (
			:producer (RAD)
			:server ("fw,30486,0x3b2a598")
			:timestamp (1564149332)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,30486,0x3b2a598")
			:timestamp (1564149334)
		)
		: (
			:producer (RAD)
			:server ("fw,19002,0x3b2a598")
			:timestamp (1565834442)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,19002,0x3b2a598")
			:timestamp (1565834444)
		)
		: (
			:producer (RAD)
			:server ("fw,14984,0x3b2a598")
			:timestamp (1567512401)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,14984,0x3b2a598")
			:timestamp (1567512403)
		)
		: (
			:producer (RAD)
			:server ("fw,20006,0x3b2a598")
			:timestamp (1569211969)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,20006,0x3b2a598")
			:timestamp (1569211972)
		)
		: (
			:producer (RAD)
			:server ("fw,15493,0x3b2a598")
			:timestamp (1570911299)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,15493,0x3b2a598")
			:timestamp (1570911302)
		)
		: (
			:producer (RAD)
			:server ("fw,4874,0x3b2bdc0")
			:timestamp (1571360082)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4874,0x3b2bdc0")
			:timestamp (1571360086)
		)
		: (
			:producer (RAD)
			:server ("fw,30928,0x3b2a598")
			:timestamp (1572222828)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,30928,0x3b2a598")
			:timestamp (1572222830)
		)
		: (
			:producer (RAD)
			:server ("fw,4845,0x3b2bdc0")
			:timestamp (1573011286)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4845,0x3b2bdc0")
			:timestamp (1573011289)
		)
		: (
			:producer (RAD)
			:server ("fw,3644,0x3b2a598")
			:timestamp (1573950217)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,3644,0x3b2a598")
			:timestamp (1573950219)
		)
		: (
			:producer (RAD)
			:server ("fw,24020,0x3b2a598")
			:timestamp (1574904167)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,24020,0x3b2a598")
			:timestamp (1574904169)
		)
		: (
			:producer (RAD)
			:server ("fw,8432,0x3b2a598")
			:timestamp (1575851529)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,8432,0x3b2a598")
			:timestamp (1575851531)
		)
		: (
			:producer (RAD)
			:server ("fw,26320,0x3b2a598")
			:timestamp (1576806704)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,26320,0x3b2a598")
			:timestamp (1576806706)
		)
		: (
			:producer (RAD)
			:server ("fw,10393,0x3b2a598")
			:timestamp (1577751698)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,10393,0x3b2a598")
			:timestamp (1577751700)
		)
		: (
			:producer (RAD)
			:server ("fw,618,0x3b2a598")
			:timestamp (1578697015)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,618,0x3b2a598")
			:timestamp (1578697018)
		)
		: (
			:producer (RAD)
			:server ("fw,23956,0x3b2a598")
			:timestamp (1579637255)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,23956,0x3b2a598")
			:timestamp (1579637257)
		)
		: (
			:producer (RAD)
			:server ("fw,18881,0x3b2a598")
			:timestamp (1580582018)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,18881,0x3b2a598")
			:timestamp (1580582020)
		)
		: (
			:producer (RAD)
			:server ("fw,19509,0x3b2a598")
			:timestamp (1581669893)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,19509,0x3b2a598")
			:timestamp (1581669895)
		)
		: (
			:producer (RAD)
			:server ("fw,32296,0x3b2a598")
			:timestamp (1583552523)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,32296,0x3b2a598")
			:timestamp (1583552525)
		)
		: (
			:producer (RAD)
			:server ("fw,18303,0x3b2a598")
			:timestamp (1585432482)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,18303,0x3b2a598")
			:timestamp (1585432485)
		)
		: (
			:producer (RAD)
			:server ("fw,32658,0x3b2a598")
			:timestamp (1587318576)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,32658,0x3b2a598")
			:timestamp (1587318578)
		)
		: (
			:producer (RAD)
			:server ("fw,13658,0x3b2a598")
			:timestamp (1589176738)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,13658,0x3b2a598")
			:timestamp (1589176740)
		)
		: (
			:producer (RAD)
			:server ("fw,23262,0x3b2a598")
			:timestamp (1591041964)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,23262,0x3b2a598")
			:timestamp (1591041967)
		)
		: (
			:producer (RAD)
			:server ("fw,4683,0x3b2a598")
			:timestamp (1592905513)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4683,0x3b2a598")
			:timestamp (1592905515)
		)
		: (
			:producer (RAD)
			:server ("fw,12603,0x3b2a598")
			:timestamp (1594767398)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,12603,0x3b2a598")
			:timestamp (1594767400)
		)
		: (
			:producer (RAD)
			:server ("fw,23358,0x3b2a598")
			:timestamp (1596643748)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,23358,0x3b2a598")
			:timestamp (1596643751)
		)
		: (
			:producer (RAD)
			:server ("fw,31214,0x3b2a598")
			:timestamp (1598503810)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,31214,0x3b2a598")
			:timestamp (1598503812)
		)
		: (
			:producer (RAD)
			:server ("fw,4790,0x3b2bdc0")
			:timestamp (1600249412)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4790,0x3b2bdc0")
			:timestamp (1600249415)
		)
		: (
			:producer (RAD)
			:server ("fw,10794,0x3b2a598")
			:timestamp (1602100842)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,10794,0x3b2a598")
			:timestamp (1602100844)
		)
	)
)

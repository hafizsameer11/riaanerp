(
	:services (
		:antivirus (
			:0 (
				:request (
					:enc_key ()
					:enc_id (0)
					:host (cws.checkpoint.com)
					:port (80)
				)
			)
		)
		:malware (
			:0 (
				:request (
					:enc_key ()
					:enc_id (0)
					:host (cws.checkpoint.com)
					:port (80)
				)
			)
		)
	)
)

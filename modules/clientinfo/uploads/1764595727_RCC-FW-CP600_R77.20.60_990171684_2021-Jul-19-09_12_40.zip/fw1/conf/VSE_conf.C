(VSE_CONF
	: (producers
		: (
			:producer (RAD)
			:server ("fw,4055,0x2e1a358")
			:timestamp (1614849797)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4055,0x2e1a358")
			:timestamp (1614849800)
		)
		: (
			:producer (RAD)
			:server ("fw,1962,0x2e1a358")
			:timestamp (1615289690)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,1962,0x2e1a358")
			:timestamp (1615289694)
		)
		: (
			:producer (RAD)
			:server ("fw,1898,0x2e1a350")
			:timestamp (1615453503)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,1898,0x2e1a350")
			:timestamp (1615453505)
		)
		: (
			:producer (RAD)
			:server ("fw,1904,0x2e1a350")
			:timestamp (1615734182)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,1904,0x2e1a350")
			:timestamp (1615734183)
		)
		: (
			:producer (RAD)
			:server ("fw,1903,0x2e1a350")
			:timestamp (1615760241)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,1903,0x2e1a350")
			:timestamp (1615760244)
		)
		: (
			:producer (RAD)
			:server ("fw,1957,0x2e1a350")
			:timestamp (1615809926)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,1957,0x2e1a350")
			:timestamp (1615809928)
		)
		: (
			:producer (RAD)
			:server ("fw,1955,0x2e1a350")
			:timestamp (1615815147)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,1955,0x2e1a350")
			:timestamp (1615815149)
		)
		: (
			:producer (RAD)
			:server ("fw,2013,0x2e1a358")
			:timestamp (1615822948)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,2013,0x2e1a358")
			:timestamp (1615822949)
		)
		: (
			:producer (RAD)
			:server ("fw,1956,0x2e1a350")
			:timestamp (1615985927)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,1956,0x2e1a350")
			:timestamp (1615985929)
		)
		: (
			:producer (RAD)
			:server ("fw,1647,0x2e18088")
			:timestamp (1620634116)
		)
		: (
			:producer (RAD)
			:server ("fw,1949,0x2e19790")
			:timestamp (1623077101)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,1949,0x2e19790")
			:timestamp (1623077103)
		)
		: (
			:producer (RAD)
			:server ("fw,18609,0x2e19790")
			:timestamp (1623656165)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,18609,0x2e19790")
			:timestamp (1623656166)
		)
	)
)

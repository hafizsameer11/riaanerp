(VSE_CONF
	: (producers
		: (
			:producer (ida_userspace)
			:server ("fw,5460,0x3b32dc0")
			:timestamp (1571345841)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,16290,0x3b315a8")
			:timestamp (1571926366)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,14567,0x3b315a8")
			:timestamp (1572524379)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,2922,0x3b315a8")
			:timestamp (1573018270)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,7075,0x3b315a8")
			:timestamp (1573563112)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,14102,0x3b315a8")
			:timestamp (1574092564)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,7677,0x3b315a8")
			:timestamp (1574628644)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4560,0x3b315a8")
			:timestamp (1575155741)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,14734,0x3b315a8")
			:timestamp (1576137555)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,10450,0x3b315a8")
			:timestamp (1577696210)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4940,0x3b315a8")
			:timestamp (1578952377)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,7060,0x3b315a8")
			:timestamp (1580417723)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4852,0x3b315a8")
			:timestamp (1581265648)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,23454,0x3b315a8")
			:timestamp (1582498989)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,8851,0x3b315a8")
			:timestamp (1583830499)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,10040,0x3b315a8")
			:timestamp (1585256580)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,21128,0x3b315a8")
			:timestamp (1586657118)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,870,0x3b315a8")
			:timestamp (1588180387)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,30037,0x3b315a8")
			:timestamp (1589601919)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,3107,0x3b315a8")
			:timestamp (1590994671)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,8721,0x3b315a8")
			:timestamp (1592523101)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4938,0x3b32dc0")
			:timestamp (1592801108)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,26982,0x3b315a8")
			:timestamp (1594099032)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,6242,0x3b315a8")
			:timestamp (1595588765)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4540,0x3b315a8")
			:timestamp (1597071425)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,31484,0x3b315a8")
			:timestamp (1598909848)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4947,0x3b32dc0")
			:timestamp (1601194779)
		)
	)
)

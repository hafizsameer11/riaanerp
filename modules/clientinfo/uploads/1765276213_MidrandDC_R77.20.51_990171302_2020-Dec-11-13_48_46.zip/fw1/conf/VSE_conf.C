(VSE_CONF
	: (producers
		: (
			:producer (ida_userspace)
			:server ("fw,5748,0xa78e2008")
			:timestamp (1594639651)
		)
		: (
			:producer (RAD)
			:server ("fw,5748,0xa78e2008")
			:timestamp (1594639767)
		)
		: (
			:producer (RAD)
			:server ("fw,3318,0xa78bc008")
			:timestamp (0)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,3318,0xa78bc008")
			:timestamp (1594640288)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,3223,0xa78f0008")
			:timestamp (1594643312)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,3224,0xa78c1008")
			:timestamp (1594703778)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,3225,0xa78b8008")
			:timestamp (1594705267)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,3222,0xa7913008")
			:timestamp (1595613059)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,3219,0xa78de008")
			:timestamp (1597077902)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,3331,0xa7941008")
			:timestamp (1607684958)
		)
	)
)

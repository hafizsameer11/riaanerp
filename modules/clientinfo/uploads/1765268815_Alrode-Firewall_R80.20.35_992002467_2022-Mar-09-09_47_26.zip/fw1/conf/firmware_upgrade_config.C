(
	:clientID (120)
	:dcUrl ("https://updates.checkpoint.com/WebService/services/DownloadMetaDataService")
	:clientVersion (1500_R80.20.35_992002613)
	:clientProduct (1500_appliance)
	:clientOS (All)
	:description ("{              
'description': 'R80.20 HFA 35 Build 992002613- What's New:'
, 'notes': [
{'text': 'SSL Inspection enhancments'}
,{'text': 'WiFi enhancments'}
,{'text': 'stability and performance improvments'}
]
}")
	:CertificateKey (CK-00-1C-7F-AE-4E-2E)
)

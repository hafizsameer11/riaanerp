{              
"description": "R80.20 HFA 35 Build 992002613- What's New:"
, "notes": [
{"text": "SSL Inspection enhancments"}
,{"text": "WiFi enhancments"}
,{"text": "stability and performance improvments"}
]
}
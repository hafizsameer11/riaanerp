(VSE_CONF
	: (producers
		: (
			:producer (rad_tp)
			:server ("fw,6465,0x4edab68")
			:timestamp (1642409736)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,6465,0x4edab68")
			:timestamp (1642409737)
		)
		: (
			:producer (rad_tp)
			:server ("fw,5939,0x53f1b98")
			:timestamp (1642411127)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,5939,0x53f1b98")
			:timestamp (1642411128)
		)
		: (
			:producer (rad_tp)
			:server ("fw,5957,0x52de698")
			:timestamp (1642487872)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,5957,0x52de698")
			:timestamp (1642487872)
		)
		: (
			:producer (rad_tp)
			:server ("fw,6000,0x5b21698")
			:timestamp (1642571487)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,6000,0x5b21698")
			:timestamp (1642571488)
		)
		: (
			:producer (rad_tp)
			:server ("fw,5992,0x69bb698")
			:timestamp (1642599221)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,5992,0x69bb698")
			:timestamp (1642599222)
		)
		: (
			:producer (rad_tp)
			:server ("fw,8787,0x51f3d78")
			:timestamp (1642600154)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,8787,0x51f3d78")
			:timestamp (1642600154)
		)
		: (
			:producer (rad_tp)
			:server ("fw,5994,0x684a698")
			:timestamp (1642959712)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,5994,0x684a698")
			:timestamp (1642959712)
		)
		: (
			:producer (rad_tp)
			:server ("fw,6027,0x5f4d698")
			:timestamp (1643001498)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,6027,0x5f4d698")
			:timestamp (1643001499)
		)
		: (
			:producer (rad_tp)
			:server ("fw,5962,0x617e698")
			:timestamp (1643032245)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,5962,0x617e698")
			:timestamp (1643032246)
		)
		: (
			:producer (rad_tp)
			:server ("fw,987,0x6463d78")
			:timestamp (1643089530)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,987,0x6463d78")
			:timestamp (1643089531)
		)
		: (
			:producer (rad_tp)
			:server ("fw,5921,0x5be7698")
			:timestamp (1645705469)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,5921,0x5be7698")
			:timestamp (1645705470)
		)
	)
)

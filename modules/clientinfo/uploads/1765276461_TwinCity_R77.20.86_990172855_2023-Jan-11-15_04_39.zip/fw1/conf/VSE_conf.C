(VSE_CONF
	: (producers
		: (
			:producer (ida_userspace)
			:server ("fw,5460,0x3b32dc0")
			:timestamp (1571345841)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,16290,0x3b315a8")
			:timestamp (1571926366)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,14567,0x3b315a8")
			:timestamp (1572524379)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,2922,0x3b315a8")
			:timestamp (1573018270)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,7075,0x3b315a8")
			:timestamp (1573563112)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,14102,0x3b315a8")
			:timestamp (1574092564)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,7677,0x3b315a8")
			:timestamp (1574628644)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4560,0x3b315a8")
			:timestamp (1575155741)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,14734,0x3b315a8")
			:timestamp (1576137555)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,10450,0x3b315a8")
			:timestamp (1577696210)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4940,0x3b315a8")
			:timestamp (1578952377)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,7060,0x3b315a8")
			:timestamp (1580417723)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4852,0x3b315a8")
			:timestamp (1581265648)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,23454,0x3b315a8")
			:timestamp (1582498989)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,8851,0x3b315a8")
			:timestamp (1583830499)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,10040,0x3b315a8")
			:timestamp (1585256580)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,21128,0x3b315a8")
			:timestamp (1586657118)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,870,0x3b315a8")
			:timestamp (1588180387)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,30037,0x3b315a8")
			:timestamp (1589601919)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,3107,0x3b315a8")
			:timestamp (1590994671)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,8721,0x3b315a8")
			:timestamp (1592523101)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4938,0x3b32dc0")
			:timestamp (1592801108)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,26982,0x3b315a8")
			:timestamp (1594099032)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,6242,0x3b315a8")
			:timestamp (1595588765)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4540,0x3b315a8")
			:timestamp (1597071425)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,31484,0x3b315a8")
			:timestamp (1598909848)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4947,0x3b32dc0")
			:timestamp (1601194779)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,9247,0x3b315a8")
			:timestamp (1604488588)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,2159,0x3b315a8")
			:timestamp (1606246567)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4957,0x3b32dc0")
			:timestamp (1607598638)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,1692,0x3b315a8")
			:timestamp (1608616454)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,7924,0x3b315a8")
			:timestamp (1609542301)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,8191,0x3b315a8")
			:timestamp (1610487660)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,25638,0x3b315a8")
			:timestamp (1611422222)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,3448,0x3b315a8")
			:timestamp (1612378398)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,10410,0x3b315a8")
			:timestamp (1613451318)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,20591,0x3b315a8")
			:timestamp (1614466343)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,15946,0x3b315a8")
			:timestamp (1615523675)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,1827,0x3b315a8")
			:timestamp (1616662947)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,21290,0x3b315a8")
			:timestamp (1617663879)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,1418,0x3b315a8")
			:timestamp (1618673228)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4379,0x3b315a8")
			:timestamp (1619679884)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,427,0x3b315a8")
			:timestamp (1620695245)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4933,0x3b32dc0")
			:timestamp (1620705459)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4882,0x3b32dc0")
			:timestamp (1621099538)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,9503,0x3b315a8")
			:timestamp (1622097797)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,21012,0x3b315a8")
			:timestamp (1623111672)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,2511,0x3b315a8")
			:timestamp (1624132770)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,32575,0x3b315a8")
			:timestamp (1625161091)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,29262,0x3b315a8")
			:timestamp (1626232037)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,15257,0x3b315a8")
			:timestamp (1628031449)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4858,0x3b32dc0")
			:timestamp (1629272499)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4796,0x3b32dc0")
			:timestamp (1629273929)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4786,0x3b32dc0")
			:timestamp (1629354088)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,23378,0x3b315a8")
			:timestamp (1639757721)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4914,0x3b32dc0")
			:timestamp (1643636891)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4899,0x3b32dc0")
			:timestamp (1645456564)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4931,0x3b32dc0")
			:timestamp (1645862019)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4813,0x3b32dc0")
			:timestamp (1654173875)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4812,0x3b32dc0")
			:timestamp (1654185878)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4819,0x3b32dc0")
			:timestamp (1654186898)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4824,0x3b32dc0")
			:timestamp (1654858058)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4818,0x3b32dc0")
			:timestamp (1655900018)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4807,0x3b32dc0")
			:timestamp (1656707316)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4811,0x3b32dc0")
			:timestamp (1657313375)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4827,0x3b32dc0")
			:timestamp (1666699483)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4816,0x3b32dc0")
			:timestamp (1666707969)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4822,0x3b32dc0")
			:timestamp (1666735516)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,14223,0x3b315a8")
			:timestamp (1667459906)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4815,0x3b32dc0")
			:timestamp (1667829911)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4817,0x3b32dc0")
			:timestamp (1667996490)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4809,0x3b32dc0")
			:timestamp (1668720894)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4823,0x3b32dc0")
			:timestamp (1668881734)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4825,0x3b32dc0")
			:timestamp (1669007135)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4826,0x3b32dc0")
			:timestamp (1669119003)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4836,0x3b32dc0")
			:timestamp (1669194466)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4831,0x3b32dc0")
			:timestamp (1671009221)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4834,0x3b32dc0")
			:timestamp (1671015187)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4851,0x3b32dc0")
			:timestamp (1671448423)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4841,0x3b32dc0")
			:timestamp (1672993331)
		)
	)
)

(VSE_CONF
	: (producers
		: (
			:producer (ida_userspace)
			:server ("fw,5297,0x3b32dc0")
			:timestamp (1561244660)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,9149,0x3b315a8")
			:timestamp (1562156600)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,12297,0x3b315a8")
			:timestamp (1562736678)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,8278,0x3b315a8")
			:timestamp (1562764849)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,1286,0x3b315a8")
			:timestamp (1562837647)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,22657,0x3b315a8")
			:timestamp (1562910419)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,19409,0x3b315a8")
			:timestamp (1563285367)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,13764,0x3b315a8")
			:timestamp (1563431121)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,19593,0x3b315a8")
			:timestamp (1563444293)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,1001,0x3b315a8")
			:timestamp (1564552939)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,6676,0x3b315a8")
			:timestamp (1564997299)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,18105,0x3b315a8")
			:timestamp (1565010853)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,22087,0x3b315a8")
			:timestamp (1565179440)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4809,0x3b32dc0")
			:timestamp (1566202684)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4815,0x3b32dc0")
			:timestamp (1566208146)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,6330,0x3b315a8")
			:timestamp (1566882832)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,12253,0x3b315a8")
			:timestamp (1566921431)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4737,0x3b315a8")
			:timestamp (1567427755)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,22460,0x3b315a8")
			:timestamp (1567594229)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,29548,0x3b315a8")
			:timestamp (1567605156)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,18115,0x3b315a8")
			:timestamp (1568291077)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,25472,0x3b315a8")
			:timestamp (1568728255)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4821,0x3b32dc0")
			:timestamp (1568785629)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,13706,0x3b315a8")
			:timestamp (1568965831)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,429,0x3b315a8")
			:timestamp (1570004188)
		)
	)
)

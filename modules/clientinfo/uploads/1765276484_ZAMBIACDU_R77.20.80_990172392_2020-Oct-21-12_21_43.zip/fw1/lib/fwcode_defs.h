#ifndef __h_fwcode_defs__
#define __h_fwcode_defs__

/*
 * All rights reserved.
 * 
 * This is proprietary information of Check Point Software Technologies
 * Ltd., which is provided for informational purposes only and for use
 * solely in conjunction with the authorized use of Check Point Software
 * Technologies Ltd. products.  The viewing and use of this information is
 * subject, to the extent appropriate, to the terms and conditions of the
 * license agreement that authorizes the use of the relevant product.
 * 
 * $Log: fwcode_defs.h,v $
 * 2008/02/05, flo, CR00403314, lee - Merge aqua_hydra to flo
 * 2008/01/28, aqua_hydra, CR00382564, hilan - merge aqua_dev to aqua_hydra 
 *
 * Revision 1.2.4.2.16.3.600.2  2007/12/13 15:00:01  danp
 *
 * Remark-ID: CR00364745
 * Authorized-By: mwindler
 *
 * Revision 1.2.4.2.16.3.600.1  2007/08/16 15:33:35  lee
 * Merge aqua_enf_ga b8 to aqua_dev
 * Remark-ID: CR00362126
 * Authorized-By: gguzner
 *
 * Revision 1.2.4.2.16.3.414.1.4.1  2007/05/29 07:11:07  tomerl
 * Code generation for ASPII additions to protocol type object
 * Remark-ID: CR00343692
 * Authorized-By: rmosh
 *
 * Revision 1.2.4.2.16.3.414.1  2007/03/26 15:11:13  reut
 * Add SPII protocol flags definition
 * Remark-ID: CR00348924
 * Authorized-By: rmosh
 *
 * Revision 1.2.4.2.16.3  2004/07/22 13:44:13  amir
 * merge cor_gtp from gal_san4 to dal
 * Remark-ID: CR00133967
 * Authorized-By: aviv
 *
 * Revision 1.2.4.2.16.1.10.1  2004/07/11 10:43:47  amir
 * merge cor_gtp to dal_san4
 * Remark-ID: CR00123456
 * Authorized-By: aviv
 *
 * Revision 1.2.4.2.16.1  2004/02/25 19:49:43  ynissim
 * Merge TRINI to DAL
 * Remark-ID: CR00126125
 * Authorized-By: ynissim
 *
 * Revision 1.2.2.2.32.1.24.1  2003/12/03 16:27:34  ynissim
 * Merge V_TRI to V_TRINI
 * Remark-ID: CR00119093
 * Authorized-By: assi
 *
 * Revision 1.2.2.2.32.1.16.1  2003/11/12 10:17:02  umaimon
 * MERGE CAL_TRI to V_TRI
 * Remark-ID: CR00116490
 * Authorized-By: umaimon
 *
 * Revision 1.2.2.2.40.1  2003/08/05 09:04:16  rimon
 * Added macros for DNS port randomization
 * Remark-ID:  CR00108147
 * Authorized-By:  assi
 *
 * Revision 1.2.4.2  2003/04/21 06:54:18  alonk
 * Merge DAY_MERGE_3 to DAY (MERGE_DAY_MERGE_3_M1_TO_DAY)
 * Remark-ID: CR00097604
 * Authorized-By: assi
 *
 * Revision 1.2.4.1.6.1  2003/03/04 14:00:31  alonk
 * Merge Cal M3 to DAY_MERGE_3
 * Remark-ID: CR00093012
 * Authorized-By: alonk
 *
 * Revision 1.2.4.1  2002/12/23 10:29:59  gguzner
 * MERGE_CAL_M2_TO_DAY
 * Remark-ID: CR00084545
 * Authorized-By: gguzner
 *
 * Revision 1.2.2.2  2003/01/09 15:52:33  zegman
 * Added CIFS_DONT_LOG_IPC
 * Remark-ID: CR00086292
 * Authorized-By: assi
 *
 * Revision 1.2.2.1  2002/12/09 17:02:10  zegman
 * Added CIFS_BLOCK_REGISTRY_ACCESS
 * Remark-ID: CR00083594
 * Authorized-By: assi
 *
 * Revision 1.2  2002/08/15 14:46:25  gguzner
 * Merge MERGE_BUF_M1_TO_DEV
 * Remark-ID: CR00071086
 * Authorized-By:gguzner
 *
 * Revision 1.1.4.4  2002/06/03 13:01:19  zegman
 * Added CIFS logging flags
 * Remark-ID: CR00061925
 * Authorized-By: assi
 *
 * $RCSfile: fwcode_defs.h,v $ $Revision: 1.2.4.2.16.3.600.2 $ $Date: 2007/12/13 15:00:01 $
 */

#ifndef TCP_START_TIMEOUT
#define TCP_START_TIMEOUT	  60
#endif

#ifndef TCP_END_TIMEOUT
#define TCP_END_TIMEOUT		  20
#endif

#ifndef SCTP_START_TIMEOUT
#define SCTP_START_TIMEOUT	  60
#endif

#ifndef SCTP_END_TIMEOUT
#define SCTP_END_TIMEOUT	  10
#endif



/*****************************************************************************/
/*                                                                           */
/*                   C O M M O N   N A T   D E F I N I T I O N S             */
/*                                                                           */
/*****************************************************************************/

/*
 * Convert parameter + type <---> method.
 *
 * method: 00000000 000000(xx) (x)(xxx)(xxx) (xxx)(xxxxx)
 *                          ^   ^   ^    ^     ^     ^
 *                          s   t   f    p     e     x
 *
 * s - xside	- on what side of fw module, 0 or 1, xlation to be done
 * f - xparam_flag
 * p - xparameter
 * e - expiration type
 * x - xlation type
 * t - dynamic table lookup
 */

#define	MAKE_METHOD(xparameter, xparam_flag, xtype) \
	( (((xparam_flag) & 0x07) << 11)                  \
	| (((xparameter) & 0x07) << 8)                    \
	| ((xtype) & 0x1f) )

/* Translation type */
#define	XL_NONE        (0)
#define	XL_HIDE        (1)
#define	XL_STATIC      (2)
#define	XL_DYNAMIC     (3)
#define XL_RAND_PORT   (4)

/* Translation side */
#define	FWXT_SRV       (0)
#define	FWXT_CLI       (1)

#define	XL_NOPROTO	(0)
#define	XL_TCP		(1)
#define	XL_UDP		(3)

#define	FWXT_EOX                0
#define	FWXT_HIDE               MAKE_METHOD(C_SRC, 0, XL_HIDE)
#define	FWXT_RAND_PORT          MAKE_METHOD(C_SPORT, 0, XL_HIDE)
#define	FWXT_SRC_STATIC         MAKE_METHOD(C_SRC, 0, XL_STATIC)
#define	FWXT_DST_STATIC         MAKE_METHOD(C_DST, 0, XL_STATIC)
#define	FWXT_SRC_DYNAMIC        MAKE_METHOD(C_SRC, 0, XL_DYNAMIC)
#define	FWXT_DST_DYNAMIC        MAKE_METHOD(C_DST, 0, XL_DYNAMIC)
#define	FWXT_SPORT_STATIC       MAKE_METHOD(C_SPORT, 0, XL_STATIC)
#define	FWXT_DPORT_STATIC       MAKE_METHOD(C_DPORT, XL_NOPROTO, XL_STATIC)
#define	FWXT_TCP_DPORT_STATIC   MAKE_METHOD(C_DPORT, XL_TCP, XL_STATIC)
#define	FWXT_UDP_DPORT_STATIC   MAKE_METHOD(C_DPORT, XL_UDP, XL_STATIC)


#define FWXT_IFS_MASK (~0 << 24)
#define FWXT_IFS_ANY  ((FWXT_IFS_MASK >> 24) & 0xff)

#define	FWXT_SET_SIDE(xm, xside) \
	(((xm) & ~(0x03 << 16)) | (((xside) & 0x03) << 16))

#define FWXT_HIDE_SRVSIDE  \
	  (FWXT_SET_SIDE( FWXT_HIDE, FWXT_SRV ) | FWXT_IFS_MASK)
#define FWXT_RAND_PORT_SRVSIDE  \
	  (FWXT_SET_SIDE( FWXT_RAND_PORT, FWXT_SRV ) | FWXT_IFS_MASK)
#define FWXT_SRC_STATIC_CLISIDE  \
	  (FWXT_SET_SIDE( FWXT_SRC_STATIC, FWXT_CLI ) | FWXT_IFS_MASK)
#define FWXT_SRC_STATIC_SRVSIDE  \
	  (FWXT_SET_SIDE( FWXT_SRC_STATIC, FWXT_SRV ) | FWXT_IFS_MASK)
#define FWXT_DST_STATIC_CLISIDE  \
	  (FWXT_SET_SIDE( FWXT_DST_STATIC, FWXT_CLI ) | FWXT_IFS_MASK)
#define FWXT_DST_STATIC_SRVSIDE  \
	  (FWXT_SET_SIDE( FWXT_DST_STATIC, FWXT_SRV ) | FWXT_IFS_MASK)

/*
 * NAT flags for new NAT tables
 */
#define NAT_AUTO_RULE		0x00000001
#define NAT_SRC_IS_DO		0x00000002
#define NAT_X_SRC_IS_DO		0x00000004
#define NAT_DST_IS_DO		0x00000008
#define NAT_X_DST_IS_DO		0x00000010
#define NAT_ON_SOURCE		0x00000020
#define NAT_ON_DESTINATION	0x00000040
#define NAT_ON_SERVICE		0x00000080
#define NAT_NAT64_RULE      0x00000100
#define NAT_CG_RULE         0x00000200
#define NAT_NAT46_RULE      0x00000400
#define NAT_RULE_ACTIVE NAT_ON_SOURCE | NAT_ON_DESTINATION | NAT_ON_SERVICE
/*
 *	CIFS logging
 */
#define CIFS_LOG_MAPPED_SHARES		0x00000001
#define CIFS_LOG_ACCESS_VIOLATION	0x00000002
#define CIFS_BLOCK_REGISTRY_ACCESS	0x00000004
#define CIFS_DONT_LOG_IPC			0x00000008

#define CIFS_ENABLE_PACKET_CAPTURE	0x00000010


/*
 * MMS flags
 */

/* Action */
#define MMS_ACCEPT				0x00000001
#define MMS_DROP				0x00000002
#define MMS_REJECT				0x00000004

/* Log */
#define MMS_NO_LOG				0x00000008
#define MMS_LOG					0x00000010
#define MMS_ALERT				0x00000020


/* SPII Protocol Type Flags 
    must be in range 0x00000008-0x00008000
*/
#define SPII_PROTO_F_STATEFUL			0x00000008
#define SPII_PROTO_F_REJECT_OLD		0x00000010
#define SPII_PROTO_F_INBOUND			0x00000020
#define SPII_PROTO_F_OUTBOUND			0x00000040
#define SPII_PROTO_F_C2S				0x00000080
#define SPII_PROTO_F_S2C				0x00000100
#define SPII_PROTO_F_ACK				0x00000200
#define SPII_PROTO_F_IPV6_SUPPORTED	0x00000400
#define SPII_PROTO_F_ASPII_TEMPLATE		0x00000800 
#define SPII_PROTO_F_ASPII_FW			0x00001000 
#define SPII_PROTO_F_ASPII_STATIC		0x00002000 
#define SPII_PROTO_F_STATIC_HANDLER		0x00004000
#define SPII_PROTO_F_STATIC_END_HANDLER	0x00008000 

#endif

#ifndef __kerntabs_h__
#define __kerntabs_h__

/*
 * (c) Copyright 1993-2010 Check Point Software Technologies Ltd.
 *
 * 2010/07/20, foxx, CR00562400, roeega, Merge flame_dev  to foxx.
 * 2007/12/05, fke_test, CR00375571, tzahiel, adding rules_uid_new_table
 *
 * (c) Copyright 1993-2004 Check Point Software Technologies Ltd.
 * All rights reserved.
 * 
 * This is proprietary information of Check Point Software Technologies
 * Ltd., which is provided for informational purposes only and for use
 * solely in conjunction with the authorized use of Check Point Software
 * Technologies Ltd. products.  The viewing and use of this information is
 * subject, to the extent appropriate, to the terms and conditions of the
 * license agreement that authorizes the use of the relevant product.
 * 
 *
 * $RCSfile: kerntabs.h,v $ $Revision: 1.34.4.5.2.3.2.8.54.1 $ $Date: 2005/06/09 10:52:32 $
 */

/*
 * IDs of special kernel tables (FWMAXTABS=8192)
 */

/* The kbufs table id must be greater than the connection table id!!! */




#define FW_KBUFS_TABLE_ID					8192 	/* NOT USED */

#define WS_PROXY_CONN_POOL_TABLE_ID	       	8191
#define WS_PROXY_CONN_POOL_TABLE_TABLE_NAME	"ws_proxy_srv_conn"
#define FWDOM_TABLE_ID						8190
#define FWX_FORW_TABLE_ID					8189
#define FWX_BACKW_TABLE_ID					8188
#define FWX_ALLOC_TABLE_ID					8187
#define FWX_ARP_TABLE_ID					8186
#define FWLIC_TABLE_ID						8185
#define FWFRAG_TABLE_ID						8184
#define FWHOLD_TABLE_ID						8183
#define FWESTAB_TABLE_ID					8182
#define FWLIC_USR_TABLE_ID					8181
#define FWSKIP_TABLE_ID						8180
#define FWSKIP_CONN_TABLE_ID				8179
#define FWSKIP_REQ_TABLE_ID					8178
#define FWHOST_IP_ADDRS						8177
#define FWMANUAL_TABLE_ID					8176
#define FWX_FRAG_TABLE_ID					8175
#define FWX_AUTH_TABLE_ID					8174
#define FWSYNATK_TABLE_ID					8173
#define FWH323_TABLE_ID             		8172
#define FWSKIP_KEYID_ID						8171
#define FW_INBOUND_SPI_TABLE_ID				8170
#define FW_ISAKMP_ESP_TABLE_ID				8169
#define FW_SA_REQUESTS_TABLE_ID				8168
#define FW_ISAKMP_AH_TABLE_ID				8167
#define FW_CRYPTLOG_TABLE_ID				8166
#define FW_IPSEC_USERC_DONT_TRAP_TABLE_ID	8165
#define FWBRIDGE_TABLE_ID					8164
#define FW_IPSEC_SHORTCUT_TABLE_ID			8163
#define FWX_DYN_CONN_TABLE_ID				8162
#define FWX_CTL_DYN_TABLE_ID				8161
#define FW_OUTBOUND_SPI_TABLE_ID			8160
#define FW_IKE_SA_TABLE_ID					8159
#define FW_CONNECTIONS_TABLE_ID				8158

#define FW_PARENT_CONN_TABLE_ID			8157
#define FW_PARENT_CONN_TABLE_NAME		"parent_conn"

#define FW_SON_CONNS_TABLE_ID				8156
#define FW_SON_CONNS_TABLE_NAME			"son_conns"

#define FWBB_RT_MAC_TABLE_ID				8155
#define FWBB_RT_IP_TABLE_ID					8154
#define FWBB_ARP_REQ_TAB_ID					8153

#define FW_NRB_HITCOUNT_TABLE_ID			8152
#define FW_NRB_HITCOUNT_TABLE_NAME			"nrb_hitcount_table"

#define FW_CRYPTLOG_KBUF_TABLE_ID			8151
#define FW_SR_UDP_ENC_GWS_TABLE_ID 			8150
#define FW_SR_UDP_ENC_CLIENTS_TABLE_ID		8149
#define FW_USERC_PENDING_TABLE_ID			8148
#define FW_SAVED_KBUF_TABLE_ID				8147

#define FW_WS_PROTECTION_SCHEME_TABLE_ID	8146
#define FW_WS_PROTECTION_SCHEME_TABLE_NAME	"ws_protection_scheme_table"

#define FW_SPII_MULTI_PSET2KBUF_ID				8145
#define FW_SPII_GLOBAL_PSET2KBUF_ID				8144
#define FW_SPII_MULTI_PSET2KBUF_NAME			"spii_multi_pset2kbuf_map"
#define FW_SPII_GLOBAL_PSET2KBUF_NAME			"spii_global_pset2kbuf_map"

#define FW_TCP_STREAMS_TABLE_ID				8143
#ifdef HIGH_AVAIL
#define FW_HA_FORWARD_TABLE_ID				8142
#endif
#define FWSAM_BLOCKED_IPS_TABLE_ID			8141
#define FWSAM_REQUEST_TABLE_ID				8140
#define FWSAM_STATE_TABLE_ID				8139
#define FWSAM_NETMASK_TABLE_ID				8138
#define FWSAM_LOG_TABLE_ID					8137

#define FW_NRB_ASYNC_PENDING_TABLE_ID		8136
#define FW_NRB_ASYNC_PENDING_TABLE_NAME	"nrb_async_pending_table"

/* String dictionary table (for the log system) */
#define FW_STRING_DICTIONARY_TABLE_ID		8135
#define FW_STRING_DICTIONARY_TABLE_NAME		"string_dictionary_table"

/* SCV tables (Gateway, Policy server) */
#define FWSCV_GW_TABLE_ID					8134
#define FWSCV_GW_TABLE_NAME					"scv_gw_table"

#define FWSCV_PS_TABLE_ID					8133
#define FWSCV_PS_TABLE_NAME					"scv_ps_table"

#define FW_PACKET_HASH_TABLE_ID				8132
#define FWX_PENDING_TABLE_ID				8131

/* Chain log unification table (inbound and outbound unification) */
#define FW_CHAIN_LOG_UNIFICATION_TABLE_ID	8130
#define FW_CHAIN_LOG_UNIFICATION_TABLE_NAME	"chain_log_unification_table"

#define FW_CONN_INFO_TABLE_ID				8129
#define FW_CONN_INFO_TABLE_NAME			"conn_info"

#define FWSCV_PS_LOGGEDON_TABLE_ID			8128
#define FWSCV_PS_LOGGEDON_TABLE_NAME		"scv_ps_loggedon_table"

#define FWSCV_HELD_PACKETS_TABLE_ID			8127
#define FWSCV_HELD_PACKETS_TABLE_NAME		"scv_held_packets_table"

/* The excessive mechanism */
#define FWEXCSV_TABLE_ID					8126
#define FWEXCSV_TABLE_NAME					"excessive_table"

#define FWHOST_IP_ADDRS_ALL_ID				8125
#define FWHOST_IP_ADDRS_ALL_NAME			"host_ip_addrs_all"

#ifdef HWD_ACCEL_TARGET
#define CPHWD_DEV_IDENTITY_TABLE_ID				8124
#define CPHWD_VPNDB_TABLE_ID				8123
#define CPHWD_DB_TABLE_ID					8122
#define CPHWD_TIMER_DB_TABLE_ID             8121
#define CPHWD_DEV_CONN_TABLE_ID             8120
#endif

#define FWX_DHCP_RELAY_TABLE_ID			    8119

#define FWH323_GATEKEEPER_PENDING_TABLE_ID	8118
#define FW_CONN_REDIRECTED_CONNS_TABLE_ID	8117
#define FWX_CACHE_TABID						8116

#define FW_SIP_REG_TAB_ID					8115
#define FW_SIP_REG_TAB_NAME				"sip_registration"

#define FW_TAB_NAME_TABLE_ID				8114
#define FW_TAB_NAME_TABLE_NAME				"tab_name_table"

#define FW_UID_2_KBUF_TAB_ID				8113
#define FW_UID_2_KBUF_TAB_NAME				"uid2kbuf"

#define FW_RULES_UID_NEW_TABLE_ID				8112
#define FW_RULES_UID_NEW_TABLE_NAME				"rules_uid_new_table"

#ifdef HWD_ACCEL_TARGET
#define CPHWD_DB_TEMPLATE_TABLE_ID          8111
#endif

#define FWH323_REGISTRATION_TABLE_ID  		       8110

#ifdef HIGH_AVAIL
#define FW_HA_PIVOT_TABLE_ID				8109
#define FW_HA_PIVOT_TABLE_NAME				"pivot_select_table"
#endif

#define FWMISP_CACHE_TABLE_ID				8108

#define CPAS_PMTU_ID						8107
#define CPAS_COOKIE_HASH					8106

#define FWTAB_CHUNK_ITERATOR_TABLE_NAME		"tab_iterators_table"
#define FWTAB_CHUNK_ITERATOR_TABLE_ID			8105

#ifdef HIGH_AVAIL
#define FWHA_VPN_TABLE_ID				8104
#define FWHA_VPN_TABLE_NAME 			"fwha_VPN_hash_table"
#endif

#define FWPORTSCN_ACCESSED_PORTS_TABLE_ID 8103
#define FWPORTSCN_ACCESSED_PORTS_TABLE_NAME "portscn_accessed_ports_table"
#define FWPORTSCN_VERTICAL_PORT_COUNT_TABLE_ID 8102
#define FWPORTSCN_VERTICAL_PORT_COUNT_TABLE_NAME "portscn_vertical_port_count"
#define FWPORTSCN_HORIZONTAL_PORT_COUNT_TABLE_ID 8101
#define FWPORTSCN_HORIZONTAL_PORT_COUNT_TABLE_NAME "portscn_horizontal_port_count"
#ifdef FW_IPV6
#define FWPORTSCN_VERTICAL_HOST_EXCLUDE_TABLE_NAME "fwportscn_vertical_exclude6"
#else
#define FWPORTSCN_VERTICAL_HOST_EXCLUDE_TABLE_NAME		"fwportscn_vertical_exclude"
#endif
#define FWPORTSCN_HORIZONTAL_PORT_EXCLUDE_TABLE_NAME	"fwportscn_horizontal_exclude"

/* String dictionary table (for the log system) */
#define FWSTRMAP_TABLE_ID					8100
#define FWSTRMAP_TABLE_NAME					"strmap_table"

/* <conn uuid; reset counter> */
#define FW_RESET_COUNT_TABLE_ID				8099
#define FW_RESET_COUNT_TABLE_NAME			"rst_count_table"

#define FW_TAB_NEIGHQ_ID					8098
#define FW_TAB_IRPQ_ID						8097	

#define FWMISP_DNS_PACKETS_ID				8096

#define FW_DBG_TRACE_CONN_TABLE_ID          8095
#define FW_DBG_TRACE_CONN_TABLE_NAME        "dbg_trace_conn"

#define FW_CLOSED_CONNS_TABLE_ID            8094
#define FW_CLOSED_CONNS_TABLE_NAME          "closed_conns"

#ifdef HWD_ACCEL_TARGET
#define	CPHWD_ANT_DB_TABLE_ID				8093
#endif

#define FW_MRT_SYNC_ID						8092
#define FW_MRT_SYNC_NAME					"mrt_sync_table"

#define GEOLOCATION_BLOCK_COUNTIES_IPS_TABLE_ID		8091
#define GEOLOCATION_BLOCK_COUNTIES_IPS_TABLE_NAME	"geolocation_block_static_table"

/* SAM V2 tables */
#define FWSAM_L2_SRC_DST_REQUEST_TABLE_ID	8090
#define FWSAM_UID_TABLE_ID					8089
#define FWSAM_REQUEST_V2_TABLE_ID			8088
#define FWSAM_BLOCKED_IPS_V2_TABLE_ID		8087
#define FWSAM_L2_REQUEST_TABLE_ID			8086

#define FW_INTEGRITY_REQUESTS_TABLE_ID      8085
#define FW_INTEGRITY_REQUESTS_TABLE_NAME    "integrity_requests"
#define FW_INTEGRITY_STATUS_TABLE_ID        8084
#define FW_INTEGRITY_STATUS_TABLE_NAME      "integrity_clients_status"

#define FW_MSN_CMD_TAB_ID					8083
#define FW_MSN_CMD_TAB_NAME					"fw_msn_cmd"
#define FW_MSN_VERSION_TAB_ID				8082
#define FW_MSN_VERSION_TAB_NAME 			"fw_msn_version"

#define FWMULTIK_LOCAL_QUOTA_TAB_ID			8079
#define FWMULTIK_LOCAL_QUOTA_TAB_NAME		"fwmultik_local_quota"


/* advanced patterns tables */
#define ADVP_TCP_RANGE_C2S_TABLE_ID			8078
#define ADVP_TCP_RANGE_C2S_TABLE_NAME		"advp_tcp_range_c2s_pm_masks_tab"
#define ADVP_TCP_RANGE_S2C_TABLE_ID			8077
#define ADVP_TCP_RANGE_S2C_TABLE_NAME		"advp_tcp_range_s2c_pm_masks_tab"
#define ADVP_UDP_RANGE_C2S_TABLE_ID			8076
#define ADVP_UDP_RANGE_C2S_TABLE_NAME		"advp_udp_range_c2s_pm_masks_tab"
#define ADVP_UDP_RANGE_S2C_TABLE_ID			8075
#define ADVP_UDP_RANGE_S2C_TABLE_NAME		"advp_udp_range_s2c_pm_masks_tab"

#define FW_DOS_NQL_SERVER_TABLE_ID			8074
#define FW_DOS_EXT_NQL_SERVER_TABLE_ID		8067
#define FW_DOS_NQL_SPECIAL_CLIENT_TABLE_ID	8073
#define FW_DOS_TABLE_ID						8072
#define FW_DOS_NQL_EXPAND_CLIENT_TABLE_ID	8071
#define FW_DOS_BWL_TABLE_ID					8070
#define FW_DOS_HTM_TABLE_ID					8069
#define FW_DOS_LOG_TABLE_ID					8081
#define FW_DOS_WHITE_TABLE_ID				8080

#define FWZONE_ASSERTION_TABLE_ID      		8068

#define FW_MTCOUNTER_SYNC_HTAB_TABLE_ID		8066
#define FW_MTCOUNTER_SYNC_HTAB_TABLE_NAME	"fw_mtcounter_sync_htab_table"

#define CVPND_SESSION_TABLE_ID				8065
#define CVPND_SESSION_TABLE_NAME			"cvpn_session"

#define CVPND_EXPIRED_SESSION_TABLE_ID		8064
#define CVPND_EXPIRED_SESSION_TABLE_NAME	"cvpn_expired_session"

#define CVPND_USER_SETTINGS_TABLE_ID		8063
#define CVPND_USER_SETTINGS_TABLE_NAME		"cvpn_user_settings"

#define CVPND_SNX_SESSION_TABLE_ID			8062
#define CVPND_SNX_SESSION_TABLE_NAME		"cvpn_snx_session"

#define CVPND_ACTIVE_SESSION_TABLE_ID			8061
#define CVPND_ACTIVE_SESSION_TABLE_NAME		"cvpn_active_session"

#define CVPND_ICS_SCAN_RESULT_XML_TABLE_ID			8060
#define CVPND_ICS_SCAN_RESULT_XML_TABLE_NAME		"cvpn_ics_scan_result_xml"

#define CVPND_ACTIVE_SYNC_DEVICES_TABLE_ID			8059
#define CVPND_ACTIVE_SYNC_DEVICES_TABLE_NAME		"cvpn_active_sync_devices"

#define CVPND_CERT_TO_SESSIONS_TABLE_ID			8058
#define CVPND_CERT_TO_SESSIONS_TABLE_NAME		"cvpn_cert_to_sessions"

#define CVPND_PENDING_WIPE_ID_TABLE_ID					8057
#define CVPND_PENDING_WIPE_ID_TABLE_NAME			"cvpn_pending_wipe_id"

#define CVPND_MOB_SESSION_TABLE_ID					8056
#define CVPND_MOB_SESSIONS_TABLE_NAME		"mob_session"

#define FWMULTIK_ANTICIPATED_USERMODE_CONNS_TABLE_ID		8055
#define FWMULTIK_ANTICIPATED_USERMODE_CONNS_TABLE_NAME	"fwmultik_anticipated_usermode"

#define FW_SOCKSTRESS_ATTACKERS_TABLE_ID	8054
#define FW_SOCKSTRESS_LOCAL_TABLE_ID			8053
#define FW_SOCKSTRESS_TABLE_ID				8052
#define FW_SOCKSTRESS_BLOCK_TABLE_ID			8051

#ifdef HWD_ACCEL_TARGET
#define CPHWD_DEV_REVOKED_IPS_TABLE_ID			8050
#endif

#define MULTIPORTAL_PORTS_TABLE_ID         8049
#define MULTIPORTAL_PORTS_TABLE_NAME       "multiportal_ports"

#define MULTIPORTAL_REAL_PORTS_BLOCK_TABLE_ID         8048
#define MULTIPORTAL_REAL_PORTS_BLOCK_TABLE_NAME       "multiportal_real_ports"

#define FW_UID_2_KBUF_TEMP_TAB_ID			8047
#define FW_UID_2_KBUF_TEMP_TAB_NAME			"uid2kbuf_temp"

#define CMI_LOADER_SAA_SKIP_TABLE_ID			8046
#define CMI_LOADER_SAA_SKIP_TABLE_NAME		"cmi_loader_saa_skip_map"

#define DLP_SESSIONS_TABLE_ID				8045
#define DLP_SESSIONS_TABLE_NAME			"dlp_sessions"

#define CMI_LOADER_SKIP_MAP_TABLE_ID			8044
#define CMI_LOADER_SKIP_MAP_TABLE_NAME		"cmi_loader_skip_val_map"

/* advanced patterns, usermode temp transfer tables */
#define ADVP_TEMP_TCP_PORT_RANGE_C2S_TABLE_ID		8043
#define ADVP_TEMP_TCP_PORT_RANGE_C2S_TABLE_NAME		"advp_port_range_tcp_c2s"
#define ADVP_TEMP_TCP_PORT_RANGE_S2C_TABLE_ID		8042
#define ADVP_TEMP_TCP_PORT_RANGE_S2C_TABLE_NAME		"advp_port_range_tcp_s2c"
#define ADVP_TEMP_UDP_PORT_RANGE_C2S_TABLE_ID		8041
#define ADVP_TEMP_UDP_PORT_RANGE_C2S_TABLE_NAME		"advp_port_range_udp_c2s"
#define ADVP_TEMP_UDP_PORT_RANGE_S2C_TABLE_ID		8040
#define ADVP_TEMP_UDP_PORT_RANGE_S2C_TABLE_NAME		"advp_port_range_udp_s2c"

#define ADVP_TEMP_TCP_IP_RANGE_C2S_TABLE_ID			8039
#define ADVP_TEMP_TCP_IP_RANGE_C2S_TABLE_NAME		"advp_temp_ip_range_tcp_c2s"
#define ADVP_TEMP_TCP_IP_RANGE_S2C_TABLE_ID			8038
#define ADVP_TEMP_TCP_IP_RANGE_S2C_TABLE_NAME		"advp_temp_ip_range_tcp_s2c"
#define ADVP_TEMP_UDP_IP_RANGE_C2S_TABLE_ID			8037
#define ADVP_TEMP_UDP_IP_RANGE_C2S_TABLE_NAME		"advp_temp_ip_range_udp_c2s"
#define ADVP_TEMP_UDP_IP_RANGE_S2C_TABLE_ID			8036
#define ADVP_TEMP_UDP_IP_RANGE_S2C_TABLE_NAME		"advp_temp_ip_range_udp_s2c"

/* advanced patterns live ip ranges tables */
#define ADVP_TCP_IP_RANGE_C2S_TABLE_ID			8035
#define ADVP_TCP_IP_RANGE_C2S_TABLE_NAME		"advp_ip_range_tcp_c2s"
#define ADVP_TCP_IP_RANGE_S2C_TABLE_ID			8034
#define ADVP_TCP_IP_RANGE_S2C_TABLE_NAME		"advp_ip_range_tcp_s2c"
#define ADVP_UDP_IP_RANGE_C2S_TABLE_ID			8033
#define ADVP_UDP_IP_RANGE_C2S_TABLE_NAME		"advp_ip_range_udp_c2s"
#define ADVP_UDP_IP_RANGE_S2C_TABLE_ID			8032
#define ADVP_UDP_IP_RANGE_S2C_TABLE_NAME		"advp_ip_range_udp_s2c"

/* Failed SMTP connections table */
#define FWDLP_FAILED_SMTP_CONNS_TABLE_ID		8031
#define FWDLP_FAILED_SMTP_CONNS_TABLE_NAME		"dlp_failed_smtp_conns"
#define SSL_VPN_AV_CLIENT_CONNECTIONS_TABLE_ID		8030
#define SSL_VPN_AV_CLIENT_CONNECTIONS_TABLE_NAME	"sslvpn_av_client_connections"

#define DLP_FOLDING_TAB_ID					8029
#define DLP_FOLDING_TAB_NAME				"DLP_folding_tab"

#define DLP_EXCLUSION_TAB_ID				8028
#define DLP_EXCLUSION_TAB_NAME				"DLP_exclusion_tab"	

/* mapping of parsers and cmi_apps registered to it */
#define CMI_LOADER_PARSER_APPS_TABLE_ID			8027
#define CMI_LOADER_PARSER_APPS_TABLE_NAME		"cmi_loader_parser_apps"

/* Appi sync ghtab table */
#define APPI_SYNC_HTAB_TABLE_ID				8026
#define APPI_SYNC_HTAB_TABLE_NAME			"appi_sync_htab_table"
#define FW_IPV6_SERIALIZE_ID				8025
#define FW_IPV6_SERIALIZE_NAME				"ipv6_serialization"

/* Contains pointers to av session data for sessions which are still being processed by the user mode */
#define AV_UM_HASH_TAB_ID					8024
#define AV_UM_HASH_TAB_NAME					"AV_UM_pending_sessions_hash_tab" /* re-defined in te\src\ted\lib\framework\LogSender.cpp */

/* Tables added for blades statistics */
#ifdef HWD_ACCEL_TARGET
#define FWRULE_COUNT_TABLE_ID				8023
#define FWRULE_COUNT_TABLE_NAME				"rule_count"
#endif

#define SD_STATS_PROT_COUNT_TABLE_ID	    8022
#define SD_STATS_PROT_COUNT_TABLE_NAME	    "sd_stats_prot_count"

#define FWSERVICE_COUNT_TABLE_ID			8021
#define FWSERVICE_COUNT_TABLE_NAME			"service_count"
/* END (Tables added for blades statistics) */

/* dlp My Org folding tables */
#define DLP_MY_ORG_FOLDING_TAB_ID			8020
#define DLP_MY_ORG_FOLDING_TAB_NAME			"DLP_my_org_folding_tab"
#define DLP_MY_ORG_EXCLUSION_TAB_ID			8019
#define DLP_MY_ORG_EXCLUSION_TAB_NAME		"DLP_my_org_exclusion_tab"

/* dlp redirection white list table */
#define DLP_SRC_REDIRECTION_WHITE_LIST_TAB_ID			8018
#define DLP_SRC_REDIRECTION_WHITE_LIST_TAB_NAME			"DLP_SRC_rd_white_list_tab"
#define DLP_DST_REDIRECTION_WHITE_LIST_TAB_ID			8017
#define DLP_DST_REDIRECTION_WHITE_LIST_TAB_NAME			"DLP_DST_rd_white_list_tab"

#define CI_AV_MD5_RAD_STATISTICS_HASH_TAB_ID		8016
#define CI_AV_MD5_RAD_STATISTICS_HASH_TAB_NAME		"av_md5_rad_statistics_hash_tab"

#define EMAIL_UNIFIED_APP_HOLD_OPAQUE_TABLE_ID			8015
#define EMAIL_UNIFIED_APP_HOLD_OPAQUE_TABLE_NAME 	"email_unified_app_hold_opaque"

#define MAL_IP_REP_TABLE_ID					8014
#define MAL_IP_REP_TABLE_NAME				"mal_ip_reputation"

#define SUSPICIOUS_MAIL_TABLE_ID					8013
#define SUSPICIOUS_MAIL_TABLE_NAME					"suspicious_mails"

#define CMI_STREAMING_APP_HOLD_OPAQUE_TABLE_ID			8012
#define CMI_STREAMING_APP_HOLD_OPAQUE_TABLE_NAME 	"cmi_streaming_app_hold_opaque"

#define FA_FREE_DISK_SPACE_TABLE_ID	       	8011
#define FA_FREE_DISK_SPACE_TABLE_NAME		"fa_free_disk_space"

#define OS_CACHE_TABLE_ID					8010
#define OS_CACHE_TABLE_NAME					"os_cache"

#define MAL_CONN_TABLE_ID					8009
#define MAL_CONN_TABLE_NAME					"mal_conns"

#define MAL_DNS_INFO_TABLE_ID				8008
#define MAL_DNS_INFO_TABLE_NAME				"mal_dns_info"

#define MAL_STAT_SRC_HR_TABLE_ID			8007
#define MAL_STAT_SRC_HR_TABLE_NAME			"mal_stat_src_hour"
#define MAL_STAT_SRC_DY_TABLE_ID			8006
#define MAL_STAT_SRC_DY_TABLE_NAME			"mal_stat_src_day"
#define MAL_STAT_SRC_WK_TABLE_ID			8005
#define MAL_STAT_SRC_WK_TABLE_NAME			"mal_stat_src_week"

#define MAL_STAT_NAMES_HR_TABLE_ID			8004
#define MAL_STAT_NAMES_HR_TABLE_NAME		"mal_stat_names_hour"
#define MAL_STAT_NAMES_DY_TABLE_ID			8003
#define MAL_STAT_NAMES_DY_TABLE_NAME		"mal_stat_names_day"
#define MAL_STAT_NAMES_WK_TABLE_ID			8002
#define MAL_STAT_NAMES_WK_TABLE_NAME		"mal_stat_names_week"

#define MAL_STAT_VALS_TABLE_ID				8001
#define MAL_STAT_VALS_TABLE_NAME			"mal_stat_vals"

#define CPAS_PENDING_KBUF_DB_TABLE_ID		8000
#define CPAS_PENDING_KBUF_DB_TABLE_NAME		"cpas_pending_kbuf_db"

#define CMIK_LOADER_SYNC_HTAB_TABLE_ID		7999
#define CMIK_LOADER_SYNC_HTAB_TABLE_NAME	"cmik_loader_sync_htab_table"

#ifdef HWD_ACCEL_TARGET
#define CPHWD_PSLGLUE_CONN_DB_TABLE_ID		7998
#define CPHWD_PSLGLUE_CONN_DB_TABLE_NAME	"cphwd_pslglue_conn_db"

#define CPHWD_PSLGLUE_TMPL_DB_TABLE_ID		7997
#define CPHWD_PSLGLUE_TMPL_DB_TABLE_NAME	"cphwd_pslglue_tmpl_db"
#endif

#define FWHA_FDB_SHADOW_TABLE_ID			7996
#define FWHA_FDB_SHADOW_TABLE_NAME			"fdb_shadow"

#define FW_SIP_RATE_LIMITING_TAB_ID			7995
#define FW_SIP_RATE_LIMITING_TAB_NAME		"sip_rate_limiting_table"

#define CPTLS_SERVER_CN_CACHE_TABLE_ID		7994
#define CPTLS_SERVER_CN_CACHE_TABLE_NAME	"cptls_server_cn_cache"

#define RAD_KERNEL_PENDING_REQUEST_TABLE_ID  7993
#define RAD_KERNEL_PENDING_REQUEST_TABLE_NAME "rad_kernel_pending_request"

#define CMI_UM_TIMEOUT_TABLE_ID				7992
#define CMI_UM_TIMEOUT_TABLE_NAME			"cmi_um_timeout"

#define FW_BRIDGE_REROUTE_CKSUM_TABLE_ID		7991
#define FW_BRIDGE_REROUTE_CKSUM_TABLE_NAME		"bridge_reroute_cksum"

#define FWX_NDP_TABLE_ID					7990
#define FWX_NDP_TABLE_NAME					"ndp_table"

#define CVPND_EXCHANGE_CONNECTED_USERS_TABLE_ID	7989
#define CVPND_EXCHANGE_CONNECTED_USERS_TABLE_NAME	"cvpn_exchange_connected_users"

#define CVPND_EXCHANGE_EXPIRED_USERS_TABLE_ID		7988
#define CVPND_EXCHANGE_EXPIRED_USERS_TABLE_NAME	"cvpn_exchange_expired_users"

#define CVPND_PN_TOKENS_SUBSCRIBED_TABLE_ID		7987
#define CVPND_PN_TOKENS_SUBSCRIBED_TABLE_NAME	"cvpn_pn_tokens_subscribed"

#define CVPND_PN_MAIL_DATA_TABLE_ID		7986
#define CVPND_PN_USER_MAIL_DATA_TABLE_NAME	"cvpn_pn_user_mail_data"

#define CVPND_PN_MAIL_CONTROL_TABLE_ID		7985
#define CVPND_PN_USER_MAIL_CONTROL_TABLE_NAME		"cvpn_pn_user_mail_control"

#define CVPND_MOB_MAIL_SESSION_TABLE_ID				7984
#define CVPND_MOB_MAIL_SESSIONS_TABLE_NAME		"mob_mail_session"

#define TCPT_INSTANCE_ID		        7983
#define TCPT_INSTANCE_NAME	            "tcpt_instance"

#define DLPK_SESSION_TABLE_ID				7982
#define DLPK_SESSION_TABLE_NAME				"dlpk_session_table"

#define FWASPAM_SCANNED_MAILS_ID			7981
#define FWASPAM_SCANNED_MAILS_NAME	"aspam_scanned_mails"

/* VVV values changed and moved here in merge gimzo_lte -> gypsy_lte */
#define FWGXSAM_BLOCKED_ATTR_TABLE_ID	        7980
#define FWGXSAM_REQUEST_TABLE_ID		7979

#define FWGTP_LOG_MEMBER_TAB_ID			7978
#define FWGTP_LOG_MEMBER_TAB_NAME		"gtp_log_member"

#define FWGTP_VER_TAB_ID			7977
#define FWGTP_VER_TAB_NAME			"gtp_ver_tab"

#define FWX_CGNAT_SUBSCRIBERS_TAB_ID		7976
#define FWX_CGNAT_SUBSCRIBERS_TAB_NAME		"fwx_cgnat_subscribers"

#define FWX_CGNAT_HAIRPINNING_MAPPINGS_TAB_ID	7975
#define FWX_CGNAT_HAIRPINNING_MAPPINGS_TAB_NAME	"fwx_cgnat_hairpinning_mappings"

#define FWSYSLOG_SERVERS_TAB_ID				7974
#define FWSYSLOG_SERVERS_TAB_NAME			"fwsyslog_servers"
/* ^^^ values changed and moved here in merge gimzo_lte -> gypsy_lte */

#define CMI_LOADER_GRANULAR_CONTEXTS_MAP_TABLE_ID 		7973
#define CMI_LOADER_GRANULAR_CONTEXTS_MAP_TABLE_NAME 	"cmi_loader_granular_ctx_map"

/**********************  Session IS tables [begin] ******************************/

#define SESSIONIS_CVPN_DIFF_TABLE_ID				7972
#define SESSIONIS_CVPN_DIFF_TABLE_NAME				"cvpn_diff_table"

#define SESSIONIS_VPN_DIFF_TABLE_ID					7971
#define SESSIONIS_VPN_DIFF_TABLE_NAME				"vpn_diff_table"

#define SESSIONIS_SESSIOND_DIFF_TABLE_ID			7970
#define SESSIONIS_SESSIOND_DIFF_TABLE_NAME			"sessiond_diff_table"

#define SESSIONIS_RA_GLOBAL_COUNTER_TABLE_ID		7969
#define SESSIONIS_RA_GLOBAL_COUNTER_TABLE_NAME		"ra_global_counter"

/**********************  Session IS tables [end] ********************************/

#define IMAP_MAIL_TABLE_ID							7968
#define IMAP_MAIL_TABLE_NAME						"imap_mails"


/* Tables added for SFW */
#define FWTRAFFIC_MONITOR_SESSIONS_TABLE_ID	7967

#define SFW_ACCESS_POLICY_INFO_TABLE_ID			7966
#define SFW_ACCESS_POLICY_INFO_TABLE_NAME		"sfw_access_policy_srcs"

#ifdef FW_MISP
#define FWPBR_IPRULE_TABLE_NAME					"pbr_iprule"
#endif

#define FWHOST_MONITOR_TABLE_ID				7965

#define SFW_HOTSPOT_SESSIONS_TABLE_ID			7964
#define SFW_HOTSPOT_SESSIONS_TABLE_NAME		"sfw_hotspot_sessions"


#define SFW_WIFI_ADMIN_ACCESS_TABLE_ID			7963
#define SFW_WIFI_ADMIN_ACCESS_TABLE_NAME		"sfw_wifi_admin_access"

#define SFW_FOLD_RULES_TABLE_ID					7962
#define SFW_FOLD_RULES_TABLE_NAME				"sfw_fold_rules"

#define FWEMAIL_AVSI_SESSIONS_TABLE_ID			7961
#define FWEMAIL_AVSI_SESSIONS_TABLE_NAME		"fwemail_avsi_sessions"

#define SFW_HOTSPOT_EXCEPTIONS_TABLE_ID		7960
#define SFW_HOTSPOT_EXCEPTIONS_TABLE_NAME		"sfw_hotspot_exceptions"

#define MAL_STAT_COUNTERS_TABLE_ID	7959
#define MAL_STAT_COUNTERS_TABLE_NAME "mal_stat_counters"

#define SFW_HOTSPOT_DST_EXCEPTIONS_TABLE_ID		7958
#define SFW_HOTSPOT_DST_EXCEPTIONS_TABLE_NAME		"sfw_hotspot_dst_exceptions"

#define SFW_MAC_FILTERING_TABLE_ID				7957
#define SFW_MAC_FILTERING_TABLE_NAME			"sfw_mac_filtering_table"

#define SW_8021X_AUTH_REQUESTS_TABLE_ID			7956
#define SW_8021X_AUTH_REQUESTS_TABLE_NAME 		"sfw_8021x_requests"

#define SW_8021X_MAC_TABLE_ID					7955
#define SW_8021X_MAC_TABLE_NAME 				"sfw_8021x_MACs"

#define SFW_BL_MAC_FILTERING_TABLE_NAME			"sfw_bl_mac_filtering_table"


/* END (Tables added for SFW) */


/********************************************************************
*
*	DEFINE NEW TABLE IDS ABOVE HERE!
*
*	Do not override reserved ranges for FG, RTM, UA, VPN!
*	Do not define tables ids below 6656! (they are reserved for INSPECT tables)
*
*********************************************************************/

#define VPN_TABLES							7936-7945
#define FLOODGATE_TABLES					7680-7935
#define UA_TABLES							7674-7679
#define RTM_TABLES							6800-6999
#define SESSIONIS_TABLES					7969-7972

#define MAX_POSSIBLE_INSPECT_TABLE_ID		6799

/* Limit INSPECT tables to FWMAXTABS-1536 (i.e. from 6660) */
#define NUM_KERN_TABS						1536

/* Is this ID the ID of a kernel table? */
#define fwtab_is_kern_tab(id)	((id) >= (FWMAXTABS - NUM_KERN_TABS))

/*
 * Defining dynamic table attributes
 * ---------------------------------
 * This I/S allows defining attributes on a table, "behind the back" of the Inspect compiler.
 * It allows SmartDefense updates to set attruibutes that are supported by the kernel, but not
 *  by the Inspect compiler.
 * This is done by defining the table names in a special table. Each line in that table describe
 *  the special attributes needed for a specific table. The kernel would iterate the table and
 *  actually apply these properties. If the kernel is old and doesn't support this, nothing will
 *  happen.
 * We use it for local sync in Hydra machines. This allows SmartDefense updates to choose
 *  enable local sync on tables, in a way that would not require the management to support it,
 *  and would do no harm on non-Hydra machines.
 *
 * Usage:
 * Define the attribute table, initialized with an entry per table. The key would be the table
 *  ID (generated by the compiler), the data is a single integer with the attributes. Example:
 * sdupdate_dynamic_tab_attrs = {
 *		<my_table; DYNAMIC_ATTR_LOCAL_SYNC>
 * }
 *
 * Note: SmartDefense updates should not rely on these definitions, because the management may
 *  not include them. They should be defined again in the update, under ifndef.
 */

/* This is the table name, to be used for defining dynamic attributes */
#define DYNAMIC_ATTR_TAB_NAME "sdupdate_dynamic_tab_attrs"

/* These are the possible attributes */
#define DYNAMIC_ATTR_LOCAL_SYNC 0x01
#define DYNAMIC_ATTR_GLOBAL_TAB 0x02

#endif /* __kerntabs_h__ */

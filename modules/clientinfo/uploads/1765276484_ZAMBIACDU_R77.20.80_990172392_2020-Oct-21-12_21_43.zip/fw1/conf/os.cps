#
# OS configuration file for the non-cpmi command line.
#
#
# Syntax (of complicated fields. The rest is obvious):
#
# SIMPLE-OID,    Name, OID, Type
#
# COLUMN,        Name, OID, Type, Index-order, Display, Display-Totals
#
# SUM-COLUMN,    Name, Display-Totlas, Column-Name-1, Column-Name-2, ....
#
# OUTPUT-FORMAT, "DEFAULT"/"LIST"    *If does not exist - assumed "DEFAULT"  
#
# OID-BASE takes effect only within the section it is in.
#

START-BLOCK

	BLOCK-NAME, "os"

	OID-BASE, 1.3.6.1.4.1.2620.1.6

	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "default"

		SIMPLE-OID, "Product Name",               1, STRING

		ADD-OID-ATOM, 4

			SIMPLE-OID, "SVN Foundation Version String", 1, STRING
			SIMPLE-OID, "SVN Foundation Build Number",   2, UINT32

		REMOVE-OID-ATOM
		
		SIMPLE-OID, "SVN Foundation Status",    103, STRING
		
		ADD-OID-ATOM, 5 
	
			SIMPLE-OID, "OS Name",              1, STRING
			SIMPLE-OID, "OS Major Version",     2, INT32
			SIMPLE-OID, "OS Minor Version",     3, INT32
			SIMPLE-OID, "OS Build Number",      4, INT32
			SIMPLE-OID, "OS SP Major",          5, INT32
			SIMPLE-OID, "OS SP Minor",          6, INT32
			SIMPLE-OID, "OS Version Level",     7, STRING
			
		REMOVE-OID-ATOM 
		
		ADD-OID-ATOM, 16

				SIMPLE-OID, "Appliance SN",    3, STRING
				SIMPLE-OID, "Appliance Name",  7, STRING
				SIMPLE-OID, "Appliance Manufacture",    9, STRING
				SIMPLE-OID, "Appliance Series",    10, STRING				

		REMOVE-OID-ATOM

	END-FLAVOUR

	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "ifconfig"

		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Interface configuration table"
				TABLE-OID,         50.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Name",        3, STRING, 0, TRUE,  FALSE
			COLUMN,     "Address",     4, IP,     0, TRUE,  FALSE
			COLUMN,     "Mask",        5, IP,     0, TRUE,  FALSE
			COLUMN,     "MTU",         6, UINT32, 0, TRUE,  FALSE
			COLUMN,     "State",       7, INT32,  0, TRUE,  FALSE
			COLUMN,     "Mac Address", 8, STRING, 0, TRUE,  FALSE
			COLUMN,     "Description", 9, STRING, 0, TRUE,  FALSE
			COLUMN,     "IPv6 Address",11,IPV6,   0, TRUE,  FALSE
			COLUMN,     "IPv6 Len",    12,UINT32, 0, TRUE,  FALSE
			COLUMN,     "RX Bytes",    13,UINT64, 0, TRUE,  FALSE
			COLUMN,     "RX Drops",    14,UINT64, 0, TRUE,  FALSE
			COLUMN,     "RX Errors",   15,UINT64, 0, TRUE,  FALSE
			COLUMN,     "RX Packets",  16,UINT64, 0, TRUE,  FALSE
			COLUMN,     "TX Bytes",    17,UINT64, 0, TRUE,  FALSE
			COLUMN,     "TX Drops",    18,UINT64, 0, TRUE,  FALSE
			COLUMN,     "TX Errors",   19,UINT64, 0, TRUE,  FALSE
			COLUMN,     "TX Packets",  20,UINT64, 0, TRUE,  FALSE
		
		END-TABLE
		
	END-FLAVOUR

	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "routing"

		START-TABLE

			START-TABLE-HEADER
			
				TABLE-NAME,        "Routing table"
				TABLE-OID,         6.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       1, UINT32,  1, FALSE, FALSE 
			COLUMN,     "Destination", 2, IP,      0, TRUE,  FALSE
			COLUMN,     "Mask",        3, IP,      0, TRUE,  FALSE
			COLUMN,     "GateWay",     4, IP,      0, TRUE,  FALSE
			COLUMN,     "Interface",   5, STRING,  0, TRUE,  FALSE

		END-TABLE

	END-FLAVOUR

        #################################################

        START-FLAVOUR

                FLAVOUR-NAME, "routing6"

                START-TABLE

                        START-TABLE-HEADER

                                TABLE-NAME,        "IPv6 Routing table"
                                TABLE-OID,         6.2
                                PRINT-ONLY-TOTALS, FALSE
                                OUTPUT-FORMAT,     DEFAULT

                        END-TABLE-HEADER

                        COLUMN,     "Index",       1, UINT32,  1, FALSE, FALSE
                        COLUMN,     "Destination", 2, IPV6,    0, TRUE,  FALSE
                        COLUMN,     "MaskLength",  3, UINT32,  0, TRUE,  FALSE
                        COLUMN,     "GateWay",     4, IPV6,    0, TRUE,  FALSE
                        COLUMN,     "Interface",   5, STRING,  0, TRUE,  FALSE

                END-TABLE

        END-FLAVOUR

	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "memory"

		ADD-OID-ATOM, 7

			ADD-OID-ATOM, 4

				SIMPLE-OID, "Total Virtual Memory (Bytes)",     1, UINT64
				SIMPLE-OID, "Active Virtual Memory (Bytes)",    2, UINT64
				SIMPLE-OID, "Total Real Memory (Bytes)",        3, UINT64
				SIMPLE-OID, "Active Real Memory (Bytes)",       4, UINT64
				SIMPLE-OID, "Free Real Memory (Bytes)",         5, UINT64
				SIMPLE-OID, "Memory Swaps/Sec",                 6, UINT32
				SIMPLE-OID, "Memory To Disk Transfers/Sec",     7, UINT32
			
			REMOVE-OID-ATOM

		REMOVE-OID-ATOM

	END-FLAVOUR

	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "old_memory"

		ADD-OID-ATOM, 7

			ADD-OID-ATOM, 1

				SIMPLE-OID, "Total Virtual Memory (Bytes, as 32bit)",     1, UINT32
				SIMPLE-OID, "Active Virtual Memory (Bytes, as 32bit)",    2, UINT32
				SIMPLE-OID, "Total Real Memory (Bytes, as 32bit)",        3, UINT32
				SIMPLE-OID, "Active Real Memory (Bytes, as 32bit)",       4, UINT32
				SIMPLE-OID, "Free Real Memory (Bytes, as 32bit)",         5, UINT32
				SIMPLE-OID, "Memory Swaps/Sec",                           6, UINT32
				SIMPLE-OID, "Memory To Disk Transfers/Sec",               7, UINT32
			
			REMOVE-OID-ATOM

		REMOVE-OID-ATOM

	END-FLAVOUR

	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "cpu"

		ADD-OID-ATOM, 7

			ADD-OID-ATOM, 2

				SIMPLE-OID, "CPU User Time (%)",    1, UINT32
				SIMPLE-OID, "CPU System Time (%)",  2, UINT32
				SIMPLE-OID, "CPU Idle Time (%)",    3, UINT32
				SIMPLE-OID, "CPU Usage (%)",        4, UINT16
				SIMPLE-OID, "CPU Queue Length",     5, UINT32
				SIMPLE-OID, "CPU Interrupts/Sec",   6, UINT32
				SIMPLE-OID, "CPUs Number",          7, UINT32

			REMOVE-OID-ATOM

		REMOVE-OID-ATOM

	END-FLAVOUR

	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "disk"

		ADD-OID-ATOM, 7

			ADD-OID-ATOM, 3

				SIMPLE-OID, "Disk Servicing Read\Write Requests Time",  1, UINT32
				SIMPLE-OID, "Disk Requests Queue",                      2, UINT32
				SIMPLE-OID, "Disk Free Space (%)",                      3, UINT16
				SIMPLE-OID, "Disk Total Free Space (Bytes)",            4, UINT64
				SIMPLE-OID, "Disk Available Free Space (Bytes)",        5, UINT64
				SIMPLE-OID, "Disk Total Space (Bytes)",                 6, UINT64

			REMOVE-OID-ATOM

		REMOVE-OID-ATOM

	END-FLAVOUR

	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "perf"

		ADD-OID-ATOM, 7

			ADD-OID-ATOM, 4

				SIMPLE-OID, "Total Virtual Memory (Bytes)",     1, UINT64
				SIMPLE-OID, "Active Virtual Memory (Bytes)",    2, UINT64
				SIMPLE-OID, "Total Real Memory (Bytes)",        3, UINT64
				SIMPLE-OID, "Active Real Memory (Bytes)",       4, UINT64
				SIMPLE-OID, "Free Real Memory (Bytes)",         5, UINT64
				SIMPLE-OID, "Memory Swaps/Sec",                 6, UINT32
				SIMPLE-OID, "Memory To Disk Transfers/Sec",     7, UINT32
			
			REMOVE-OID-ATOM

			ADD-OID-ATOM, 2

				SIMPLE-OID, "CPU User Time (%)",    1, UINT32
				SIMPLE-OID, "CPU System Time (%)",  2, UINT32
				SIMPLE-OID, "CPU Idle Time (%)",    3, UINT32
				SIMPLE-OID, "CPU Usage (%)",        4, UINT16
				SIMPLE-OID, "CPU Queue Length",     5, UINT32
				SIMPLE-OID, "CPU Interrupts/Sec",   6, UINT32
				SIMPLE-OID, "CPUs Number",          7, UINT32
			
			REMOVE-OID-ATOM

			ADD-OID-ATOM, 3

				SIMPLE-OID, "Disk Servicing Read\Write Requests Time",  1, UINT32
				SIMPLE-OID, "Disk Requests Queue",                      2, UINT32
				SIMPLE-OID, "Disk Free Space (%)",                      3, UINT16
				SIMPLE-OID, "Disk Total Free Space (Bytes)",            4, UINT64
				SIMPLE-OID, "Disk Available Free Space (Bytes)",        5, UINT64
				SIMPLE-OID, "Disk Total Space (Bytes)",                 6, UINT64
			
			REMOVE-OID-ATOM

		REMOVE-OID-ATOM

	END-FLAVOUR

	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "multi_cpu"

		START-TABLE

			START-TABLE-HEADER
			
				TABLE-NAME,        "Processors load"
				TABLE-OID,         7.5.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "CPU#",       1, UINT32,  1, TRUE, FALSE 
			COLUMN,     "User Time(%)", 2, UINT32,      0, TRUE,  FALSE
			COLUMN,     "System Time(%)", 3, UINT32,      0, TRUE,  FALSE
			COLUMN,     "Idle Time(%)", 4, UINT32,      0, TRUE,  FALSE
			COLUMN,     "Usage(%)", 5, UINT32,      0, TRUE,  FALSE
			COLUMN,     "Run queue", 6, UINT32,      0, TRUE,  FALSE
			COLUMN,     "Interrupts/sec", 7, UINT32,      0, TRUE,  FALSE

		END-TABLE

	END-FLAVOUR

	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "multi_disk"

		START-TABLE

			START-TABLE-HEADER
			
				TABLE-NAME,        "Partitions space"
				TABLE-OID,         7.6.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       1, UINT32,  1, FALSE, FALSE 
			COLUMN,     "Partition", 2, STRING,      0, TRUE,  FALSE
			COLUMN,     "Size (bytes)", 3, INT64,      0, TRUE,  FALSE
			COLUMN,     "Used (bytes)", 4, INT64,      0, TRUE,  FALSE
			COLUMN,     "Free total (bytes)", 5, INT64,      0, TRUE,  FALSE
			COLUMN,     "Free total (%)", 6, UINT16,      0, TRUE,  FALSE
			COLUMN,     "Free available (bytes)", 7, INT64,      0, TRUE,  FALSE
			COLUMN,     "Free available (%)", 8, UINT16,      0, TRUE,  FALSE

		END-TABLE

	END-FLAVOUR

	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "sensors"

		ADD-OID-ATOM, 7

		ADD-OID-ATOM, 8

		START-TABLE

			START-TABLE-HEADER
			
				TABLE-NAME,        "Temperture Sensors"
				TABLE-OID,         1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index", 1, UINT32,      1, FALSE,  FALSE
			COLUMN,     "Name", 2, STRING,      0, TRUE,  FALSE
			COLUMN,     "Value", 3, STRING,      0, TRUE,  FALSE
			COLUMN,     "Unit", 4, STRING,      0, TRUE,  FALSE
			COLUMN,     "Type", 5, STRING,      0, TRUE,  FALSE
			COLUMN,     "Status", 6, INT32,      0, TRUE,  FALSE

		END-TABLE

		START-TABLE

			START-TABLE-HEADER
			
				TABLE-NAME,        "Fan Speed Sensors"
				TABLE-OID,         2.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index", 1, UINT32,      1, FALSE,  FALSE
			COLUMN,     "Name", 2, STRING,      0, TRUE,  FALSE
			COLUMN,     "Value", 3, STRING,      0, TRUE,  FALSE
			COLUMN,     "Unit", 4, STRING,      0, TRUE,  FALSE
			COLUMN,     "Type", 5, STRING,      0, TRUE,  FALSE
			COLUMN,     "Status", 6, INT32,      0, TRUE,  FALSE

		END-TABLE

		START-TABLE

			START-TABLE-HEADER
			
				TABLE-NAME,        "Voltage Sensors"
				TABLE-OID,         3.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index", 1, UINT32,      1, FALSE,  FALSE
			COLUMN,     "Name", 2, STRING,      0, TRUE,  FALSE
			COLUMN,     "Value", 3, STRING,      0, TRUE,  FALSE
			COLUMN,     "Unit", 4, STRING,      0, TRUE,  FALSE
			COLUMN,     "Type", 5, STRING,      0, TRUE,  FALSE
			COLUMN,     "Status", 6, INT32,      0, TRUE,  FALSE

		END-TABLE

		REMOVE-OID-ATOM

		REMOVE-OID-ATOM

	END-FLAVOUR

	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "power_supply"

		ADD-OID-ATOM, 7

		ADD-OID-ATOM, 9

		START-TABLE

			START-TABLE-HEADER
			
				TABLE-NAME,        "Power Supply"
				TABLE-OID,         1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index", 1, UINT32,      1, TRUE,  FALSE
			COLUMN,     "Status", 2, STRING,      0, TRUE,  FALSE

		END-TABLE

		REMOVE-OID-ATOM

		REMOVE-OID-ATOM

	END-FLAVOUR
	
	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "hw_info"

		ADD-OID-ATOM, 16

				SIMPLE-OID, "Appliance SN",    3, STRING
				SIMPLE-OID, "Appliance Name",  7, STRING
				SIMPLE-OID, "Appliance Manufacture",    9, STRING
				SIMPLE-OID, "Appliance Series",    10, STRING				


		REMOVE-OID-ATOM

	END-FLAVOUR

	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "all"

		SIMPLE-OID, "Product Name",                   1, STRING
		SIMPLE-OID, "SVN Foundation Major Version",   2, UINT16
		SIMPLE-OID, "SVN Foundation Minor Version",   3, UINT16
		SIMPLE-OID, "SVN Foundation Service Pack",  999, UINT16

		ADD-OID-ATOM, 4 

			SIMPLE-OID, "SVN Foundation Version String", 1, STRING
			SIMPLE-OID, "SVN Foundation Build Number",   2, UINT32

		REMOVE-OID-ATOM
		
		SIMPLE-OID, "SVN Foundation Status code",   101, UINT32
		SIMPLE-OID, "SVN Foundation Status short",  102, STRING
		SIMPLE-OID, "SVN Foundation Status long",   103, STRING

		ADD-OID-ATOM, 5 

			SIMPLE-OID, "OS Name",              1, STRING
			SIMPLE-OID, "OS Major Version",     2, INT32
			SIMPLE-OID, "OS Minor Version",     3, INT32
			SIMPLE-OID, "OS Build Number",      4, INT32
			SIMPLE-OID, "OS SP Major",          5, INT32
			SIMPLE-OID, "OS SP Minor",          6, INT32
			SIMPLE-OID, "OS Version Level",     7, STRING
			
		REMOVE-OID-ATOM 
		
		ADD-OID-ATOM, 16

				SIMPLE-OID, "Appliance SN",    3, STRING
				SIMPLE-OID, "Appliance Name",  7, STRING
				SIMPLE-OID, "Appliance Manufacture",    9, STRING
				SIMPLE-OID, "Appliance Series",    10, STRING				


		REMOVE-OID-ATOM

		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Interface configuration table"
				TABLE-OID,         50.1.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       1, UINT32, 1, FALSE, FALSE 
			COLUMN,     "Name",        3, STRING, 0, TRUE,  FALSE
			COLUMN,     "Address",     4, IP,     0, TRUE,  FALSE
			COLUMN,     "Mask",        5, IP,     0, TRUE,  FALSE
			COLUMN,     "MTU",         6, UINT32, 0, TRUE,  FALSE
			COLUMN,     "State",       7, INT32,  0, TRUE,  FALSE
			COLUMN,     "Mac Address", 8, STRING, 0, TRUE,  FALSE
			COLUMN,     "Description", 9, STRING, 0, TRUE,  FALSE
		
		END-TABLE

		START-TABLE

			START-TABLE-HEADER
			
				TABLE-NAME,        "Routing table"
				TABLE-OID,         6.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       1, UINT32,  1, FALSE, FALSE 
			COLUMN,     "Destination", 2, IP,      0, TRUE,  FALSE
			COLUMN,     "Mask",        3, IP,      0, TRUE,  FALSE
			COLUMN,     "GateWay",     4, IP,      0, TRUE,  FALSE
			COLUMN,     "Interface",   5, STRING,  0, TRUE,  FALSE

		END-TABLE

		ADD-OID-ATOM, 7

			ADD-OID-ATOM, 4

				SIMPLE-OID, "Total Virtual Memory (Bytes)",     1, UINT64
				SIMPLE-OID, "Active Virtual Memory (Bytes)",    2, UINT64
				SIMPLE-OID, "Total Real Memory (Bytes)",        3, UINT64
				SIMPLE-OID, "Active Real Memory (Bytes)",       4, UINT64
				SIMPLE-OID, "Free Real Memory (Bytes)",         5, UINT64
				SIMPLE-OID, "Memory Swaps/Sec",                 6, UINT32
				SIMPLE-OID, "Memory To Disk Transfers/Sec",     7, UINT32
			
			REMOVE-OID-ATOM 

			ADD-OID-ATOM, 2

				SIMPLE-OID, "CPU User Time (%)",    1, UINT32
				SIMPLE-OID, "CPU System Time (%)",  2, UINT32
				SIMPLE-OID, "CPU Idle Time (%)",    3, UINT32
				SIMPLE-OID, "CPU Usage (%)",        4, UINT16
				SIMPLE-OID, "CPU Queue Length",     5, UINT32
				SIMPLE-OID, "CPU Interrupts/Sec",   6, UINT32
				SIMPLE-OID, "CPUs Number",          7, UINT32
			
			REMOVE-OID-ATOM

			ADD-OID-ATOM, 3

				SIMPLE-OID, "Disk Servicing Read\Write Requests Time",  1, UINT32
				SIMPLE-OID, "Disk Requests Queue",                      2, UINT32
				SIMPLE-OID, "Disk Free Space (%)",                      3, UINT16
				SIMPLE-OID, "Disk Total Free Space (Bytes)",            4, UINT64
				SIMPLE-OID, "Disk Available Free Space (Bytes)",        5, UINT64
				SIMPLE-OID, "Disk Total Space (Bytes)",                 6, UINT64
			
			REMOVE-OID-ATOM

		REMOVE-OID-ATOM

		START-TABLE

			START-TABLE-HEADER
		
				TABLE-NAME,        "Processors load"
				TABLE-OID,         7.5.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "CPU#",       1, UINT32,  1, TRUE, FALSE 
			COLUMN,     "User Time(%)", 2, UINT32,      0, TRUE,  FALSE
			COLUMN,     "System Time(%)", 3, UINT32,      0, TRUE,  FALSE
			COLUMN,     "Idle Time(%)", 4, UINT32,      0, TRUE,  FALSE
			COLUMN,     "Usage(%)", 5, UINT32,      0, TRUE,  FALSE
			COLUMN,     "Run queue", 6, UINT32,      0, TRUE,  FALSE
			COLUMN,     "Interrupts/sec", 7, UINT32,      0, TRUE,  FALSE

		END-TABLE

		START-TABLE

			START-TABLE-HEADER
			
				TABLE-NAME,        "Partitions space"
				TABLE-OID,         7.6.1
				PRINT-ONLY-TOTALS, FALSE
				OUTPUT-FORMAT,     DEFAULT

			END-TABLE-HEADER

			COLUMN,     "Index",       1, UINT32,  1, FALSE, FALSE 
			COLUMN,     "Partition", 2, STRING,      0, TRUE,  FALSE
			COLUMN,     "Size (bytes)", 3, INT64,      0, TRUE,  FALSE
			COLUMN,     "Used (bytes)", 4, INT64,      0, TRUE,  FALSE
			COLUMN,     "Free total (bytes)", 5, INT64,      0, TRUE,  FALSE
			COLUMN,     "Free total (%)", 6, UINT16,      0, TRUE,  FALSE
			COLUMN,     "Free available (bytes)", 7, INT64,      0, TRUE,  FALSE
			COLUMN,     "Free available (%)", 8, UINT16,      0, TRUE,  FALSE

		END-TABLE
		
		SIMPLE-OID, "System Time",     8, UINT32
		SIMPLE-OID, "System Start Time",     12, UINT32

	END-FLAVOUR

	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "average_cpu"

		OID-BASE, 1.3.6.1.4.1.2620.999.6 # statistical info

		ADD-OID-ATOM, 7

			ADD-OID-ATOM, 2

				SIMPLE-OID, "Average CPU User Time (%)",    1.1, UINT32
				SIMPLE-OID, "Average CPU System Time (%)",  2.1, UINT32
				SIMPLE-OID, "Average CPU Idle Time (%)",    3.1, UINT32
				SIMPLE-OID, "Average CPU Usage (%)",        4.1, UINT16
				SIMPLE-OID, "Average CPU Queue Length",     5.1, UINT32
				SIMPLE-OID, "Average CPU Interrupts/Sec",   6.1, UINT32
			
			REMOVE-OID-ATOM

		REMOVE-OID-ATOM

	END-FLAVOUR

	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "average_memory"

		OID-BASE, 1.3.6.1.4.1.2620.999.6 # statistical info

		ADD-OID-ATOM, 7

			ADD-OID-ATOM, 4

				SIMPLE-OID, "Average Active Virtual Memory (Bytes)",    2.1, UINT64
				SIMPLE-OID, "Average Active Real Memory (Bytes)",       4.1, UINT64
				SIMPLE-OID, "Average Free Real Memory (Bytes)",         5.1, UINT64
				SIMPLE-OID, "Average Memory Swaps/Sec",                 6.1, UINT32
				SIMPLE-OID, "Average Memory To Disk Transfers/Sec",     7.1, UINT32
			
			REMOVE-OID-ATOM

		REMOVE-OID-ATOM

	END-FLAVOUR

	#################################################

	START-FLAVOUR

		FLAVOUR-NAME, "statistics"

		OID-BASE, 1.3.6.1.4.1.2620.999.6 # statistical info

		ADD-OID-ATOM, 7

			ADD-OID-ATOM, 2

				SIMPLE-OID, "Average CPU User Time (%)",    1.1, UINT32
				SIMPLE-OID, "Average CPU System Time (%)",  2.1, UINT32
				SIMPLE-OID, "Average CPU Idle Time (%)",    3.1, UINT32
				SIMPLE-OID, "Average CPU Usage (%)",        4.1, UINT16
				SIMPLE-OID, "Average CPU Queue Length",     5.1, UINT32
				SIMPLE-OID, "Average CPU Interrupts/Sec",   6.1, UINT32
			
			REMOVE-OID-ATOM
			
			ADD-OID-ATOM, 4

				SIMPLE-OID, "Average Active Virtual Memory (Bytes)",    2.1, UINT64
				SIMPLE-OID, "Average Active Real Memory (Bytes)",       4.1, UINT64
				SIMPLE-OID, "Average Free Real Memory (Bytes)",         5.1, UINT64
				SIMPLE-OID, "Average Memory Swaps/Sec",                 6.1, UINT32
				SIMPLE-OID, "Average Memory To Disk Transfers/Sec",     7.1, UINT32
			
			REMOVE-OID-ATOM

		REMOVE-OID-ATOM

	END-FLAVOUR
END-BLOCK

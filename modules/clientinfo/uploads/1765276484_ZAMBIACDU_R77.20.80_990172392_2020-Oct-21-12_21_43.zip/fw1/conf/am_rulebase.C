(
	:rulebase (A__67100973-7618-BD49-B353-9E7D50622C4D_
		:num_format ("%d")
		:uid ("{67100973-7618-BD49-B353-9E7D50622C4D}")
	)
	:rule (
		:0 (A__8300928B-C059-0542-864D-3AE08206AF46_
			:AdminInfo (
				:chkpf_uid ("{C075536D-81E9-2642-85E0-3A8A9C49DF7D}")
				:ClassName (anti_malware_rulebase_rule)
				:table (anti_malware_rulebase_rules)
			)
			:Exceptions (ReferenceObject
				:Table (anti_malware_rulebases)
				:Name (A__877635C6-DE4F-5840-95C6-D0E0178D550C_)
				:Uid ("{877635C6-DE4F-5840-95C6-D0E0178D550C}")
			)
			:action (
				:AdminInfo (
					:chkpf_uid ("{C32A540A-D96C-4283-BB86-BDBB05D83734}")
					:ClassName (rulebase_basic_action)
					:table (rulebase_actions)
				)
				:display_name (Allow)
				:sort_order (1)
				:type (rulebase_basic_action)
			)
			:am_action (ReferenceObject
				:Table (am_profiles)
				:Name (Recommended_Profile)
				:Uid ("{44B83C65-E73C-4D63-AA55-4CDCEA4A6D4B}")
			)
			:dst (
				:AdminInfo (
					:chkpf_uid ("{0B9D687E-3DC3-A34A-ADA6-E46D952F33D7}")
					:ClassName (anti_malware_dst_field_t)
				)
				:ReferenceObject (
					: (Any
						:description ()
						:ID (-5)
						:display_name (Any)
					)
				)
				:op (false)
			)
			:enable_packet_capture (true)
			:entity_name ()
			:identity_settings (
				:AdminInfo (
					:chkpf_uid ("{59683D0A-147A-3E4D-B421-7D629C06C9D0}")
					:ClassName (identity_action_settings)
				)
				:allow_ad_query (true)
				:allow_captive_portal (true)
				:allow_identity_agent (true)
				:allowed_sources ("All Sources")
				:redirect_to_captive_portal (false)
				:require_packet_tagging (false)
				:type (identity_action_settings)
			)
			:install (
				: (All
					:ID (0)
					:description ()
					:display_name ()
				)
			)
			:num_for_audit ()
			:protection (
				:AdminInfo (
					:chkpf_uid ("{1C9E1705-14E3-0B4C-B282-75B489476E93}")
					:ClassName (armada_protection_field_not_relevant_t)
				)
				:ReferenceObject (
					: (not_applicable
						:ID (0)
						:description ("Not applicable for rule. Protection is relevant only for rule exception.")
						:display_name ("n/a")
					)
				)
				:op (false)
			)
			:rule_name ()
			:scope (
				:AdminInfo (
					:chkpf_uid ("{2550E143-2928-1C4F-BACE-F1222120E1CE}")
					:ClassName (anti_malware_scope_field_t)
				)
				:ReferenceObject (
					: (Any
						:description ()
						:ID (-5)
						:display_name (Any)
					)
				)
				:op (false)
			)
			:services (
				:AdminInfo (
					:chkpf_uid ("{6EEDB1F5-D338-F040-B075-B6677EB53182}")
					:ClassName (armada_service_field_t)
				)
				:ReferenceObject (
					: (Any
						:description ()
						:ID (-5)
						:display_name (Any)
					)
				)
				:op (false)
			)
			:src (
				:AdminInfo (
					:chkpf_uid ("{3C5CB9BC-6222-664A-9661-FB391CA695AA}")
					:ClassName (anti_malware_src_field_t)
				)
				:ReferenceObject (
					: (Any
						:description ()
						:ID (-5)
						:display_name (Any)
					)
				)
				:op (false)
			)
			:track (
				:AdminInfo (
					:chkpf_uid ("{6057E8D5-5185-453B-A416-4029C8ECA6D0}")
					:ClassName (rulebase_basic_track)
					:table (rulebase_tracks)
				)
				:display_name (Log)
				:relevance (All)
				:settings (
					:AdminInfo (
						:chkpf_uid ("{16A3BC81-D7E8-4A1B-CD11-A16D03E12F01}")
						:ClassName (rulebase_track_settings)
					)
					:enable_session_suppression (true)
					:include_mode ("First Connection")
					:override_global_timeout (false)
					:timeout (180)
				)
				:sort_order (2)
				:tracking_type (Log)
				:type (rulebase_basic_track)
			)
			:disabled (false)
			:parent_section ("{9422ACDA-AF03-C74A-9ABD-ECF17997564D}")
			:rule_number (1)
			:rule_number_formatted (1)
		)
	)
	:sections (
		: (A__9422ACDA-AF03-C74A-9ABD-ECF17997564D_
			:AdminInfo (
				:chkpf_uid ("{9422ACDA-AF03-C74A-9ABD-ECF17997564D}")
				:ClassName (anti_malware_rulebase_section)
				:table (anti_malware_rulebase_sections)
			)
			:entity_name ()
			:is_shared (false)
			:num_rules_this_section (1)
			:rulebase_name ()
			:parent_section ()
		)
	)
)

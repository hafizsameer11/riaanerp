(FW1_basic_scheme
        :groups (
                : (user
                        :type (string)
                        : (
                                :field_name (user)
                                :field_type (string)
                        )
                        : (
                                :field_name (vpn_user)
                                :field_type (string)
                        )
                )
        )
        :unification (
                : (
                        :group (HeaderAction)
                        :action (use_internal_action)
                  )
                : (
                        :group (HeaderInterfaceDir)
                        :action (use_internal_action)
                  )
                : (
                        :group (HeaderOrigin)
                        :action (use_first_value)
                  )
                : (
                        :group (HeaderInterfaceName)
                        :action (use_first_significant)
                  )
                : (
                        :group (HeaderTime)
                        :action (use_last_value)
                  )
                : (
                        :group (product)
                        :action (add_unique_value)
                  )
                : (
                        :group (proto)
                        :action (use_last_value)
                  )
                : (
                        :group (src)
                        :action (use_last_value)
                  )
                : (
                        :group (dst)
                        :action (use_last_value)
                  )
                : (
                        :group (service)
                        :action (use_last_value)
                  )
                : (
                        :group (rule)
                        :action (use_last_value)
                  )
                : (
                        :group (message)
                        :action (add_value)
                  )
                : (
                        :group (elapsed)
                        :action (add_value)
                  )
                : (
                        :group (bytes)
                        :action (add_value)
                  )
                : (
                        :group (bytes_received_client)
                        :action (add_value)
                  )
                : (
                        :group (bytes_received_server)
                        :action (add_value)
                  )
                : (
                        :group (bytes_transmitted_client)
                        :action (add_value)
                  )
                : (
                        :group (bytes_transmitted_server)
                        :action (add_value)
                  )
                : (
                        :group (dropped_incoming)
                        :action (add_value)
                  )
                : (
                        :group (dropped_outgoing)
                        :action (add_value)
                  )
                : (
                        :group (dropped_total)
                        :action (add_value)
                  )
                : (
                        :group (client_inbound_packets)
                        :action (add_value)
                  )
                : (
                        :group (client_outbound_packets)
                        :action (add_value)
                  )
                : (
                        :group (h_len)
                        :action (add_value)
                  )
                : (
                        :group (len)
                        :action (add_value)
                  )
                : (
                        :group (packets)
                        :action (add_value)
                  )
                : (
                        :group (packets_received)
                        :action (add_value)
                  )
                : (
                        :group (packets_transmitted)
                        :action (add_value)
                  )
                : (
                        :group (reason)
                        :action (add_value)
                  )
                : (
                        :group (resource)
                        :action (add_value)
                  )
                : (
                        :group (server_inbound_packets)
                        :action (add_value)
                  )
                : (
                        :group (server_outbound_packets)
                        :action (add_value)
                  )
                : (
                        :group (start_time)
                        :action (use_first_value)
                  )
                : (
                        :group (to)
                        :action (add_value)
                  )
		: (
                        :group (from)
                        :action (add_value)
                  )
                : (
                        :group (res_action)
                        :action (add_value)
                  )
                : (
                        :group (file)
                        :action (add_value)
                  )
    			: (
                        :group (message_info)
                        :action (add_value)
                  )
    			: (
                        :group (server_inbound_bytes)
                        :action (add_value)
                  )
    			: (
                        :group (server_outbound_bytes)
                        :action (add_value)
                  )
    			: (
                        :group (client_inbound_bytes)
                        :action (add_value)
                  )
    			: (
                        :group (client_outbound_bytes)
                        :action (add_value)
                  )
		 		: (
                        :group (query:)
                        :action (add_value)
                  )
                : (
                        :group (dns_query)
                        :action (add_value)
                  )
         		: (
                        :group (dns_type)
                        :action (add_value)
                  )
				: (
                        :group ("src phone number")
                        :action (add_value)
                  )
				: (
                        :group ("dst phone number")
                        :action (add_value)
                  )
				: (
                        :group ("media type")
                        :action (add_value)
                  )
				: (
                        :group ("Log ID")
                        :action (add_unique_value)
                  )
				 : (
					  	:group ("Suppressed Logs")
					  	:action (add_value)
				 )
                : (
                        :group (sent_bytes)
                        :action (add_value)
                  )
                : (
                        :group (received_bytes)
                        :action (add_value)
                  )
                : (
                        :group (spyware_name)
                        :action (use_first_value)
                  )
                : (
                        :group (app_sig_id)
                        :action (add_value)
                  )
                  : (
                          :group (packet_capture_unique_id)
                          :action (add_value)
                  )
                  : (
                          :group (packet_capture_time)
                          :action (add_value)
                  )
                  : (
                         :group (packet_capture_name)
                         :action (add_value)
                  )
				  : (
                         :group (portal_message)
                         :action (use_first_value)
                  )
                :default_action (use_last_value)
        )
)

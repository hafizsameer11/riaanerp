(
	:__orig (
		:display_name ("Origin")
	)

	:__policy_id_tag (
		:display_name ("Policy ID Tag")
	)

	:__time (
		:display_name ("Time")
	)
		
	:src (
		:display_name ("Source")
	)
	
	:Src (
		:display_name ("Source")
	)
		
	:s_port (
		:display_name ("Source Port")
	)
	
	:dst (
		:display_name ("Destination")
	)
	
	:Dst (
		:display_name ("Destination")
	)
	
	:service_tcp (
		:display_name ("Service")
		:values (
			:256 (
				:display_name ("FW1")
			)
			:257 (
				:display_name ("FW1_log")
			)
			:258 (
				:display_name ("FW1_mgmt")
			)
			:259 (
				:display_name ("FW1_clntauth_telnet")
			)
			:261 (
				:display_name ("FW1_snauth")
			)
			:264 (
				:display_name ("FW1_topo")
			)
			:265 (
				:display_name ("FW1_key")
			)
			:900 (
				:display_name ("FW1_clntauth_http")
			)
			:18181 (
				:display_name ("FW1_cvp")
			)
			:18182 (
				:display_name ("FW1_ufp")
			)
			:18183 (
				:display_name ("FW1_sam")
			)
			:18185 (
				:display_name ("FW1_omi")
			)
			:18186 (
				:display_name ("FW1_omi-sic")
			)
			:18187 (
				:display_name ("FW1_ela")
			)
			:18190 (
				:display_name ("CPMI")
			)
			:18191 (
				:display_name ("CPD")
			)
			:18192 (
				:display_name ("CPD_amon")
			)
			:18193 (
				:display_name ("FW1_amon")
			)
			:18202 (
				:display_name ("CP_rtm")
			)
			:18205 (
				:display_name ("CP_reporting")
			)
			:18207 (
				:display_name ("FW1_pslogon")
			)
			:18208 (
				:display_name ("FW1_CPRID")
			)
			:18210 (
				:display_name ("FW1_ica_pull")
			)
			:18211 (
				:display_name ("FW1_ica_push")
			)
			:18221 (
				:display_name ("CP_redundant")
			)
			:18232 (
				:display_name ("FW1_sds_logon")
			)
			:18262 (
				:display_name ("CP_Exnet_PK")
			)
			:18263 (
				:display_name ("CP_Exnet_resolve")
			)
			:18264 (
				:display_name ("FW1_ica_services")
			)
			:18265 (
				:display_name ("FW1_ica_mgmt_tools")
			)
			:18266 (
				:display_name ("CP_seam")
			)
			:19190 (
				:display_name ("FW1_netso")
			)
			:19191 (
				:display_name ("FW1_uaa")
			)
			:20 (
				:display_name ("FTP")
			)
			:21 (
				:display_name ("FTP")
			)
			:23 (
				:display_name ("TELNET")
			)
			:22 (
				:display_name ("SSH")
			)
			:1723 (
				:display_name ("PPTP_TCP")
			)
			:389 (
				:display_name ("LDAP")
			)
			:139 (
				:display_name ("SMBOverNetBIOS")
			)
			:445 (
				:display_name ("CIFS")
			)
			:3389 (
				:display_name ("Remote desktop")
			)
			:179 (
				:display_name ("BGP")
			)
			:25 (
				:display_name ("SMTP")
			)
			:110 (
				:display_name ("POP3")
			)
			:143 (
				:display_name ("IMAP")
			)
			:119 (
				:display_name ("NNTP")
			)
			:3128 (
				:display_name ("Squid_NTLM")
			)
			:80 (
				:display_name ("HTTP")
			)
			:8080 (
				:display_name ("HTTP")
			)
			:443 (
				:display_name ("HTTPS")
			)
			:4434 (
				:display_name ("Local_WebUI")
			)
			:444 (
				:display_name ("CP_SSL_Network_Extender")
			)
			:2000 (
				:display_name ("SCCP")
			)
			:513 (
				:display_name ("rlogin")
			)
			:1037 (
				:display_name ("AMS")
			)			
			:53 (
				:display_name ("DNS")
			)
			:500 (
				:display_name ("IKE")
			)
			:554 (
				:display_name ("RTSP")
			)
			:123 (
				:display_name ("NTP")
			)
			:135 (
				:display_name ("RPC")
			)
		)	
	)
	:service_udp (
		:display_name ("Service")
		:values (
			:2746 (
				:display_name ("VPN1_IPSEC_encapsulation")
			)
			:8116 (
				:display_name ("CP_Cluster_sync")
			)
			:18212 (
				:display_name ("FW1_load_agent")
			)
			:18233 (
				:display_name ("FW1_scv_keep_alive")
			)
			:18241 (
				:display_name ("E2ECP")
			)
			:260 (
				:display_name ("FW1_snmp")
			)
			:137 (
				:display_name ("NetBIOSName")
			)
			:138 (
				:display_name ("NetBIOSDatagram")
			)
			:259 (
				:display_name ("RDP")
			)
			:5060 (
				:display_name ("SIP")
			)
			:161 (
				:display_name ("SNMP")
			)
			:162 (
				:display_name ("SNMP-trap")
			)
			:520 (
				:display_name ("RIP")
			)
			:1701 (
				:display_name ("L2TP")
			)
			:514 (
				:display_name ("syslog")
			)
			:67 (
				:display_name ("DHCP")
			)			
			:68 (
				:display_name ("DHCP")
			)			
			:69 (
				:display_name ("TFTP")
			)
			:53 (
				:display_name ("DNS")
			)
			:500 (
				:display_name ("IKE")
			)
			:123 (
				:display_name ("NTP")
			)
			:135 (
				:display_name ("RPC")
			)
		)	
	)
	
	:proto (
		:display_name ("Protocol")
		:values (
			:1 (
				:display_name ("ICMP")
			)
			:6 (
				:display_name ("TCP")
			)
			:17 (
				:display_name ("UDP")
			)
			:47 (
				:display_name ("gre")
			)
			:89 (
				:display_name ("ospf")
			)
			:2 (
				:display_name ("igmp")
			)
			:3 (
				:display_name ("ggp")
			)
			:8 (
				:display_name ("egp")
			)
			:9 (
				:display_name ("igrp")
			)
		)	
	)

	:rule_base (
		:display_name ("Rule Base")
		:values (
			:1 (
				:display_name ("Outgoing to Internet")
			)
			:2 (
				:display_name ("Incoming")
			)
		)	
	)
	
	:rule (
		:display_name ("Rule")
	)
	
	:rule_uid (
		:display_name ("Rule UID")
	)
	
	:rule_name (
		:display_name ("Rule Name")
	)
	
	:service_id (
		:display_name ("Service ID")
	)
	
	:service (
		:display_name ("Service Port")
	)
	
	:type (
		:display_name ("Type")
		:values (
			:0 (
				:display_name ("Log")
				:image ("log_level.log-small.gif")
			)
			:1 (
				:display_name ("Alert")
				:image ("log_level.alert-small.gif")
			)
			:2 (
				:display_name ("Account")
			)
			:4 (
				:display_name ("Control")
				:image ("log_level.control.gif")	
			)
			:8 (
				:display_name ("System Alert")
			)
		)
	)

	:Severity (
		:display_name ("Severity")
		:values (
			:1 (
				:display_name ("Low")
				:image ("ips_rank_level.low.gif")
			)
			:2 (
				:display_name ("Medium")
				:image ("ips_rank_level.medium.gif")
			)
			:3 (
				:display_name ("High")
				:image ("ips_rank_level.high.gif")
			)
			:4 (
				:display_name ("Critical")
				:image ("ips_rank_level.critical.gif")
			)
		)
	)

	:"Confidence Level" (
		:display_name ("Confidence Level")
		:values (
			:1 (
				:display_name ("Low")
				:image ("ips_confidence_rank_level.low.gif")
			)
			:2 (
				:display_name ("Medium-low")
				:image ("ips_confidence_rank_level.mediumlow.gif")
			)
			:3 (
				:display_name ("Medium")
				:image ("ips_confidence_rank_level.medium.gif")
			)
			:4 (
				:display_name ("Medium-high")
				:image ("ips_confidence_rank_level.mediumhigh.gif")
			)
			:5 (
				:display_name ("High")
				:image ("ips_confidence_rank_level.high.gif")
			)
		)
	)

	:"Performance Impact" (
		:display_name ("Performance Impact")
		:values (
			:1 (
				:display_name ("Very-low")
				:image ("ips_rank_level.verylow.gif")			
			)
			:2 (
				:display_name ("Low")
				:image ("ips_rank_level.low.gif")
			)
			:3 (
				:display_name ("Medium")
				:image ("ips_rank_level.medium.gif")
			)
			:4 (
				:display_name ("High")
				:image ("ips_rank_level.high.gif")
			)
		)
	)
	
	:product (
		:display_name ("Product")
		:values (
			:"VPN-1 & FireWall-1" (
				:display_name ("Firewall")
				:image ("product_fw1.gif")
			)
			:"SmartDefense"  (
				:display_name ("IPS")
				:image ("product_asm.gif")
			)
			:"Anti Spam"  (
				:display_name ("Anti Spam")
				:image ("product_anti_spam.gif")
			)
			:"Anti Virus"  (
				:display_name ("Anti Virus")
				:image ("product_anti_virus.gif")
			)
			:"Connectra"  (
				:display_name ("Connectra")
				:image ("product_connectra.gif")
			)
			:"FireWall-1 GX"  (
				:display_name ("FireWall-1 GX")
				:image ("product_everest.gif")
			)
			:"QoS"  (
				:display_name ("QoS")
				:image ("product_fg1.gif")
			)
			:"Endpoint Security"  (
				:display_name ("Endpoint Security")
				:image ("product_integrity.gif")
			)
			:"Perform Command"  (
				:display_name ("Perform Command")
				:image ("product_opsec.gif")
			)
			:"SmartView Monitor"  (
				:display_name ("SmartView Monitor")
				:image ("product_rtm.gif")
			)
			:"SecureClient"  (
				:display_name ("SecureClient")
				:image ("product_secureclient.gif")
			)
			:"SmartPortal"  (
				:display_name ("SmartPortal")
				:image ("product_smartportal.gif")
			)
			:"UTM-1 Edge"  (
				:display_name ("UTM-1 Edge")
				:image ("product_sofaware.gif")
			)
			:"UA Server"  (
				:display_name ("UA Server")
				:image ("product_uaserver.gif")
			)
			:"UA WebAccess"  (
				:display_name ("UA WebAccess")
				:image ("product_uawebaccess.gif")
			)
			:"Web Filtering"  (
				:display_name ("Web Filtering")
				:image ("product_web_filtering.gif")
			)
			:"Application Control"  (
				:display_name ("Application Control")
				:image ("product_appi.gif")
			)
			:"Application Control?URL Filtering" (
				:display_name ("Application Control/URL Filtering")
				:image ("product_general.gif")
			)
			:"URL Filtering" (
				:display_name ("URL Filtering")
				:image ("product_web_filtering.gif")
			)
			:"Identity Awareness" (
				:display_name ("Identity Awareness")
				:image ("product_IdentityLogging.gif")
			)
		)
	)
	
	:if_name (
		:display_name ("Interface")
	)
	
	:ctrl_category (
		:display_name ("Control Log Category")
	)

	:connectivity_state (
		:display_name ("Connectivity State")
	)

	:description (
		:display_name ("Description")
	)

	:subs_exp (
		:display_name ("Subscription Expiration")
	)
	
	:direction (
		:display_name ("Direction")
	)
	
	:alert (
		:display_name ("Alert")
	)
	
	:action (
		:display_name ("Action")
		:values (
			:-1 (
				:display_name ("")
				:image ("log_level.none-small.gif")	
			)
			:0 (
				:display_name ("Drop")
				:image ("action_drop.gif")
			)
			:1 (
				:display_name ("Reject")
				:image ("action_reject.gif")
			)
			:2 (
				:display_name ("Accept")
				:image ("action_accept.gif")
			)
			:3 (
				:display_name ("Encrypt")
				:image ("action_encrypt.gif")
			)
			:4 (
				:display_name ("Decrypt")
				:image ("action_decrypt.gif")
			)
			:5 (
				:display_name ("Hold")
			)
			:6 (
				:display_name ("Vanish")
			)
			:7 (
				:display_name ("VPN Route")
				:image ("action_vpn_rauting.gif")
			)
			:16 (
				:display_name ("Key Install")
				:image ("action_keyinstall.gif")
			)
			:17 (
				:display_name ("Authorize")
				:image ("action_authorize.gif")
			)
			:18 (
				:display_name ("De-Authorize")
				:image ("action_deauthorize.gif")
			)
			:19 (
				:display_name ("Translate")
			)
			:20 (
				:display_name ("Translate Source")
			)
			:21 (
				:display_name ("Translate Destination")
			)
			:22 (
				:display_name ("Translate Port")
			)
			:23 (
				:display_name ("AUTHCRYPT")
				:image ("action_authcrypt.gif")
			)
			:30 (
				:display_name ("Bypass")
				:image ("action_bypass.gif")
			)
			:31 (
				:display_name ("Inspect")
				:image ("action_inspect.gif")
			)
			:32 (
				:display_name ("Quarantine")
				:image ("action_quarantine.gif")
			)
			:33 (
				:display_name ("Block")
				:image ("action_block.gif")
			)
			:34 (
				:display_name ("Detect")
				:image ("action_monitor_only.gif")
			)
			:35 (
				:display_name ("MC_REPLACE")
			)
			:36 (
				:display_name ("Stamp")
				:image ("action_monitor_only.gif")
			)
			:37 (
				:display_name ("authcrypt")
			)
			:38 (
				:display_name ("Log Out")
				:image ("action_disassociate.gif")
			)
			:39 (
				:display_name ("Discard")
			)
			:40 (
				:display_name ("Send")
			)
			:41 (
				:display_name ("Expired")
			)
			:42 (
				:display_name ("Prevent")
			)
			:43 (
				:display_name ("Allow")
				:image ("action_accept.gif")
			)
			:44 (
				:display_name ("Inform")
			)
			:45 (
				:display_name ("Delete")
			)
			:46 (
				:display_name ("Ask")
			)
			:47 (
				:display_name ("Review")
			)
			:48 (
				:display_name ("IP Changed")
			)
			:49 (
				:display_name ("Packet Tagging")
			)
			:50 (
				:display_name ("Redirect")
				:image ("action_redirect.gif")
			)
			:51 (
				:display_name ("HTTPS Inspect")
			)
			:52 (
				:display_name ("HTTPS Bypass")
			)
			:54 (
				:display_name ("Update")
				:image ("action_update.gif")
			)
			:255 (
				:display_name ("")
			)
		)
	)
	
	:inzone (
		:display_name ("From Zone")
	)
	
	:outzone (
		:display_name ("To Zone")
	)
	
	:app_id (
		:display_name ("Signature ID")
	)
	
	:sent_bytes (
		:display_name ("Sent Bytes")
	)

	:bytes (
		:display_name ("Total Bytes")
	)

	:received_bytes (
		:display_name ("Received Bytes")
	)

	:app_risk (
		:display_name ("Risk")
		:values (
			:0 (
				:display_name ("Unknown")
			)
			:1 (
				:display_name ("Very Low")
			)
			:2 (
				:display_name ("Low")
			)
			:3 (
				:display_name ("Medimm")
			)
			:4 (
				:display_name ("High")
			)
			:5 (
				:display_name ("Critical")
			)
		)
	)

	:app_desc (
		:display_name ("Description")
	)

	:appi_name (
		:display_name ("Application / Site")
	)

	:web_client_type (
		:display_name ("Client Type")
	)

	:app_properties (
		:display_name ("All Categories")
	)

	:matched_category (
		:display_name ("Matched Category")
	)

	:app_category (
		:display_name ("Primary Category")
	)

	:proxy_src_ip (
		:display_name ("Proxied Source IP")
	)

	:UserCheck_incident_uid (
		:display_name ("UserCheck ID")
	)

	:app_rule_id (
		:display_name ("Application Rule ID")
	)

	:resource (
		:display_name ("URL")
	)

	:reason (
		:display_name ("Reason")
	)

	:db_ver (
		:display_name ("Database Version")
	)

	:duration (
		:display_name ("Duration")
	)

	:Identity_src (
		:display_name ("Identity Source")
	)

	:termination_reason (
		:display_name ("Description")
	)

	:src_user_group (
		:display_name ("Source User Group")
	)

	:auth_status (
		:display_name ("Authentication Method")
	)

	:scheme (
		:display_name ("Encryption Scheme")
		:values (
			:"IKE" (
				:display_name ("IKE")
				:image ("encryption_scheme_ike.gif")
			)
		)
	)

	:"Protection Type" (
		:display_name ("Protection Type")
		:values (
			:"anomaly" (
				:display_name ("Protocol Anomaly")
				:image ("pro_type_anomaly.gif")
			)
			:"protection" (
				:display_name ("Signature")
				:image ("pro_type_protections.gif")
			)
		)
	)

	:"Update Status" (
		:display_name ("Update Status")
		:values (
			:"updated" (
				:display_name ("Updated")
			)
		)
	)

	:"SmartDefense Profile" (
		:display_name ("IPS Profile")
	)	
)
	

(
	:version (6.03)
	: (D_NULL_ACTION
		:AdminInfo (
			:chkpf_uid ("{58BB5031-EAAB-44C5-B50D-70EDA750296C}")
			:ClassName (log_action_object)
			:table (log_actions)
			:LastModified (
				:Time ("Tue Apr 11 16:19:00 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (255)
		:action_name (" ")
		:action_priority (5000)
	)
	: (D_ACCEPT
		:AdminInfo (
			:chkpf_uid ("{49589B99-D51A-4CD0-BD37-9F0510A4DFD5}")
			:ClassName (log_action_object)
			:table (log_actions)
			:LastModified (
				:Time ("Tue Apr 11 16:19:00 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (2)
		:action_name ("accept")
		:action_priority (10000)
	)
	: (D_MONITOR
		:AdminInfo (
			:chkpf_uid ("{B19D6BD2-8A1C-4FE7-8A4F-B0E116E07420}")
			:ClassName (log_action_object)
			:table (log_actions)
			:LastModified (
				:Time ("Tue Apr 11 16:19:00 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (34)
		:action_name ("monitor")
		:action_priority (15000)
	)
	: (D_ENCRYPT
		:AdminInfo (
			:chkpf_uid ("{43631FDB-A7CE-4A0C-9640-3429710CF6A3}")
			:ClassName (log_action_object)
			:table (log_actions)
			:LastModified (
				:Time ("Tue Apr 11 16:19:00 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (3)
		:action_name ("encrypt")
		:action_priority (20000)
	)
	: (D_DECRYPT
		:AdminInfo (
			:chkpf_uid ("{F50B5C5E-BC7D-4007-9470-1A869C1CBC63}")
			:ClassName (log_action_object)
			:table (log_actions)
			:LastModified (
				:Time ("Tue Apr 11 16:19:00 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (4)
		:action_name ("decrypt")
		:action_priority (25000)
	)
	: (D_VPNROUTE
		:AdminInfo (
			:chkpf_uid ("{ABC44645-0099-49C4-94B2-CCFA21D0A236}")
			:ClassName (log_action_object)
			:table (log_actions)
			:LastModified (
				:Time ("Tue Apr 11 16:19:00 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (7)
		:action_name ("vpnroute")
		:action_priority (30000)
	)
	: (D_HOLD
		:AdminInfo (
			:chkpf_uid ("{46081FAF-A494-4EE1-8D58-863E8F4B9998}")
			:ClassName (log_action_object)
			:table (log_actions)
			:LastModified (
				:Time ("Tue Apr 11 16:19:00 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (5)
		:action_name ("")
		:action_priority (35000)
	)
	: (D_KEYINST
		:AdminInfo (
			:chkpf_uid ("{7066BFD2-BFCA-4BB3-ABC0-D635395D9582}")
			:ClassName (log_action_object)
			:table (log_actions)
			:LastModified (
				:Time ("Tue Apr 11 16:19:00 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (16)
		:action_name ("keyinst")
		:action_priority (40000)
	)
	: (D_AUTHORIZE
		:AdminInfo (
			:chkpf_uid ("{EF5EF7D0-F8F3-4E32-B869-43AE3649107E}")
			:ClassName (log_action_object)
			:table (log_actions)
			:LastModified (
				:Time ("Tue Apr 11 16:19:00 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (17)
		:action_name ("authorize")
		:action_priority (45000)
	)
	: (D_DEAUTHORIZE
		:AdminInfo (
			:chkpf_uid ("{6B5533F6-511E-4985-B0BC-8E0B095C8B3F}")
			:ClassName (log_action_object)
			:table (log_actions)
			:LastModified (
				:Time ("Tue Apr 11 16:19:00 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (18)
		:action_name ("deauthorize")
		:action_priority (50000)
	)
	: (D_XLATEHIDE
		:AdminInfo (
			:chkpf_uid ("{EE41922A-0406-4F28-ACA6-10E23C61DE77}")
			:ClassName (log_action_object)
			:table (log_actions)
			:LastModified (
				:Time ("Tue Apr 11 16:19:00 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (19)
		:action_name ("")
		:action_priority (55000)
	)
	: (D_XLATESRC
		:AdminInfo (
			:chkpf_uid ("{846048F6-B0BA-4BE2-A3C0-175D702435CE}")
			:ClassName (log_action_object)
			:table (log_actions)
			:LastModified (
				:Time ("Tue Apr 11 16:19:00 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (20)
		:action_name ("")
		:action_priority (60000)
	)
	: (D_XLATEDST
		:AdminInfo (
			:chkpf_uid ("{C2CE0A91-0857-4808-86D4-5A1994FD0625}")
			:ClassName (log_action_object)
			:table (log_actions)
			:LastModified (
				:Time ("Tue Apr 11 16:19:00 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (21)
		:action_name ("")
		:action_priority (65000)
	)
	: (D_XLATEPORT
		:AdminInfo (
			:chkpf_uid ("{235081AC-C588-44BB-90B9-D79ABD0769FA}")
			:ClassName (log_action_object)
			:table (log_actions)
			:LastModified (
				:Time ("Tue Apr 11 16:19:00 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (22)
		:action_name ("")
		:action_priority (70000)
	)
	: (D_AUTHCRYPT
		:AdminInfo (
			:chkpf_uid ("{766AECDD-8FCF-4821-9B11-B70A13F999F0}")
			:ClassName (log_action_object)
			:table (log_actions)
			:LastModified (
				:Time ("Tue Apr 11 16:19:00 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (23)
		:action_name ("authcrypt")
		:action_priority (75000)
	)
	: (D_REJECT
		:AdminInfo (
			:chkpf_uid ("{D94101CB-2996-47D4-924F-1245B6C688E5}")
			:ClassName (log_action_object)
			:table (log_actions)
			:LastModified (
				:Time ("Tue Apr 11 16:19:00 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (1)
		:action_name ("reject")
		:action_priority (80000)
	)
	: (D_VANISH
		:AdminInfo (
			:chkpf_uid ("{EE1F1053-62C7-47F2-A3FC-A3BF2282C588}")
			:ClassName (log_action_object)
			:table (log_actions)
			:LastModified (
				:Time ("Tue Apr 11 16:19:00 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (6)
		:action_name ("drop")
		:action_priority (85000)
	)
	: (D_DROP
		:AdminInfo (
			:chkpf_uid ("{50F40B9F-50AB-4093-8389-CA49A5832FA5}")
			:ClassName (log_action_object)
			:table (log_actions)
			:LastModified (
				:Time ("Tue Apr 11 16:19:00 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (0)
		:action_name ("drop")
		:action_priority (90000)
	)
	: (D_BYPASS
		:AdminInfo (
			:chkpf_uid ("{726C39D5-560F-4E98-BFBC-7A63AEF12168}")
			:ClassName (log_action_object)
			:table (log_actions)
			:LastModified (
				:Time ("Tue Apr 11 16:19:00 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (30)
		:action_name ("bypass")
		:action_priority (95000)
	)
	: (D_INSPECT
		:AdminInfo (
			:chkpf_uid ("{700FE4C4-DB79-4108-8786-D6BB7D6B2262}")
			:ClassName (log_action_object)
			:table (log_actions)
			:LastModified (
				:Time ("Tue Apr 11 16:19:00 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (31)
		:action_name ("inspect")
		:action_priority (100000)
	)
	: (D_QUARANTINE
		:AdminInfo (
			:chkpf_uid ("{7926EBE8-E370-497A-9D8B-B5A1562E38DD}")
			:ClassName (log_action_object)
			:table (log_actions)
			:LastModified (
				:Time ("Tue Apr 11 16:19:00 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (32)
		:action_name ("quarantine")
		:action_priority (105000)
	)
	: (D_BLOCK
		:AdminInfo (
			:chkpf_uid ("{D4B49A99-60D9-4C3D-8E0A-429F66787503}")
			:ClassName (log_action_object)
			:table (log_actions)
			:LastModified (
				:Time ("Tue Apr 11 16:19:00 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (33)
		:action_name ("block")
		:action_priority (110000)
	)
	: (D_MC_REPLACE
		:AdminInfo (
			:chkpf_uid ("{B86A4D2F-E5AD-4D38-8EB3-696FF722543C}")
			:ClassName (log_action_object)
			:table (log_actions)
			:LastModified (
				:Time ("Tue Apr 11 16:19:00 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (35)
		:action_name ("mcreplace")
		:action_priority (115000)
	)
	: (D_STAMP
		:AdminInfo (
			:chkpf_uid ("{5DFAF9D5-2679-4CF4-8B98-7573BC763884}")
			:ClassName (log_action_object)
			:table (log_actions)
			:LastModified (
				:Time ("Tue Apr 11 16:19:00 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (36)
		:action_name ("Flag")
		:action_priority (7500)
	)
	: (D_ASSOCIATE
		:AdminInfo (
			:chkpf_uid ("{C8AAF731-6873-43e1-9658-7EBE31FC2C65}")
			:ClassName (log_action_object)
			:Table (log_actions)
			:LastModified (
				:Time ("Tue Apr 11 16:19:00 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (37)
		:action_name ("authcrypt")
		:action_priority (120000)
	)
	: (D_DISASSOCIATE
		:AdminInfo (
			:chkpf_uid ("{8E3EC02A-1664-419e-8168-6276ED726B0C}")
			:ClassName (log_action_object)
			:Table (log_actions)
			:LastModified (
				:Time ("Tue Apr 11 16:19:00 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (38)
		:action_name ("logout")
		:action_priority (125000)
	)
	: (D_ASSOCIATE_FAILED
		:AdminInfo (
			:chkpf_uid ("{7E616269-1352-494f-B5A9-13CA7EC59EA4}")
			:ClassName (log_action_object)
			:Table (log_actions)
			:LastModified (
				:Time ("Mon Jul 16 16:19:00 2012")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (57)
		:action_name ("authcrypt_failed")
		:action_priority (127000)
	)
	: (D_DISCARD
		:AdminInfo (
			:chkpf_uid ("{7C188589-954F-44d0-80F6-BE89547ECD08}")
			:ClassName (log_action_object)
			:Table (log_actions)
			:LastModified (
				:Time ("Tue Apr 11 16:19:00 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (39)
		:action_name ("discard")
		:action_priority (130000)
	)
	: (D_SEND
		:AdminInfo (
			:chkpf_uid ("{1D587B1D-45E2-4373-8BED-D5164A5BB788}")
			:ClassName (log_action_object)
			:Table (log_actions)
			:LastModified (
				:Time ("Tue Apr 11 16:19:00 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (40)
		:action_name ("send")
		:action_priority (135000)
	)
	: (D_EXPIRED
		:AdminInfo (
			:chkpf_uid ("{50AC3FE3-905F-4d8b-AA3B-4F0E5594BE65}")
			:ClassName (log_action_object)
			:Table (log_actions)
			:LastModified (
				:Time ("Tue Apr 11 16:19:00 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (41)
		:action_name ("expired")
		:action_priority (140000)
	)
	: (D_PREVENT
		:AdminInfo (
			:chkpf_uid ("{CE223E92-E787-4115-A428-0D191F8ADFDD}")
			:ClassName (log_action_object)
			:Table (log_actions)
			:LastModified (
				:Time ("Tue Apr 11 16:19:00 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (42)
		:action_name ("prevent")
		:action_priority (145000)
	)
	: (D_ALLOW
		:AdminInfo (
			:chkpf_uid ("{139BBCAE-5A4C-45a2-88FA-AEA6F2A84CEE}")
			:ClassName (log_action_object)
			:Table (log_actions)
			:LastModified (
				:Time ("Tue Apr 11 16:19:00 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (43)
		:action_name ("allow")
		:action_priority (106000)
	)
	: (D_INFORM
		:AdminInfo (
			:chkpf_uid ("{D942B8B8-1FCA-4a4d-B55E-22F1E534622F}")
			:ClassName (log_action_object)
			:Table (log_actions)
			:LastModified (
				:Time ("Tue Apr 11 16:19:00 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (44)
		:action_name ("inform")
		:action_priority (155000)
	)
	: (D_DELETE
		:AdminInfo (
			:chkpf_uid ("{59265FE1-8A65-40da-A59C-85924172B005}")
			:ClassName (log_action_object)
			:Table (log_actions)
			:LastModified (
				:Time ("Tue Apr 11 16:19:00 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (45)
		:action_name ("delete")
		:action_priority (160000)
	)
	: (D_ASK
		:AdminInfo (
			:chkpf_uid ("{CB8607D2-BD22-433d-BAF2-BF08D39591C6}")
			:ClassName (log_action_object)
			:Table (log_actions)
			:LastModified (
				:Time ("Tue Apr 11 16:19:00 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (46)
		:action_name ("ask")
		:action_priority (165000)
	)
	: (D_REVIEW
		:AdminInfo (
			:chkpf_uid ("{C399BBB6-7F48-4220-956F-073CBED94FD3}")
			:ClassName (log_action_object)
			:Table (log_actions)
			:LastModified (
				:Time ("Tue Apr 11 16:19:00 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (47)
		:action_name ("review")
		:action_priority (170000)
	)
	: (D_IP_CHANGED
		:AdminInfo (
			:chkpf_uid ("{2BD761F0-05B3-4022-8FFE-25316504ED2C}")
			:ClassName (log_action_object)
			:Table (log_actions)
			:LastModified (
				:Time ("Tue Apr 11 16:19:00 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (48)
		:action_name ("ip changed")
		:action_priority (175000)
	)
	: (D_PACKET_TAGGING
		:AdminInfo (
			:chkpf_uid ("{7A983B9A-F668-48f5-86C6-E5798ECCC799}")
			:ClassName (log_action_object)
			:Table (log_actions)
			:LastModified (
				:Time ("Tue Apr 11 16:19:00 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (49)
		:action_name ("packet tagging")
		:action_priority (180000)
	)
	: (D_REDIRECT
		:AdminInfo (
			:chkpf_uid ("{7AA44B6B-882E-403B-9B59-6A3D121CB83D}")
			:ClassName (log_action_object)
			:Table (log_actions)
			:LastModified (
				:Time ("Mon Nov 1 16:19:00 2010")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (50)
		:action_name ("redirect")
		:action_priority (104000)
	)
	: (D_HTTPS_INSPECT
		:AdminInfo (
			:chkpf_uid ("{C71E2E69-0801-4575-A1BE-73A59DBFC85E}")
			:ClassName (log_action_object)
			:Table (log_actions)
			:LastModified (
				:Time ("Mon Nov 1 16:19:00 2010")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (51)
		:action_name ("HTTPS Inspect")
		:action_priority (100000)
	)
	: (D_HTTPS_BYPASS
		:AdminInfo (
			:chkpf_uid ("{C20F18F2-9360-4007-B624-76A9B93CD39F}")
			:ClassName (log_action_object)
			:Table (log_actions)
			:LastModified (
				:Time ("Mon Nov 1 16:19:00 2010")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (52)
		:action_name ("HTTPS Bypass")
		:action_priority (95000)
	)
	: (D_UPDATE
		:AdminInfo (
			:chkpf_uid ("{3B8DF0FA-E673-413D-9800-EA55DDD92071}")
			:ClassName (log_action_object)
			:Table (log_actions)
			:LastModified (
				:Time ("Mon Nov 1 16:19:00 2011")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (54)
		:action_name ("update")
		:action_priority (121000)
	)
	: (D_REMOTE_WIPE
		:AdminInfo (
			:chkpf_uid ("{B5C096A5-7F3A-477C-A8D2-FBE0443BFB24}")
			:ClassName (log_action_object)
			:Table (log_actions)
			:LastModified (
				:Time ("Mon Nov 1 16:19:00 2011")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (58)
		:action_name ("remote_wipe")
		:action_priority (121000)
	)
	: (D_RESET_PASSCODE
		:AdminInfo (
			:chkpf_uid ("{2C396CCD-5567-4BAF-ADD3-FDC0F058316D}")
			:ClassName (log_action_object)
			:Table (log_actions)
			:LastModified (
				:Time ("Mon Nov 1 16:19:00 2011")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (59)
		:action_name ("reset_passcode")
		:action_priority (121000)
	)
	: (D_FORGOT_PASSCODE
		:AdminInfo (
			:chkpf_uid ("{05B58D87-502E-4880-9C41-DC1527A02614}")
			:ClassName (log_action_object)
			:Table (log_actions)
			:LastModified (
				:Time ("Mon Nov 1 16:19:00 2011")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:action_code (60)
		:action_name ("forgot_passcode")
		:action_priority (121000)
	)	
)

(
	:version (6.0)
	: (local_time
		:field_name (local_time)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:translation_rules ()
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (timestmp_local)
				:Uid ("{63EB0125-73BB-4653-8BE8-1084250A0067}")
			)
			:filter_CLSID ()
		)
	)
	: (number
		:field_name (num)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (none)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (none)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (none)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (HeaderDateHour
		:field_name (HeaderDateHour)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (none)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (none)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (none)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (HeaderDateHour)
				:Uid ("{04FC15CC-C956-409F-A425-DBFC0A89D1C5}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (port_svc
		:field_name (port_svc)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (none)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (svc)
				:Uid ("{DD9801D9-4834-4C1F-81E2-529EEA2781DF}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (Date_field
		:field_name (Date)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (Date_type)
				:Uid ("{C34D93BA-5AA6-4DEA-8F21-0571BC614F1D}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (hour
		:field_name (hour)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (Hour)
				:Uid ("{FBC8FE6F-B338-4F49-8ED3-C2C061931E4A}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (interface_field
		:field_name (interface)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (Interface_type)
				:Uid ("{73716DB6-8A96-4D5F-A312-B38E12818274}")
			)
			:filter_CLSID ()
			:translation_rules (
				: (
					:display_value (In)
					:log_value (inbound)
				)
				: (
					:display_value (Out)
					:log_value (outbound)
				)
				: (
					:display_value (Both)
					:log_value (both)
				)
			)
		)
	)
	: (Origin
		:field_name (Origin)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (none)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (none)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (Origin)
				:Uid ("{960B2585-5477-4EE8-A59E-5B1B37B5D237}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (field_Type
		:field_name (type)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (type)
				:Uid ("{23A03F3C-475D-4617-A1D6-FE3E158EFE35}")
			)
			:filter_CLSID ()
			:translation_rules (
				: (
					:display_value (Alert)
					:log_value (alert)
				)
				: (
					:display_value (Log)
					:log_value (log)
				)
				: (
					:display_value (Control)
					:log_value (control)
				)
				: (
					:display_value (Account)
					:log_value (account)
				)
				: (
					:display_value ("System Alert")
					:log_value ("sys alert")
				)
			)
		)
	)
	: (Action
		:field_name (Action)
		:server_definitions (
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (actioncode)
				:Uid ("{9DA04A60-E263-4171-A889-A620A167C130}")
			)
			:filter_CLSID ()
			:translation_rules (
				: (
					:display_value (Accept)
					:log_value (accept)
				)
				: (
					:display_value (Drop)
					:log_value (drop)
				)
				: (
					:display_value (Reject)
					:log_value (reject)
				)
				: (
					:display_value (Encrypt)
					:log_value (encrypt)
				)
				: (
					:display_value (Decrypt)
					:log_value (decrypt)
				)
				: (
					:display_value ("Key Install")
					:log_value (keyinst)
				)
				: (
					:display_value (Authorize)
					:log_value (authorize)
				)
				: (
					:display_value (Deauthorize)
					:log_value (deauthorize)
				)
				: (
					:display_value ("VPN Routing")
					:log_value (vpnroute)
				)
				: (
					:display_value (Block)
					:log_value (block)
				)
				: (
					:display_value (Quarantine)
					:log_value (quarantine)
				)
				: (
					:display_value (Inspect)
					:log_value (inspect)
				)
				: (
					:display_value (Bypass)
					:log_value (bypass)
				)
				: (
					:display_value (Detect)
					:log_value (monitor)
				)
				: (
					:display_value ("Replace Malicious Code")
					:log_value (mcreplace)
				)
				: (
					:display_value (Detect)
					:log_value (34)
				)
				: (
					:display_value ("Log In")
					:log_value (authcrypt)
				)
				: (
					:display_value ("Log Out")
					:log_value (logout)
				)
				: (
					:display_value ("Failed Log In")
					:log_value (authcrypt_failed)
				)
				: (
					:display_value ("Do not send")
					:log_value (discard)
				)
				: (
					:display_value ("Send")
					:log_value (send)
				)
				: (
					:display_value ("Quarantine Expired")
					:log_value (expired)
				)
				: (
					:display_value (Prevent)
					:log_value (prevent)
				)
				: (
					:display_value (Allow)
					:log_value (allow)
				)
				: (
					:display_value ("Inform User")
					:log_value (inform)
				)
				: (
					:display_value ("Deleted Due To Quota")
					:log_value (delete)
				)
				: (
					:display_value ("Ask User")
					:log_value (ask)
				)
				: (
					:display_value ("Incident Reviewed")
					:log_value (review)
				)
				: (
					:display_value ("IP Changed")
					:log_value ("ip changed")
				)
				: (
					:display_value ("Packet Tagging Key Exchange")
					:log_value ("packet tagging")
				)
				: (
					:display_value ("Redirect")
					:log_value ("redirect")
				)
				: (
					:display_value ("HTTPS Inspect")
					:log_value ("HTTPS Inspect")
				)
				: (
					:display_value ("HTTPS Bypass")
					:log_value ("HTTPS Bypass")
				)
				: (
					:display_value (Update)
					:log_value (update)
				)
                                : (
					:display_value ("Remote Wipe")
					:log_value (remote_wipe)
				)
                : (
					:display_value ("Reset Passcode")
					:log_value (reset_passcode)
				)
                : (
					:display_value ("Forgot Passcode")
					:log_value (forgot_passcode)
				)				
			)
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (none)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
		)
	)
	: (svc
		:field_name (svc)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (svc)
				:Uid ("{DD9801D9-4834-4C1F-81E2-529EEA2781DF}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (SPort_Svc
		:field_name (SPort_Svc)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (svc)
				:Uid ("{DD9801D9-4834-4C1F-81E2-529EEA2781DF}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (Src_field
		:field_name (Src)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (ipaddr)
				:Uid ("{7659019C-4DFE-4D8C-B5E0-0B3590E4047E}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (Dst_field
		:field_name (Dst)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (ipaddr)
				:Uid ("{7659019C-4DFE-4D8C-B5E0-0B3590E4047E}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (Proto
		:field_name (Proto)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (proto)
				:Uid ("{DE854063-BF6C-4738-A7CB-96638875F976}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (Rule
		:field_name (Rule)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (rule)
				:Uid ("{65215788-6518-4733-A878-E0573F873F48}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (rule_uid
		:field_name (rule_uid)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (rule_name
		:field_name (rule_name)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (mixedstrandid)
				:Uid ("{B179E0DD-5E2F-4FDF-AA30-E51F52C42430}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (normalized_rule_num
		:field_name (normalized_rule_num)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (normalized_rule_num)
				:Uid ("{6E36C7F7-B948-4992-A152-FFAB6E12DBFA}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (NAT_rulenum
		:field_name (NAT_rulenum)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (rule)
				:Uid ("{65215788-6518-4733-A878-E0573F873F48}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (NAT_addtnl_rulenum
		:field_name (NAT_addtnl_rulenum)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (rule)
				:Uid ("{65215788-6518-4733-A878-E0573F873F48}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (User_field
		:field_name (User)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ("{A569C4C7-5E64-4ACF-AC22-AB214ECDE34C}")
			:translation_rules ()
			:permissions (4)
		)
	)
	: (XlateSrc_field
		:field_name (XlateSrc)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (ipaddr)
				:Uid ("{7659019C-4DFE-4D8C-B5E0-0B3590E4047E}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (XlateDst_field
		:field_name (XlateDst)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (ipaddr)
				:Uid ("{7659019C-4DFE-4D8C-B5E0-0B3590E4047E}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (XlateSPort_Svc
		:field_name (XlateSPort_Svc)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (svc)
				:Uid ("{DD9801D9-4834-4C1F-81E2-529EEA2781DF}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (XlateDPort_Svc
		:field_name (XlateDPort_Svc)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (svc)
				:Uid ("{DD9801D9-4834-4C1F-81E2-529EEA2781DF}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (partner
		:field_name (partner)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (Community
		:field_name (Community)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (Session_Id
		:field_name (Session_Id)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (reject_category
		:field_name (reject_category)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (reject_id
		:field_name (reject_id)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (Info
		:field_name (Info)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ("{347247A4-84D0-4235-9F6B-F4582025958B}")
			:translation_rules ()
		)
	)
	: (ipv6_dst
		:field_name (ipv6_dst)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (ipv6addr)
				:Uid ("{E14BC9EA-DC1E-4D89-BC5C-BC8ABDDE8EE9}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (ipv6_src
		:field_name (ipv6_src)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (ipv6addr)
				:Uid ("{E14BC9EA-DC1E-4D89-BC5C-BC8ABDDE8EE9}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (srckeyid
		:field_name (srckeyid)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (dstkeyid
		:field_name (dstkeyid)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (scheme_field
		:field_name ("scheme:")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules (
				: (
					:display_value (IKE)
					:log_value (IKE)
				)
				: (
					:display_value (FWZ)
					:log_value (FWZ)
				)
				: (
					:display_value (L2TP)
					:log_value (L2TP)
				)
			)
		)
	)
	: (methods_field
		:field_name ("methods:")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (CookieI
		:field_name (CookieI)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (CookieR
		:field_name (CookieR)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (msgid
		:field_name (msgid)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (peer_gateway
		:field_name ("peer gateway")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (ipaddr)
				:Uid ("{7659019C-4DFE-4D8C-B5E0-0B3590E4047E}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (fw_subproduct
		:field_name (fw_subproduct)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules (
				: (
					:display_value (VPN)
					:log_value (VPN-1)
				)
			)
		)
	)
	: (vpn_feature_name
		:field_name (vpn_feature_name)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (elapsed
		:field_name (elapsed)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (time)
				:Uid ("{7909CC04-892B-4520-A6A4-DC9CDEBD8465}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (bytes
		:field_name (bytes)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (packets
		:field_name (packets)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (start_time
		:field_name (start_time)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (timestmp)
				:Uid ("{30AC2230-69B0-4F99-874C-0BE46C1AAA07}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (client_inbound_interface
		:field_name (client_inbound_interface)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (client_outbound_interface
		:field_name (client_outbound_interface)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (server_inbound_interface
		:field_name (server_inbound_interface)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (server_outbound_interface
		:field_name (server_outbound_interface)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (client_inbound_bytes
		:field_name (client_inbound_bytes)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (client_outbound_bytes
		:field_name (client_outbound_bytes)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (server_outbound_bytes
		:field_name (server_outbound_bytes)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (server_inbound_bytes
		:field_name (server_inbound_bytes)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (client_inbound_packets
		:field_name (client_inbound_packets)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (client_outbound_packets
		:field_name (client_outbound_packets)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (server_inbound_packets
		:field_name (server_inbound_packets)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (server_outbound_packets
		:field_name (server_outbound_packets)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (client_inbound_diffserv
		:field_name (client_inbound_diffserv)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (client_outbound_diffserv
		:field_name (client_outbound_diffserv)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (server_inbound_diffserv
		:field_name (server_inbound_diffserv)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (server_outbound_diffserv
		:field_name (server_outbound_diffserv)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (fg-1_client_in_rule_name
		:field_name (fg-1_client_in_rule_name)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (fg-1_client_out_rule_name
		:field_name (fg-1_client_out_rule_name)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (fg-1_server_in_rule_name
		:field_name (fg-1_server_in_rule_name)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (fg-1_server_out_rule_name
		:field_name (fg-1_server_out_rule_name)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (fg-1_sub_service
		:field_name (fg-1_sub_service)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (src_phone_number
		:field_name ("src phone number")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (dst_phone_number
		:field_name ("dst phone number")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (media_type
		:field_name ("media type")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (Registered_IP_phones
		:field_name ("Registered IP-phones")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (snid
		:field_name (snid)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (ua_snid
		:field_name (ua_snid)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (d_name
		:field_name (d_name)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (id_src
		:field_name (id_src)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules (
				: (
					:display_value ("VPN SC")
					:log_value ("VPN-1 SC")
				)
				: (
					:display_value ("UA SecureAngent")
					:log_value ("UA SecureAngent")
				)
				: (
					:display_value ("UA WebAccess")
					:log_value ("UA WebAccess")
				)
				: (
					:display_value ("FW-1 Client Auth")
					:log_value ("FW-1 Client Auth")
				)
				: (
					:display_value (Other)
					:log_value (Other)
				)
			)
		)
	)
	: (ua_operation
		:field_name (ua_operation)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (sso_type_desc
		:field_name (sso_type_desc)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (appi_name
		:field_name (appi_name)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (mixedobfstrandid)
				:Uid ("{4DEE2C65-B31D-4fdf-B22C-43E547D2B2E8}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (18)
		)
	)
	: (auth_domain
		:field_name (auth_domain)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (uname4domain
		:field_name (uname4domain)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (wa_headers
		:field_name (wa_headers)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (result_desc
		:field_name (result_desc)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (r_dest
		:field_name (r_dest)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (ipaddr)
				:Uid ("{7659019C-4DFE-4D8C-B5E0-0B3590E4047E}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (comment
		:field_name (comment)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (url
		:field_name (url)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (redirect_url
		:field_name (redirect_url)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (enc_desc
		:field_name (enc_desc)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules (
				: (
					:display_value ("not encrypted")
					:log_value ("not encrypted")
				)
				: (
					:display_value (VPN)
					:log_value (VPN-1)
				)
				: (
					:display_value (SSL)
					:log_value (SSL)
				)
			)
		)
	)
	: (e2e_enc_desc
		:field_name (e2e_enc_desc)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules (
				: (
					:display_value (Unknown)
					:log_value (unknown)
				)
				: (
					:display_value (False)
					:log_value (false)
				)
				: (
					:display_value (True)
					:log_value (true)
				)
			)
		)
	)
	: (auth_result
		:field_name (auth_result)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules (
				: (
					:display_value (Accept)
					:log_value (Accept)
				)
				: (
					:display_value (Reject)
					:log_value (Reject)
				)
				: (
					:display_value (Authenticate)
					:log_value (Authenticate)
				)
				: (
					:display_value (Redirect)
					:log_value (Redirect)
				)
				: (
					:display_value ("Redirect to SSL")
					:log_value ("Redirect to ssl")
				)
			)
		)
	)
	: (sample_id
		:field_name (sample_id)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (estimation
		:field_name (estimation)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (wire_byte_ps_in
		:field_name (wire_byte_ps_in)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (wire_byte_ps_out
		:field_name (wire_byte_ps_out)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (wire_pack_ps_in
		:field_name (wire_pack_ps_in)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (wire_pack_ps_out
		:field_name (wire_pack_ps_out)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (app_byte_ps_in
		:field_name (app_byte_ps_in)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (app_byte_ps_out
		:field_name (app_byte_ps_out)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (app_pack_ps_in
		:field_name (app_pack_ps_in)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (app_pack_ps_out
		:field_name (app_pack_ps_out)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (src_gw
		:field_name (src_gw)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (ipaddr)
				:Uid ("{7659019C-4DFE-4D8C-B5E0-0B3590E4047E}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (dst_gw
		:field_name (dst_gw)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (ipaddr)
				:Uid ("{7659019C-4DFE-4D8C-B5E0-0B3590E4047E}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (rtt
		:field_name (rtt)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (rtt_threshold
		:field_name (rtt_threshold)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (bw_loss
		:field_name (bw_loss)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (bw_loss_threshold
		:field_name (bw_loss_threshold)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (cir
		:field_name (cir)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (cir_threshold
		:field_name (cir_threshold)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (sla_violation
		:field_name (sla_violation)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (vl
		:field_name (vl)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (status
		:field_name (status)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (tid
		:field_name (tid)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
        : (user_status
		:field_name (user_status)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (24)
		)
	)
     : (portal_message
			:field_name (portal_message)
			:server_definitions (
				:display_mode (
					: (
						:application_display_mode (own_column)
						:application_name (SmartViewTracker)
					)
					: (
						:application_display_mode (own_column)
						:application_name (FWLog)
					)
					: (
						:application_display_mode (own_column)
						:application_name (FWMLogExport)
					)
				)
				:field_type (ReferenceObject
					:Table (log_field_server_types)
					:Name (string)
					:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
				)
				:filter_CLSID ()
				:translation_rules ()
				:permissions (28)
			)
		)
	: (session_uid
		:field_name (session_uid)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (guid)
				:Uid ("{2F237A9A-44B3-459B-B3AD-B2C384E1899B}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (login_timestamp
		:field_name (login_timestamp)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (timestmp)
				:Uid ("{30AC2230-69B0-4F99-874C-0BE46C1AAA07}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (UserCheck_Interaction_name
		:field_name (UserCheck_Interaction_name)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (24)
		)
	)	 
	: (UserCheck_UserInput
		:field_name (UserCheck_UserInput)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (24)
		)
	)
	: (matched_category
		:field_name (matched_category)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (obf_string_id)
				:Uid ("{9E5C40C7-3139-455C-A9D5-2E998805673F}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (18)
		)
	)		
		: (UserCheck
				:field_name (UserCheck)
				:server_definitions (
					:display_mode (
						: (
					:application_display_mode (own_column)
							:application_name (SmartViewTracker)
						)
						: (
					:application_display_mode (own_column)
							:application_name (FWLog)
						)
						: (
					:application_display_mode (own_column)
							:application_name (FWMLogExport)
						)
					)
					:field_type (ReferenceObject
						:Table (log_field_server_types)
						:Name (uint)
						:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
					)
					:filter_CLSID ()
					:translation_rules ()
					:permissions (24)
				)
			)
			: (UserCheck_incident_uid
					:field_name (UserCheck_incident_uid)
					:server_definitions (
						:display_mode (
							: (
								:application_display_mode (own_column)
								:application_name (SmartViewTracker)
							)
							: (
								:application_display_mode (own_column)
								:application_name (FWLog)
							)
							: (
								:application_display_mode (own_column)
								:application_name (FWMLogExport)
							)
						)
						:field_type (ReferenceObject
							:Table (log_field_server_types)
							:Name (guid)
							:Uid ("{2F237A9A-44B3-459B-B3AD-B2C384E1899B}")
						)
						:filter_CLSID ()
						:translation_rules ()
					)
	)
	: (ms_isdn
		:field_name (ms_isdn)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (apn
		:field_name (apn)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (signal_type
		:field_name (signal_type)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (end_user_address
		:field_name (end_user_address)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (ipaddr)
				:Uid ("{7659019C-4DFE-4D8C-B5E0-0B3590E4047E}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (sgsn_signal
		:field_name (sgsn_signal)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (ipaddr)
				:Uid ("{7659019C-4DFE-4D8C-B5E0-0B3590E4047E}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (sgsn_traffic
		:field_name (sgsn_traffic)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (ipaddr)
				:Uid ("{7659019C-4DFE-4D8C-B5E0-0B3590E4047E}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (ggsn_signal
		:field_name (ggsn_signal)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (ipaddr)
				:Uid ("{7659019C-4DFE-4D8C-B5E0-0B3590E4047E}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (ggsn_traffic
		:field_name (ggsn_traffic)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (ipaddr)
				:Uid ("{7659019C-4DFE-4D8C-B5E0-0B3590E4047E}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (selection_mode
		:field_name (selection_mode)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (gtp_ver
		:field_name (gtp_ver)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (nsapi
		:field_name (nsapi)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (linked_nsapi
		:field_name (linked_nsapi)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (teid_dnlink
		:field_name (teid_dnlink)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (hex)
				:Uid ("{D0900A0C-37E0-4DCA-A24F-D59EEBA9AE75}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (teid_uplink
		:field_name (teid_uplink)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (hex)
				:Uid ("{D0900A0C-37E0-4DCA-A24F-D59EEBA9AE75}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (mobile_country_code
		:field_name (mobile_country_code)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (mobile_network_code
		:field_name (mobile_network_code)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (mobile_subscriber_code
		:field_name (mobile_subscriber_code)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (end_user_address_ipv6
		:field_name (end_user_address_ipv6)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (ipv6addr)
				:Uid ("{E14BC9EA-DC1E-4D89-BC5C-BC8ABDDE8EE9}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (rat_type
		:field_name (rat_type)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (user_location
		:field_name (user_location)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (time_zone
		:field_name (time_zone)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (imei
		:field_name (imei)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (attack
		:field_name (attack)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (mixedstrandid)
				:Uid ("{B179E0DD-5E2F-4FDF-AA30-E51F52C42430}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (Attack_Info
		:field_name ("Attack Info")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (mixedstrandid)
				:Uid ("{B179E0DD-5E2F-4FDF-AA30-E51F52C42430}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (active_conn_elapsed
		:field_name (active_conn_elapsed)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (time)
				:Uid ("{7909CC04-892B-4520-A6A4-DC9CDEBD8465}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (command_field
		:field_name ("command:")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (ObjectName
		:field_name (ObjectName)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (ObjectTable
		:field_name (ObjectTable)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (ObjectType
		:field_name (ObjectType)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (Operation
		:field_name (Operation)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (Uid
		:field_name (Uid)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (Administrator
		:field_name (Administrator)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (Machine
		:field_name (Machine)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (FieldsChanges
		:field_name (FieldsChanges)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (ContainerChanges
		:field_name (ContainerChanges)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (Additional_Info
		:field_name ("Additional Info")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (Subject
		:field_name (Subject)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (Audit_Status
		:field_name ("Audit Status")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (Operation_Number
		:field_name ("Operation Number")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (scan_direction
		:field_name ("scan direction")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (mixedstrandid)
				:Uid ("{B179E0DD-5E2F-4FDF-AA30-E51F52C42430}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (scan_result
		:field_name ("scan result")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (mixedstrandid)
				:Uid ("{B179E0DD-5E2F-4FDF-AA30-E51F52C42430}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (virus_name
		:field_name ("virus name")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (data_origin
		:field_name ("data origin")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (update_src
		:field_name (update_src)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (Update_Status
		:field_name ("Update Status")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules (
				: (
					:display_value (Failed)
					:log_value (failed)
				)
				: (
					:display_value (Updated)
					:log_value (updated)
				)
			)
		)
	)
	: (sig_ver
		:field_name (sig_ver)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (subs_exp
		:field_name (subs_exp)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (file_type
		:field_name (file_type)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (mixedstrandid)
				:Uid ("{B179E0DD-5E2F-4FDF-AA30-E51F52C42430}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (spyware_name
		:field_name (spyware_name)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (spyware_type
		:field_name (spyware_type)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (version
		:field_name (version)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (mixedstrandid)
				:Uid ("{B179E0DD-5E2F-4FDF-AA30-E51F52C42430}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (event_type
		:field_name (event_type)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules (
				: (
					:display_value (Firewall)
					:log_value (firewall)
				)
				: (
					:display_value ("Malicious Code Protection")
					:log_value ("malicious code")
				)
				: (
					:display_value (Anti-spyware)
					:log_value (spyware)
				)
				: (
					:display_value (Mailsafe)
					:log_value (mailsafe)
				)
				: (
					:display_value ("Client Error")
					:log_value ("client error")
				)
				: (
					:display_value (Application)
					:log_value (application)
				)
				: (
					:display_value ("Compliance Violation")
					:log_value ("compliance violation")
				)
				: (
					:display_value ("IM Security")
					:log_value (imsecure)
				)
				: (
					:display_value (Antivirus)
					:log_value (antivirus)
				)
				: (
					:display_value (SmartDefense)
					:log_value (smartdefense)
				)
				: (
					:display_value ("Log In")
					:log_value ("Login")
				)
				: (
					:display_value ("Log Out")
					:log_value ("Logout")
				)
				: (
					:display_value ("Authentication Failed")
					:log_value ("Authentication Failure")
				)
				: (
					:display_value ("Policy Update")
					:log_value ("Policy Update")
				)
				: (
					:display_value ("Scan Start")
					:log_value ("Scan Start")
				)
				: (
					:display_value ("Scan Stop")
					:log_value ("Scan Stop")
				)
				: (
					:display_value (Infection)
					:log_value (Infection)
				)
				: (
					:display_value (Update)
					:log_value (Update)
				)
				: (
					:display_value ("Status Changed")
					:log_value ("Status Changed")
				)
				: (
					:display_value (Remediation)
					:log_value (Remediation)
				)
				: (
					:display_value (Account)
					:log_value (Account)
				)
				: (
					:display_value (Status)
					:log_value (Status)
				)
				: (
					:display_value (Traffic)
					:log_value (Firewall)
				)
				: (
					:display_value ("Application Control")
					:log_value ("Application Control")
				)
				: (
					:display_value (MEPP)
					:log_value (MEPP)
				)
				: (
					:display_value ("RMM Audit")
					:log_value ("RMM Audit")
				)
				: (
					:display_value ("Device Manager")
					:log_value ("Device Manager")
				)
				: (
					:display_value ("Phishing Site DB")
					:log_value ("Phish Site DB")
				)
				: (
					:display_value ("File Download")
					:log_value ("File Download")
				)
				: (
					:display_value ("Site Visit")
					:log_value ("Site Visit")
				)
				: (
					:display_value ("Protection Suspend")
					:log_value ("Protection Suspend")
				)
				: (
					:display_value ("Media Encryption Policy Update")
					:log_value ("ME Policy Update")
				)
				: (
					:display_value ("User Check")
					:log_value ("User Check")
				)
				: (
					:display_value ("File Operation")
					:log_value ("File Operation")
				)
				: (
					:display_value ("Authorization")
					:log_value ("Authorization")
				)
				: (
					:display_value ("Infection State Change")
					:log_value ("Infection State Change")
				)				
				: (
					:display_value ("Encryption")
					:log_value ("Encryption")
				)	
				: (
					:display_value ("Plug-in")
					:log_value ("Plug-in")
				)
			)
		)
	)
	: (domain_name
		:field_name (domain_name)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (endpoint_id
		:field_name (endpoint_id)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (policy_name
		:field_name (policy_name)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (user_directory
		:field_name (user_directory)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (user_group
		:field_name (user_group)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ("{4B521F43-33F4-47D0-9F86-84FF989D2708}")
			:translation_rules ()
			:permissions (4)
		)
	)
	: (policy_id_tag
		:field_name (__policy_id_tag)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (none)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (none)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (time
		:field_name (time)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (none)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (none)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (none)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (timestmp)
				:Uid ("{30AC2230-69B0-4F99-874C-0BE46C1AAA07}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (service
		:field_name (service)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (none)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (none)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (none)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (int)
				:Uid ("{91694BE7-D52D-474E-A565-635734A73B22}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (xlatesport_field
		:field_name (xlatesport)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (none)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (none)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (none)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (port)
				:Uid ("{19882316-BC4C-4BD0-BDE3-C8512915EDA8}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (xlatedport_field
		:field_name (xlatedport)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (none)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (none)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (none)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (port)
				:Uid ("{19882316-BC4C-4BD0-BDE3-C8512915EDA8}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (port
		:field_name (port)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (none)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (none)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (none)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (int)
				:Uid ("{91694BE7-D52D-474E-A565-635734A73B22}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (s_port
		:field_name (s_port)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (none)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (none)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (none)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (port)
				:Uid ("{19882316-BC4C-4BD0-BDE3-C8512915EDA8}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (flags
		:field_name (flags)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (none)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (none)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (int)
				:Uid ("{91694BE7-D52D-474E-A565-635734A73B22}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (InterfaceName
		:field_name (InterfaceName)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (none)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (none)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (InterfaceDir
		:field_name (InterfaceDir)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (none)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (none)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (ifdircode)
				:Uid ("{1C60F626-5A79-4C37-AA89-B42E590A0E4A}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (product
		:field_name (product)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (none)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (none)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (none)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (mixedstrandid)
				:Uid ("{B179E0DD-5E2F-4FDF-AA30-E51F52C42430}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (service_name
		:field_name (service_name)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (none)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (none)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (service)
				:Uid ("{8435A6DC-95D9-4C8A-ACE1-9FD6EB2BDE0B}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (uuid
		:field_name (uuid)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (none)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (none)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (luuid)
				:Uid ("{3B08D5EE-F647-45F4-B746-09122A8624A1}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (alert_field
		:field_name (alert)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (none)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (none)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (category
		:field_name (category)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (none)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (none)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (none)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (mask)
				:Uid ("{85697092-C651-4C9D-B1F7-C549D6EDCD02}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (DCE_RPC_Interface_UID
		:field_name ("DCE-RPC Interface UID")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (info_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (DCE_RPC_Interface_UID)
				:Uid ("{9F7C4CEF-3533-4E56-AD38-B2B39FB9542B}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (DCE_RPC_Interface_UUID
		:field_name ("DCE-RPC Interface UUID")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (none)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (none)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (none)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uuid)
				:Uid ("{91878CF4-C005-4D93-BFB6-2F2FBCFE2E8F}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (DCE_RPC_Interface_UUID_1
		:field_name ("DCE-RPC Interface UUID-1")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (none)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (none)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (none)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uuid)
				:Uid ("{91878CF4-C005-4D93-BFB6-2F2FBCFE2E8F}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (DCE_RPC_Interface_UUID_2
		:field_name ("DCE-RPC Interface UUID-2")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (none)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (none)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (none)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uuid)
				:Uid ("{91878CF4-C005-4D93-BFB6-2F2FBCFE2E8F}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (DCE_RPC_Interface_UUID_3
		:field_name ("DCE-RPC Interface UUID-3")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (none)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (none)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (none)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uuid)
				:Uid ("{91878CF4-C005-4D93-BFB6-2F2FBCFE2E8F}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (OriginIP
		:field_name (OriginIP)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (none)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (none)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (ipaddr)
				:Uid ("{7659019C-4DFE-4D8C-B5E0-0B3590E4047E}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (origin_sic_name
		:field_name (origin_sic_name)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (none)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (none)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (none)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (UfpCategory
		:field_name (UfpCategory)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (none)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (UfpCategory)
				:Uid ("{9A8EB15F-DBDE-40C3-8499-8D003A686F55}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (OriginSicName
		:field_name (OriginSicName)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (none)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:filter_CLSID ()
			:translation_rules ()
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (OriginSicName)
				:Uid ("{68A0EE25-DD41-40B5-904A-951CCE0D53DD}")
			)
		)
	)
	: (ProductName_audit
		:field_name (ProductNameInAuditMode)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (ProductName)
				:Uid ("{1A8994C5-1A16-4CDC-9653-AB2E0881909D}")
			)
			:filter_CLSID ()
			:translation_rules (
				: (
					:display_value ("SmartEvent Server")
					:log_value ("Eventia Analyzer Server")
				)
				: (
					:display_value ("SmartEvent Client")
					:log_value ("Eventia Analyzer Client")
				)
				: (
					:display_value ("SmartReporter Generator")
					:log_value ("Eventia Reporter Generator")
				)
				: (
					:display_value ("SmartReporter Server")
					:log_value ("Eventia Reporter Server")
				)
				: (
					:display_value ("SmartReporter Client")
					:log_value ("Eventia Reporter Client")
				)
				: (
					:display_value ("SmartReporter Log Consolidator")
					:log_value ("Eventia Reporter Log Consolidator")
				)
				: (
					:display_value ("Security Management Server")
					:log_value ("SmartCenter Server")
				)
				: (
					:display_value ("SmartProvisioning")
					:log_value ("SmartLSM")
				)
				: (
					:display_value ("Management Portal")
					:log_value ("SmartPortal")
				)
				: (
					:display_value ("Mobile Access")
					:log_value ("Connectra")
				)
				: (
					:display_value ("SmartDomain Manager")
					:log_value ("MDS Client")
				)
				: (
					:display_value ("SmartEvent Intro")
					:log_value ("IPS Event Analysis Client")
				)
				: (
					:display_value ("SmartLog")
					:log_value ("Logs Indexer")
				)
				: (
					:display_value ("SmartLog Server")
					:log_value ("Logs Indexer Server")
				)
			)
		)
	)
	: (ProductName
		:field_name (ProductName)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (ProductName)
				:Uid ("{1A8994C5-1A16-4CDC-9653-AB2E0881909D}")
			)
			:filter_CLSID ()
			:translation_rules (
				: (
					:display_value ("Security Gateway/Management")
					:log_value ("VPN-1 & FireWall-1")
				)
				: (
					:display_value (QoS)
					:log_value (FG)
				)
				: (
					:display_value ("Real-Time Monitor")
					:log_value (rtm)
				)
				: (
					:display_value ("SmartView Monitor")
					:log_value ("SmartView Monitor")
				)
				: (
					:display_value (SecureClient)
					:log_value (SecureClient)
				)
				: (
					:display_value ("UA WebAccess")
					:log_value (WebAccess)
				)
				: (
					:display_value ("UA Server")
					:log_value (UAG)
				)
				: (
					:display_value ("FireWall-1 GX")
					:log_value (Everest)
				)
				: (
					:display_value ("IPS Software Blade")
					:log_value (SmartDefense)
				)
				: (
					:display_value ("UTM-1 Edge")
					:log_value ("VPN-1 Edge")
				)
				: (
					:display_value ("System Monitor")
					:log_value ("System Monitor")
				)
				: (
					:display_value ("VPN Embedded Connector")
					:log_value ("VPN-1 Embedded Connector")
				)
				: (
					:display_value ("Endpoint Security")
					:log_value (Integrity)
				)
				: (
					:display_value ("Policy Server")
					:log_value ("Policy Server")
				)
				: (
					:display_value ("Legacy URL Filtering")
					:log_value ("Web Filtering")
				)
				: (
					:display_value (CVPN)
					:log_value (CVPN)
				)
				: (
					:display_value ("Mobile Access")
					:log_value (Connectra)
				)
				: (
					:display_value ("IPS-1 Sensor")
					:log_value ("IPS-1")
				)
				: (
					:display_value (SmartEvent)
					:log_value ("Eventia Analyzer")
				)
				: (
					:display_value ("DLP")
					:log_value ("DLP")
				)
				: (
					:display_value ("Anti-Bot")
					:log_value ("Anti Malware")
				)
				: (
					:display_value ("Anti-Virus")
					:log_value ("New Anti Virus")
				)
				: (
					:display_value ("Traditional Anti-Virus")
					:log_value ("Anti Virus")
				)
				: (
					:display_value ("DDoS Protector")
					:log_value (DefensePro)
				)
				: (
					:display_value (Core)
					:log_value (Core)
				)
				: (
					:display_value (Compliance)
					:log_value (Compliance)
				)
				: (
					:display_value ("Full Disk Encryption")
					:log_value (FDE)
				)
				: (
					:display_value (MEPP)
					:log_value (MEPP)
				)
				: (
					:display_value (Firewall)
					:log_value (Firewall)
				)
				: (
					:display_value (WebCheck)
					:log_value (WebCheck)
				)
				: (
					:display_value (Server)
					:log_value (Server)
				)
				: (
					:display_value ("Anti-Malware")
					:log_value (Anti-Malware)
				)
				: (
					:display_value ("Application Control")
					:log_value ("Application Control")
				)
			)
		)
	)
	: (categories
		:field_name (categories)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (ticket_id
		:field_name (ticket_id)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (uf_sig_ver
		:field_name (uf_sig_ver)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (reason_web_filtering
		:field_name (reason)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (activity_web_filtering
		:field_name (activity)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (resource_web_filtering
		:field_name (resource)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (16)
		)
	)
	: (pos
		:field_name (__pos)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (none)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (none)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (none)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (int)
				:Uid ("{91694BE7-D52D-474E-A565-635734A73B22}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (nsons
		:field_name (__nsons)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (none)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (none)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (none)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (int)
				:Uid ("{91694BE7-D52D-474E-A565-635734A73B22}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (p_dport
		:field_name (__p_dport)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (none)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (none)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (none)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (port)
				:Uid ("{19882316-BC4C-4BD0-BDE3-C8512915EDA8}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (SmartDefense_profile
		:field_name ("SmartDefense profile")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:translation_rules ()
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
		)
	)
	: (ApplicationIP
		:field_name (application_ip)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (ipaddr)
				:Uid ("{7659019C-4DFE-4D8C-B5E0-0B3590E4047E}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (MachineIP
		:field_name (endpoint_ip)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (ipaddr)
				:Uid ("{7659019C-4DFE-4D8C-B5E0-0B3590E4047E}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (SpywareStatus
		:field_name (spyware_status)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (IMUser
		:field_name (im_userid)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (EndpointSecurityAVMailSender
		:field_name (integrity_av_email_from)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (EndpointSecurityAVMailRecipient
		:field_name (integrity_av_email_to)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (MachineName
		:field_name (endpoint_addr)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (EventCount
		:field_name (event_count)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (ApplicationFileName
		:field_name (file_name)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (ComplianceName
		:field_name (compliance_name)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (IMProtocol
		:field_name (im_protocol)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (mixedstrandid)
				:Uid ("{B179E0DD-5E2F-4FDF-AA30-E51F52C42430}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (EndpointSecurityScanEvent
		:field_name (integrity_av_event)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (EndpointSecurityAVScanType
		:field_name (integrity_av_invoke_type)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules (
				: (
					:display_value (Unknown)
					:log_value (unknown)
				)
				: (
					:display_value (Automatic)
					:log_value (automatic)
				)
				: (
					:display_value ("On-demand")
					:log_value ("on-demand")
				)
				: (
					:display_value ("On-access")
					:log_value ("on-access")
				)
				: (
					:display_value (Scheduled)
					:log_value (scheduled)
				)
			)
		)
	)
	: (ComplianceType
		:field_name (compliance_type)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (mixedstrandid)
				:Uid ("{B179E0DD-5E2F-4FDF-AA30-E51F52C42430}")
			)
			:filter_CLSID ()
			:translation_rules (
				: (
					:display_value ("AV Client")
					:log_value (AV_NONCOMPLIANT)
				)
				: (
					:display_value ("AV DAT Date")
					:log_value (AV_MINDATDATE)
				)
				: (
					:display_value ("AV DAT Version")
					:log_value (AV_MINDATVERS)
				)
				: (
					:display_value ("AV DAT Age")
					:log_value (AV_MAXDATAGE)
				)
				: (
					:display_value ("AV Auto Version")
					:log_value (AV_AUTOVERS)
				)
				: (
					:display_value (Group)
					:log_value (GROUP)
				)
				: (
					:display_value ("Endpoint Security Client")
					:log_value (ZL_COMPLIANCE)
				)
				: (
					:display_value (Anti-Spyware)
					:log_value (SPY_COMPLIANCE)
				)
				: (
					:display_value (Require)
					:log_value (REQUIRE)
				)
				: (
					:display_value (Prohibit)
					:log_value (PROHIBIT)
				)
			)
		)
	)
	: (ComplianceAction
		:field_name (compliance_action)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (mixedstrandid)
				:Uid ("{B179E0DD-5E2F-4FDF-AA30-E51F52C42430}")
			)
			:filter_CLSID ()
			:translation_rules (
				: (
					:display_value (Restrict)
					:log_value (restrict)
				)
				: (
					:display_value (Warn)
					:log_value (warn)
				)
				: (
					:display_value (Observe)
					:log_value (observe)
				)
			)
		)
	)
	: (SpywareAction
		:field_name (spyware_action)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (mixedstrandid)
				:Uid ("{B179E0DD-5E2F-4FDF-AA30-E51F52C42430}")
			)
			:filter_CLSID ()
			:translation_rules (
				: (
					:display_value (Found)
					:log_value (found)
				)
				: (
					:display_value (Ignored)
					:log_value (ignored)
				)
				: (
					:display_value (Quarantine)
					:log_value (quarantine)
				)
				: (
					:display_value (Remove)
					:log_value (remove)
				)
				: (
					:display_value (Restore)
					:log_value (restore)
				)
			)
		)
	)
	: (ApplicationPort
		:field_name (application_port)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (port)
				:Uid ("{19882316-BC4C-4BD0-BDE3-C8512915EDA8}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (IMEvent
		:field_name (im_event)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (mixedstrandid)
				:Uid ("{B179E0DD-5E2F-4FDF-AA30-E51F52C42430}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (file_name
		:field_name ("file name")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (from
		:field_name (from)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (4)
		)
	)
	: (orig_from
		:field_name (orig_from)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (email_session_id
		:field_name (email_session_id)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (email_id
		:field_name (email_id)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (email_spool_id
		:field_name (email_spool_id)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (email_message_id
		:field_name (email_message_id)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (to
		:field_name (to)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ("{4B521F43-33F4-47D0-9F86-84FF989D2708}")
			:translation_rules ()
		)
	)
	: (orig_to
		:field_name (orig_to)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ("{4B521F43-33F4-47D0-9F86-84FF989D2708}")
			:translation_rules ()
		)
	)
	: (src_country
		:field_name (src_country)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (email_spam_category
		:field_name (email_spam_category)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (agent
		:field_name (agent)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (email_recipients_num
		:field_name (email_recipients_num)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (email_control_analysis
		:field_name (email_control_analysis)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (email_control
		:field_name (email_control)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (protection_id
		:field_name (protection_id)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (ProtectionName
		:field_name ("Protection Name")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (Severity
		:field_name (Severity)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules (
				: (
					:display_value ("N/A")
					:log_value (0)
				)
				: (
					:display_value (Low)
					:log_value (1)
				)
				: (
					:display_value (Medium)
					:log_value (2)
				)
				: (
					:display_value (High)
					:log_value (3)
				)
				: (
					:display_value (Critical)
					:log_value (4)
				)
			)
		)
	)
	: (ConfidenceLevel
		:field_name ("Confidence Level")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules (
				: (
					:display_value ("N/A")
					:log_value (0)
				)
				: (
					:display_value (Low)
					:log_value (1)
				)
				: (
					:display_value ("Medium-Low")
					:log_value (2)
				)
				: (
					:display_value (Medium)
					:log_value (3)
				)
				: (
					:display_value ("Medium-High")
					:log_value (4)
				)
				: (
					:display_value (High)
					:log_value (5)
				)
			)
		)
	)
	: (capture_uuid
		:field_name (capture_uuid)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (luuid)
				:Uid ("{3B08D5EE-F647-45F4-B746-09122A8624A1}")
			)
			:filter_CLSID ()
			:translation_rules (
				: (
					:display_value ("Packet Capture")
					:log_value ("*")
				)
			)
		)
	)
	: ("IP addresses"
		:field_name ("IP addresses")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ("{4B521F43-33F4-47D0-9F86-84FF989D2708}")
			:translation_rules ()
		)
	)
	: (FollowUp
		:field_name (FollowUp)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (FollowUp)
				:Uid ("{18A0EE35-D141-45B5-954A-951CCE0D53DD}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (Performance_Impact
		:field_name ("Performance Impact")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules (
				: (
					:display_value ("N/A")
					:log_value (0)
				)
				: (
					:display_value ("Very Low")
					:log_value (1)
				)
				: (
					:display_value (Low)
					:log_value (2)
				)
				: (
					:display_value (Medium)
					:log_value (3)
				)
				: (
					:display_value (High)
					:log_value (4)
				)
				: (
					:display_value (Critical)
					:log_value (5)
				)
			)
		)
	)
	: (Protection_Type
		:field_name ("Protection Type")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules (
				: (
					:display_value ("Protocol Anomaly")
					:log_value (anomaly)
				)
				: (
					:display_value (Signature)
					:log_value (protection)
				)
				: (
					:display_value ("Application Control")
					:log_value (app_control)
				)
				: (
					:display_value ("Engine Settings")
					:log_value (settings)
				)
				: (
					:display_value ("Engine Settings - TCP")
					:log_value (settings_tcp)
				)
				: (
					:display_value ("Geo Protection")
					:log_value (geo_protection)
				)
				: (
					:display_value ("IP Reputation")
					:log_value ("IP reputation")
				)
				: (
					:display_value ("URL Reputation")
					:log_value ("URL reputation")
				)
				: (
					:display_value ("DNS Reputation")
					:log_value ("DNS reputation")
				)
				: (
					:display_value ("Suspicious Mail")
					:log_value (email)
				)
				: (
					:display_value ("Protocol Anomaly HTTP")
					:log_value (anomaly_http)
				)
				: (
					:display_value ("Protocol Anomaly DNS")
					:log_value (anomaly_dns)
				)
				: (
					:display_value ("Archive")
					:log_value ("Archive")
				)	
				: (
					:display_value ("File Type")
					:log_value ("File Type")
				)					
				: (
					:display_value ("DNS Trap")
					:log_value ("DNS Trap")
				)
				: (
					:display_value ("HTTP Emulation")
					:log_value (HTTPEmulation)
				)
				: (
					:display_value ("SMTP Emulation")
					:log_value (SMTPEmulation)
				)
				: (
					:display_value ("CIFS Emulation")
					:log_value ("CIFS Emulation")
				)				
			)
		)
	)
	: (Industry_Reference
		:field_name ("Industry Reference")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (ESOD_scan_status
		:field_name (ESOD_scan_status)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (ESOD_access_status
		:field_name (ESOD_access_status)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (cvpn_category
		:field_name (cvpn_category)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (cvpn_resource
		:field_name (cvpn_resource)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (access_status
		:field_name (access_status)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (group_field
		:field_name (group)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (outgoing_url
		:field_name (outgoing_url)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (auth_method
		:field_name (auth_method)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (fs_proto
		:field_name (fs_proto)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (auth_status
		:field_name (auth_status)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (description
		:field_name (description)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (Anti_Virus_type
		:field_name (Anti_Virus_type)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (End_User_Firewall_type
		:field_name (End_User_Firewall_type)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (user_ESOD
		:field_name (user_ESOD)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (user_isb
		:field_name (user_isb)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (ESOD_Rule_Name
		:field_name (ESOD_Rule_Name)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (ESOD_Rule_Type
		:field_name (ESOD_Rule_Type)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (ESOD_Rule_Action
		:field_name (ESOD_Rule_Action)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (ESOD_Noncompliance_Reason
		:field_name (ESOD_Noncompliance_Reason)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (ESOD_Associated_Policies
		:field_name (ESOD_Associated_Policies)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (voip_reg_user_type
		:field_name (voip_reg_user_type)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (voip_call_id
		:field_name (voip_call_id)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (voip_reg_server
		:field_name (voip_reg_server)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (ipaddr)
				:Uid ("{7659019C-4DFE-4D8C-B5E0-0B3590E4047E}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (voip_from_user_type
		:field_name (voip_from_user_type)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (voip_to_user_type
		:field_name (voip_to_user_type)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (voip_media_port
		:field_name (voip_media_port)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (voip_media_ipp
		:field_name (voip_media_ipp)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (voip_est_codec
		:field_name (voip_est_codec)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (voip_attach_action_info
		:field_name (voip_attach_action_info)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (voip_config
		:field_name (voip_config)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (voip_method
		:field_name (voip_method)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (voip_call_dir
		:field_name (voip_call_dir)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (voip_call_state
		:field_name (voip_call_state)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (voip_reg_period
		:field_name (voip_reg_period)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (voip_exp
		:field_name (voip_exp)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (voip_attach_sz
		:field_name (voip_attach_sz)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (voip_reg_ip
		:field_name (voip_reg_ip)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (ipaddr)
				:Uid ("{7659019C-4DFE-4D8C-B5E0-0B3590E4047E}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (voip_reg_port
		:field_name (voip_reg_port)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (port)
				:Uid ("{19882316-BC4C-4BD0-BDE3-C8512915EDA8}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (voip_reg_ipp
		:field_name (voip_reg_ipp)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (proto)
				:Uid ("{DE854063-BF6C-4738-A7CB-96638875F976}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (voip_duration
		:field_name (voip_duration)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (time)
				:Uid ("{7909CC04-892B-4520-A6A4-DC9CDEBD8465}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (voip_call_term_time
		:field_name (voip_call_term_time)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (timestmp)
				:Uid ("{30AC2230-69B0-4F99-874C-0BE46C1AAA07}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (content_type
		:field_name (content_type)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (voip_log_type
		:field_name (voip_log_type)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (voip_reject_reason
		:field_name (voip_reject_reason)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (voip_reason_info
		:field_name (voip_reason_info)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (ctrl_category
        :field_name (ctrl_category)
        :server_definitions (
            :display_mode (
                : (
                    :application_display_mode (own_column)
                    :application_name (SmartViewTracker)
                )
                : (
                    :application_display_mode (own_column)
                    :application_name (FWLog)
                )
                : (
                    :application_display_mode (own_column)
                    :application_name (FWMLogExport)
                )
            )
            :field_type (ReferenceObject
                :Table (log_field_server_types)
                :Name (string_id)
                :Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
            )
            :filter_CLSID ()
            :translation_rules ()
        )
    )
	: (identity_src
		:field_name (identity_src)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (user_additional_info
		:field_name (user_additional_info)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (termination_reason
		:field_name (termination_reason)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (src_machine_group
		:field_name (src_machine_group)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ("{4B521F43-33F4-47D0-9F86-84FF989D2708}")
			:translation_rules ()
			:permissions (4)
		)
	)
	: (previous_ip
		:field_name (previous_ip)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (ipaddr)
				:Uid ("{7659019C-4DFE-4D8C-B5E0-0B3590E4047E}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (packet_tagging_key
		:field_name (packet_tagging_key)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (connectivity_state
		:field_name (connectivity_state)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (RPCServiceNumber
		:field_name ("RPC Service Number")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (int)
				:Uid ("{91694BE7-D52D-474E-A565-635734A73B22}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (VLANID
		:field_name ("VLAN ID")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (int)
				:Uid ("{91694BE7-D52D-474E-A565-635734A73B22}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (MACDestinationAddress
		:field_name ("MAC Destination Address")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (macaddr)
				:Uid ("{380DD84F-9879-4C91-A60C-262E3303E61C}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (MACSourceAddress
		:field_name ("MAC Source Address")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (macaddr)
				:Uid ("{380DD84F-9879-4C91-A60C-262E3303E61C}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (Command
		:field_name ("Command")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (Cookie
		:field_name ("Cookie")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (DestinationDHCPHostname
		:field_name ("Destination DHCP Hostname")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (DestinationDNSHostname
		:field_name ("Destination DNS Hostname")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (DestinationOS
		:field_name ("Destination OS")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (EmailAddress
		:field_name ("Email Address")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (EmailSubject
		:field_name ("Email Subject")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (Hostname
		:field_name (Hostname)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (HTTPModifier
		:field_name ("HTTP Modifier")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (NetBIOSDestinationHostname
		:field_name ("NetBIOS Destination Hostname")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (NetBIOSSourceHostname
		:field_name ("NetBIOS Source Hostname")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (Payload
		:field_name (Payload)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (HTTPReferer
		:field_name ("HTTP Referer")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (SourceDHCPHostname
		:field_name ("Source DHCP Hostname")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (SourceDNSHostname
		:field_name ("Source DNS Hostname")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (SourceOS
		:field_name ("Source OS")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (URI_field
		:field_name (URI)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (AttackAssessment
		:field_name ("Attack Assessment")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (AttackImpact
		:field_name ("Attack Impact")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (SensorMode
		:field_name ("Sensor Mode")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (Log_ID
		:field_name ("Log ID")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (mixedstrandid)
				:Uid ("{B179E0DD-5E2F-4FDF-AA30-E51F52C42430}")
			)
			:filter_CLSID ("{0C40BC22-2BEA-412E-AD85-51BC715B9808}")
			:translation_rules ()
		)
	)
	: (duration
		:field_name (Duration)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (time)
				:Uid ("{7909CC04-892B-4520-A6A4-DC9CDEBD8465}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (ProtectedServer
		:field_name ("Protected Server")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (ipaddr)
				:Uid ("{7659019C-4DFE-4D8C-B5E0-0B3590E4047E}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (dst_machine_name
		:field_name (dst_machine_name)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ("{4B521F43-33F4-47D0-9F86-84FF989D2708}")
			:translation_rules ()
			:permissions (4)
		)
	)
	: (dst_user_name
		:field_name (dst_user_name)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ("{4B521F43-33F4-47D0-9F86-84FF989D2708}")
			:translation_rules ()
			:permissions (4)
		)
	)
	: (src_machine_name
		:field_name (src_machine_name)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ("{4B521F43-33F4-47D0-9F86-84FF989D2708}")
			:translation_rules ()
			:permissions (4)
		)
	)
	: (src_user_name
		:field_name (src_user_name)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ("{4B521F43-33F4-47D0-9F86-84FF989D2708}")
			:translation_rules ()
			:permissions (4)
		)
	)
	: (proxy_src_ip
		:field_name (proxy_src_ip)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (ipaddr)
				:Uid ("{7659019C-4DFE-4D8C-B5E0-0B3590E4047E}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (src_reputation
		:field_name (src_reputation)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules (
				: (
					:display_value (Unknown)
					:log_value (0)
				)
				: (
					:display_value ("Good Reputation")
					:log_value (20)
				)
				: (
					:display_value ("Neutral Reputation")
					:log_value (50)
				)
				: (
					:display_value ("Bad Reputation")
					:log_value (80)
				)
				: (
					:display_value ("Very Bad Reputation")
					:log_value (100)
				)
			)
		)
	)
	: (dst_reputation
		:field_name (dst_reputation)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules (
				: (
					:display_value (Unknown)
					:log_value (0)
				)
				: (
					:display_value ("Good Reputation")
					:log_value (20)
				)
				: (
					:display_value ("Neutral Reputation")
					:log_value (50)
				)
				: (
					:display_value ("Bad Reputation")
					:log_value (80)
				)
				: (
					:display_value ("Very Bad Reputation")
					:log_value (100)
				)
			)
		)
	)
	: (web_client_type
		:field_name (web_client_type)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (web_server_type
		:field_name (web_server_type)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (dlp_rule_name
		:field_name (dlp_rule_name)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (obf_str)
				:Uid ("{D4F84DB4-6EE6-11DE-9EF8-0AE055D89593}")
			)
			:filter_CLSID ("{4B521F43-33F4-47D0-9F86-84FF989D2708}")
			:translation_rules ()
			:permissions (17)
		)
	)
	: (dlp_rule_uid
		:field_name (dlp_rule_uid)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (17)
		)
	)
	: (dlp_incident_uid
		:field_name (dlp_incident_uid)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (guid)
				:Uid ("{2F237A9A-44B3-459B-B3AD-B2C384E1899B}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (0)
		)
	)
	: (dlp_data_type_name
		:field_name (dlp_data_type_name)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (obf_str)
				:Uid ("{D4F84DB4-6EE6-11DE-9EF8-0AE055D89593}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (17)
		)
	)
	: (dlp_data_type_uid
		:field_name (dlp_data_type_uid)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (17)
		)
	)
	: (dlp_action_comment
		:field_name (dlp_action_comment)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (obf_str)
				:Uid ("{D4F84DB4-6EE6-11DE-9EF8-0AE055D89593}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (17)
		)
	)
	: (dlp_recipients
		:field_name (dlp_recipients)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (obf_str)
				:Uid ("{D4F84DB4-6EE6-11DE-9EF8-0AE055D89593}")
			)
			:filter_CLSID ("{4B521F43-33F4-47D0-9F86-84FF989D2708}")
			:translation_rules ()
			:permissions (5)
		)
	)
	: (dlp_file_name
		:field_name (dlp_file_name)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (obf_str)
				:Uid ("{D4F84DB4-6EE6-11DE-9EF8-0AE055D89593}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (17)
		)
	)
	: (dlp_violation_description
		:field_name (dlp_violation_description)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (obf_str)
				:Uid ("{D4F84DB4-6EE6-11DE-9EF8-0AE055D89593}")
			)
			:filter_CLSID ("{4B521F43-33F4-47D0-9F86-84FF989D2708}")
			:translation_rules ()
			:permissions (17)
		)
	)
	: (dlp_categories
		:field_name (dlp_categories)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (obf_str)
				:Uid ("{D4F84DB4-6EE6-11DE-9EF8-0AE055D89593}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (17)
		)
	)
	: (dlp_word_list
		:field_name (dlp_word_list)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (obf_str)
				:Uid ("{D4F84DB4-6EE6-11DE-9EF8-0AE055D89593}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (17)
		)
	)
	: (dlp_action_reason
		:field_name (dlp_action_reason)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules	(
				: (
					:display_value ("Rule Base")
					:log_value ("Rule Base")
				)
				: (
					:display_value ("Rule Base (Action set by different rule)")
					:log_value ("Rule Base (Action set by different rule)")
				)
				: (
					:display_value ("Prior User Decision")
					:log_value ("Prior User Decision")
				)
				: (
					:display_value ("Internal Error")
					:log_value ("Internal Error")
				)
			)	
		)
	)
	: (dlp_related_incident_uid
		:field_name (dlp_related_incident_uid)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (guid)
				:Uid ("{2F237A9A-44B3-459B-B3AD-B2C384E1899B}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (dlp_subject
		:field_name (dlp_subject)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (obf_str)
				:Uid ("{D4F84DB4-6EE6-11DE-9EF8-0AE055D89593}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (17)
		)
	)
	: (dlp_transport
		:field_name (dlp_transport)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (caused_quarantine
		:field_name (caused_quarantine)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (connection_uid
		:field_name (connection_uid)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (luuid)
				:Uid ("{3B08D5EE-F647-45F4-B746-09122A8624A1}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (client_ip
		:field_name (client_ip)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (ipaddr)
				:Uid ("{7659019C-4DFE-4D8C-B5E0-0B3590E4047E}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (duplicate
        :field_name (duplicate)
        :server_definitions (
            :display_mode (
                : (
                    :application_display_mode (own_column)
                    :application_name (SmartViewTracker)
                )
                : (
                    :application_display_mode (own_column)
                    :application_name (FWLog)
                )
                : (
                    :application_display_mode (own_column)
                    :application_name (FWMLogExport)
                )
            )
            :field_type (ReferenceObject
                :Table (log_field_server_types)
                :Name (string_id)
                :Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
            )
            :filter_CLSID ()
            :translation_rules ()
        )
    )
    : (src_user_group
        :field_name (src_user_group)
        :server_definitions (
            :display_mode (
                : (
                    :application_display_mode (own_column)
                    :application_name (SmartViewTracker)
                )
                : (
                    :application_display_mode (own_column)
                    :application_name (FWLog)
                )
                : (
                    :application_display_mode (own_column)
                    :application_name (FWMLogExport)
                )
            )
            :field_type (ReferenceObject
                :Table (log_field_server_types)
                :Name (string)
                :Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
            )
            :filter_CLSID ()
            :translation_rules ()
			:permissions (4)
        )
    )
	: (app_id
		:field_name (app_id)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (18)			
		)
	)
	: (app_risk
		:field_name (app_risk)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules (
				: (
					:display_value ("Unknown")
					:log_value (0)
				)
				: (
					:display_value ("Very Low")
					:log_value (1)
				)
				: (
					:display_value (Low)
					:log_value (2)
				)
				: (
					:display_value (Medium)
					:log_value (3)
				)
				: (
					:display_value (High)
					:log_value (4)
				)
				: (
					:display_value (Critical)
					:log_value (5)
				)
			)
			:permissions (18)
		)
	)
	: (app_rule_id
		:field_name (app_rule_id)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (18)
		)
	)
	: (app_desc
		:field_name (app_desc)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (obf_string_id)
				:Uid ("{9E5C40C7-3139-455C-A9D5-2E998805673F}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (18)
		)
	)
	: (app_category
		:field_name (app_category)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (obf_string_id)
				:Uid ("{9E5C40C7-3139-455C-A9D5-2E998805673F}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (18)
		)
	)
	: (app_properties
		:field_name (app_properties)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (mixedobfstrandid)
				:Uid ("{4DEE2C65-B31D-4fdf-B22C-43E547D2B2E8}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (18)
		)
	)
	: (app_rule_name
		:field_name (app_rule_name)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (obf_string_id)
				:Uid ("{9E5C40C7-3139-455C-A9D5-2E998805673F}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (18)
		)
	)
    : (Suppressed_Logs
        :field_name ("Suppressed Logs")
        :server_definitions (
            :display_mode (
                : (
                    :application_display_mode (own_column)
                    :application_name (SmartViewTracker)
                )
                : (
                    :application_display_mode (own_column)
                    :application_name (FWLog)
                )
                : (
                    :application_display_mode (own_column)
                    :application_name (FWMLogExport)
                )
            )
            :field_type (ReferenceObject
                :Table (log_field_server_types)
                :Name (uint)
                :Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
            )
            :filter_CLSID ()
            :translation_rules ()
        )
    )
    : (roles
        :field_name (roles)
        :server_definitions (
            :display_mode (
                : (
                    :application_display_mode (own_column)
                    :application_name (SmartViewTracker)
                )
                : (
                    :application_display_mode (own_column)
                    :application_name (FWLog)
                )
                : (
                    :application_display_mode (own_column)
                    :application_name (FWMLogExport)
                )
            )
            :field_type (ReferenceObject
                :Table (log_field_server_types)
                :Name (string)
                :Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
            )
            :filter_CLSID ()
            :translation_rules ()
        )
    )
	: (Update_Service
		:field_name (update_service)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:permissions (0)
			:translation_rules ()
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
		)
	)
	: (Failure_Impact
		:field_name (failure_impact)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:permissions (0)
			:translation_rules ()
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
		)
	)
	: (db_ver
		:field_name (db_ver)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (app_sig_id
		:field_name (app_sig_id)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (identity_type
		:field_name (identity_type)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
    : (sent_bytes
        :field_name (sent_bytes)
        :server_definitions (
            :display_mode (
                : (
                    :application_display_mode (own_column)
                    :application_name (SmartViewTracker)
                )
                : (
                    :application_display_mode (own_column)
                    :application_name (FWLog)
                )
                : (
                    :application_display_mode (own_column)
                    :application_name (FWMLogExport)
                )
            )
            :field_type (ReferenceObject
                :Table (log_field_server_types)
                :Name (uint)
                :Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
            )
            :filter_CLSID ()
            :translation_rules ()
        )
    )
    : (received_bytes
        :field_name (received_bytes)
        :server_definitions (
            :display_mode (
                : (
                    :application_display_mode (own_column)
                    :application_name (SmartViewTracker)
                )
                : (
                    :application_display_mode (own_column)
                    :application_name (FWLog)
                )
                : (
                    :application_display_mode (own_column)
                    :application_name (FWMLogExport)
                )
            )
            :field_type (ReferenceObject
                :Table (log_field_server_types)
                :Name (uint)
                :Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
            )
            :filter_CLSID ()
            :translation_rules ()
        )
    )
	: (dropped_outgoing
		:field_name (dropped_outgoing)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (dropped_incoming
		:field_name (dropped_incoming)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (dropped_total
		:field_name (dropped_total)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (limit_requested
		:field_name (limit_requested)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (int)
				:Uid ("{91694BE7-D52D-474E-A565-635734A73B22}")
			)
			:filter_CLSID ()
			:translation_rules (
				: (
					:display_value ("No")
					:log_value (0)
				)
				: (
					:display_value ("Yes")
					:log_value (1)
				)
			)
		)
	)
	: (limit_applied
		:field_name (limit_applied)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (int)
				:Uid ("{91694BE7-D52D-474E-A565-635734A73B22}")
			)
			:filter_CLSID ()
			:translation_rules (
				: (
					:display_value ("No")
					:log_value (0)
				)
				: (
					:display_value ("Yes")
					:log_value (1)
				)
			)
		)
	)
	: (Referrer_self_uid
		:field_name (Referrer_self_uid)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (guid)
				:Uid ("{2F237A9A-44B3-459B-B3AD-B2C384E1899B}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (18)
		)
	)
	: (Referrer_Parent_uid
		:field_name (Referrer_Parent_uid)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (guid)
				:Uid ("{2F237A9A-44B3-459B-B3AD-B2C384E1899B}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (18)
		)
	)
    : (dlp_template_score
        :field_name (dlp_template_score)
        :server_definitions (
            :display_mode (
                : (
                    :application_display_mode (own_column)
                    :application_name (SmartViewTracker)
                )
                : (
                    :application_display_mode (own_column)
                    :application_name (FWLog)
                )
                : (
                    :application_display_mode (own_column)
                    :application_name (FWMLogExport)
                )
            )
            :field_type (ReferenceObject
                :Table (log_field_server_types)
                :Name (obf_str)
                :Uid ("{D4F84DB4-6EE6-11DE-9EF8-0AE055D89593}")
            )
            :filter_CLSID ()
            :translation_rules ()
            :permissions (17)
        )
    )
	: (dlp_relevant_data_type
        :field_name ("DLP relevant data types")
        :server_definitions (
            :display_mode (
                : (
                    :application_display_mode (own_column)
                    :application_name (SmartViewTracker)
                )
                : (
                    :application_display_mode (own_column)
                    :application_name (FWLog)
                )
                : (
                    :application_display_mode (own_column)
                    :application_name (FWMLogExport)
                )
            )
            :field_type (ReferenceObject
                :Table (log_field_server_types)
                :Name (obf_str)
                :Uid ("{D4F84DB4-6EE6-11DE-9EF8-0AE055D89593}")
            )
            :filter_CLSID ()
            :translation_rules ()
            :permissions (17)
        )
    )
    : (dst_country
        :field_name (dst_country)
        :server_definitions (
            :display_mode (
                : (
                    :application_display_mode (own_column)
                    :application_name (SmartViewTracker)
                )
                : (
                    :application_display_mode (own_column)
                    :application_name (FWLog)
                )
                : (
                    :application_display_mode (own_column)
                    :application_name (FWMLogExport)
                )
            )
            :field_type (ReferenceObject
                :Table (log_field_server_types)
                :Name (string_id)
                :Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
            )
            :filter_CLSID ()
            :translation_rules ()
        )
    )
	: (https_inspection_action
		:field_name (https_inspection_action)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (16)
		)
	)
	: (HTTPS_inspection_rule_id
		:field_name (https_inspection_rule_id)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (16)
		)
	)
	: (HTTPS_inspection_rule_name
		:field_name (https_inspection_rule_name)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (16)
		)
	)
	: (HTTPS_validation
		:field_name (https_validation)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules (
				: (
					:display_value ("Untrusted Server Certificate")
					:log_value (untrusted)
				)
				: (
					:display_value ("Revoked Certificate or Invalid CRL")
					:log_value (invalid)
				)
				: (
					:display_value ("Server Certificate Expired")
					:log_value (expired)
				)
				: (
					:display_value ("SSL Protocol Error")
					:log_value (unsupported)
				)
				: (
					:display_value ("Client has not installed CA certificate")
					:log_value (empty_ssl_conn)
				)				
			)
		)
	)
	: (DLP_additional_action
		:field_name (dlp_addtional_action)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules (
				: (
					:display_value ("Watermark")
					:log_value (Watermark)
				)
				: (
					:display_value ("None")
					:log_value (None)
				)				
			)
		)
	)
	: (DLP_watermark_profile
		:field_name (dlp_watermark_profile)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (DLP_message_size
		:field_name (message_size)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (incident_extension
		:field_name (incident_extension)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (Origin)
				:Uid ("{960B2585-5477-4EE8-A59E-5B1B37B5D237}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (18)
		)
	)
		: (malware_family
		:field_name (malware_family)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (malware_action
		:field_name (malware_action)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules (
				: (
					:display_value (Spam)
					:log_value (spam)
				)
				: (
					:display_value ("Communication with Command & Control")
					:log_value (comm_c&c)
				)
				: (
					:display_value ("Distributed Denial of Service")
					:log_value (ddos)
				)
				: (
					:display_value ("Click Fraud")
					:log_value ("click fraud")
				)
				: (
					:display_value ("Self Distribution")
					:log_value ("self_distrib")
				)
			)
		)
	)
	: (malware_rule_name
		:field_name (malware_rule_name)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (malware_rule_id
		:field_name (malware_rule_id)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (Engine
		:field_name (engine)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules (
				: (
					:display_value ("IP Reputation")
					:log_value ("IP reputation")
				)
				: (
					:display_value ("URL Reputation")
					:log_value ("URL reputation")
				)
				: (
					:display_value ("DNS Reputation")
					:log_value ("DNS reputation")
				)
				: (
					:display_value ("Signature")
					:log_value ("Signature")
				)
			)
		)
	)
	: (packet_capture_unique_id
		:field_name (packet_capture_unique_id)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:permissions (0)
			:translation_rules ()
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
		)
	)
	: (packet_capture_name
		:field_name (packet_capture_name)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:permissions (0)
			:translation_rules ()
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
		)
	)
	: (packet_capture_time
		:field_name (packet_capture_time)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:permissions (0)
			:translation_rules ()
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
		)
	)
	: (Scope
		:field_name (scope)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (ipaddr)
				:Uid ("{7659019C-4DFE-4D8C-B5E0-0B3590E4047E}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (log_id
		:field_name (log_id)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (auth_method2
		:field_name (auth_method2)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (auth_method3
		:field_name (auth_method3)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (24)
		)
	)
	: (device_identification
		:field_name (device_identification)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (fingerprint
		:field_name (fingerprint)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	) 
	: (user_dn
		:field_name (user_dn)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (4)
		)
	) 
	: (host_type
		:field_name (host_type)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	) 
	: (host_ip
		:field_name (host_ip)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (ipaddr)
				:Uid ("{7659019C-4DFE-4D8C-B5E0-0B3590E4047E}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	) 
	: (os_name
		:field_name (os_name)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (os_version
		:field_name (os_version)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (browser
		:field_name (browser)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	) 
	: (client_name
		:field_name (client_name)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (client_version
		:field_name (client_version)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (client_build
		:field_name (client_build)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	) 
	: (installed_products
		:field_name (installed_products)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (compliance_check
		:field_name (compliance_check)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	) 
	: (office_mode_ip
		:field_name (office_mode_ip)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (ipaddr)
				:Uid ("{7659019C-4DFE-4D8C-B5E0-0B3590E4047E}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (tunnel_protocol
		:field_name (tunnel_protocol)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (session_timeout
		:field_name (session_timeout)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (timestmp)
				:Uid ("{30AC2230-69B0-4F99-874C-0BE46C1AAA07}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (auth_encryption_methods
		:field_name (auth_encryption_methods)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (ProductFamily
		:field_name (ProductFamily)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:translation_rules (
				: (
					:display_value (Network)
					:log_value (Network)
				)
				: (
					:display_value (Endpoint)
					:log_value (Endpoint)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (ProductFamily)
				:Uid ("{22703250-5703-4BB8-B478-5E403AADE91D}")
			)
			:filter_CLSID ()
		)
	)
	: (UserCheck_Confirmation_Level
		:field_name (UserCheck_Confirmation_Level)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (browse_time
		:field_name (browse_time)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:translation_rules ()
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (time)
				:Uid ("{7909CC04-892B-4520-A6A4-DC9CDEBD8465}")
			)
			:filter_CLSID ()
			:permissions (18)
		)
	)
	: (media_access_permission
		:field_name (media_access_permission)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (is_scanned
		:field_name (is_scanned)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (int)
				:Uid ("{91694BE7-D52D-474E-A565-635734A73B22}")
			)
			:filter_CLSID ()
			:translation_rules (
				: (
					:display_value (No)
					:log_value (0)
				)
				: (
					:display_value (Yes)
					:log_value (1)
				)
			)
		)
	)
	: (is_authorized
		:field_name (is_authorized)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (int)
				:Uid ("{91694BE7-D52D-474E-A565-635734A73B22}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (is_compliant_policy
		:field_name (is_compliant_policy)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (int)
				:Uid ("{91694BE7-D52D-474E-A565-635734A73B22}")
			)
			:filter_CLSID ()
			:translation_rules (
				: (
					:display_value (No)
					:log_value (0)
				)
				: (
					:display_value (Yes)
					:log_value (1)
				)
			)
		)
	)
	: (file_size
		:field_name (file_size)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint64)
				:Uid ("{755E4FAC-3036-4B6D-8EA6-99702EA1611D}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (source_path
		:field_name (source_path)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (destination_path
		:field_name (destination_path)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (incident_type
		:field_name (incident_type)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
		: (media_description
		:field_name (media_description)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (media_manufacturer
		:field_name (media_manufacturer)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (media_authorized
		:field_name (media_authorized)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules (
				: (
					:display_value (No)
					:log_value (0)
				)
				: (
					:display_value (Yes)
					:log_value (1)
				)
			)
		)
	)
	: (media_encrypted
		:field_name (media_encrypted)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (media_class_id
		:field_name (media_class_id)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (process
		:field_name (process)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (file_operation
		:field_name (file_operation)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (incident_time
		:field_name (incident_time)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (timestmp)
				:Uid ("{30AC2230-69B0-4F99-874C-0BE46C1AAA07}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (is_target_encrypted_storage
		:field_name (is_target_encrypted_storage)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (int)
				:Uid ("{91694BE7-D52D-474E-A565-635734A73B22}")
			)
			:filter_CLSID ()
			:translation_rules (
				: (
					:display_value (No)
					:log_value (0)
				)
				: (
					:display_value (Yes)
					:log_value (1)
				)
			)
		)
	)
	: (is_organization_host
		:field_name (is_organization_host)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (int)
				:Uid ("{91694BE7-D52D-474E-A565-635734A73B22}")
			)
			:filter_CLSID ()
			:translation_rules (
				: (
					:display_value (No)
					:log_value (0)
				)
				: (
					:display_value (Yes)
					:log_value (1)
				)
			)
		)
	)
	: (is_encrypted_storage
		:field_name (is_encrypted_storage)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (Action_Details
		:field_name (action_details)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (4)
		)
	)
	: (Additional_IP
		:field_name (additional_ip)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (4)
		)
	)
	: (indicator_name
		:field_name (indicator_name)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (4)
		)
	)
	: (indicator_description
		:field_name (indicator_description)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (4)
		)
	)
	: (indicator_reference
		:field_name (indicator_reference)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (4)
		)
	)
	: (observable_name
		:field_name (observable_name)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (4)
		)
	)
	: (observable_comment
		:field_name (observable_comment)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (4)
		)
	)
	: (physical_port
		:field_name ("PhysicalPort")
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)	
	: (os_flavor
		:field_name (os_flavor)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (os_build
		:field_name (os_build)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (os_bits
		:field_name (os_bits)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (jailbreak_message
		:field_name (jailbreak_message)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (os_edition
		:field_name (os_edition)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (os_service_pack
		:field_name (os_service_pack)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (hardware_model
		:field_name (hardware_model)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (mac_address
		:field_name (mac_address)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (macaddr)
				:Uid ("{380DD84F-9879-4C91-A60C-262E3303E61C}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (auth_protocol
		:field_name (auth_protocol)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)	
	: (scan_id
		:field_name (scan_id)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:translation_rules ()
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
		)
	)
	: (dlp_repository_root_path
		:field_name (dlp_repository_root_path)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:translation_rules ()
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
		)
	)
	: (long_status
		:field_name (long_status)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:translation_rules ()
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
		)
	)
	: (dlp_repository_total_size
		:field_name (dlp_repository_total_size)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (dlp_repository_scanned_files_number
		:field_name (dlp_repository_scanned_files_number)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (dlp_repository_directories_number
		:field_name (dlp_repository_directories_number)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (dlp_repository_unreachable_directories_number
		:field_name (dlp_repository_unreachable_directories_number)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (dlp_fingerprinted_files_number
		:field_name (dlp_fingerprinted_files_number)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (dlp_repository_skipped_files_number
		:field_name (dlp_repository_skipped_files_number)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (dlp_repository_scanned_directories_number
		:field_name (dlp_repository_scanned_directories_number)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (number_of_errors
		:field_name (number_of_errors)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (dlp_repository_scan_remaining_time
		:field_name (dlp_repository_scan_remaining_time)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (time)
				:Uid ("{7909CC04-892B-4520-A6A4-DC9CDEBD8465}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (dlp_repository_scan_progress
		:field_name (dlp_repository_scan_progress)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (speed
		:field_name (speed)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (dlp_repository_not_scanned_directories_percentage
		:field_name (dlp_repository_not_scanned_directories_percentage)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (dlp_repository_reached_directories_number
		:field_name (dlp_repository_reached_directories_number)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (dlp_repository_scanned_total_size
		:field_name (dlp_repository_scanned_total_size)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (dlp_repository_files_number
		:field_name (dlp_repository_files_number)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (dlp_repository_scan_current_directory
		:field_name (dlp_repository_scan_current_directory)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:translation_rules ()
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
		)
	)
	: (matched_file
		:field_name (matched_file)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:translation_rules ()
			:permissions (17)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (obf_str)
				:Uid ("{D4F84DB4-6EE6-11DE-9EF8-0AE055D89593}")
			)
			:filter_CLSID ()
		)
	)
	: (more_matched_file
		:field_name (more_matched_file)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:translation_rules ()
			:permissions (17)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (obf_str)
				:Uid ("{D4F84DB4-6EE6-11DE-9EF8-0AE055D89593}")
			)
			:filter_CLSID ()
		)
	)
	: (matched_file_percentage
		:field_name (matched_file_percentage)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (17)
		)
	)
	: (more_matched_file_percentage
		:field_name (more_matched_file_percentage)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (17)
		)
	)
	: (matched_file_text_segments
		:field_name (matched_file_text_segments)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (17)
		)
	)
	: (more_matched_file_text_segments
		:field_name (more_matched_file_text_segments)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
			:permissions (17)
		)
	)
	: (dlp_rule_names
		:field_name (dlp_rule_names)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (obf_str)
				:Uid ("{D4F84DB4-6EE6-11DE-9EF8-0AE055D89593}")
			)
			:filter_CLSID ("{4B521F43-33F4-47D0-9F86-84FF989D2708}")
			:translation_rules ()
			:permissions (17)
		)
	)
	: (dlp_data_type_names
		:field_name (dlp_data_type_names)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (obf_str)
				:Uid ("{D4F84DB4-6EE6-11DE-9EF8-0AE055D89593}")
			)
			:filter_CLSID ("{4B521F43-33F4-47D0-9F86-84FF989D2708}")
			:translation_rules ()
			:permissions (17)
		)
	)
	: (dlp_file_names
		:field_name (dlp_file_names)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (obf_str)
				:Uid ("{D4F84DB4-6EE6-11DE-9EF8-0AE055D89593}")
			)
			:filter_CLSID ("{4B521F43-33F4-47D0-9F86-84FF989D2708}")
			:translation_rules ()
			:permissions (17)
		)
	)
	: (dlp_repository_id
		:field_name (dlp_repository_id)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (device_process
		:field_name (device_process)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (user_guid
		:field_name (user_guid)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (guid)
				:Uid ("{2F237A9A-44B3-459B-B3AD-B2C384E1899B}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (user_sid
		:field_name (user_sid)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (machine_guid
		:field_name (machine_guid)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (guid)
				:Uid ("{2F237A9A-44B3-459B-B3AD-B2C384E1899B}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (action_comment
		:field_name (action_comment)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (items_scanned
		:field_name (items_scanned)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (items_detected
		:field_name (items_detected)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (items_treated
		:field_name (items_treated)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (treatment_result
		:field_name (treatment_result)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (infection_type
		:field_name (scan_category)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (treatment_mode
		:field_name (treatment_mode)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (failed_updates
		:field_name (failed_updates)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (program_name
		:field_name (program_name)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (compliance_provider
		:field_name (compliance_provider)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (remediation
		:field_name (remediation)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (fde_account
		:field_name (fde_account)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (fde_account_guid
		:field_name (fde_account_guid)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (guid)
				:Uid ("{2F237A9A-44B3-459B-B3AD-B2C384E1899B}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (fde_rh_guid
		:field_name (fde_rh_guid)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (guid)
				:Uid ("{2F237A9A-44B3-459B-B3AD-B2C384E1899B}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (detection_type
		:field_name (detection_type)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (action_reason
		:field_name (action_reason)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (attacked_org
		:field_name (attacked_org)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (dst_file_name
		:field_name (dst_file_name)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (device_enumerator
		:field_name (device_enumerator)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (device_class_guid
		:field_name (device_class_guid)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (guid)
				:Uid ("{2F237A9A-44B3-459B-B3AD-B2C384E1899B}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)	
	: (device_description
		:field_name (device_description)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (guid)
				:Uid ("{2F237A9A-44B3-459B-B3AD-B2C384E1899B}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (device_manufacturer
		:field_name (device_manufacturer)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (guid)
				:Uid ("{2F237A9A-44B3-459B-B3AD-B2C384E1899B}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (device_friendly_name
		:field_name (device_friendly_name)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (guid)
				:Uid ("{2F237A9A-44B3-459B-B3AD-B2C384E1899B}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (device_compatible_ids
		:field_name (device_compatible_ids)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (guid)
				:Uid ("{2F237A9A-44B3-459B-B3AD-B2C384E1899B}")
			)
			:filter_CLSID ("{4B521F43-33F4-47D0-9F86-84FF989D2708}")
			:translation_rules ()
		)
	)
	: (auth_type
		:field_name (auth_type)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (engine_ver
		:field_name (engine_ver)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (signature_ver
		:field_name (signature_ver)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (policy_type
		:field_name (policy_type)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (int)
				:Uid ("{91694BE7-D52D-474E-A565-635734A73B22}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (policy_date
		:field_name (policy_date)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (timestmp)
				:Uid ("{30AC2230-69B0-4F99-874C-0BE46C1AAA07}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (policy_guid
		:field_name (policy_guid)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (guid)
				:Uid ("{2F237A9A-44B3-459B-B3AD-B2C384E1899B}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (product_family
		:field_name (product_family)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (none)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (none)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (none)
					:application_name (FWMLogExport)
				)
			)
			:translation_rules ()
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
		)
	)
	: (SecurityPolicy
		:field_name (SecurityPolicy)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (EndpointName
		:field_name (EndpointName)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (EndpointUser
		:field_name (EndpointUser)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (endpoint_rule_uid
		:field_name (endpoint_rule_uid)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (ep_rule_id
		:field_name (ep_rule_id)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (user_name
		:field_name (user_name)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (reading_data_access
		:field_name (reading_data_access)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (writing_data_access
		:field_name (writing_data_access)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (data_type
		:field_name (data_type)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (dlp_fingerprint_short_status
		:field_name (dlp_fingerprint_short_status)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (dlp_fingerprint_long_status
		:field_name (dlp_fingerprint_long_status)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:translation_rules ()
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
		)
	)
	: (special_properties
		:field_name (special_properties)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (none)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (none)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (none)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (next_scheduled_scan_date
		:field_name (next_scheduled_scan_date)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (timestmp)
				:Uid ("{30AC2230-69B0-4F99-874C-0BE46C1AAA07}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (frequency
		:field_name (frequency)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (user_reported_wrong_category
		:field_name (user_reported_wrong_category)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (certificate_serial_number
		:field_name (certificate_serial_number)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (certificate_issuer
		:field_name (certificate_issuer)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string_id)
				:Uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
        : (analyzed_on
		:field_name (analyzed_on)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (file_md5
		:field_name (file_md5)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (file_sha1
		:field_name (file_sha1)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (emulated_on
		:field_name (emulated_on)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (detected_on
		:field_name (detected_on)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (verdict
		:field_name (verdict)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (image_os
		:field_name (image_os)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
	: (control_log_type
		:field_name (control_log_type)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (uint)
				:Uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			)
			:filter_CLSID ()
			:translation_rules (			
				: (
					:display_value (General)
					:log_value (0)
				)
				: (
					:display_value (Cloud)
					:log_value (1)
				)
				: (
					:display_value (Database)
					:log_value (2)
				)
				: (
					:display_value (Emulation)
					:log_value (3)
				)
				: (
					:display_value ("File Aggregation")
					:log_value (4)
				)
				: (
					:display_value (Policy)
					:log_value (5)
				)
				: (
					:display_value (Resources)
					:log_value (6)
				)
				: (
					:display_value (Updates)
					:log_value (7)
				)
			)
		)
	)
	: (malicous_activity_determined_by
		:field_name (TE_verdict_determined_by)
		:server_definitions (
			:display_mode (
				: (
					:application_display_mode (own_column)
					:application_name (SmartViewTracker)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWLog)
				)
				: (
					:application_display_mode (own_column)
					:application_name (FWMLogExport)
				)
			)
			:field_type (ReferenceObject
				:Table (log_field_server_types)
				:Name (string)
				:Uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			)
			:filter_CLSID ()
			:translation_rules ()
		)
	)
)

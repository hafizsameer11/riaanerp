(
	:version (5.9)
	: (msnms_chats_block_video_http_log
		:AdminInfo (
            		:chkpf_uid ("{22DBDED7-BA62-EEE0-B9C5-D31F466C2865}")
            		:ClassName (inspect_log)
            		:table (inspect_logs)
        	)
        	:formats (
            		: (format1
                		:AdminInfo (
		                        :chkpf_uid ("{CBDDE5C6-6B1C-90AA-8044-A7A11330038C}")
                    			:ClassName (inspect_logs_formats)
                		)
                		:ver_1 (
                    			: (param1
                        			:AdminInfo (
                            				:chkpf_uid ("{D6A5804D-8631-A1CB-E903-434235480D5D}")
                            				:ClassName (inspect_logs_format_params)
                        			)
                        			:param_type (string_id)
                        			:type (inspect_logs_format_params)
                        			:value ("MSN Messenger - Chat")
                    			)
                		)
                		:excessive_report (true)
                		:id (83)
                		:type (inspect_logs_formats)
            		)
            		: (format2
                		:AdminInfo (
                    			:chkpf_uid ("{265C58CA-47CD-9E58-EB6E-487E701097DB}")
                    			:ClassName (inspect_logs_formats)
                		)
                		:ver_1 (
                    			: (param1
                        			:AdminInfo (
                            				:chkpf_uid ("{15DF8345-1F4D-5685-6543-1F2B760638D4}")
                            				:ClassName (inspect_logs_format_params)
                        			)
                        			:param_type (string_id)
                        			:type (inspect_logs_format_params)
                        			:value ("Video is not allowed by the security policy")
                    			)
                		)
                		:excessive_report (true)
                		:id (82)
                		:type (inspect_logs_formats)
            		)
        	)
        	:alert (log)
        	:dynamic_format (72)
        	:enable_excessive (true)
        	:enable_excessive_report (true)
        	:excessive_conn_mask (13)
        	:flags (0)
        	:location (msn_msnms:msnms_chats_track)
        	:type (inspect_log)
        	:unify (false)
    	)
	: (msnms_chats_block_audio_http_log
        	:AdminInfo (
            		:chkpf_uid ("{6DABD02A-8E5F-5202-1B87-29A9CF14488A}")
            		:ClassName (inspect_log)
            		:table (inspect_logs)
        	)
        	:formats (
            		: (format1
                		:AdminInfo (
                    			:chkpf_uid ("{8634D3A0-385B-EE17-B562-BCECA4F23E5C}")
                    			:ClassName (inspect_logs_formats)
                		)
                		:ver_1 (
                    			: (param1
                        			:AdminInfo (
                            				:chkpf_uid ("{36B523F2-AD6A-3AFC-A3E3-A1F7534B46C7}")
                            				:ClassName (inspect_logs_format_params)
                        			)
                        			:param_type (string_id)
                        			:type (inspect_logs_format_params)
                        			:value ("MSN Messenger - Chat")
                    			)
                		)
                		:excessive_report (true)
                		:id (83)
                		:type (inspect_logs_formats)
            		)
            		: (format2
                		:AdminInfo (
                    			:chkpf_uid ("{0B4201E6-B581-7D7F-D2CF-474C88017B77}")
                    			:ClassName (inspect_logs_formats)
                		)
                		:ver_1 (
                    			: (param1
                        			:AdminInfo (
                            				:chkpf_uid ("{8FE94943-0117-9572-24FD-B91D6522DAC5}")
                            				:ClassName (inspect_logs_format_params)
                        			)
                        			:param_type (string_id)
                        			:type (inspect_logs_format_params)
                        			:value ("Audio is not allowed by the security policy")
                    			)
                		)
                		:excessive_report (true)
                		:id (82)
                		:type (inspect_logs_formats)
            		)
        	)
	        :alert (log)
        	:dynamic_format (72)
	        :enable_excessive (true)
        	:enable_excessive_report (true)
	        :excessive_conn_mask (13)
        	:flags (0)
        	:location (msn_msnms:msnms_chats_track)
        	:type (inspect_log)
        	:unify (false)
    	)
	: (msnms_files_block_file_transfer_http_log
        	:AdminInfo (
            		:chkpf_uid ("{A1621419-1B2B-48DD-2941-AC125416F8EA}")
            		:ClassName (inspect_log)
            		:table (inspect_logs)
        	)
        	:formats (
            		: (format1
                		:AdminInfo (
                    			:chkpf_uid ("{85A8ECC1-6357-4558-1158-58D1B96A63FE}")
                    			:ClassName (inspect_logs_formats)
                		)
                		:ver_1 (
                    			: (param1
                        			:AdminInfo (
                            				:chkpf_uid ("{553381D6-13C9-43EB-F560-8C999B2D613B}")
                            				:ClassName (inspect_logs_format_params)
                        			)
                        			:param_type (string_id)
                        			:type (inspect_logs_format_params)
                        			:value ("MSN Messenger - Files")
                    			)
                		)
                		:excessive_report (true)
                		:id (83)
                		:type (inspect_logs_formats)
            		)
            		: (format2
                		:AdminInfo (
                    			:chkpf_uid ("{5FACCA22-B24C-F7B6-C111-765CB6D0794C}")
                    			:ClassName (inspect_logs_formats)
                		)
                		:ver_1 (
                    			: (param1
                        			:AdminInfo (
                            				:chkpf_uid ("{8CB89938-7E76-8685-3CEB-F01DAF64562D}")
			                            	:ClassName (inspect_logs_format_params)
                        			)
	                     			:param_type (string_id)
	        	                	:type (inspect_logs_format_params)
        	        		        :value ("File Transfer is not allowed by the security policy")
                			)
                		)
		                :excessive_report (true)
                		:id (82)
		                :type (inspect_logs_formats)
            		)
        	)
	        :alert (log)
        	:dynamic_format (72)
	        :enable_excessive (true)
        	:enable_excessive_report (true)
	        :excessive_conn_mask (13)
	        :flags (0)
	        :location (msn_msnms:msnms_files_track)
	        :type (inspect_log)
	        :unify (false)
    	)
	: (msnms_apps_block_application_sharing_http_log
	        :AdminInfo (
        	    	:chkpf_uid ("{AF6DCD9D-9014-C424-E1B3-7A35FAEE7161}")
            		:ClassName (inspect_log)
            		:table (inspect_logs)
        	)
        	:formats (
            		: (format1
	                	:AdminInfo (
        	          		:chkpf_uid ("{FC8B65C7-2BC1-AC46-02D2-27AF987B1370}")
                	    		:ClassName (inspect_logs_formats)
                		)
                		:ver_1 (
		        	    	: (param1
			                        :AdminInfo (
                            				:chkpf_uid ("{DF2C9DA6-F6DD-A0EE-D452-FE33AEF34FF2}")
                            				:ClassName (inspect_logs_format_params)
			                        )
			                        :param_type (string_id)
			                        :type (inspect_logs_format_params)
			                        :value ("MSN Messenger - Application")
		            		)
                		)
                		:excessive_report (true)
                		:id (83)
                		:type (inspect_logs_formats)
            		)
            		: (format2
		                :AdminInfo (
                			:chkpf_uid ("{9BC017C5-9E65-9FBC-DF2C-0C09608E234B}")
			                :ClassName (inspect_logs_formats)
                		)
                		:ver_1 (
                    			: (param1
			                        :AdminInfo (
                            				:chkpf_uid ("{102B4868-DC8A-465B-66C2-21B7CD5F6238}")
                            				:ClassName (inspect_logs_format_params)
			                        )
			                        :param_type (string_id)
			                        :type (inspect_logs_format_params)
			                        :value ("Application Sharing is not allowed by the security policy")
                    			)
                		)
                		:excessive_report (true)
	                	:id (82)
        	        	:type (inspect_logs_formats)
            		)
        	)
	        :alert (log)
        	:dynamic_format (72)
	        :enable_excessive (true)
        	:enable_excessive_report (true)
	        :excessive_conn_mask (13)
        	:flags (0)
	        :location (msn_msnms:msnms_apps_track)
        	:type (inspect_log)
	        :unify (false)
    	)
	: (msnms_apps_block_remote_assistant_http_log
	        :AdminInfo (
        		:chkpf_uid ("{7BDCCBF5-F585-9C87-CB99-2C16922E1218}")
		        :ClassName (inspect_log)
            		:table (inspect_logs)
        	)
	        :formats (
        	    	: (format1
               			:AdminInfo (
                    			:chkpf_uid ("{23ACB939-AF1C-BCB6-52EB-A9A0281947C6}")
                    			:ClassName (inspect_logs_formats)
                		)
		                :ver_1 (
                    			: (param1
			                        :AdminInfo (
                             				:chkpf_uid ("{2C2600BC-D525-FD23-4420-5377E6AC8DAA}")
                            				:ClassName (inspect_logs_format_params)
                        			)
	                        		:param_type (string_id)
			                        :type (inspect_logs_format_params)
                			        :value ("MSN Messenger - Application")
                    			)
	                	)
        	        	:excessive_report (true)
                		:id (83)
                		:type (inspect_logs_formats)
	            	)
            		: (format2
		                :AdminInfo (
        		        	:chkpf_uid ("{41611A4D-BD53-5805-A5BA-A87BBB69907D}")
                		    	:ClassName (inspect_logs_formats)
	                	)
		                :ver_1 (
                    			: (param1
		                        	:AdminInfo (
                            				:chkpf_uid ("{4FAC5D01-9609-FDC9-69A5-9EFBCC7FBFCF}")
                            				:ClassName (inspect_logs_format_params)
                       				)
			                        :param_type (string_id)
                        			:type (inspect_logs_format_params)
			                        :value ("Remote Assistance is not allowed by the security policy")
                    			)
                		)
                		:excessive_report (true)
                		:id (82)
                		:type (inspect_logs_formats)
            		)
        	)
        	:alert (log)
	        :dynamic_format (72)
        	:enable_excessive (true)
	        :enable_excessive_report (true)
	        :excessive_conn_mask (13)
        	:flags (0)
	        :location (msn_msnms:msnms_apps_track)
        	:type (inspect_log)
	        :unify (false)
	)
	: (msnms_apps_block_white_board_http_log
	        :AdminInfo (
            		:chkpf_uid ("{4B0C53C2-0105-FDC5-EAA2-E53CC4B5C0B0}")
            		:ClassName (inspect_log)
            		:table (inspect_logs)
	        )
	        :formats (
            		: (format1
			                :AdminInfo (
			                    :chkpf_uid ("{F7B5711E-C1F2-E7C4-1BF0-B1C25BCCEF5D0}")
			                    :ClassName (inspect_logs_formats)
			                )
			                :ver_1 (
                    			: (param1
			                        :AdminInfo (
                            				:chkpf_uid ("{723FB1F4-E089-AB45-4EF2-0BF11653CC74}")
                            				:ClassName (inspect_logs_format_params)
			                        )
			                        :param_type (string_id)
			                        :type (inspect_logs_format_params)
			                        :value ("MSN Messenger - Application")
			                    )
			                )
			                :excessive_report (true)
			                :id (83)
			                :type (inspect_logs_formats)
            		)
            		: (format2
			                :AdminInfo (
			                    :chkpf_uid ("{FF666B00-AA41-C109-2646-9932C80273D6}")
			                    :ClassName (inspect_logs_formats)
			                )
			                :ver_1 (
			                    : (param1
			                        :AdminInfo (
                            				:chkpf_uid ("{14C39432-0F52-7A28-E75D-DB644C0A6497}")
                            				:ClassName (inspect_logs_format_params)
			                        )
			                        :param_type (string_id)
			                        :type (inspect_logs_format_params)
			                        :value ("Whiteboard is not allowed by the security policy")
			                    )
			                )
			                :excessive_report (true)
			                :id (82)
			                :type (inspect_logs_formats)
            		)
	        )
	        :alert (log)
	        :dynamic_format (72)
	        :enable_excessive (true)
	        :enable_excessive_report (true)
	        :excessive_conn_mask (13)
	        :flags (0)
	        :location (msn_msnms:msnms_apps_track)													
	        :type (inspect_log)
	        :unify (false)
	)
	: (fasttrack_block
		:AdminInfo (
			:LastModified (
				:Time ("Mon Aug 27 14:54:07 2003")
				:By (CheckPoint)
				:From (CheckPoint)
			)
			:chkpf_uid ("{A64C98E4-05E3-46B0-ACCF-B83F873760E6}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:alert (log)
		:unify (false)
		:dynamic_format (-1)
		:excessive_conn_mask (17)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:flags (0)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{93255EA7-15DF-4B00-A74D-920AFEB99C63}")
					:ClassName (inspect_logs_formats)
				)
				:id (83)
				:excessive_report (true)
				:ver_1 (
					: (param1 
						:AdminInfo (
							:chkpf_uid ("{168FBE21-D2BF-465B-A21E-39D860CBCA36}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("Peer to Peer")
					)
				)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{68F90A34-A36E-4BB2-B582-9456F33850E1}")
					:ClassName (inspect_logs_formats)
				)
				:id (82)
				:excessive_report (true)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{D680E93D-3E74-42DC-BBB7-ACB8CCE4CB14}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("Kazaa (Fasttrack) protocol detected on connection")
					)
				)
			)
		)
		:location (p2p_applications:kazaa_application_enforcement:p2p_track_options)
	)
	: (edonkey_block
		:AdminInfo (
			:LastModified (
				:Time ("Mon Aug 27 14:54:07 2003")
				:By (CheckPoint)
				:From (CheckPoint)
			)
			:chkpf_uid ("{A40B6F8A-5DD0-4E8E-BAC9-B3DD75CA8B2A}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:alert (log)
		:unify (false)
		:dynamic_format (-1)
		:excessive_conn_mask (17)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:flags (0)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{780D96CC-422C-48DE-9F04-F5BD51BA1B5C}")
					:ClassName (inspect_logs_formats)
				)
				:id (83)
				:excessive_report (true)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{083DC523-EADD-4119-853B-6194FDFE6FB9}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("Peer to Peer")
					)
				)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{D4BDA72C-AFD0-47B8-B74E-D89C8EF92C01}")
					:ClassName (inspect_logs_formats)
				)
				:id (82)
				:excessive_report (true)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{E303167A-0A22-4881-9AC0-49C013A03E9A}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("eMule (eDonkey) protocol detected on connection")
					)
				)
			)
		)
		:location (p2p_applications:emule_application_enforcement:p2p_track_options)
	)
	: (gnutella_block
		:AdminInfo (
			:LastModified (
				:Time ("Mon Aug 27 14:54:07 2003")
				:By (CheckPoint)
				:From (CheckPoint)
			)
			:chkpf_uid ("{FB84BDD8-81CD-45CD-9E3C-45C8F4F14D31}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:alert (log)
		:unify (false)
		:dynamic_format (-1)
		:excessive_conn_mask (17)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:flags (0)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{5C41EC39-B3DE-490F-8EA4-9C022991A928}")
					:ClassName (inspect_logs_formats)
				)
				:id (83)
				:excessive_report (true)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{CE194FE8-34C6-4FC7-A420-96636A42E80E}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("Peer to Peer")
					)
				)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{81BB800B-565E-444A-9045-B2A049A1A961}")
					:ClassName (inspect_logs_formats)
				)
				:id (82)
				:excessive_report (true)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{047D8900-6853-4D4E-B333-87ED5C826BAF}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("Gnutella protocol detected on connection")
					)
				)
			)
		)
		:location (p2p_applications:gnutella_application_enforcement:p2p_track_options)
	)
	: (bittorrent_block
		:AdminInfo (
			:LastModified (
				:Time ("Mon Oct 27 14:54:07 2003")
				:By (CheckPoint)
				:From (CheckPoint)
			)
			:chkpf_uid ("{03922AAC-3BC0-4997-AD69-003F3DD83718}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:alert (log)
		:unify (false)
		:dynamic_format (-1)
		:excessive_conn_mask (17)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:flags (0)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{CD1AFDCF-CB13-4FAF-9FF7-CE40DE8E5B4B}")
					:ClassName (inspect_logs_formats)
				)
				:id (83)
				:excessive_report (true)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{AA89D3D7-2805-4F45-B98A-B6B25C9E1265}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("Peer to Peer")
					)
				)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{45363177-7F8A-4365-9D09-D0D1FE5AE6C3}")
					:ClassName (inspect_logs_formats)
				)
				:id (82)
				:excessive_report (true)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{D4E46CC8-D238-4AD5-9027-1E83C30B1A19}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("BitTorrent protocol detected on connection")
					)
				)
			)
		)
		:location (p2p_applications:bittorrent_application_enforcement:p2p_track_options)
	)
	: (exeem_block
		:AdminInfo (
			:LastModified (
				:Time ("Mon Oct 27 14:54:07 2003")
				:By (CheckPoint)
				:From (CheckPoint)
			)
			:chkpf_uid ("{9D43EA3A-A4A1-4FCA-B514-BECFA913D087}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:alert (log)
		:unify (false)
		:dynamic_format (-1)
		:excessive_conn_mask (17)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:flags (0)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{D00857EC-8E4B-42E3-9DA2-BF9E29696B59}")
					:ClassName (inspect_logs_formats)
				)
				:id (83)
				:excessive_report (true)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{87EC9A0E-B9D0-4692-8481-1C850857C866}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("Peer to Peer")
					)
				)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{1456D067-130B-4513-AC76-14E74C92EF15}")
					:ClassName (inspect_logs_formats)
				)
				:id (82)
				:excessive_report (true)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{0ED5C385-9AA4-46C9-BBDF-5E6D249BEA9D}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("BitTorrent/eXeem protocol detected on connection")
					)
				)
			)
		)
		:location (p2p_applications:bittorrent_application_enforcement:p2p_track_options)
	)
	: (skype_block
		:AdminInfo (
			:LastModified (
				:Time ("Mon Oct 27 14:54:07 2003")
				:By (CheckPoint)
				:From (CheckPoint)
			)
			:chkpf_uid ("{0929BD6D-622B-444A-9483-A6AAB0437D44}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:alert (log)
		:unify (false)
		:dynamic_format (-1)
		:excessive_conn_mask (1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:flags (0)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{564A6519-4EC5-4EAE-B822-730CF151AE12}")
					:ClassName (inspect_logs_formats)
				)
				:id (83)
				:excessive_report (true)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{125734AF-231A-4E60-B460-CCBD7F939DA7}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("Instant Messengers")
					)
				)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{109BFB6A-10ED-4FFA-845D-9CB7614DD696}")
					:ClassName (inspect_logs_formats)
				)
				:id (82)
				:excessive_report (true)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{D944B1FF-BCEC-4ADE-867A-426CE0A2E716}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("Skype protocol detected on connection")
					)
				)
			)
		)
		:location (p2p_applications:skype_application_enforcement:p2p_track_options)
	)
	: (yahoo_block
		:AdminInfo (
			:LastModified (
				:Time ("Mon Dec 27 13:14:34 2003")
				:By (CheckPoint)
				:From (CheckPoint)
			)
			:chkpf_uid ("{87AADE25-3F19-4C90-84F1-6156B7199872}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:alert (log)
		:unify (false)
		:dynamic_format (-1)
		:excessive_conn_mask (17)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:flags (0)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{A3A5D6D6-0AC4-49CC-B3D6-4071A48C02EB}")
					:ClassName (inspect_logs_formats)
				)
				:id (83)
				:excessive_report (true)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{B3E5FE87-9885-4ED8-9843-B5D1FBF878F8}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("Instant Messengers")
					)
				)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{1611FD50-B79B-4E17-80E6-B9F48FF27200}")
					:ClassName (inspect_logs_formats)
				)
				:id (82)
				:excessive_report (true)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{D8E4900A-BE76-4A3F-A94E-83C07557BE83}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("Yahoo! Messenger protocol detected on connection")
					)
				)
			)
		)
		:location (p2p_applications:yahoo_application_enforcement:p2p_track_options)
	)
	: (icq_block
		:AdminInfo (
			:LastModified (
				:Time ("Mon Dec 27 13:12:54 2003")
				:By (CheckPoint)
				:From (CheckPoint)
			)
			:chkpf_uid ("{F741921C-66B7-4027-BC74-85475016CD26}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:alert (log)
		:unify (false)
		:dynamic_format (-1)
		:excessive_conn_mask (17)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:flags (0)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{07794676-5688-4A0A-AEB9-CBACBF434A20}")
					:ClassName (inspect_logs_formats)
				)
				:id (83)
				:excessive_report (true)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{2B0F4B42-7BF3-40A8-929B-149CBA7FA0C0}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("Instant Messengers")
					)
				)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{1611FD50-B79B-4E17-80E6-B9F48FF27200}")
					:ClassName (inspect_logs_formats)
				)
				:id (82)
				:excessive_report (true)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{C2B80292-4B44-46CD-B845-1847173C8BB6}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("ICQ (AIM) protocol detected on connection")
					)
				)
			)
		)
		:location (p2p_applications:icq_application_enforcement:p2p_track_options)
	)
	: (snmp_version
		:AdminInfo (
			:LastModified (
				:Time ("Mon Aug 27 14:54:07 2003")
				:By (CheckPoint)
				:From (CheckPoint)
			)
			:chkpf_uid ("{AF13760D-B3B2-4E05-8B68-2EF4C0E40D00}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:alert (log)
		:unify (false)
		:dynamic_format (-1)
		:excessive_conn_mask (13)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:flags (0)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{9E8C94A4-51D5-42CB-97AB-477ED71414B1}")
					:ClassName (inspect_logs_formats)
				)
				:type (inspect_logs_formats)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{427CF5DC-277F-4C4B-AA0B-EF8E2208CFE0}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("SNMP Enforcement Violation")
					)
				)
				:excessive_report (true)
				:id (83)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{7165014A-720F-4622-951C-702064197288}")
					:ClassName (inspect_logs_formats)
				)
				:type (inspect_logs_formats)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{25CE9E49-B301-4E09-BFFA-3120F0F8DFB8}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Version earlier than version 3 was detected")
					)
				)
				:excessive_report (true)
				:id (82)
			)
		)
		:location (snmp_track)
	)
	: (snmp_community
		:AdminInfo (
			:LastModified (
				:Time ("Mon Aug 27 14:54:07 2003")
				:By (CheckPoint)
				:From (CheckPoint)
			)
			:chkpf_uid ("{546AE9E9-CD9D-4C82-915B-71CEC54F5B38}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:alert (log)
		:unify (false)
		:dynamic_format (-1)
		:excessive_conn_mask (13)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:flags (0)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{FABBF9D6-7B1B-4228-90DA-542C2C700754}")
					:ClassName (inspect_logs_formats)
				)
				:type (inspect_logs_formats)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{EC8B7B7F-BE06-436E-BE73-C6B3CC1B71D9}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("SNMP Enforcement Violation")
					)
				)
				:excessive_report (true)
				:id (83)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{EE78F771-B49E-423F-8D7F-07B719FD27CD}")
					:ClassName (inspect_logs_formats)
				)
				:type (inspect_logs_formats)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{B52C1803-BB42-451C-B4B0-7040C5300B95}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Bad community was detected")
					)
				)
				:excessive_report (true)
				:id (82)
			)
		)
		:location (snmp_track)
	)
	: (net_quota
		:AdminInfo (
			:LastModified (
				:Time ("Mon Oct 27 14:54:07 2003")
				:By (CheckPoint)
				:From (CheckPoint)
			)
			:chkpf_uid ("{8AE9FECE-7BC4-4370-BA28-7D87A8ED59A9}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:alert (log)
		:unify (false)
		:dynamic_format (-1)
		:excessive_conn_mask (0)
		:enable_excessive (false)
		:enable_excessive_report (false)
		:flags (0)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{D2901616-A30E-4E7D-98B6-EAF192AD4873}")
					:ClassName (inspect_logs_formats)
				)
				:id (83)
				:excessive_report (false)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{5BEF0CBA-BF5E-4D24-A46D-9167BB1C9FD3}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("Network Quota Violation")
					)
				)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{25BFC033-275A-44AE-B0AA-378EBD5838F8}")
					:ClassName (inspect_logs_formats)
				)
				:id (82)
				:excessive_report (false)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{56AEFD14-58B8-4BEF-B989-F8C79C65FA3A}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("Network quota was exceeded")
					)		
				)
			)
		)
		:location (net_quota_log)
	)
	: (dcerpc_992
		:AdminInfo (
			:LastModified (
				:Time ("Mon Oct 27 14:54:07 2003")
				:By (CheckPoint)
				:From (CheckPoint)
			)
			:chkpf_uid ("{CEA1B7BF-16E7-471E-A59F-32336E97AD06}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:alert (log)
		:unify (false)
		:dynamic_format (-1)
		:excessive_conn_mask (13)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:flags (0)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{B75EABB0-6DD2-425B-994A-573FFE7A3849}")
					:ClassName (inspect_logs_formats)
				)
				:id (83)
				:excessive_report (true)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{1597DDFD-6CC6-466D-985C-3F259C9C06A1}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("DCE-RPC Enforcement Violation")
					)	
				)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{216F8CEB-6EFE-43A1-9E0A-6032515E384A}")
					:ClassName (inspect_logs_formats)
				)
				:id (82)
				:excessive_report (true)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{4AEA3B1C-E097-4AA3-92D5-5760FA0E98EB}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("Unallowed UUID in a multi UUID Bind/Alter context request")
					)
				)
			)
		)
		:location ("kernel_props_by_type:string_props:dcerpc_992")
	)
	: (dcerpc_993
		:AdminInfo (
			:LastModified (
				:Time ("Mon Oct 27 14:54:07 2003")
				:By (CheckPoint)
				:From (CheckPoint)
			)
			:chkpf_uid ("{99D72374-1390-4E3B-A61F-9D1A1715C69A}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:alert (alert)
		:unify (false)
		:dynamic_format (-1)
		:excessive_conn_mask (13)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:flags (0)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{BAD17CBB-5125-4A36-976F-A0268B02348C}")
					:ClassName (inspect_logs_formats)
				)
				:id (83)
				:excessive_report (true)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{1F6B26A5-A029-4CCA-975C-F412D39470B8}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("DCE-RPC Enforcement Violation")
					)		
				)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{87A1588F-96FA-4859-9AAD-AC679375765F}")
					:ClassName (inspect_logs_formats)
				)
				:id (82)
				:excessive_report (true)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{AF3DF607-95B8-4967-A943-89B3FFB551F8}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("DCOM buffer overflow attempt")
					)		
				)
			)
		)
		:location ("kernel_props_by_type:string_props:drop_0xd8_track")
	)
	: (dcerpc_994
		:AdminInfo (
			:LastModified (
				:Time ("Mon Oct 27 14:54:07 2003")
				:By (CheckPoint)
				:From (CheckPoint)
			)
			:chkpf_uid ("{3FD235D5-E01C-4EC6-A8E1-E60A8FE4B446}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:alert (alert)
		:unify (false)
		:dynamic_format (-1)
		:excessive_conn_mask (13)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:flags (0)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{24A04A8D-D737-4CAB-A4FD-4D81DAA7FF21}")
					:ClassName (inspect_logs_formats)
				)
				:id (83)
				:excessive_report (true)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{74A32363-66A1-48CA-9771-36A6A761ED63}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("DCE-RPC Enforcement Violation")
					)		
				)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{2C0FF4E5-CFE4-4C1F-8478-A433D02E916A}")
					:ClassName (inspect_logs_formats)
				)
				:id (82)
				:excessive_report (true)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{37691DB1-D9B4-430A-B048-51682692445E}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("Blaster attack blocked")
					)
				)
			)
		)
		:location ("kernel_props_by_type:string_props:drop_ms026_track")
	)
	: (dcerpc_995
		:AdminInfo (
			:LastModified (
				:Time ("Mon Oct 27 14:54:07 2003")
				:By (CheckPoint)
				:From (CheckPoint)
			)
			:chkpf_uid ("{FE5F5299-90FF-457E-9A93-B807AA6CEBF8}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:alert (log)
		:unify (false)
		:dynamic_format (-1)
		:excessive_conn_mask (13)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:flags (0)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{C9F30367-9A9C-451A-841C-22A06EA1EADE}")
					:ClassName (inspect_logs_formats)
				)
				:id (83)
				:excessive_report (true)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{A1C9A514-3723-4044-AE3D-143B27BAEBAD}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("DCE-RPC Enforcement Violation")
					)
				)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{DA0143A5-E36B-4784-9456-98E9B05E9FF9}")
					:ClassName (inspect_logs_formats)
				)
				:id (82)
				:excessive_report (true)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{05FD8F53-9EAA-4C6B-9537-6906CD12355D}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("Unallowed number of context items in Bind/Alter context request")
					)
				)
			)
		)
		:location ("kernel_props_by_type:string_props:MSRPC_PROT_PROPS_LOG")
	)
	: (dcerpc_996
		:AdminInfo (
			:LastModified (
				:Time ("Mon Oct 27 14:54:07 2003")
				:By (CheckPoint)
				:From (CheckPoint)
			)
			:chkpf_uid ("{C792DB44-9009-435F-BC28-B4CD6C1B690B}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:alert (log)
		:unify (false)
		:dynamic_format (-1)
		:excessive_conn_mask (13)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:flags (0)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{12BE880D-3604-4CF7-9CAC-FF85B4322062}")
					:ClassName (inspect_logs_formats)
				)
				:id (83)
				:excessive_report (true)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{6FCC6912-AFA9-4A82-91AB-5B57DA0F5505}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("DCE-RPC Enforcement Violation")
					)
				)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{1120C25E-342A-40B6-972A-CE54854EE606}")
					:ClassName (inspect_logs_formats)
				)
				:id (82)
				:excessive_report (true)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{F4B5B38C-1028-4494-901A-EF785F970EF1}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("Invalid DCE-RPC Type")
					)		
				)
			)
		)
		:location ("kernel_props_by_type:string_props:dcerpc_996")
	)
	: (dcerpc_997
		:AdminInfo (
			:LastModified (
				:Time ("Mon Oct 27 14:54:07 2003")
				:By (CheckPoint)
				:From (CheckPoint)
			)
			:chkpf_uid ("{415C8CE8-866B-4F2B-B4BE-1B35410165D2}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:alert (log)
		:unify (false)
		:dynamic_format (-1)
		:excessive_conn_mask (13)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:flags (0)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{26A5AFA1-359E-4BAC-869E-A81FBA36326D}")
					:ClassName (inspect_logs_formats)
				)
				:id (83)
				:excessive_report (true)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{DF60C83A-D77B-49A3-BFC0-72B7728AD4C5}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("DCE-RPC Enforcement Violation")
					)
				)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{4E861216-FBD6-4FF8-B1DD-5A6EA1689763}")
					:ClassName (inspect_logs_formats)
				)
				:id (82)
				:excessive_report (true)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{9A80A790-FEA0-4F9C-94B6-94CC23E88C07}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("No match on Alter Context request")
					)
				)
			)
		)
		:location ("kernel_props_by_type:string_props:dcerpc_997")
	)
	: (dcerpc_998
		:AdminInfo (
			:LastModified (
				:Time ("Mon Oct 27 14:54:07 2003")
				:By (CheckPoint)
				:From (CheckPoint)
			)
			:chkpf_uid ("{C168C87D-AF80-4760-82D1-F9001C83B979}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:alert (log)
		:unify (false)
		:dynamic_format (-1)
		:excessive_conn_mask (13)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:flags (0)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{6F1FC6CD-3CC7-4132-8CDA-ACB9AD8749B6}")
					:ClassName (inspect_logs_formats)
				)
				:id (83)
				:excessive_report (true)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{E43F336C-4EA2-4061-BB31-64CB548D2A74}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("DCE-RPC Enforcement Violation")
					)
				)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{ABB85028-13F1-4053-86D8-5113AFD6B10F}")
					:ClassName (inspect_logs_formats)
				)
				:id (82)
				:excessive_report (true)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{1783C422-AFCA-4164-8834-64E5E7902DDE}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("No match on Bind request")
					)
				)
			)
		)
		:location ("kernel_props_by_type:string_props:dcerpc_998")
	)
	: (dcerpc_999
		:AdminInfo (
			:LastModified (
				:Time ("Mon Oct 27 14:54:07 2003")
				:By (CheckPoint)
				:From (CheckPoint)
			)
			:chkpf_uid ("{2B82C839-C410-488A-987C-5178CCC1BD22}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:alert (alert)
		:unify (false)
		:dynamic_format (-1)
		:excessive_conn_mask (13)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:flags (0)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{F5F78B53-5175-4A4A-B9BE-2E513AD5270A}")
					:ClassName (inspect_logs_formats)
				)
				:id (83)
				:excessive_report (true)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{4DF52770-A5A3-4E73-BDAA-4C9A04968A42}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("DCE-RPC Enforcement Violation")
					)
				)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{EC879901-3188-4A0B-97BE-64005CCA2068}")
					:ClassName (inspect_logs_formats)
				)
				:id (82)
				:excessive_report (true)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{4F53F297-4414-44DB-9EBE-351453AC3D8C}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("No match on Bind response")
					)
				)
			)
		)
		:location ("kernel_props_by_type:string_props:dcerpc_999")
	)
	: (dcerpc_unallowed_uuid
		:AdminInfo (
			:LastModified (
				:Time ("Mon Oct 27 14:54:07 2003")
				:By (CheckPoint)
				:From (CheckPoint)
			)
			:chkpf_uid ("{CF4C6CD2-6FFB-4C98-9E98-73DE4C52C3AA}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:alert (log)
		:unify (false)
		:dynamic_format (84)
		:excessive_conn_mask (13)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:flags (0)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{A4349356-79B5-4F64-8839-E5F7839CBC86}")
					:ClassName (inspect_logs_formats)
				)
				:id (83)
				:excessive_report (true)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{30C4CDAD-136C-468E-B7F2-F95F0B9F62DD}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("DCE-RPC Enforcement Violation")
					)
				)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{A54DD17B-D774-46E4-ACE8-6E6D148F9E5D}")
					:ClassName (inspect_logs_formats)
				)
				:id (82)
				:excessive_report (true)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{CDE4DF40-7E3F-42C4-A19C-C0E7E2DF8FE9}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("UUID is not allowed through the Rule Base")
					)
				)
			)
		)
		:location ("kernel_props_by_type:string_props:dcerpc_unallowed_uuid")
	)
	: (bad_port_command
		:AdminInfo (
			:LastModified (
				:Time ("Mon Oct 27 14:54:07 2003")
				:By (CheckPoint)
				:From (CheckPoint)
			)
			:chkpf_uid ("{42CA666B-BC75-47EB-A3FB-7E7DE874AC50}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:alert (alert)
		:unify (false)
		:dynamic_format (-1)
		:excessive_conn_mask (13)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:flags (0)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{DB4F0B8B-A0DA-4E7C-AEB3-C3ED1C0EBEF5}")
					:ClassName (inspect_logs_formats)
				)
				:id (83)
				:excessive_report (true)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{E993770F-877A-443A-AACD-A6580E24FD09}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("DCE-RPC Enforcement Violation")
					)
				)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{4D8B3BD5-82C8-4404-8C27-FD18952D92E2}")
					:ClassName (inspect_logs_formats)
				)
				:id (82)
				:excessive_report (true)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{4139FCD1-BB17-437E-8996-C529737CE3C5}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("Source IP in port command is different than the Server IP")
					)
				)
			)
		)
		:location ("kernel_props_by_type:string_props:bad_port_command")
	)
	: (dcerpc_no_auth
		:AdminInfo (
			:LastModified (
				:Time ("Mon Oct 27 14:54:07 2003")
				:By (CheckPoint)
				:From (CheckPoint)
			)
			:chkpf_uid ("{D87E1DF2-DFDC-45C6-BA2B-B62E13BE61C2}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:alert (log)
		:unify (false)
		:dynamic_format (-1)
		:excessive_conn_mask (13)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:flags (0)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{9CA8D4AA-14E0-4C3E-BDEB-286BFF3CBA13}")
					:ClassName (inspect_logs_formats)
				)
				:id (83)
				:excessive_report (true)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{2003092D-F3CF-494C-B91B-3BE36F6E9B4A}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("DCE-RPC Enforcement Violation")
					)
				)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{35157A15-5830-4FD6-90A4-6778CB81A0FA}")
					:ClassName (inspect_logs_formats)
				)
				:id (82)
				:excessive_report (true)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{3E1BAAA7-5374-4D8D-8857-D95E17588076}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("DCOM BIND request with no authentication")
					)
				)
			)
		)
		:location ("kernel_props_by_type:string_props:dcerpc_no_auth")
	)
	: (CPDShield_blocklist
		:AdminInfo (
			:LastModified (
				:Time ("Sun Mar 7 18:39:00 2004")
				:By (CheckPoint)
				:From (CheckPoint)
			)
			:chkpf_uid ("{FAC7474C-11CD-43B7-9001-3FCC94FD9BAD}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:alert (alert)
		:unify (false)
		:dynamic_format (-1)
		:excessive_conn_mask (29)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:flags (0)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{1FDDD171-CCCD-4C2D-A33C-4C6E41319E95}")
					:ClassName (inspect_logs_formats)
				)
				:id (83)
				:excessive_report (true)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{7BE45967-FE88-4EF1-8F3B-D39F686FA980}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("Storm Center Block List Enforcement")
					)
				)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{2558DACE-A9CD-4312-B4A1-F3EA7DC3B18F}")
					:ClassName (inspect_logs_formats)
				)
				:id (82)
				:excessive_report (true)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{3114F03A-565E-475F-94B7-EE495E8E8C0E}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("Packet originated from a host on the DShield block list")
					)
				)
			)
		)
		:location (storm_center_list:DShield:storm_center_downstream:track)
	)
	: (snmp_ro
		:AdminInfo (
			:chkpf_uid ("{D0272A86-CB39-11D8-90FC-C21D2EDD2B2B}")
			:ClassName (inspect_log)
			:table (inspect_logs)
			:LastModified (
				:Time ("Thu Jul  1 08:36:57 2004")
				:By (aa)
				:From (liorsol)
			)
		)
		:alert (none)
		:dynamic_format (87)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{D02A0EE0-CB39-11D8-90FC-C21D2EDD2B2B}")
					:ClassName (inspect_logs_formats)
				)
				:excessive_report (true)
				:id (81)
				:type (inspect_logs_formats)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{D02B6B96-CB39-11D8-90FC-C21D2EDD2B2B}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("SNMP: Non read operation")
					)
				)
			)
		)
		:location (snmp_track)
		:type (inspect_log)
		:unify (false)
	)
	: (snmp_fw_asn_error
		:AdminInfo (
			:chkpf_uid ("{5027F0E4-CB44-11D8-BAC5-C21D2EDDC9C9}")
			:ClassName (inspect_log)
			:table (inspect_logs)
			:LastModified (
				:Time ("Thu Jul  1 09:52:07 2004")
				:By (aa)
				:From (liorsol)
			)
		)
		:alert (none)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{502AC1AC-CB44-11D8-BAC5-C21D2EDDC9C9}")
					:ClassName (inspect_logs_formats)
				)
				:excessive_report (true)
				:id (81)
				:type (inspect_logs_formats)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{502C1ED0-CB44-11D8-BAC5-C21D2EDDC9C9}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("SNMP: ASN integer representation too long")
					)
				)
			)
		)
		:location (snmp_track)
		:type (inspect_log)
		:unify (false)
	)
	: (snmp_asm_asn_error
		:AdminInfo (
			:chkpf_uid ("{504ABF20-CB44-11D8-BAC5-C21D2EDDC9C9}")
			:ClassName (inspect_log)
			:table (inspect_logs)
			:LastModified (
				:Time ("Thu Jul  1 09:52:07 2004")
				:By (aa)
				:From (liorsol)
			)
		)
		:alert (none)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{D02A0EE0-CB39-11D8-90FC-C21D2EDD2B2B}")
					:ClassName (inspect_logs_formats)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{D02B6B96-CB39-11D8-90FC-C21D2EDD2B2B}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("SNMP Enforcement Violation")
					)
				)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{504E843E-CB44-11D8-BAC5-C21D2EDDC9C9}")
					:ClassName (inspect_logs_formats)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
				:ver_1 (
					: (param2
						:AdminInfo (
							:chkpf_uid ("{504FE6A8-CB44-11D8-BAC5-C21D2EDDC9C9}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("ASN integer representation too long")
					)
				)
			)
		)
		:location (snmp_track)
		:type (inspect_log)
		:unify (false)
	)
	: (pptp_violation
		:AdminInfo (
			:chkpf_uid ("{091C0208-CA68-11D8-BF62-000000003838}")
			:ClassName (inspect_log)
			:table (inspect_logs)
			:LastModified (
				:Time ("Wed Jun 30 07:35:18 2004")
				:By (aa)
				:From (lilith)
			)
		)
		:alert (none)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (7)
		:flags (0)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{091E4E82-CA68-11D8-BF62-000000003838}")
					:ClassName (inspect_logs_formats)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{091F4030-CA68-11D8-BF62-000000003838}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Malformed PPTP Message")
					)
				)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{09222034-CA68-11D8-BF62-000000003838}")
					:ClassName (inspect_logs_formats)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
				:ver_1 (
					: (param2
						:AdminInfo (
							:chkpf_uid ("{09231926-CA68-11D8-BF62-000000003838}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Malformed PPTP message was detected")
					)
				)
			)
		)
		:location ("kernel_props_by_type:string_props:pptp_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dcerpc_uuid_str
		:AdminInfo (
			:LastModified (
				:Time ("Mon Oct 27 14:54:07 2003")
				:By (CheckPoint)
				:From (CheckPoint)
			)
			:chkpf_uid ("{18EC6B97-387C-426C-BFBA-0B7830BBB6B1}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:alert (log)
		:unify (false)
		:dynamic_format (57)
		:excessive_conn_mask (13)
		:enable_excessive (false)
		:enable_excessive_report (false)
		:flags (0)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{D31A6A63-3FE6-4FC3-AEC8-D0785B130EC8}")
					:ClassName (inspect_logs_formats)
				)
				:id (81)
				:excessive_report (false)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{912A1FB8-06B9-4AFA-8498-F6E94BFFF197}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("DCE-RPC Rule: UUID Enforcement")
					)
				)
			)
		)
		:location ()
	)
	: (dcerpc_uuid_sk
		:AdminInfo (
			:LastModified (
				:Time ("Mon Oct 27 14:54:07 2003")
				:By (CheckPoint)
				:From (CheckPoint)
			)
			:chkpf_uid ("{16EB297B-4853-177D-401A-32A1FABF1912}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:alert (log)
		:unify (false)
		:dynamic_format (57)
		:excessive_conn_mask (13)
		:enable_excessive (false)
		:enable_excessive_report (false)
		:flags (0)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{85606D50-3290-C1A2-77A8-F8AC1F4FF107}")
					:ClassName (inspect_logs_formats)
				)
				:id (81)
				:excessive_report (false)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{CF595717-E588-0FA8-CC63-F070DBD0CCE8}")
							:ClassName (inspect_logs_format_params)
						)
						:type (inspect_logs_format_params)
						:param_type (string_id)
						:value ("Blocked DCE-RPC Interface over then EPM on port 135 (See sk45029)")
					)
				)
			)
		)
		:location ()
	)
	: (X11_connection
		:AdminInfo (
			:chkpf_uid ("{F3718FE0-FFFA-11D8-90C7-000000000707}")
			:ClassName (inspect_log)
			:table (inspect_logs)
			:LastModified (
				:Time ("Mon Sep  6 11:50:29 2004")
				:By (aa)
				:From (tomlinux)
			)
		)
		:alert (log)
		:dynamic_format (57)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{F371E0D0-FFFA-11D8-90C7-000000000707}")
					:ClassName (inspect_logs_formats)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{F37204B6-FFFA-11D8-90C7-000000000707}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("X11 Enforcement Violation")
					)
				)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{F3724AAC-FFFA-11D8-90C7-000000000707}")
					:ClassName (inspect_logs_formats)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
				:ver_1 (
					: (param2
						:AdminInfo (
							:chkpf_uid ("{F3726B04-FFFA-11D8-90C7-000000000707}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("X11 is not allowed through service 'ANY'. To enable, create an earlier rule that explicitly allows X11.")
					)
				)
			)
		)
		:location ()
		:type (inspect_log)
		:unify (false)
	)
	: (dcerpc_lookup
		:AdminInfo (
			:chkpf_uid ("{3E7C3F98-00E7-11D9-9CBB-000000007676}")
			:ClassName (inspect_log)
			:table (inspect_logs)
			:LastModified (
				:Time ("Tue Sep  7 16:01:57 2004")
				:By (aa)
				:From (tomlinux)
			)
		)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{3E7ECE66-00E7-11D9-9CBB-000000007676}")
					:ClassName (inspect_logs_formats)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{3E7F1754-00E7-11D9-9CBB-000000007676}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("DCE-RPC interface scanning detected")
					)
				)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{3E7F77BC-00E7-11D9-9CBB-000000007676}")
					:ClassName (inspect_logs_formats)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
				:ver_1 (
					: (param2
						:AdminInfo (
							:chkpf_uid ("{3E7F9FE4-00E7-11D9-9CBB-000000007676}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("DCE-RPC Enforcement Violation")
					)
				)
			)
		)
		:location ("kernel_props_by_type:string_props:dcerpc_lookup_log")
		:type (inspect_log)
		:unify (false)
	)
	: (snmp_empty_community
		:AdminInfo (
			:chkpf_uid ("{BDD07662-2C28-4EAE-AFC0-0D016AF2DCDF}")
			:ClassName (inspect_log)
			:table (inspect_logs)
			:LastModified (
				:Time ("Sun Oct 31 08:40:43 2004")
				:By (aa)
				:From (fistuk9)
			)
		)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{E63EA329-03B0-4D1D-9DB8-2988DAC9ACB5}")
					:ClassName (inspect_logs_formats)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{A7E9ECD9-3366-4D59-81ED-6FBC765DDDD8}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("SNMP Enforcement Violation")
					)
				)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{7A7D08E7-AE1D-439B-9260-999D5E7D6B32}")
					:ClassName (inspect_logs_formats)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
				:ver_1 (
					: (param2
						:AdminInfo (
							:chkpf_uid ("{E39476DE-356B-4B6F-91D3-AC1AD399B785}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("An snmp connection attempt with an empty snmp community")
					)
				)
			)
		)
		:location (snmp_track)
		:type (inspect_log)
		:unify (false)
	)
	: (ftp_blocked_cmds_log
		:AdminInfo (
			:chkpf_uid ("{2BCF8735-047B-4A10-A8B1-2E70D0E404F6}")
			:ClassName (inspect_log)
			:table (inspect_logs)
			:icon (Unknown)
		)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{61F9FFAA-54C2-465B-8E48-FC22A73A4695}")
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{1A72CC94-A3DA-4083-859E-066290A15FD8}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("FTP Command")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{F9E31F5F-6307-47BE-9C1A-65AFA510E7B8}")
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{C32864E1-DB28-49B6-9D85-C58BE5DA8721}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("FTP blocked command was detected")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
		)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location (ftp_blocked_cmds_track)
		:type (inspect_log)
		:unify (false)
	)
	: (http_worm_catcher_log
		:AdminInfo (
			:chkpf_uid ("{7115739D-1F91-426F-8895-B9A1EAE22687}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{298320F3-9DAA-4232-BE8B-80FB69A3A415}")
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{EE8F9188-83F8-409D-A7E8-DB8613A6A0B6}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
	                    :type (inspect_logs_format_params)
	                    :value ("HTTP Worm Catcher") # Attack Name
					)
				)
				:excessive_report (false)
				:id (83)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{C0A397AA-A40E-48D6-96A5-B97876B4B04A}")
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{4B05D9F6-3B34-4DD9-B02B-8138FC1F904E}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
	                    :type (inspect_logs_format_params)
	                    :value ("WSE0070001 worm catcher pattern found") # Attack Info
					)
				)
				:excessive_report (false)
				:id (82)
				:type (inspect_logs_formats)
			)
		)
		:type (inspect_log)
		:alert (log)
		:dynamic_format (72)
		:enable_excessive (false)
		:enable_excessive_report (false)
		:excessive_conn_mask (13)
		:flags (0)
		:location (asm_http_worm_catcher_log) # Log Location (path of track attribute)
		:unify (false)
	)
	: (http_header_rejection_log
		:AdminInfo (
			:chkpf_uid ("{E63CC2D1-9C10-4B28-B0EA-D392D2713A66}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{F5865D2E-DD16-4EAA-B3D7-4EE603698AA7}")
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{9AE484E6-93DE-4BC9-BE01-A23D12B56E0C}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
	                    :type (inspect_logs_format_params)
	                    :value ("Header Rejection") # Attack Name
					)
				)
				:excessive_report (false)
				:id (83)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{291E74ED-7FC7-49E7-99FD-CA868DB18472}")
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{D166EC80-BD53-4990-8244-B579A4C30CEE}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
	                    :type (inspect_logs_format_params)
	                    :value ("WSE0100001 header rejection pattern found in request") # Attack Info
					)
				)
				:excessive_report (false)
				:id (82)
				:type (inspect_logs_formats)
			)
		)
		:type (inspect_log)
		:alert (log)
		:dynamic_format (72)
		:enable_excessive (false)
		:enable_excessive_report (false)
		:excessive_conn_mask (13)
		:flags (0)
		:location (http_header_rejection:http_header_rejection_track) # Log Location (path of track attribute)
		:unify (false)
	)
	: (http_ascii_only_request_form_fields_log
		:AdminInfo (
			:chkpf_uid ("{7D24317A-632C-40D3-9F7B-6074A0D1615C}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{02C1C4D2-9A44-4A03-A450-20F558ED619A}")
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{9205335E-2E23-434B-80AD-435D7612453F}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
	                    :type (inspect_logs_format_params)
	                    :value ("ASCII Only Request") # Attack Name
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{14C27022-AAF5-48A2-AE04-30A0B56021BE}")
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{C24488FC-8F98-43FF-8D50-AF749CFF3DCA}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
	                    :type (inspect_logs_format_params)
	                    :value ("WSE0060002 invalid character detected in request form input") # Attack Info
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
		)
		:type (inspect_log)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location (http_request_validity_track) # Log Location (path of track attribute)
		:unify (false)
	)
	: (http_ascii_only_request_url_log
		:AdminInfo (
			:chkpf_uid ("{41116EF0-99DF-4648-8D07-F8B8791315D0}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{313578E9-ADB1-4B18-B8AB-B02F932619D8}")
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{57B0D841-7B26-43E7-9620-C27B1559C63B}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
	                    :type (inspect_logs_format_params)
	                    :value ("ASCII Only Request") # Attack Name
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{BB0A0B3A-CB72-4052-ABFE-B00EC92D186B}")
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{55618206-B23D-4C8A-AEAA-75D5671217EF}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
	                    :type (inspect_logs_format_params)
	                    :value ("WSE0060001 invalid character detected in request URL") # Attack Info
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
		)
		:type (inspect_log)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location (http_request_validity_track) # Log Location (path of track attribute)
		:unify (false)
	)
	: (http_ascii_only_request_header_log
		:AdminInfo (
			:chkpf_uid ("{ED719F25-1666-4DB7-8230-D53036438135}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{49C51484-1087-4F5E-B557-676D1FE03ACC}")
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{D66BA87B-6E82-4976-B947-704CC48CA3C7}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
	                    :type (inspect_logs_format_params)
	                    :value ("ASCII Only Request") # Attack Name
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{2E772F48-BA1F-4353-A020-D0A99AB5A9F5}")
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{DFF8ABC2-5068-43FF-B601-03B1A71D95C1}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
	                    :type (inspect_logs_format_params)
	                    :value ("WSE0060004 invalid character detected in request headers") # Attack Info
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
		)
		:type (inspect_log)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location (http_request_validity_track) # Log Location (path of track attribute)
		:unify (false)
	)
	: (http_ascii_only_response_log
		:AdminInfo (
			:chkpf_uid ("{E6C99444-183B-4BDC-BA4A-C7CD45989A72}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{3846CBD2-F785-4527-B32C-BF4E1A85038E}")
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{AA32EFE3-AE78-4A91-9871-3390DB4C4C58}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
	                    :type (inspect_logs_format_params)
	                    :value ("ASCII Only Response Header") # Attack Name
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{195819A2-5A40-4A88-BFCB-70E93CE39886}")
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{5026D4D6-5569-4C44-85FC-5298BE85D3FA}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
	                    :type (inspect_logs_format_params)
	                    :value ("WSE0060003 invalid character detected in response headers") # Attack Info
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
		)
		:type (inspect_log)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location (http_response_validity_track) # Log Location (path of track attribute)
		:unify (false)
	)
	: (cifs_worm_catcher_log
		:AdminInfo (
			:chkpf_uid ("{644434FD-45D7-4E04-9AC2-2B036830DB76}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{F935B38A-B1F1-455B-B95E-8BDA1FEB97DC}")
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{F110A389-BEC1-4634-9F78-A6836FC6FC4D}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("CIFS Worm Catcher")
					)
				)
				:excessive_report (false)
				:id (83)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{013C134E-AC13-463F-890F-7AC3D57B50DF}")
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{37E746DD-CDDB-407A-B775-A69B045488DA}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("CIFS worm catcher pattern found")
					)
				)
				:excessive_report (false)
				:id (82)
				:type (inspect_logs_formats)
			)
		)
		:alert (log)
		:dynamic_format (72)
		:enable_excessive (false)
		:enable_excessive_report (false)
		:excessive_conn_mask (13)
		:flags (0)
		:location (general_cifs_worm_catcher_protection:asm_cifs_worm_catcher_log)
		:type (inspect_log)
		:unify (false)
	)
	: (ftp_block_known_ports_log
		:AdminInfo (
			:chkpf_uid ("{466904BF-BA78-457A-8C41-EC3010BD4F98}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{E41308D1-9CA6-4B9C-B5D6-25EC7FB2B78C}")
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{6EF517AC-8C6C-44BF-8E06-A1BD79941A47}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("FTP Known Port")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{F8864675-E76B-4C7B-8524-4E4A4C2CF0B8}")
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{8CA3EF36-3066-4F67-87EC-BAA38548F863}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("FTP data connection to known port was blocked")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
		)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location (ftp_known_ports_track)
		:type (inspect_log)
		:unify (false)
	)
	: (Kazaa_http_log
		:AdminInfo (
			:chkpf_uid ("{974B2EF1-7ED0-43D8-8049-0898C68BD899}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{A8277180-24F1-4D48-A78D-0BD85C39CEFC}")
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{E838D507-734B-44DF-B73E-B45EB3334F31}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Peer to Peer")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{30240D65-E6CA-4561-8DF2-E90E4483DEA8}")
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{85687F72-C076-488D-955E-8E8BBCC44C0A}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("WSE0140001 peer to peer pattern found, application: Kazaa")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
		)
		:type (inspect_log)
		:alert (log)
		:dynamic_format (72)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (9)
		:flags (0)
		:location (p2p_applications:kazaa_application_enforcement:p2p_track_options)
		:unify (false)
	)
	: (Gnutella_http_log
		:AdminInfo (
			:chkpf_uid ("{AB39BB8C-6A15-4715-85BE-281FFC943B49}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{CE196AB2-5443-467B-B318-26D71876404F}")
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{B101FFDC-816B-4F4F-8E6C-DCC8447C9039}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Peer to Peer")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{F18A711E-3442-4081-A79D-9C9DB66AEDC9}")
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{E9FCB477-B39E-4153-9D8F-2DED52EB42CE}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("WSE0140001 peer to peer pattern found, application: Gnutella")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
		)
		:type (inspect_log)
		:alert (log)
		:dynamic_format (72)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (9)
		:flags (0)
		:location (p2p_applications:gnutella_application_enforcement:p2p_track_options)
		:unify (false)
	)
	: (BitTorrent_http_log
		:AdminInfo (
			:chkpf_uid ("{7EC6B163-AC61-4360-B7F4-EF4D791FAEEC}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{A1C2882A-B345-4645-B6DD-E33252EB8723}")
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{B6CACBAA-0D2E-4043-96BD-40B1E663FC8A}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Peer to Peer")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{3B907780-B46F-4F82-B092-2F0C0C058C8A}")
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{45311B11-E49F-4666-B7E7-270029056357}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("WSE0140001 peer to peer pattern found, application: BitTorrent")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
		)
		:type (inspect_log)
		:alert (log)
		:dynamic_format (72)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (9)
		:flags (0)
		:location (p2p_applications:bittorrent_application_enforcement:p2p_track_options)
		:unify (false)
	)
	: (eMule_http_log
		:AdminInfo (
			:chkpf_uid ("{B1720863-AC24-4E2D-AC4B-07E688FEF5C8}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{35230C9E-F39E-4E87-954F-3EF4CCB9B562}")
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{753C5482-34CB-45F0-A463-36CE3CBA8AE8}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Peer to Peer")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{C7DC255B-2534-4F20-87E8-1050E7F658FB}")
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{4DD6A670-B5B2-48E2-BB2D-6497B9D2DFF5}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("WSE0140001 peer to peer pattern found, application: eMule")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
		)
		:type (inspect_log)
		:alert (log)
		:dynamic_format (72)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (9)
		:flags (0)
		:location (p2p_applications:emule_application_enforcement:p2p_track_options)
		:unify (false)
	)
	: (Skype_http_log
		:AdminInfo (
			:chkpf_uid ("{0940B2DE-5EA5-45E2-BAE0-82964F3314F9}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{268B6E30-5FEF-4F4F-8FEE-269F1A47BED2}")
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{79AA890A-4182-44F5-A810-D99C14FF423F}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Instant Messengers")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{3A090DC7-2BB8-4CD3-BD81-84AF1F440633}")
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{215A9CAB-04C9-403E-B414-323D0603A31E}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("WSE0180001 instant messenger pattern found, application: Skype")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
		)
		:type (inspect_log)
		:alert (log)
		:dynamic_format (72)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (9)
		:flags (0)
		:location (p2p_applications:skype_application_enforcement:p2p_track_options)
		:unify (false)
	)
	: (Yahoo_http_log
		:AdminInfo (
			:chkpf_uid ("{EA008AEA-F859-4A08-8C5F-98019CE0312C}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{5BDB539B-7B70-4288-A4BF-498FA758B153}")
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{4E01FBB7-8404-44A7-A2CF-0712A2338604}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Instant Messengers")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{7EFEA724-25C6-46C7-90D3-F0034021A49C}")
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{19A02E17-6556-446E-B48D-929A73BECFB0}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("WSE0180001 instant messenger pattern found, application: Yahoo")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
		)
		:type (inspect_log)
		:alert (log)
		:dynamic_format (72)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (9)
		:flags (0)
		:location (p2p_applications:yahoo_application_enforcement:p2p_track_options)
		:unify (false)
	)
	: (ICQ_http_log
		:AdminInfo (
			:chkpf_uid ("{AEA92C6A-7C1E-4361-A74D-313FA3FFB42D}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:formats (
			: (format1
				:AdminInfo (
					:chkpf_uid ("{309B6B87-8D11-41EE-B3D7-27D98C60425F}")
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{67244E20-C8B7-4C19-95F3-7F8467C3C7F4}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Instant Messengers")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:chkpf_uid ("{64BDCC4E-837D-4500-AC41-FBE879D21644}")
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:chkpf_uid ("{3D3ADFB5-CD1B-46D8-8C43-F0129A91594B}")
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("WSE0180001 instant messenger pattern found, application: ICQ")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
		)
		:type (inspect_log)
		:alert (log)
		:dynamic_format (72)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (9)
		:flags (0)
		:location (p2p_applications:icq_application_enforcement:p2p_track_options)
		:unify (false)
	)
		: (dynlog_sip_block_basic_auth
		:AdminInfo (
			:chkpf_uid ("{4854F666-55D7-4A3B-99D9-2E3D7EE1AD10}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Basic authorization is not allowed by the security policy")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Basic Authorization detected")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_sip_block_basic_auth_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_sip_block_notify_substate
		:AdminInfo (
			:chkpf_uid ("{5C96D0AA-CD0D-4F65-9EDC-35590F1F4E01}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Invalid or missing 'Subscription-State' header")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("NOTIFY message with Invalid Subscription-State header")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_sip_block_notify_substate_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_sip_block_unrec_err
		:AdminInfo (
			:chkpf_uid ("{5854192E-582F-4168-BC2D-AF1B0D2A0A8B}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Firewall cannot process this packet in the normal VoIP flow")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Unrecoverable SIP inspection error occurred")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_sip_block_unrec_err_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_sip_strict_protocol
		:AdminInfo (
			:chkpf_uid ("{922D301F-BBCE-457D-A99A-C01FF90E8D16}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("May be one of the following options: 1)Out of state SIP message 2)Not a part of any SIP transaction 3)Response to unknown request 4)Illegal IP-Address, possible spoofing")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("SIP protocol flow violation detected")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_sip_strict_protocol_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_sip_header_format
		:AdminInfo (
			:chkpf_uid ("{46D84E7B-A292-4561-83C4-0106310A61C2}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Invalid header format")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("SIP header with invalid format detected")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_sip_header_format_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_sip_mndtry_fields
		:AdminInfo (
			:chkpf_uid ("{E9F489BD-DA5D-46D0-B81D-4F989A235C72}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("May be one of the following options: 1)Invalid or missing 'To' header 2)Invalid or missing 'From' header 3)Invalid or missing 'Call-ID' header 4)Invalid or missing 'Cseq' header")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Mandatory fields deficiency detected")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_sip_mndtry_fields_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_sip_singl_filed_occur
		:AdminInfo (
			:chkpf_uid ("{7CF24209-653A-44A6-8483-61E255F4D504}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Multiple occurrences of one of the headers: Cseq/To/From/Max-Forwards/Call-ID/Content-Length")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("SIP header field appears more than once")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_sip_singl_filed_occur_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_sip_blk_hdr_invalid
		:AdminInfo (
			:chkpf_uid ("{E96F49FF-526D-4f7A-8D1B-75ABA304A97B}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("May be one of the following: Invalid or missing headers (For example 'To' or 'Allow' or 'Date' or 'Warning' or 'Expires' or 'Contact' or 'Content-Length' or 'Expires' or 'Max-Forwards')")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Message with invalid header value detected")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_sip_blk_hdr_invalid_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_sip_blk_sdp_inval
		:AdminInfo (
			:chkpf_uid ("{020BF446-F0B3-41F2-ACE1-2D223B064E73}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Malformed SDP format")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Message with invalid SDP format detected")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_sip_blk_sdp_inval_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_sip_strtln_invld
		:AdminInfo (
			:chkpf_uid ("{E915C0FA-3EDB-4F26-AF99-29879F917465}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Illegal format in 'Start-Line'")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Message with invalid format in Start-Line detected")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_sip_strtln_invld_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_sip_viahdr_invld
		:AdminInfo (
			:chkpf_uid ("{5E73B6EF-173C-4B0D-88BD-2A82A745EC6E}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Invalid or missing 'Via' header")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Message with invalid format in Via header detected")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_sip_viahdr_invld_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_sip_hdrs_invalid_frmt
		:AdminInfo (
			:chkpf_uid ("{B06F4DA7-44E7-42EE-A3BC-91E5472014C9}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("May be one of the following options: 1)Illegal SIP-URI format in 'From'/'To' header 2)Illegal SIP-URI format in 'Start-Line' 3)Illegal SIP-URI format in 'Contact' header")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Message with invalid format in header with username detected")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_sip_hdrs_invalid_frmt_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_sip_sdp_ip_invalid
		:AdminInfo (
			:chkpf_uid ("{A7760EE1-87FA-4CEF-B079-9992FB35337E}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Invalid SDP header")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Message with invalid IP address in SDP header detected")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_sip_sdp_ip_invalid_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_sip_sdp_invld_port
		:AdminInfo (
			:chkpf_uid ("{A449C41C-27AB-4EF8-A778-F755F2DDD428}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Invalid SDP header")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Message with invalid port in SDP header detected")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_sip_sdp_invld_port_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_sip_cseqhdr_invldfrmt
		:AdminInfo (
			:chkpf_uid ("{82EE1039-1BBC-4649-92EC-2067DDBA8978}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Invalid or missing 'Cseq' header")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Message with invalid format in CSeq header detected")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_sip_cseqhdr_invldfrmt_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_sip_blk_unreg_users
		:AdminInfo (
			:chkpf_uid ("{01C5AAD3-8AB4-4741-BD8A-CDAA3B825861}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("SIP calls between unregistered users are not allowed by the security policy")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Call from unregistered user detected")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_sip_blk_unreg_users_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_sip_blk_proxy_failovr
		:AdminInfo (
			:chkpf_uid ("{BC76B984-0BF7-4BB6-B1FE-D1982996D921}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("SIP proxy failover is not allowed by the security policy")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("SIP proxy failover detected")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_sip_blk_proxy_failovr_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_sip_block_early_media
		:AdminInfo (
			:chkpf_uid ("{F7409003-7A99-497B-86C9-65B95EC7D759}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("SIP Early Media is not allowed by the security policy")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("SIP Early Media detected")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_sip_block_early_media_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_sip_blk_audio_traffic
		:AdminInfo (
			:chkpf_uid ("{154003DB-65C1-4DEF-87D5-F1A766CB8924}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("SIP audio is not allowed by the security policy")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Attempt to open Audio connection detected")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_sip_blk_audio_traffic_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_sip_blk_video_traffic
		:AdminInfo (
			:chkpf_uid ("{03998219-C31A-41E1-909C-B9245F838DFA}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("SIP video is not allowed by the security policy")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Attempt to open Video connection detected")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_sip_blk_video_traffic_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_sip_blk_instnt_msging
		:AdminInfo (
			:chkpf_uid ("{860EF32B-5A39-48D4-84B6-6AE5A264A86A}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("SIP Instant messaging is not allowed by the security policy")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Instant msaging detected")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_sip_blk_instnt_msging_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_sip_media_admission_control
		:AdminInfo (
			:chkpf_uid ("{A38B4517-731E-49A5-8C7F-DEA6918A7E47}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value (" ")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Media admission control violation")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_sip_media_admission_control_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_sip_block_keep_alive
		:AdminInfo (
			:chkpf_uid ("{0DA3251C-D69E-4A07-8462-3D94AB0ED2DD}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("SIP keep-alive messages are not allowed by the security policy")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("SIP keep-alive message detected")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_sip_block_keep_alive_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_sip_rtp_block_multicast_conns
		:AdminInfo (
			:chkpf_uid ("{6558BA04-849D-435C-A50D-99D86685F359}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value (" ")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Attempt to open SIP multicast data connection detected")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_sip_rtp_block_multicast_conns_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_mgcp_blk_unrec_err
		:AdminInfo (
			:chkpf_uid ("{874B8A55-1520-4400-9333-B1131009028C}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Firewall cannot process this packet in the normal VoIP flow")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Unrecoverable MGCP inspection error occurred")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_mgcp_blk_unrec_err_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_mgcp_blk_fax
		:AdminInfo (
			:chkpf_uid ("{D6BAF4B8-8824-4A8C-BD1E-40580E1312EC}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("MGCP Fax is not allowed by the security policy")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Attempt to open Fax connection detected")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_mgcp_blk_fax_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_mgcp_media_admission_control
		:AdminInfo (
			:chkpf_uid ("{49E4CD6C-3FB3-4DAB-83D3-EF0EEFE98725}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value (" ")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Media admission control violation")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_mgcp_media_admission_control_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_mgcp_rtp_block_multicast_conns
		:AdminInfo (
			:chkpf_uid ("{5573B4E6-FCA5-431C-BF8F-4A997E5F4FE3}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value (" ")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Attempt to open MGCP multicast data connection detected")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_mgcp_rtp_block_multicast_conns_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_h323_blk_unrec_err
		:AdminInfo (
			:chkpf_uid ("{4627DB5F-41EF-4D04-B21B-FCC35DED8A4E}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value (" ")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Unrecoverable H.323 inspection error occurred")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_h323_blk_unrec_err_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_h323_illegal_asn1
		:AdminInfo (
			:chkpf_uid ("{50ED7CEE-1A66-43A4-B74B-A5D0AB4C8AE6}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("ASN.1 encoding in message is illegal")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Illegal ASN.1 encoding detected")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_h323_illegal_asn1_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_h323_state_machine
		:AdminInfo (
			:chkpf_uid ("{CD239F7A-2D26-4C8B-88B1-9C599B33B23E}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("May be one of the following options: 1) Confirm to unknown request 2) Received Unregistration Request without prior registration")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("H.323 state violation")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_h323_state_machine_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_h323_verify_content
		:AdminInfo (
			:chkpf_uid ("{49DDA760-06C6-45B4-A834-0137822364BE}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("May be one of the following options: 1) No requestSeqNum field found 2) No rasAddress field found 3) No callSignalAddress field found 4) No destCallSignalAddress field found 5) No replyAddress field found 6) No answerCall field found 7) No dialedDigits field found")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("H.323 message content fault detected")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_h323_verify_content_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_h323_without_setup
		:AdminInfo (
			:chkpf_uid ("{BBF62F1C-B500-4C51-8C68-CBBB42C3DA94}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("H.225 session is not initialized with a Setup message")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Attempt to open session that does not start with a Setup message detected")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_h323_without_setup_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_h323_block_h245_tunn
		:AdminInfo (
			:chkpf_uid ("{0BB29293-DFFD-4624-B183-C704CF1924F0}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("H.245 tunneling is not allowed by the security policy")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("H.245 Tunneling detected")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_h323_block_h245_tunn_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_h323_dyn_open_t120
		:AdminInfo (
			:chkpf_uid ("{4D16AA83-4C53-4EF8-B80B-413D6CEA6C19}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("T.120 connections are not allowed, T.120 connections will not be dynamically opened")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("T.120 from H.323 detected")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_h323_dyn_open_t120_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_h323_media_admission_control
		:AdminInfo (
			:chkpf_uid ("{24413888-EDDD-4CAA-BC96-DA98984BF2AA}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value (" ")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Media admission control violation")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_h323_media_admission_control_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_h323_rtp_block_multicast_conns
		:AdminInfo (
			:chkpf_uid ("{F8B19DEF-B769-46AE-BC83-09D7416A41C6}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value (" ")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Attempt to open H.323 multicast data connection detected")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_h323_rtp_block_multicast_conns_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_sccp_state_machine
		:AdminInfo (
			:chkpf_uid ("{B5699193-0439-4727-BCCC-1321D5C00CFE}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("May be one of the following options: 1) CallStateMessage is out of state 2) OpenReceiveChannel is out of state 3) OpenReceiveChannelAck is out of state 4) StartMediaTransmission is out of state 5) RegisterMessage is out of state 6) RegisterAckMessage is out of state 7) IpPortMessage is out of state")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("SCCP state violation")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_sccp_state_machine_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_sccp_verify_hdr
		:AdminInfo (
			:chkpf_uid ("{C9F3B60F-D43D-44A9-96E0-0839E4C2D343}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("May be one of the following options: 1) Malformed SCCP datagram 2) Invalid field in packet. (For example: 'Calling Party' or 'Called Party' or 'Line Dir Number' or 'DeviceName' or 'Reserved' or 'Msg ID' or 'Call Type' or 'Call ID' or 'Codec' or 'Port' or 'IP')")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("SCCP header content fault detected")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_sccp_verify_hdr_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_sccp_blk_unrec_err
		:AdminInfo (
			:chkpf_uid ("{3C77D12C-8B88-4EE2-AB41-3FEA19E71036}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Firewall cannot process this packet in the normal VoIP flow")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Unrecoverable SCCP inspection error occurred")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_sccp_blk_unrec_err_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_sccp_blk_unknown_msgs
		:AdminInfo (
			:chkpf_uid ("{CFC035FD-0A4A-4C99-96F2-CFECB94466C0}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("SCCP - message type unknown")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Unknown SCCP Message")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_sccp_blk_unknown_msgs_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_sccp_media_admission_control
		:AdminInfo (
			:chkpf_uid ("{A15B2112-537A-431D-B7DF-69C2416E93D9}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value (" ")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Media admission control violation")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_sccp_media_admission_control_log")
		:type (inspect_log)
		:unify (false)
	)
	: (dynlog_sccp_rtp_block_multicast_conns
		:AdminInfo (
			:chkpf_uid ("{EE8A6092-1A2D-4F58-B1A7-AFD9292B7007}")
			:ClassName (inspect_log)
			:table (inspect_logs)
		)
		:advanced_dynamic_format (-1)
		:formats (
			: (format1
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param1
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value (" ")
					)
				)
				:excessive_report (true)
				:id (82)
				:type (inspect_logs_formats)
			)
			: (format2
				:AdminInfo (
					:ClassName (inspect_logs_formats)
				)
				:ver_1 (
					: (param2
						:AdminInfo (
							:ClassName (inspect_logs_format_params)
						)
						:param_type (string_id)
						:type (inspect_logs_format_params)
						:value ("Attempt to open SCCP multicast data connection detected")
					)
				)
				:excessive_report (true)
				:id (83)
				:type (inspect_logs_formats)
			)
		)
		:kernel_resolved_str_mask (0)
		:alert (log)
		:dynamic_format (-1)
		:enable_excessive (true)
		:enable_excessive_report (true)
		:excessive_conn_mask (13)
		:flags (0)
		:location ("kernel_props_by_type:string_props:enable_sccp_rtp_block_multicast_conns_log")
		:type (inspect_log)
		:unify (false)
	)
)

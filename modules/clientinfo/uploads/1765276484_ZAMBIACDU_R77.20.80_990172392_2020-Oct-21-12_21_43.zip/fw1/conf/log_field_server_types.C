(
	:version (6.0)
	: (estring
		:AdminInfo (
			:chkpf_uid ("{04E2630D-6721-4C91-9086-E27C73A11132}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu Mar 02 10:12:21 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (estring)
		:filter_CLSID ("{7ECC80B0-0282-4620-8A8E-633BE7EFA0C7}")
		:resolver_CLSID ("{E461D14D-EA1A-49AF-A715-4B894E4142A9}")
	)
	: (xmethod
		:AdminInfo (
			:chkpf_uid ("{95109BFE-7774-4780-A463-81EE803BA396}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu Mar 02 10:12:56 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (xmethod)
		:filter_CLSID ("{4227D8E0-7B67-4C0F-AD64-87914470563D}")
		:resolver_CLSID ("{DCCD7E5D-EF45-4DF7-B952-80EAA6FA9A97}")
	)
	: (timestmp
		:AdminInfo (
			:chkpf_uid ("{30AC2230-69B0-4F99-874C-0BE46C1AAA07}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu Mar 02 10:13:45 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (timestmp)
		:filter_CLSID ("{7ECC80B0-0282-4620-8A8E-633BE7EFA0C7}")
		:resolver_CLSID ("{A401855D-6595-4714-B28E-94AC6AE48833}")
	)
	: (rule
		:AdminInfo (
			:chkpf_uid ("{65215788-6518-4733-A878-E0573F873F48}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu Mar 02 10:14:55 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (rule)
		:filter_CLSID ("{4227D8E0-7B67-4C0F-AD64-87914470563D}")
		:resolver_CLSID ("{DCCD7E5D-EF45-4DF7-B952-80EAA6FA9A97}")
	)
	: (reasoncode
		:AdminInfo (
			:chkpf_uid ("{F26E6E02-DA52-4B64-AFE2-9697665E2849}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu Mar 02 10:16:11 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (reasoncode)
		:filter_CLSID ("{7ECC80B0-0282-4620-8A8E-633BE7EFA0C7}")
		:resolver_CLSID ("{B6ECDEEF-C674-4CFA-BF5B-E50A1DEF83D1}")
	)
	: (mask
		:AdminInfo (
			:chkpf_uid ("{85697092-C651-4C9D-B1F7-C549D6EDCD02}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu Mar 02 10:37:33 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (mask)
		:filter_CLSID ("{7ECC80B0-0282-4620-8A8E-633BE7EFA0C7}")
		:resolver_CLSID ("{58336C22-23D6-4EFC-9D3E-E7C599A6D72A}")
	)
	: (uuid
		:AdminInfo (
			:chkpf_uid ("{91878CF4-C005-4D93-BFB6-2F2FBCFE2E8F}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu Mar 02 11:54:54 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (uuid)
		:filter_CLSID ("{7ECC80B0-0282-4620-8A8E-633BE7EFA0C7}")
		:resolver_CLSID ("{58336C22-23D6-4EFC-9D3E-E7C599A6D72A}")
	)
	: (string_id
		:AdminInfo (
			:chkpf_uid ("{FD284077-FB53-4F48-B332-9AB56F5C90AE}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu Mar 02 11:55:26 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (string_id)
		:filter_CLSID ("{6D76067E-7BB7-4D31-A0DF-22D468475B58}")
		:resolver_CLSID ("{82890EF6-D76E-4270-AF70-168D52288413}")
	)
	: (int64
		:AdminInfo (
			:chkpf_uid ("{432ECDD0-FA8C-48E8-BE38-44666943EE06}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu Mar 02 11:56:00 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (int64)
		:filter_CLSID ("{CB1C3199-64E8-4EFC-AB48-5F01C8E2F915}")
		:resolver_CLSID ("{312ECFF1-9476-462F-AB48-73966B826127}")
	)
	: (uint64
		:AdminInfo (
			:chkpf_uid ("{755E4FAC-3036-4B6D-8EA6-99702EA1611D}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu Mar 02 11:56:34 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (uint64)
		:filter_CLSID ("{CB1C3199-64E8-4EFC-AB48-5F01C8E2F915}")
		:resolver_CLSID ("{93376125-6703-4D87-92E9-B045FBDE49BF}")
	)
	: (guid
		:AdminInfo (
			:chkpf_uid ("{2F237A9A-44B3-459B-B3AD-B2C384E1899B}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu Mar 02 11:56:58 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (guid)
		:filter_CLSID ("{7ECC80B0-0282-4620-8A8E-633BE7EFA0C7}")
		:resolver_CLSID ("{65B3C7C0-CC42-4C46-B98D-A3E549B6126D}")
	)
	: (luuid
		:AdminInfo (
			:chkpf_uid ("{3B08D5EE-F647-45F4-B746-09122A8624A1}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu Mar 02 11:58:18 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (luuid)
		:filter_CLSID ("{7ECC80B0-0282-4620-8A8E-633BE7EFA0C7}")
		:resolver_CLSID ("{11BDFE41-F108-4A94-BE77-16B8BDC4A7EA}")
	)
	: (actioncode
		:AdminInfo (
			:chkpf_uid ("{9DA04A60-E263-4171-A889-A620A167C130}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu Mar 02 11:58:35 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (actioncode)
		:filter_CLSID ("{D8DCEAC4-F0BF-469F-A628-95B92120D4FB}")
		:resolver_CLSID ("{A579B247-BE0E-444D-8AE5-B51D3A9EC711}")
	)
	: (ifdircode
		:AdminInfo (
			:chkpf_uid ("{1C60F626-5A79-4C37-AA89-B42E590A0E4A}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu Mar 02 11:59:02 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (ifdircode)
		:filter_CLSID ("{7ECC80B0-0282-4620-8A8E-633BE7EFA0C7}")
		:resolver_CLSID ("{32BFB4BB-8C01-426C-95BB-E2DDA38745B1}")
	)
	: (macaddr
		:AdminInfo (
			:chkpf_uid ("{380DD84F-9879-4C91-A60C-262E3303E61C}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu Mar 02 11:59:30 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (macaddr)
		:filter_CLSID ("{4D67BCED-F8CD-41A3-B3F6-D67735E5FD3F}")
		:resolver_CLSID ("{9BFF7568-4175-4182-AAE5-0B594CBA4704}")
	)
	: (time
		:AdminInfo (
			:chkpf_uid ("{7909CC04-892B-4520-A6A4-DC9CDEBD8465}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu Mar 02 11:59:56 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (time)
		:filter_CLSID ("{E24DB534-42A1-4533-9B9C-3D6DF1849ED9}")
		:resolver_CLSID ("{D57ABA5B-7F42-40CE-85A2-C38E506D854D}")
	)
	: (normalized_rule_num
		:AdminInfo (
			:chkpf_uid ("{6E36C7F7-B948-4992-A152-FFAB6E12DBFA}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu Mar 02 12:00:51 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (normalized_rule_num)
		:filter_CLSID ("{343FA492-4C33-48CB-B030-26770AE614AE}")
		:resolver_CLSID ("{F0DACE01-23D2-46CA-B84F-2A1D10AEBC5E}")
	)
	: (Origin
		:AdminInfo (
			:chkpf_uid ("{960B2585-5477-4EE8-A59E-5B1B37B5D237}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu Mar 02 12:01:24 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (Origin)
		:filter_CLSID ("{DCAF400D-5D9E-47E9-9A65-11334018E798}")
		:resolver_CLSID ("{75E193BA-0886-44A2-920E-BBAFEE80D93F}")
	)
	: (type
		:AdminInfo (
			:chkpf_uid ("{23A03F3C-475D-4617-A1D6-FE3E158EFE35}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu Mar 02 12:01:48 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (type)
		:filter_CLSID ("{47C4364F-B9E1-41F6-8D0E-7BF488C79677}")
		:resolver_CLSID ("{79E042D5-A56B-4AFC-B368-B51481131BB4}")
	)
	: (Date_type
		:AdminInfo (
			:chkpf_uid ("{C34D93BA-5AA6-4DEA-8F21-0571BC614F1D}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu Mar 02 12:04:07 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (Date)
		:filter_CLSID ("{F63DEDD0-5697-4E89-B86E-BDC94E040C12}")
		:resolver_CLSID ("{D3912C39-01BB-46C0-A66F-70A7FC86776A}")
	)
	: (Hour
		:AdminInfo (
			:chkpf_uid ("{FBC8FE6F-B338-4F49-8ED3-C2C061931E4A}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu Mar 02 12:04:36 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (Hour)
		:filter_CLSID ("{0E8DCD23-DDFE-439F-A448-59498FF13AE9}")
		:resolver_CLSID ("{E3E52C32-49F3-44A9-B934-52FB8FCA5273}")
	)
	: (ProductName
		:AdminInfo (
			:chkpf_uid ("{1A8994C5-1A16-4CDC-9653-AB2E0881909D}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu Mar 02 12:04:58 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (ProductName)
		:filter_CLSID ("{5F0645C4-E31D-4C6C-B8F7-3410A0E96A42}")
		:resolver_CLSID ("{D8814EA0-525F-4492-93C4-E137234292CD}")
	)
	: (mixedstrandid
		:AdminInfo (
			:chkpf_uid ("{B179E0DD-5E2F-4FDF-AA30-E51F52C42430}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu Mar 02 12:05:17 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (mixedstrandid)
		:filter_CLSID ("{E2C6C256-0350-4288-AF64-7D5D5314A8A8}")
		:resolver_CLSID ("{1C17B4BE-A1F6-44c6-BC71-1F78F9C75D45}")
	)
	: (UfpCategory
		:AdminInfo (
			:chkpf_uid ("{9A8EB15F-DBDE-40C3-8499-8D003A686F55}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu Mar 02 12:05:37 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (UfpCategory)
		:filter_CLSID ("{7ECC80B0-0282-4620-8A8E-633BE7EFA0C7}")
		:resolver_CLSID ("{AA7079B3-7266-4E81-891F-AB96F00E0EF8}")
	)
	: (DCE_RPC_Interface_UID
		:AdminInfo (
			:chkpf_uid ("{9F7C4CEF-3533-4E56-AD38-B2B39FB9542B}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu Mar 02 12:06:26 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type ("DCE-RPC Interface UID")
		:filter_CLSID ("{7ECC80B0-0282-4620-8A8E-633BE7EFA0C7}")
		:resolver_CLSID ("{09F101C9-54BA-4742-869B-4E875C8EE227}")
	)
	: (HeaderDateHour
		:AdminInfo (
			:chkpf_uid ("{04FC15CC-C956-409F-A425-DBFC0A89D1C5}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu Mar 02 12:06:47 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (HeaderDateHour)
		:filter_CLSID ("{7ECC80B0-0282-4620-8A8E-633BE7EFA0C7}")
		:resolver_CLSID ("{6CE1ECB5-36E2-4A2B-A981-386F3E52687A}")
	)
	: (Interface_type
		:AdminInfo (
			:chkpf_uid ("{73716DB6-8A96-4D5F-A312-B38E12818274}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu Mar 02 12:07:16 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (Interface)
		:filter_CLSID ("{CA6A2922-8FAE-4103-BC86-F98E49B8CB3F}")
		:resolver_CLSID ("{FFBAEF8A-A2ED-4BF1-8445-D00AB6E6CAAB}")
	)
	: (hex
		:AdminInfo (
			:chkpf_uid ("{D0900A0C-37E0-4DCA-A24F-D59EEBA9AE75}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu Mar 02 13:37:05 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (hex)
		:filter_CLSID ("{7ECC80B0-0282-4620-8A8E-633BE7EFA0C7}")
		:resolver_CLSID ("{58336C22-23D6-4EFC-9D3E-E7C599A6D72A}")
	)
	: (ipaddr
		:AdminInfo (
			:chkpf_uid ("{7659019C-4DFE-4D8C-B5E0-0B3590E4047E}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu Mar 02 13:38:07 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (ipaddr)
		:filter_CLSID ("{109BB198-697C-465B-B599-387CA47462B5}")
		:resolver_CLSID ("{D7FBBCFA-61C3-40BF-B528-C9E0BAFFF947}")
	)
	: (ipv6addr
		:AdminInfo (
			:chkpf_uid ("{E14BC9EA-DC1E-4D89-BC5C-BC8ABDDE8EE9}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu Mar 02 13:38:27 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (ipv6addr)
		:filter_CLSID ("{7ECC80B0-0282-4620-8A8E-633BE7EFA0C7}")
		:resolver_CLSID ("{CF75CF70-336A-4D9F-932F-2B98B3E896B5}")
	)
	: (port
		:AdminInfo (
			:chkpf_uid ("{19882316-BC4C-4BD0-BDE3-C8512915EDA8}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu Mar 02 13:39:01 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (port)
		:filter_CLSID ("{4227D8E0-7B67-4C0F-AD64-87914470563D}")
		:resolver_CLSID ("{DCCD7E5D-EF45-4DF7-B952-80EAA6FA9A97}")
	)
	: (proto
		:AdminInfo (
			:chkpf_uid ("{DE854063-BF6C-4738-A7CB-96638875F976}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu Mar 02 13:39:25 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (proto)
		:filter_CLSID ("{872F9CB3-7111-435D-9186-971BDD7962CA}")
		:resolver_CLSID ("{1162A954-D62F-484D-9179-943F917A5446}")
	)
	: (service
		:AdminInfo (
			:chkpf_uid ("{8435A6DC-95D9-4C8A-ACE1-9FD6EB2BDE0B}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu Mar 02 13:39:59 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (service)
		:filter_CLSID ("{4227D8E0-7B67-4C0F-AD64-87914470563D}")
		:resolver_CLSID ("{DCCD7E5D-EF45-4DF7-B952-80EAA6FA9A97}")
	)
	: (string
		:AdminInfo (
			:chkpf_uid ("{4156E437-06A5-4D83-863A-EAAF69873CD7}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu Mar 02 13:40:25 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (string)
		:filter_CLSID ("{7B23A49B-AD82-451E-8ACE-62EA0E73BDFC}")
		:resolver_CLSID ("{E461D14D-EA1A-49AF-A715-4B894E4142A9}")
	)
	: (svc
		:AdminInfo (
			:chkpf_uid ("{DD9801D9-4834-4C1F-81E2-529EEA2781DF}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu Mar 02 13:40:54 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (svc)
		:filter_CLSID ("{BEC6657A-6D2C-477F-900B-90400C97BDE2}")
		:resolver_CLSID ("{6BC55CF9-DD55-4BD1-B6D2-49BBD099357F}")
	)
	: (uint
		:AdminInfo (
			:chkpf_uid ("{7093FEB8-CEB3-4D12-95B7-725D76375FAC}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu Mar 02 13:41:31 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (uint)
		:filter_CLSID ("{4227D8E0-7B67-4C0F-AD64-87914470563D}")
		:resolver_CLSID ("{2EE9B19B-4F8B-4AD2-82FE-19912370ADA7}")
	)
	: (int
		:AdminInfo (
			:chkpf_uid ("{91694BE7-D52D-474E-A565-635734A73B22}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu Mar 02 13:42:26 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (int)
		:filter_CLSID ("{4227D8E0-7B67-4C0F-AD64-87914470563D}")
		:resolver_CLSID ("{DCCD7E5D-EF45-4DF7-B952-80EAA6FA9A97}")
	)
	: (OriginSicName
		:AdminInfo (
			:chkpf_uid ("{68A0EE25-DD41-40B5-904A-951CCE0D53DD}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Wed Mar 08 12:24:56 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (OriginSicName)
		:filter_CLSID ("{7ECC80B0-0282-4620-8A8E-633BE7EFA0C7}")
		:resolver_CLSID ("{C0A62273-3655-4C50-8D63-72BD6357743E}")
	)
	: (FollowUp
		:AdminInfo (
			:chkpf_uid ("{18A0EE35-D141-45B5-954A-951CCE0D53DD}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Wed Mar 08 12:24:56 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (FollowUp)
		:filter_CLSID ("{458233CB-F13A-4d6b-8F31-AFD1ECC40C71}")
		:resolver_CLSID ("{675CD6A0-7150-410f-8843-F2F2D129CB73}")
	)
	: (obf_str
		:AdminInfo (
			:chkpf_uid ("{D4F84DB4-6EE6-11DE-9EF8-0AE055D89593}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu Jul 12 13:40:25 2009")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (obf_str)
		:filter_CLSID ("{7B23A49B-AD82-451E-8ACE-62EA0E73BDFC}")
		:resolver_CLSID ("{E461D14D-EA1A-49AF-A715-4B894E4142A9}")
	)
	: (obf_string_id
		:AdminInfo (
			:chkpf_uid ("{9E5C40C7-3139-455C-A9D5-2E998805673F}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu May 27 13:31:39 IDT 2010")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (obf_string_id)
		:filter_CLSID ("{7870BCA6-3C59-4333-903E-2AD524CF51BF}")
		:resolver_CLSID ("{82890EF6-D76E-4270-AF70-168D52288413}")
	)
	: (mixedobfstrandid
		:AdminInfo (
			:chkpf_uid ("{4DEE2C65-B31D-4fdf-B22C-43E547D2B2E8}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu May 27 13:31:39 IDT 2010")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (mixedobfstrandid)
		:filter_CLSID ("{F03C8636-9162-4601-BC9C-4263EBF430A3}")
		:resolver_CLSID ("{3B1D4CEC-4352-47a1-9E89-89E1DD47DBFC}")
	)
	: (ProductFamily
		:AdminInfo (
			:chkpf_uid ("{22703250-5703-4BB8-B478-5E403AADE91D}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Wed Dec 08 09:09:03 2010")
				:By (CheckPoint)
				:From (CheckPoint)
			)
			:icon (Unknown)
		)
		:field_type (ProductFamily)
		:filter_CLSID ("{6D76067E-7BB7-4D31-A0DF-22D468475B58}")
		:resolver_CLSID ("{82890EF6-D76E-4270-AF70-168D52288413}")
	)
	: (timestmp_local
		:AdminInfo (
			:chkpf_uid ("{63EB0125-73BB-4653-8BE8-1084250A0067}")
			:ClassName (field_server_type_definition_object)
			:table (log_field_server_types)
			:LastModified (
				:Time ("Thu Mar 02 10:13:45 2006")
				:By (CheckPoint)
				:From (CheckPoint)
			)
		)
		:field_type (timestmp_local)
		:filter_CLSID ("{7ECC80B0-0282-4620-8A8E-633BE7EFA0C7}")
		:resolver_CLSID ("{93041F50-6636-4913-9A5B-B3274B077097}")
	)
)

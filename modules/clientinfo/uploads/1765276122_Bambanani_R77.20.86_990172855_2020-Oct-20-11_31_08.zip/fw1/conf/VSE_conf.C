(VSE_CONF
	: (producers
		: (
			:producer (ida_userspace)
			:server ("fw,5435,0x3b32dc8")
			:timestamp (1558393576)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4978,0x3b32dc8")
			:timestamp (1558802294)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,5008,0x3b32dc8")
			:timestamp (1565602259)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4969,0x3b32dc8")
			:timestamp (1567065314)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4989,0x3b32dc8")
			:timestamp (1568818584)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4984,0x3b32dc8")
			:timestamp (1568819025)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4974,0x3b32dc8")
			:timestamp (1570423064)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4869,0x3b32dc8")
			:timestamp (1571222472)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4975,0x3b32dc8")
			:timestamp (1571494461)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,31815,0x3b315b0")
			:timestamp (1572061553)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,16454,0x3b315b0")
			:timestamp (1572624457)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,5047,0x3b315b0")
			:timestamp (1573182860)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,21252,0x3b315b0")
			:timestamp (1573747268)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,6260,0x3b315b0")
			:timestamp (1574307791)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,18934,0x3b315b0")
			:timestamp (1574871923)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,3825,0x3b315b0")
			:timestamp (1575445971)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4963,0x3b32dc8")
			:timestamp (1575589167)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4964,0x3b32dc8")
			:timestamp (1575868479)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,12864,0x3b315b0")
			:timestamp (1576897022)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,17026,0x3b315b0")
			:timestamp (1577717913)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4968,0x3b32dc8")
			:timestamp (1578259101)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,20056,0x3b315b0")
			:timestamp (1579358867)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,12789,0x3b315b0")
			:timestamp (1580178009)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4978,0x3b32dc0")
			:timestamp (1580702347)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4962,0x3b32dc0")
			:timestamp (1580769231)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4974,0x3b32dc0")
			:timestamp (1580941447)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4963,0x3b32dc0")
			:timestamp (1581002224)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4964,0x3b32dc0")
			:timestamp (1581173042)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4966,0x3b32dc0")
			:timestamp (1581849001)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4970,0x3b32dc0")
			:timestamp (1582353538)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4965,0x3b32dc0")
			:timestamp (1583951279)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4983,0x3b32dc0")
			:timestamp (1584008667)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4973,0x3b32dc0")
			:timestamp (1584182097)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,12713,0x3b315a8")
			:timestamp (1585695654)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,22839,0x3b315a8")
			:timestamp (1587251260)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,1701,0x3b315a8")
			:timestamp (1588798041)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4321,0x3b315a8")
			:timestamp (1590348339)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,9570,0x3b315a8")
			:timestamp (1592867113)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,19832,0x3b315a8")
			:timestamp (1594449839)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4969,0x3b32dc0")
			:timestamp (1594666807)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4989,0x3b32dc0")
			:timestamp (1596497521)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4893,0x3b32dc0")
			:timestamp (1597343261)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4913,0x3b32dc0")
			:timestamp (1597781500)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4923,0x3b32dc0")
			:timestamp (1597999362)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4922,0x3b32dc0")
			:timestamp (1597999900)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4914,0x3b32dc0")
			:timestamp (1598095960)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4908,0x3b32dc0")
			:timestamp (1598593000)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4899,0x3b32dc0")
			:timestamp (1598625040)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4903,0x3b32dc0")
			:timestamp (1598627260)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4909,0x3b32dc0")
			:timestamp (1598628521)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4898,0x3b32dc0")
			:timestamp (1598696082)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4902,0x3b32dc0")
			:timestamp (1598884600)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4933,0x3b32dc0")
			:timestamp (1599163303)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4888,0x3b32dc0")
			:timestamp (1599401621)
		)
		: (
			:producer (ida_userspace)
			:server ("fw,4788,0x3b32dc0")
			:timestamp (1601211692)
		)
	)
)
